# Desktop Pet → AI Productivity Companion
## Architecture & Migration Plan

> **Purpose of this document.** This is the foundation for evolving the existing offline Electron pet into a companion that also coaches focus, wellness, learning, and presentations — *without* discarding anything that already works, and without ever requiring the network. It covers deliverables 1–9 from the product brief (architecture, folder structure, data models, wireframes, roadmap, performance, testing, migration, risk). Production code is delivered afterward, one working slice at a time.

---

## 0. Guiding principles

1. **Additive, never destructive.** Every existing module (`PetState`, `MoodEngine`, `Behavior`, `Pet`, `Animator`, `sprites`, `Store`, `Settings`, achievements, UI panels, tray) stays. New capability is added *beside* it through a uniform extension point, not by rewriting the core.
2. **Offline-first, network-optional.** The app must run perfectly with zero connectivity forever. Anything that *could* use a network (the future AI layer) is an optional provider behind an interface, defaulting to a local implementation. This is not a nice-to-have — your environment already proved the network is hostile.
3. **One pattern, many features.** Coding-buddy, hydration, stretch, eye-breaks, learning, and presentation are all variations of the same shape: *track state over time → maybe nudge → keep streaks → show a dashboard*. We build that shape **once** (the `System` interface + the shared `NudgeEngine`) and express each feature as a thin instance of it. This is what keeps 12 features from becoming 12 tangled codebases.
4. **Privacy by construction.** Context awareness is inferred only from coarse signals the OS already exposes (idle time, window focus, the clock). No screenshots, no keylogging, no content inspection, no cloud. This is enforced by *not building* those capabilities, not by policy.
5. **Charm over nagging.** A companion that nags gets closed within a day. A global attention budget (Section 6) guarantees the pet can never exceed N interruptions per hour regardless of how many systems want to speak.
6. **Ship vertical slices.** Each roadmap phase produces something runnable and useful on its own. We never have a six-week branch that doesn't launch.

---

## 1. Target architecture (layers)

The current app is essentially "renderer does everything, main owns the window and disk." That's fine for one simulation but will collapse under a dozen stateful subsystems. We introduce **four clean layers inside the renderer**, plus modest additions to main.

```
┌─────────────────────────────────────────────────────────────┐
│ MAIN PROCESS (Node / CommonJS)                                │
│  existing: window, tray, autolaunch, Store (atomic JSON)      │
│  NEW: ContextMonitor (idle/focus/power) · NudgeScheduler      │
│       (OS notifications that survive window-hidden)           │
└───────────────▲───────────────────────────────┬──────────────┘
                │  IPC (preload → window.petAPI) │
┌───────────────┴───────────────────────────────▼──────────────┐
│ RENDERER — CORE                                               │
│  EventBus · SystemRegistry · Clock · StateHub (one save model)│
├───────────────────────────────────────────────────────────────┤
│ RENDERER — SYSTEMS  (each implements the System interface)    │
│  PetSystem(wraps existing pet) · CodingBuddy · Hydration ·    │
│  Movement(stretch/posture/eye) · Tasks · Learning ·           │
│  Presentation · Relationship · Analytics · …plugins           │
├───────────────────────────────────────────────────────────────┤
│ RENDERER — SHARED SERVICES                                    │
│  NudgeEngine (attention budget) · DialogueService ·           │
│  AchievementService · AIProvider (Null default) · ChartKit    │
├───────────────────────────────────────────────────────────────┤
│ RENDERER — UI SHELL                                           │
│  CompanionDeck (tabbed dashboard) · existing panels · toasts  │
│  · canvas stage (the pet)                                     │
└───────────────────────────────────────────────────────────────┘
```

**Why an EventBus + SystemRegistry?** Today `renderer.js` hand-wires every object to every other. Add ten systems and that file becomes unmaintainable. With a bus, the CodingBuddy emits `focus:milestone`; the PetSystem reacts with a celebration animation, the Relationship system bumps trust, Analytics logs it, and the DialogueService maybe speaks — none of them know about each other. New systems subscribe to events that already exist and emit their own.

---

## 2. The `System` interface (the spine)

Every feature — existing or new, core or plugin — implements one small contract. This is the single most important design decision in the upgrade.

```js
/**
 * A System owns one slice of companion state and behaviour.
 * Lifecycle is managed by SystemRegistry; communication is via the EventBus.
 */
export class System {
  static id = 'unique-id';          // e.g. 'coding', 'hydration'
  static schemaVersion = 1;          // for this system's own save slice

  constructor(ctx) {
    // ctx = { bus, clock, state, nudges, dialogue, ai, settings }
  }

  init() {}                          // subscribe to bus events, set up timers
  tick(dt, now) {}                   // called from the main loop (throttled)
  onContext(signal) {}               // idle/focus/time-of-day changes
  serialize() { return {}; }         // its slice of the save file
  hydrate(data) {}                   // restore from save
  views() { return []; }             // dashboard tab descriptors (optional)
  dispose() {}                       // remove listeners/timers cleanly
}
```

- **`init` / `dispose`** make memory-leak safety structural: the registry calls `dispose()` and every listener/timer the system created is gone. (The current app already removes listeners on quit; this generalizes it.)
- **`serialize` / `hydrate`** mean each system owns its own save slice under its `id`. No more god-object save shape.
- **`views`** lets a system contribute a dashboard tab declaratively, so the UI shell doesn't hard-code knowledge of every feature.

A **`TimedHabitSystem extends System`** base class captures the shared "reminder + streak + daily goal + dashboard" pattern, so Hydration, Movement, EyeBreaks, and Learning are ~40 lines each instead of ~300.

---

## 3. Folder structure (extends what exists)

Existing paths are kept; new directories slot in. Nothing moves in Phase 0 except by re-export shims, so imports never break mid-migration.

```
desktop-pet/
├─ src/
│  ├─ main/                    # EXISTING + additions
│  │   ├─ main.js · preload.js · tray.js · autolaunch.js
│  │   ├─ ContextMonitor.js    # NEW: powerMonitor idle, focus, clock ticks
│  │   └─ NudgeScheduler.js    # NEW: OS notifications when window hidden
│  ├─ storage/                 # EXISTING store.js + schema.js (extended)
│  ├─ core/                    # NEW
│  │   ├─ EventBus.js · SystemRegistry.js · Clock.js · StateHub.js
│  ├─ systems/                 # NEW — one folder per feature
│  │   ├─ System.js · TimedHabitSystem.js   # base classes
│  │   ├─ pet/PetSystem.js     # thin wrapper over existing Pet/PetState
│  │   ├─ coding/              # CodingBuddy, Pomodoro, sessions, streaks
│  │   ├─ hydration/ · movement/ · tasks/ · learning/ · presentation/
│  │   ├─ relationship/        # trust/friendship, dialogue gating
│  │   └─ analytics/           # event log + rollups
│  ├─ services/                # NEW
│  │   ├─ NudgeEngine.js · DialogueService.js · AchievementService.js
│  │   ├─ ChartKit.js          # tiny canvas charts (no heavy dep)
│  │   └─ ai/  Provider.js · NullProvider.js · OllamaProvider.js (later)
│  ├─ plugins/                 # NEW — drop-in modules + loader + manifest schema
│  ├─ pet/ · animations/       # EXISTING simulation + procedural art
│  ├─ ui/                      # EXISTING panels + NEW CompanionDeck shell
│  ├─ config/constants.js      # EXISTING (extended)
│  └─ renderer/                # EXISTING entry; renderer.js shrinks to a bootstrapper
├─ tests/                      # NEW — unit + integration
├─ tools/genicons.js          # EXISTING
└─ ARCHITECTURE.md            # this file
```

---

## 4. Data models

### 4.1 Save file evolution

The current save is one object (`{ version, pet, stats, achievements, settings }`) written atomically by `Store` with `.bak` recovery, validated by `migrate()`. We keep that envelope and add a namespaced `systems` map. **The existing `pet`/`stats`/`achievements` keys are left exactly where they are** so old saves load unchanged.

```jsonc
{
  "version": 2,                    // bumped; migrate() v1→v2 just adds {} defaults
  "pet":    { /* unchanged: needs, level, xp, accessory, position */ },
  "stats":  { /* unchanged lifetime stats + lastSeen */ },
  "achievements": { /* unchanged */ },
  "settings": { /* unchanged + new toggles */ },

  "systems": {                     // NEW — each key owned by one System.id
    "relationship": { "trust": 0, "friendship": 1, "minutesTogether": 0, "careScore": 0 },
    "coding":     { "streakDays": 0, "todayFocusSec": 0, "sessions": [], "sprint": null },
    "hydration":  { "goalMl": 2000, "todayMl": 0, "streakDays": 0, "lastDrink": 0, "intervalMin": 60 },
    "movement":   { "stretch": {…}, "stand": {…}, "eye": {…} },   // sub-habits
    "tasks":      { "today": [ { "id", "text", "done", "priority" } ], "completionRate7d": 0 },
    "learning":   { "goals": [], "tech": [], "weeklyHours": 0, "streakDays": 0 },
    "presentation": { "events": [ { "title", "date", "rehearsals", "confidence" } ] }
  },

  "analytics": {                   // NEW — append-only local event log (capped/rolled)
    "events": [ { "t": 0, "type": "focus.session.end", "v": 5400 } ],
    "rollups": { "daily": { "2026-06-06": { "focusSec": 7200, "ml": 1500 } } }
  }
}
```

### 4.2 Migration mechanics

You already have the right primitive: `migrate(raw)` in `schema.js`, which never throws and clamps values. We extend it into a **stepwise migrator** — `v1→v2`, `v2→v3`, … each a pure function — so every future feature adds one small, tested step instead of editing a monolith. Unknown future keys are preserved, never dropped, so a newer save opened by an older build degrades gracefully.

### 4.3 Analytics storage

Raw events are small (`{t,type,v}`) and **rolled up daily**, then pruned (keep ~90 days of dailies, drop raw events older than 7 days). This keeps the JSON well under the size where load/parse cost matters, and keeps dashboards instant because they read rollups, not raw logs.

---

## 5. Context awareness (privacy-preserving)

Implemented in `main/ContextMonitor.js`, pushed to the renderer over IPC as discrete signals — **never raw data**.

| Signal | Source (Electron/OS) | What it is | What it is **not** |
|---|---|---|---|
| `idle` / `active` | `powerMonitor.getSystemIdleTime()` | seconds since last input | *not* what you typed or clicked |
| `focus.app` | `BrowserWindow` blur/focus + `powerMonitor` | "user is at the machine" | *not* which app, *not* window titles |
| `time.bucket` | system clock | morning / day / evening / late / weekend | — |
| `suspend`/`resume` | `powerMonitor` | laptop slept/woke | — |

"Long coding session" = *active* (low idle) for a sustained span during a focus session the user started. It's a coarse inference, deliberately. The brief's "no screenshots / no keylogging / no cloud" is satisfied because those code paths don't exist.

---

## 6. The NudgeEngine (why it never gets annoying)

Cross-cutting service. Every system that wants to interrupt you (water, stretch, eye-break, "one more bug?") does **not** speak directly — it submits a *nudge request* with a priority and category. The engine enforces:

- **Attention budget:** a token-bucket cap, e.g. ≤ 3 interruptions/hour, configurable, with a hard quiet floor (never two nudges within X minutes).
- **Adaptive backoff:** if a nudge is dismissed/ignored, that category's interval grows (e.g. 60→90→120 min); if acted on, it gently shrinks back. This is the "adaptive reminder frequency" the brief asks for, centralized.
- **Context gating:** suppress during detected deep focus unless it's a health nudge past a hard limit (e.g. eye-break at 90 min wins); never nudge while idle/away (pointless) — defer to return.
- **Do-not-disturb / Focus mode:** one switch silences non-critical categories.
- **Channel choice:** if the window is hidden, route through `NudgeScheduler` (OS notification) instead of a speech bubble.

Because all nudging funnels through here, "never spammy" is a property of the system, not a hope.

---

## 7. Personality & relationship system

Replaces the current hardcoded `LINES` object with a **DialogueService** backed by a tagged line pool, plus a **Relationship** system tracking `trust`, `friendship`, `minutesTogether`, `careScore`.

- Lines are tagged by `{ context, mood, minFriendship, tone }`. The service selects by current context + relationship level, so deeper friendship literally unlocks new dialogue (brief requirement) and the voice stays "encouraging, witty, never rude" by curating tone tags — and by never selecting rude tags.
- Friendship rises from consistent care and met goals; trust rises from the pet's advice being acted on. These gate features gently (e.g. the pet only offers to break down tasks once you've worked together a bit), which makes the companion feel earned rather than pushy on day one.
- When the AI layer (Section 9) is present, DialogueService can *optionally* ask it to phrase a line; when absent (default), it uses the templated pool. Same call site, no branching in feature code.

---

## 8. UI shell — CompanionDeck

The current Dashboard and Settings panels stay. We add a **CompanionDeck**: a single panel with tabs, where each tab is contributed by a system's `views()`. Tabs map to the brief's dashboards:

- **Pet** (existing stats/needs/accessories/achievements)
- **Coding** (focus today, streak, sessions, deep-work hours, sprint)
- **Wellness** (hydration bottle fill, movement score, break compliance)
- **Plan** (today's priorities, completion rate)
- **Growth** (learning hours, streak, tech studied, certs)
- **Stage** (presentation checklist, rehearsals, countdown, confidence)

Wireframe (single deck, tabbed, sits where panels already appear):

```
┌──────────────── Companion ───────────────[Focus][✕]┐
│ ◉Pet  ○Coding  ○Wellness  ○Plan  ○Growth  ○Stage    │
├──────────────────────────────────────────────────────┤
│  ┌─ Focus today ─┐ ┌─ Streak ─┐ ┌─ Deep work ─┐       │
│  │   02:41:00    │ │  6 days  │ │   18.5 hrs  │       │
│  └───────────────┘ └──────────┘ └─────────────┘       │
│  Weekly focus  ▁▃▅▇▆▄▂   (ChartKit canvas sparkline)   │
│  ▶ Start Pomodoro   ⏸ Focus mode   + Log task          │
└──────────────────────────────────────────────────────┘
```

Charts are drawn by a tiny **ChartKit** on canvas (bars/lines/sparklines/rings) — no heavyweight charting dependency, keeping the bundle small and offline.

---

## 9. AI abstraction layer (ready, optional, off by default)

```js
export class AIProvider {
  async available() { return false; }
  async complete(prompt, opts) { throw new Error('no provider'); }
}
export class NullProvider extends AIProvider {        // the DEFAULT
  async available() { return false; }                  // app behaves fully without AI
}
// Later, behind a setting the user must enable:
export class OllamaProvider extends AIProvider {       // talks to localhost:11434
  async available() { /* probe local Ollama */ }
  async complete(prompt) { /* local LLM, still offline */ }
}
```

- The registry injects an `ai` provider into every system; systems call `if (await ai.available()) …` and **always** have a templated fallback. So "core functions perfectly with no model installed" is guaranteed by the `NullProvider` default.
- Ollama is local (`localhost`), so even the "AI on" mode stays offline. Cloud providers (OpenAI/Claude) would be a clearly-labelled, opt-in, network-on choice added much later — and your locked-down network means local Ollama is the realistic target anyway.

---

## 10. Plugin framework

A plugin is just a `System` shipped in its own folder with a manifest:

```jsonc
// plugins/habit-tracker/plugin.json
{ "id": "habit-tracker", "name": "Habit Tracker", "version": "1.0.0",
  "entry": "index.js", "apiVersion": 1, "permissions": ["nudge", "dashboard"] }
```

- The **PluginLoader** reads manifests at startup, validates `apiVersion` and declared `permissions`, instantiates the exported `System`, and registers it. No core edits needed to add Fitness/Finance/Study/Language modules.
- Plugins receive the **same `ctx`** as core systems but filtered to their declared permissions (e.g. a plugin without `nudge` can't interrupt). This is the decoupling + clean-interface the brief wants, with a basic capability guard so a plugin can't quietly do everything.
- Documented surface: the `System` interface, the event catalog, and the `ctx` services — published as `plugins/README.md`.

---

## 11. Performance strategy (targets: <2% idle, 60 FPS active)

The current single rAF loop always runs. With more systems that's wasteful. Strategy:

- **Tiered cadence.** Render loop (rAF) runs at 60 FPS **only while something is animating or the cursor is near**; otherwise it idles to a slow heartbeat. Simulation/needs tick at 1 Hz (already the case). System `tick`s run on a coarse scheduler (most need seconds-to-minutes granularity, not frames).
- **Pause when invisible.** When the overlay is hidden, occluded, or the app is blurred and the pet is resting, drop to event-driven only — no continuous repaint. (Electron/Chromium throttles background rAF anyway; we make it explicit.)
- **Dirty-rect drawing.** The pet occupies a small area; clear/redraw only its bounding box plus the bubble, not the full-screen canvas every frame.
- **Cheap context signals.** Idle/focus polled at low frequency in main, pushed as deltas.
- **Profiling gate.** A perf harness (Section 12) records frame time and wakeups; a phase isn't "done" until idle CPU is verified low on a real machine. *Honest caveat:* exact CPU% depends on GPU/driver and can only be confirmed on your hardware, not in a headless sandbox.

---

## 12. Testing strategy

| Layer | What | Tooling | Runs in sandbox? |
|---|---|---|---|
| **Unit** | Pure logic: `PetState` decay, streak math, NudgeEngine budget, migrators, relationship curves, each system's `serialize/hydrate` | Vitest/Jest | ✅ yes |
| **Integration** | Store atomic write + `.bak` recovery; full save→load→migrate round-trip; SystemRegistry lifecycle (init/dispose leak check) | Vitest + tmp dir | ✅ yes |
| **Contract** | Every System satisfies the interface; every plugin manifest validates | schema tests | ✅ yes |
| **E2E / GUI** | Window shows, click-through, tray, panels render | Playwright-for-Electron | ⚠️ needs a real display — runs on your machine/CI, not here |

The hard truth from our build sessions: the overlay itself can't be exercised in a headless environment. So we maximize the logic that *is* testable (the vast majority of the new code is pure state machines and math) and keep GUI verification as a scripted manual checklist + optional Playwright on your side.

---

## 13. TypeScript migration (incremental, not a rewrite)

Big-bang TS conversion mid-feature-work is a classic way to stall a project. Instead:

1. Add `tsconfig.json` with `allowJs: true`, `checkJs: true`. Get type-checking on the *existing JS* via JSDoc — zero file renames, immediate value.
2. Define core types first: the `System` interface, `ctx`, the save schema, the event catalog — as `.d.ts`. These are the contracts everything leans on.
3. Convert **leaf modules** to `.ts` as you touch them (a new system is born in TS; an edited old module gets converted opportunistically).
4. Convert the core (`EventBus`, `Registry`, `StateHub`) once it's stable.
5. The CommonJS **main process** can stay JS or convert last; it's small and stable.

Net: types arrive gradually, the app stays runnable at every commit, and we never hold features hostage to the migration.

---

## 14. Implementation roadmap (vertical slices)

Each phase is independently shippable and useful. Estimated relative size in parentheses.

- **Phase 0 — Foundation (M).** EventBus, SystemRegistry, Clock, StateHub; extend `schema.js` to v2 with stepwise migrator; wrap existing pet as `PetSystem`; shrink `renderer.js` to a bootstrapper. *No user-visible change — but everything after gets easy.* Add unit + integration test harness here.
- **Phase 1 — Personality + Coding Buddy (L).** Relationship system, DialogueService, NudgeEngine; CodingBuddy with Pomodoro, focus/session tracking, coding streaks, milestone celebrations; Coding dashboard tab; ContextMonitor for idle/focus. *First real "companion" moment.*
- **Phase 2 — Wellness (M).** `TimedHabitSystem` base; Hydration (bottle-fill animation, goal, streak), Movement (stretch/stand/eye-break with mini animations), break compliance + movement score; Wellness tab. *Reuses NudgeEngine — fast because the pattern exists.*
- **Phase 3 — Planning (S–M).** Tasks (today's priorities, quick capture, daily/weekly review), completion rate, productivity streak; Plan tab.
- **Phase 4 — Growth (M).** Learning goals, skill/tech tracking, certs, interview-prep, resume reminders, weekly learning hours + streak; Growth tab.
- **Phase 5 — Presentation (S–M).** Checklist, rehearsal timer + history, countdowns, confidence tracker; Stage tab.
- **Phase 6 — Visual upgrade (L).** Breathing, smoother eased idles, expressive eyes, ear/tail motion, emotion poses; day/night themes, dynamic shadow, ambient glow, particle/weather effects; all behind the dirty-rect + tiered-cadence perf work.
- **Phase 7 — Analytics (M).** Event log + rollups + ChartKit; weekly/monthly charts, streak history, achievement progress across all dashboards.
- **Phase 8 — Plugin framework (M).** Loader, manifest schema, permission filtering, `plugins/README.md`; ship one example plugin (Habit Tracker) to prove it.
- **Phase 9 — AI layer (S to wire, M to integrate).** Provider interface + NullProvider (default) + OllamaProvider; DialogueService optional phrasing; "Enable local AI" setting, off by default.
- **Phase 10 — Hardening (ongoing).** TS migration sweeps, perf profiling on real hardware, accessibility (focusable controls, ARIA on the deck, high-contrast theme, respects reduced-motion), Playwright E2E.

Recommended build order if you want fastest payoff: **0 → 1 → 2**, then pick the dashboard you personally want most next.

---

## 15. Risk assessment

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| **Scope creep** — 12 systems at once → nothing ships | High | High | Vertical slices; Phase 0 enforces the pattern; "done = runnable + tested" gate |
| **Annoyance kills adoption** — too many nudges | High | High | Central NudgeEngine budget + adaptive backoff + DND/Focus; default to fewer, opt into more |
| **Perf regression** — many tickers, always-on rAF | Med | Med | Tiered cadence, pause-when-invisible, dirty-rect, profiling gate per phase |
| **Network hostility** (already real for you) | High | Med | Offline-first; AI is local Ollama, opt-in; no runtime fetches; build deps cached |
| **Save corruption / migration bug** | Low | High | Existing atomic write + `.bak`; stepwise pure migrators; round-trip + migration unit tests; never drop unknown keys |
| **TS migration churn** stalls features | Med | Med | `allowJs`+`checkJs` first; convert leaves opportunistically; main process last |
| **Plugin misbehavior** (perf/data) | Med | Med | Manifest `apiVersion` + permission filtering; plugins can't exceed declared capabilities |
| **Context inference feels "creepy"** | Low | Med | Coarse signals only, documented; a visible "what the pet can see" explainer in Settings builds trust |
| **GUI untestable headlessly** | Certain | Low | Maximize pure-logic coverage; manual checklist + optional Playwright on real hardware |

---

## 16. Migration plan from the current codebase

Concrete, keeps the app green at every step.

1. **Introduce core without using it.** Add `core/EventBus.js`, `SystemRegistry.js`, `Clock.js`, `StateHub.js` with tests. App still boots the old way. *(No risk.)*
2. **Bump schema to v2.** Add the `systems` + `analytics` keys with empty defaults; write the `v1→v2` migrator; add a save→load→migrate round-trip test against a real old save file. Existing keys untouched, so current saves load identically.
3. **Wrap the pet.** Create `PetSystem` that *contains* today's `Pet`/`PetState`/`Behavior`/`Animator` and exposes `tick/serialize/hydrate`. `renderer.js` now creates a `SystemRegistry`, registers `PetSystem`, and runs the loop through it. Behaviorally identical — verify by running it and seeing the same pet.
4. **Route existing speech/achievements through services.** Move the hardcoded `LINES` into `DialogueService` and the achievement checks into `AchievementService`, both as thin wrappers first (same behavior), so later systems plug into them.
5. **Land Phase 1 on top.** New systems only *add* registrations and dashboard tabs — no edits to the pet simulation. From here, each phase is "register a system, contribute a view, subscribe to events."

At no point is a working feature removed or a save format broken. If a phase misbehaves, it's one `registry.register(...)` line to disable while you fix it.

---

## Appendix A — Event catalog (initial)

`time:tick` · `context:idle` · `context:active` · `context:focus` · `context:blur` · `context:bucket` (morning/…) · `pet:interaction` (feed/play/…) · `pet:mood` · `pet:levelup` · `focus:start` · `focus:tick` · `focus:milestone` · `focus:end` · `habit:logged` (water/stretch/eye) · `habit:streak` · `task:added` · `task:done` · `relationship:changed` · `nudge:request` · `nudge:shown` · `nudge:dismissed` · `achievement:unlocked` · `plugin:loaded`.

Systems subscribe to what they need and emit their own; the bus is the only coupling.

## Appendix B — What stays exactly as-is

`main.js` window/overlay/click-through logic · `preload.js` bridge (extended, not changed) · `tray.js` · `autolaunch.js` · `Store` atomic write + recovery · `Behavior` / `MoodEngine` / `Animator` / `sprites` procedural rendering · all current needs, XP, accessories, achievements, settings. The upgrade surrounds this core; it does not replace it.
