# 🛠️ Debugging guide — when something goes wrong

You should never be stuck guessing. Here's exactly where to look, in order.

## 1. Look at the logs (start here)

The app writes a log file you can open anytime:

- **Right-click the tray icon → “Open Logs Folder.”**
- The file is `app.log` at:
  ```
  %APPDATA%\Desktop Pet\logs\app.log
  ```
- It records app starts, warnings, and any errors (from both the visible pet window and the background process). Open it in Notepad; the newest lines are at the bottom. If you report a problem, copy the last 20–30 lines.

## 2. Open the DevTools console (for the live pet window)

The pet runs in a Chromium window, so it has the same dev console as a browser.

- Add this once to see it automatically: in `src/main/main.js`, right after `win.loadFile(...)`, add `win.webContents.openDevTools({ mode: 'detach' });`
- Errors show up in red in the **Console** tab. This is the fastest way to see a crash in the pet’s logic (animation, save, systems).

## 3. Run the tests (proves the logic is healthy)

Most of the app is pure logic with automated tests — no internet needed:

```bash
npm test
```

If everything passes, a problem is almost certainly in the **visual layer** or **environment** (Electron, GPU, Windows), not the core logic. If something fails, the failing test name points right at the broken piece.

## Common problems & fixes

| Symptom | Cause | Fix |
|---|---|---|
| `'electron' is not recognized` | `npm install` didn’t finish | Run `npm install` again (see README) |
| `Electron failed to install correctly` | The big Electron binary download was blocked/dropped | Use a phone hotspot, or the manual download in the README |
| Pet window is a **black box** | GPU compositing quirk | Already mitigated (`disableHardwareAcceleration()` in `main.js`); persists only on some old drivers |
| Pet doesn’t appear but no error | Window hidden | Tray icon → **Show / Hide Pet** |
| Want to start fresh | Corrupt or unwanted save | Quit, delete `%APPDATA%\Desktop Pet\save\pet-save.json`, relaunch |
| Reminders feel off | — | They’re rate-limited on purpose (the NudgeEngine); adjust base intervals in the system files |

## Where things live (so you know which file to open)

- **The dog’s looks** → `src/animations/sprites.js` (and poses in `Animator.js`)
- **Celebrations/confetti** → `src/ui/Celebration.js`
- **Focus sprints / coding streak** → `src/systems/coding/CodingSystem.js`
- **Anki reminder + streak** → `src/systems/habits/AnkiSystem.js`
- **How often it’s allowed to remind you** → `src/services/NudgeEngine.js`
- **What it says** → `src/services/DialogueService.js`
- **Saving/loading** → `src/storage/` and `src/core/StateHub.js`
- **The window, tray, logs** → `src/main/`

## Reset just one part

Because each feature stores its own slice in the save file under `systems.<name>`, you can hand-edit `pet-save.json` (while the app is closed) to reset, say, just the coding streak, without losing your pet. Keep a backup copy first.

## Still stuck?

Grab three things and you’ll have everything needed to diagnose: the last lines of `app.log`, any red text from the DevTools console, and the output of `npm test`.
