# 🐾 Desktop Pet

A fully offline, Tamagotchi-style desktop companion for Windows, built with **Electron + vanilla JavaScript**. It lives as a transparent always-on-top overlay, wanders your desktop, reacts to your cursor, and needs feeding, watering, play, and rest — all without ever touching the internet.

> **No internet. No APIs. No telemetry. No binary assets.** Every byte of state lives in a local JSON file on your PC, and the pet itself is *drawn with code* (HTML canvas), not loaded from sprite images.

---

## Why this is shipped as source (not a prebuilt `.exe`)

A Windows desktop overlay has to be **compiled and launched on a real Windows machine** to do its job (transparent window, always-on-top, click-through, start-on-boot, system tray). It also can't be meaningfully tested inside a sandbox without a GPU/desktop. So you get the complete, production-quality source and build it locally in two commands. This is normal for Electron apps and takes about a minute.

---

## Quick start

You'll need **[Node.js](https://nodejs.org/) 18 or newer** (includes `npm`).

```bash
# 1. Install the build tooling (electron + electron-builder only)
npm install

# 2a. Run it live (great for trying it out / tweaking)
npm start

# 2b. …or build the real Windows installer
npm run build
```

After `npm run build`, your installer is in **`dist/`**:

- `Desktop Pet Setup 1.0.0.exe` — a normal installer (creates Start-menu + desktop shortcuts).
- Prefer a single portable file? Run `npm run build:portable` → `dist/DesktopPet-portable.exe`.

> `npm install` downloads Electron from npm **once, at build time**. The *app itself* makes zero network calls — you can build on a connected machine and run it forever offline.

---

## Starting automatically with Windows

Open the pet → click it → **⚙️ Settings → “Start with Windows.”** That's it; it registers a login item via Electron's native API (no scripts, no registry hacks). Toggle it off the same way.

---

## Where your pet is saved

State is written atomically (with a `.bak` fallback and self-healing recovery) to your user data folder:

```
%APPDATA%\Desktop Pet\save\pet-save.json
```

It saves automatically **every minute**, on **app close**, and on **Windows shutdown/sleep**, and restores your pet's exact needs, level, streak, achievements, accessories, and last screen position on restart. Closing the window only hides the pet — quit fully from the **tray icon → Quit**.

---

## Using your pet

- **Click the pet** for the radial menu: feed (different foods), water, pet, play, clean, sleep, treats, plus 📊 Stats and ⚙️ Settings.
- **Drag** it anywhere — it remembers where it last sat. Drag it around too much and it'll squirm away.
- **Hover** and it reacts; ignore it and it wanders, sits, stretches, watches your cursor, naps, and occasionally chirps a speech bubble.
- **Tray icon** (bottom-right): quick Show/Hide, Feed, Statistics, Settings, Quit.
- Empty desktop space is always **click-through**, so the pet never blocks your work. (The “Click-through when idle” setting controls whether clicks land on the *pet's body* too.)

### What it tracks
Seven needs (hunger, thirst, happiness, energy, cleanliness, health, affection), an 8-state mood engine, XP & levels that unlock foods and accessories (bow tie, glasses, top hat, party hat, cape), a daily care streak, lifetime stats, and 11 achievements.

---

## Settings

Pet size · transparency · animation speed · sound volume · mute · always-on-top · click-through · start-on-boot. Everything applies live and persists.

---

## Project layout

```
desktop-pet/
├─ package.json            # scripts + electron-builder config (no runtime deps)
├─ tools/genicons.js       # draws build/icon.png with pure Node (no image libs)
└─ src/
   ├─ main/                # Electron main process (CommonJS)
   │   ├─ main.js          #   window, tray, IPC, autosave, power events
   │   ├─ preload.js       #   safe contextBridge → window.petAPI
   │   ├─ tray.js · autolaunch.js
   ├─ renderer/            # the overlay page (native ES modules, no bundler)
   │   ├─ index.html · styles.css · renderer.js   # the conductor
   ├─ config/constants.js  # all tunable numbers (decay rates, XP, unlocks…)
   ├─ storage/             # schema + atomic, self-healing JSON store
   ├─ pet/                 # PetState (model) · MoodEngine · Behavior · Pet
   ├─ animations/          # Animator (pose blending) · sprites.js (canvas art)
   ├─ achievements/ · settings/ · ui/   # panels, menu, speech, toasts, sound
   └─ assets/              # (intentionally empty — the pet is procedural)
```

**Architecture in one line:** the renderer runs the simulation and draws each frame; the main process owns the window, tray, and durable saves; they talk over a tiny IPC bridge.

---

## Customizing it

It's designed to be tweaked — open these and reload:

- **`src/config/constants.js`** — make needs decay slower/faster, retune XP, change what unlocks at which level, adjust speeds, default settings.
- **`src/animations/sprites.js`** — this *is* the pet. It's procedural canvas drawing (shapes, not images), so you can recolor (`PALETTE`), reshape, or add accessories without any art files. Want image sprites instead? Swap `drawPet()` to blit your own sheet.
- **`src/ui/SpeechBubble.js`** — edit the `LINES` the pet says.
- **`src/achievements/achievements.js`** — add your own achievements with a one-line predicate.

---

## Performance

One `requestAnimationFrame` loop, a 1 Hz needs simulation, coalesced saves, no polling timers left running, listeners cleaned up — it's built to idle quietly all day. If you want it even lighter, lower `animationSpeed` or shrink the pet; the canvas only redraws the area it occupies.

---

## Troubleshooting

- **The window looks like a black box instead of being transparent.** This is almost always a GPU compositing quirk. The app already calls `disableHardwareAcceleration()` to avoid it; if it persists on an old laptop, that flag is in `src/main/main.js`.
- **It didn't start on boot.** Toggle the setting off and on once after installing (the login item is registered against the installed path).
- **I closed it and it vanished.** Closing only hides it — reopen from the tray, or fully quit via **tray → Quit**.
- **Reset the pet.** Quit, delete `%APPDATA%\Desktop Pet\save\pet-save.json`, relaunch.

---

## License

MIT — do whatever you like with it. Built to be offline, private, and yours.
