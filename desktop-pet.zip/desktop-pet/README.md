# 🐾 Desktop Pet

A fully offline desktop companion for Windows — a **cute, expressive dog** — built with **Electron + vanilla JavaScript**. It lives as a transparent always-on-top overlay, reacts to you, needs care, **runs Pomodoro focus sprints, reminds you to do your Anki flashcards, and throws confetti when you hit your goals** — all without ever touching the internet.

> **No internet. No APIs. No telemetry. No binary assets.** State lives in a local JSON file; the dog is *drawn with code* (HTML canvas), and sounds are synthesised at runtime.

### What it does for you
- **Knows when to stay quiet (Adaptive Attention):** the companion goes calm during deep work, meetings, focus sprints, or when you're busy in another app — slower motion, no idle chatter, no barking, and reminders held back. It uses only coarse, privacy-safe signals (idle time, whether our own window is focused, screen lock) — **no screenshots, no window titles, no app names, no microphone, no camera.** Higher-priority health reminders can still break through; a locked screen silences everything.
  - **Deep Work** and **Meeting** toggles live in the click menu (🔕 / 📵). Turn one on and the dog settles down and keeps silent until you switch it off (they reset to off on restart).
- **Lively dog:** breathes gently, blinks naturally, wags and emotes with **smooth blended transitions** between states (poses *and* motion ease in, and the walk/bob cycle never jumps when the dog speeds up or changes mood). Sits in a soft **day/night glow** with a shadow that lengthens toward evening (toggle "Day/night ambiance" in Settings). The ambiance is subtle and translucent — it never blocks your desktop.
- **Pet it like a real dog:** move your mouse over different body parts and each feels different — scratch an **ear** and the back leg thumps, **boop** the snout, rub the **belly** for full zoomies, stroke the **head/back** for happy sighs, or ruffle the **tail** for a wag. Keep stroking and it keeps reacting (gently rate-limited so it stays calm).
- **Coding buddy:** click the dog → **🎯 Focus sprint** (Pomodoro). It tracks your focus time, a day-over-day streak, and celebrates each finished sprint.
- **Anki reminder:** click the dog → **🧠 Anki done** to log your reviews and build a streak. Gentle reminders if you haven’t yet — never naggy (a global attention budget makes sure).
- **Wellness coach:** click the dog → **💧 Water / 🧘 Stretch / 🧍 Stand / 👁️ Eyes**. Tracks a daily water goal, a movement score across stretch/stand/eye-breaks (20-20-20), streaks for each, and reminders that share the same anti-nag budget.
- **Daily planner:** click the dog → **📝 Tasks**. Capture today's priorities, star your one main goal, tick them off (the main goal celebrates biggest), and build a productive-day streak. Unfinished tasks carry over to tomorrow; a gentle morning nudge asks for your main goal.
- **Learning tracker:** click the dog → **📚 Learn**. Jot what you learned today, log study time, tag skills/tech, and keep learning goals, with a learning streak. *Professional development only — no interview-prep, resume, or job-search features.*
- **Presentation coach:** click the dog → **🎤 Talks**. Add upcoming talks with a date countdown, rate your confidence (1–5), run a rehearsal timer that logs practice sessions, and work a prep checklist. A gentle reminder if a talk is within a few days.
- **"Today" dashboard:** click the dog → **📈 Today**. Goal rings (focus / water / movement / tasks), all your streaks at a glance, a weekly study-minutes bar chart, a task-completion sparkline, and your friendship/level/next-talk summary — drawn with a tiny built-in chart kit (no libraries).
- **Plugins:** drop-in feature modules that plug into the same lifecycle with a capability-limited sandbox. A built-in example (Habit Tracker) adds a 🐾 menu button. Write your own in minutes — see `src/plugins/README.md`.
- **Optional local AI:** off by default. If you turn on "Local AI phrasing" in Settings *and* run [Ollama](https://ollama.com) locally, the dog can reword its lines using a model on your own machine. It talks to **localhost only** — never any external server — and falls back to built-in lines if it's off or unavailable.
- **Chat with the dog (local):** click the dog → **💬 Chat**. Rubber-duck a bug, get a quick explanation, be quizzed on what you're learning, or pick your main task — answered by your local model, with context (your streaks, tasks, learning, next talk) and a local **memory** you control ("remember I'm learning ARM assembly"). While it thinks, the dog settles into a thoughtful pose. With AI off, your memories still save and it tells you how to enable a model. All local.
- **Knowledge vault:** click the dog → **📓 Notes**. Keep learning/coding/research notes with tags and a fast built-in search (no libraries). Ask the chat "what did I learn about ARM NEON?" and it pulls your most relevant notes in as context automatically. Stored locally.
- **Project tracker:** click the dog → **🗂️ Projects**. Track projects with milestones (progress bar), a deadline countdown, and notes. Tick a milestone for a small celebration; finish them all to celebrate the whole project. A conservative once-a-day reminder surfaces a deadline that's almost here.
- **Flashcards (spaced repetition):** click the dog → **🃏 Cards**. A real Anki-style scheduler — add cards, review the due queue (Again / Hard / Good / Easy), and cards graduate through growing intervals based on recall. Builds a daily review streak; a gentle reminder when cards are due. All local, no libraries.
- **Life timeline:** click the dog → **📜 Timeline**. The companion remembers your journey — projects shipped, goals learned, level-ups, friendship growth — plus "together" milestones as lifetime totals cross thresholds ("100 focus sprints together!"). Lifetime totals up top, a memory feed below.
- **Play fetch:** click the dog → **🦴 Fetch**. A stick appears in hand; **flick and release** to throw it across your desktop. The puppy sprints after it, picks it up, and trots it back — and how eagerly depends on its mood: excited = a fast dash, sleepy = a slow amble, and a worn-out dog might just ignore you. Tracks throws, fetches, best distance, and a fetch streak. All canvas, no assets.
- **Play UNO:** click the dog → **🎴 UNO**. A full offline UNO game, you vs. the dog, with a real 108-card deck and three difficulties (Easy / Medium / **Smart Dog**). The dog has a personality — it wags after a good play, looks surprised when you drop a Wild +4 on it, gets disappointed when forced to draw, and barks "UNO!" on its last card. Earns XP and badges, and tracks games, wins, streaks, and your favourite colour. Pure local logic, no libraries.
- **Your coworker:** click the dog → **🐶 Coworker**. This is the thread that ties everything together — the dog works beside you, earning a treat for every focus sprint, then gently offering a break-time game once you've put a couple in: **fetch** when you've stepped away, **cricket** around lunch, a quick **UNO** otherwise. It stays completely quiet during deep work and meetings. The panel shows treats, sprints, breaks, and games played together, with one-tap launch for each game.
- **Play cricket:** click the dog → **🏏 Cricket**. Hand-cricket with three modes (Quick Play / Practice Nets / **Challenge**). You bat first — pick a shot (defend/push/drive/loft) and stop the timing bar in the middle for clean contact; the dog bowls and fields, taking diving catches and the occasional dropped sitter. Then you bowl the chase, picking deliveries (bouncer/yorker/spin) to fox the dog batter. Sixes trigger a chase-to-the-fence; wins build toward the **Dog Premier League** title. Tracks runs, wickets, high score, best partnership, sixes, and trophies. The dog gets sharper the more you play. All local, no libraries.
- **Health dashboard:** click the dog → **🩺 Health**. Live runtime stats (uptime, FPS, memory, event-bus traffic, systems/plugins), save-integrity status, and in-memory **state snapshots** you can restore. Copy a diagnostics report or jump to the logs folder. All in-process and local. (Saves are already crash-safe: atomic writes with a `.bak` and self-healing reads.)
- **Accessibility:** panels expose dialog roles/labels, toasts announce politely, and the app honors your OS "reduce motion" setting (calmer breathing/celebrations).

### Safe for a work laptop
**Zero network by default**: with the default settings the app makes no connections of any kind — no auto-updater, no telemetry, no accounts. All data lives in one JSON file under `%APPDATA%\Desktop Pet\` that you can delete anytime. The *only* networking code in the project is the optional local-AI provider, which is **disabled by default** and, even when enabled, connects solely to `127.0.0.1` (your own machine via Ollama) — never the internet. The learning tracker is scoped to ordinary upskilling and intentionally contains nothing job-search-related.
- **Gamified, ADHD-friendly payoff:** finishing things triggers confetti, a happy bark, a sound, and **+XP** that levels you (and the dog) up. The reward is immediate and visible.
- **A bond that grows:** caring for the dog and following its coaching raises friendship, which unlocks warmer dialogue.
- Plus everything the pet already did: needs, moods, drag-and-drop, accessories, achievements, stats, settings, tray.

### If something breaks
You’re not stuck guessing — see **`DEBUGGING.md`**. Quick version: right-click the tray icon → **Open Logs Folder**, run `npm test`, and check the DevTools console.

---

## Why this is shipped as source (not a prebuilt `.exe`)

A Windows desktop overlay has to be **compiled and launched on a real Windows machine** to do its job (transparent window, always-on-top, click-through, start-on-boot, system tray). It also can't be meaningfully tested inside a sandbox without a GPU/desktop. So you get the complete, production-quality source and build it locally in two commands. This is normal for Electron apps and takes about a minute.

---

## Quick start

You'll need **[Node.js](https://nodejs.org/) 18 or newer** (includes `npm`).

```bash
# 1. Install the build tooling (electron + electron-builder only)
npm install

# 2a. Run it live (great for trying it out / tweaking)
npm start

# 2b. …or build the real Windows installer
npm run build
```

After `npm run build`, your installer is in **`dist/`**:

- `Desktop Pet Setup 1.0.0.exe` — a normal installer (creates Start-menu + desktop shortcuts).
- Prefer a single portable file? Run `npm run build:portable` → `dist/DesktopPet-portable.exe`.

> `npm install` downloads Electron from npm **once, at build time**. The *app itself* makes zero network calls — you can build on a connected machine and run it forever offline.

---

## Development & tests

The codebase is being evolved into a fuller companion (coding buddy, wellness, planning…). The plan lives in **`ARCHITECTURE.md`**. The foundation (**Phase 0**) is in place: an `EventBus`, `SystemRegistry`, `Clock`, and `StateHub` under `src/core/`, with every feature — starting with the pet itself (`src/systems/pet/PetSystem.js`) — implemented against a single `System` interface (`src/systems/System.js`).

Run the test suite (no install needed — it uses Node's built-in runner):

```bash
npm test
```

It covers the event bus, clock, registry lifecycle/leak-safety, the save-schema migrator, and save round-trips. New features land as a new `System` plus tests, without touching the pet simulation.

## Starting automatically with Windows

Open the pet → click it → **⚙️ Settings → “Start with Windows.”** That's it; it registers a login item via Electron's native API (no scripts, no registry hacks). Toggle it off the same way.

---

## Where your pet is saved

State is written atomically (with a `.bak` fallback and self-healing recovery) to your user data folder:

```
%APPDATA%\Desktop Pet\save\pet-save.json
```

It saves automatically **every minute**, on **app close**, and on **Windows shutdown/sleep**, and restores your pet's exact needs, level, streak, achievements, accessories, and last screen position on restart. Closing the window only hides the pet — quit fully from the **tray icon → Quit**.

---

## Using your pet

- **Click the pet** for the radial menu: feed (different foods), water, pet, play, clean, sleep, treats, plus 📊 Stats and ⚙️ Settings.
- **Drag** it anywhere — it remembers where it last sat. Drag it around too much and it'll squirm away.
- **Hover** and it reacts; ignore it and it wanders, sits, stretches, watches your cursor, naps, and occasionally chirps a speech bubble.
- **Tray icon** (bottom-right): quick Show/Hide, Feed, Statistics, Settings, Quit.
- Empty desktop space is always **click-through**, so the pet never blocks your work. (The “Click-through when idle” setting controls whether clicks land on the *pet's body* too.)

### What it tracks
Seven needs (hunger, thirst, happiness, energy, cleanliness, health, affection), an 8-state mood engine, XP & levels that unlock foods and accessories (bow tie, glasses, top hat, party hat, cape), a daily care streak, lifetime stats, and 11 achievements.

---

## Settings

Pet size · transparency · animation speed · sound volume · mute · always-on-top · click-through · start-on-boot. Everything applies live and persists.

---

## Project layout

```
desktop-pet/
├─ package.json            # scripts + electron-builder config (no runtime deps)
├─ tools/genicons.js       # draws build/icon.png with pure Node (no image libs)
└─ src/
   ├─ main/                # Electron main process (CommonJS)
   │   ├─ main.js          #   window, tray, IPC, autosave, power events
   │   ├─ preload.js       #   safe contextBridge → window.petAPI
   │   ├─ tray.js · autolaunch.js
   ├─ renderer/            # the overlay page (native ES modules, no bundler)
   │   ├─ index.html · styles.css · renderer.js   # the conductor
   ├─ config/constants.js  # all tunable numbers (decay rates, XP, unlocks…)
   ├─ storage/             # schema + atomic, self-healing JSON store
   ├─ pet/                 # PetState (model) · MoodEngine · Behavior · Pet
   ├─ animations/          # Animator (pose blending) · sprites.js (canvas art)
   ├─ achievements/ · settings/ · ui/   # panels, menu, speech, toasts, sound
   └─ assets/              # (intentionally empty — the pet is procedural)
```

**Architecture in one line:** the renderer runs the simulation and draws each frame; the main process owns the window, tray, and durable saves; they talk over a tiny IPC bridge.

---

## Customizing it

It's designed to be tweaked — open these and reload:

- **`src/config/constants.js`** — make needs decay slower/faster, retune XP, change what unlocks at which level, adjust speeds, default settings.
- **`src/animations/sprites.js`** — this *is* the pet. It's procedural canvas drawing (shapes, not images), so you can recolor (`PALETTE`), reshape, or add accessories without any art files. Want image sprites instead? Swap `drawPet()` to blit your own sheet.
- **`src/ui/SpeechBubble.js`** — edit the `LINES` the pet says.
- **`src/achievements/achievements.js`** — add your own achievements with a one-line predicate.

---

## Performance

One `requestAnimationFrame` loop, a 1 Hz needs simulation, coalesced saves, no polling timers left running, listeners cleaned up — it's built to idle quietly all day. If you want it even lighter, lower `animationSpeed` or shrink the pet; the canvas only redraws the area it occupies.

---

## Troubleshooting

- **The window looks like a black box instead of being transparent.** This is almost always a GPU compositing quirk. The app already calls `disableHardwareAcceleration()` to avoid it; if it persists on an old laptop, that flag is in `src/main/main.js`.
- **It didn't start on boot.** Toggle the setting off and on once after installing (the login item is registered against the installed path).
- **I closed it and it vanished.** Closing only hides it — reopen from the tray, or fully quit via **tray → Quit**.
- **Reset the pet.** Quit, delete `%APPDATA%\Desktop Pet\save\pet-save.json`, relaunch.

---

## License

MIT — do whatever you like with it. Built to be offline, private, and yours.
