# 🐾 Desktop Pet

A fully offline desktop companion for Windows — a **cute, expressive puppy** — built with **Electron + vanilla JavaScript**. It lives as a transparent always-on-top overlay, reacts to you, needs a little care, plays fetch, keeps you company while you code, and remembers your time together — all without ever touching the internet.

> **No internet. No APIs. No telemetry. No binary assets.** State lives in a local JSON file; the puppy is *drawn with code* (HTML canvas), and sounds are synthesised at runtime.

> **v3 — the puppy is the product.** Earlier builds grew a lot of productivity machinery (task/project/learning trackers, flashcards, wellness reminders, deep-work detection, UNO & cricket). v3 strips all of that back out: this is a desktop *pet* and a quiet coding companion, not a task manager or a games console.

### What it does
- **A lively puppy:** breathes gently, blinks naturally, wags and emotes with **smooth blended transitions** between states (poses *and* motion ease in, and the walk/bob cycle never jumps). Sits in a soft **day/night glow** with a shadow that lengthens toward evening (toggle "Day/night ambiance" in Settings) — subtle and translucent, never blocking your desktop.
- **Follows its own routine:** wanders, sits, looks around, stretches, sleeps, and occasionally asks for attention — so it feels alive rather than static.
- **Pet it like a real dog:** move your mouse over different body parts and each feels different — scratch an **ear** and the back leg thumps, **boop** the snout, rub the **belly** for full zoomies, stroke the **head/back** for happy sighs, or ruffle the **tail** for a wag. Keep stroking and it keeps reacting (gently rate-limited so it stays calm).
- **Sleep is the quiet mode:** the puppy naps at night or whenever you tell it to (🛌 Sleep), going still and silent — no separate "deep work" or "meeting" modes needed. It wakes naturally after a rest.
- **Three meals a day:** feed **Breakfast / Lunch / Dinner** from the click menu — each once per day, with a ✓ once given, resetting automatically the next morning. No hunger economy, no inventory; feeding is just a happy little ritual.
- **Unlimited treats:** give a treat anytime for a small happiness + friendship boost and a cute reaction. Treats exist purely because giving treats is fun.
- **Play fetch:** click the puppy → **🦴 Fetch**. A stick appears in hand; **flick and release** to throw it across your desktop. The puppy sprints after it, picks it up, and trots it back — and how eagerly depends on its mood: excited = a fast dash, sleepy = a slow amble, and a worn-out pup might just ignore you.
- **A coding buddy through presence:** click the puppy → **🎯 Focus with me**. It simply keeps you company while you work — no enforcement, no tracking dashboards.
- **Chat with the puppy (optional, local):** click → **💬 Chat**. Rubber-duck or chat, answered by a local model if you've enabled it — **localhost only**, off by default, with built-in lines as the fallback.
- **A memory of your time together:** click → **📜 Timeline**. The puppy remembers the day you met, level-ups, friendship growth, and cute "together" milestones (100 pets received, 100 fetches played, one year together). Pet-only memories — no productivity milestones.
- **Health dashboard:** click → **🩺 Health**. Live runtime stats (uptime, FPS, memory, event-bus traffic), save-integrity status, and in-memory **state snapshots** you can restore. Saves are crash-safe (atomic writes with a `.bak` and self-healing reads).
- **Grows with you:** caring for the puppy and playing together raises **friendship** and earns **XP/levels**, unlocking warmer dialogue. Finishing a fetch or sharing a meal triggers a little confetti, a happy sound, and +XP.
- **Plugins:** drop-in feature modules with a capability-limited sandbox (a 🐾 example is included). Write your own — see `src/plugins/README.md`.
- **Accessibility:** panels expose dialog roles/labels, toasts announce politely, and the app honors your OS "reduce motion" setting (calmer breathing/celebrations).

### Safe for a work laptop
**Zero network by default**: with the default settings the app makes no connections of any kind — no auto-updater, no telemetry, no accounts. All data lives in one JSON file under `%APPDATA%\Desktop Pet\` that you can delete anytime. The *only* networking code in the project is the optional local-AI provider, which is **disabled by default** and, even when enabled, connects solely to `127.0.0.1` (your own machine via Ollama) — never the internet. There is no webcam, microphone, screen-reading, or window/app monitoring of any kind.

### If something breaks
You’re not stuck guessing — see **`DEBUGGING.md`**. Quick version: right-click the tray icon → **Open Logs Folder**, run `npm test`, and check the DevTools console.

---

## Why this is shipped as source (not a prebuilt `.exe`)

A Windows desktop overlay has to be **compiled and launched on a real Windows machine** to do its job (transparent window, always-on-top, click-through, start-on-boot, system tray). It also can't be meaningfully tested inside a sandbox without a GPU/desktop. So you get the complete, production-quality source and build it locally in two commands. This is normal for Electron apps and takes about a minute.

---

## Quick start

You'll need **[Node.js](https://nodejs.org/) 18 or newer** (includes `npm`).

```bash
# 1. Install the build tooling (electron + electron-builder only)
npm install

# 2a. Run it live (great for trying it out / tweaking)
npm start

# 2b. …or build the real Windows installer
npm run build
```

After `npm run build`, your installer is in **`dist/`**:

- `Desktop Pet Setup 1.0.0.exe` — a normal installer (creates Start-menu + desktop shortcuts).
- Prefer a single portable file? Run `npm run build:portable` → `dist/DesktopPet-portable.exe`.

> `npm install` downloads Electron from npm **once, at build time**. The *app itself* makes zero network calls — you can build on a connected machine and run it forever offline.

---

## Development & tests

The codebase is being evolved into a fuller companion (coding buddy, wellness, planning…). The plan lives in **`ARCHITECTURE.md`**. The foundation (**Phase 0**) is in place: an `EventBus`, `SystemRegistry`, `Clock`, and `StateHub` under `src/core/`, with every feature — starting with the pet itself (`src/systems/pet/PetSystem.js`) — implemented against a single `System` interface (`src/systems/System.js`).

Run the test suite (no install needed — it uses Node's built-in runner):

```bash
npm test
```

It covers the event bus, clock, registry lifecycle/leak-safety, the save-schema migrator, and save round-trips. New features land as a new `System` plus tests, without touching the pet simulation.

## Starting automatically with Windows

Open the pet → click it → **⚙️ Settings → “Start with Windows.”** That's it; it registers a login item via Electron's native API (no scripts, no registry hacks). Toggle it off the same way.

---

## Where your pet is saved

State is written atomically (with a `.bak` fallback and self-healing recovery) to your user data folder:

```
%APPDATA%\Desktop Pet\save\pet-save.json
```

It saves automatically **every minute**, on **app close**, and on **Windows shutdown/sleep**, and restores your pet's exact needs, level, streak, achievements, accessories, and last screen position on restart. Closing the window only hides the pet — quit fully from the **tray icon → Quit**.

---

## Using your pet

- **Click the pet** for the radial menu: feed (different foods), water, pet, play, clean, sleep, treats, plus 📊 Stats and ⚙️ Settings.
- **Drag** it anywhere — it remembers where it last sat. Drag it around too much and it'll squirm away.
- **Hover** and it reacts; ignore it and it wanders, sits, stretches, watches your cursor, naps, and occasionally chirps a speech bubble.
- **Tray icon** (bottom-right): quick Show/Hide, Feed, Statistics, Settings, Quit.
- Empty desktop space is always **click-through**, so the pet never blocks your work. (The “Click-through when idle” setting controls whether clicks land on the *pet's body* too.)

### What it tracks
Seven needs (hunger, thirst, happiness, energy, cleanliness, health, affection), an 8-state mood engine, XP & levels that unlock foods and accessories (bow tie, glasses, top hat, party hat, cape), a daily care streak, lifetime stats, and 11 achievements.

---

## Settings

Pet size · transparency · animation speed · sound volume · mute · always-on-top · click-through · start-on-boot. Everything applies live and persists.

---

## Project layout

```
desktop-pet/
├─ package.json            # scripts + electron-builder config (no runtime deps)
├─ tools/genicons.js       # draws build/icon.png with pure Node (no image libs)
└─ src/
   ├─ main/                # Electron main process (CommonJS)
   │   ├─ main.js          #   window, tray, IPC, autosave, power events
   │   ├─ preload.js       #   safe contextBridge → window.petAPI
   │   ├─ tray.js · autolaunch.js
   ├─ renderer/            # the overlay page (native ES modules, no bundler)
   │   ├─ index.html · styles.css · renderer.js   # the conductor
   ├─ config/constants.js  # all tunable numbers (decay rates, XP, unlocks…)
   ├─ storage/             # schema + atomic, self-healing JSON store
   ├─ pet/                 # PetState (model) · MoodEngine · Behavior · Pet
   ├─ animations/          # Animator (pose blending) · sprites.js (canvas art)
   ├─ achievements/ · settings/ · ui/   # panels, menu, speech, toasts, sound
   └─ assets/              # (intentionally empty — the pet is procedural)
```

**Architecture in one line:** the renderer runs the simulation and draws each frame; the main process owns the window, tray, and durable saves; they talk over a tiny IPC bridge.

---

## Customizing it

It's designed to be tweaked — open these and reload:

- **`src/config/constants.js`** — make needs decay slower/faster, retune XP, change what unlocks at which level, adjust speeds, default settings.
- **`src/animations/sprites.js`** — this *is* the pet. It's procedural canvas drawing (shapes, not images), so you can recolor (`PALETTE`), reshape, or add accessories without any art files. Want image sprites instead? Swap `drawPet()` to blit your own sheet.
- **`src/ui/SpeechBubble.js`** — edit the `LINES` the pet says.
- **`src/achievements/achievements.js`** — add your own achievements with a one-line predicate.

---

## Performance

One `requestAnimationFrame` loop, a 1 Hz needs simulation, coalesced saves, no polling timers left running, listeners cleaned up — it's built to idle quietly all day. If you want it even lighter, lower `animationSpeed` or shrink the pet; the canvas only redraws the area it occupies.

---

## Troubleshooting

- **The window looks like a black box instead of being transparent.** This is almost always a GPU compositing quirk. The app already calls `disableHardwareAcceleration()` to avoid it; if it persists on an old laptop, that flag is in `src/main/main.js`.
- **It didn't start on boot.** Toggle the setting off and on once after installing (the login item is registered against the installed path).
- **I closed it and it vanished.** Closing only hides it — reopen from the tray, or fully quit via **tray → Quit**.
- **Reset the pet.** Quit, delete `%APPDATA%\Desktop Pet\save\pet-save.json`, relaunch.

---

## License

MIT — do whatever you like with it. Built to be offline, private, and yours.
