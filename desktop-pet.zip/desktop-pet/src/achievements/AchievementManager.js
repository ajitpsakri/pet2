/**
 * AchievementManager.js
 * ----------------------------------------------------------------------------
 * Periodically evaluates achievement predicates against the live PetState and
 * records first-unlock timestamps directly onto state.achievements (so they
 * persist with the save). Emits a callback for any newly unlocked achievement
 * so the UI can toast it.
 */

import { ACHIEVEMENTS } from './achievements.js';

export class AchievementManager {
  /**
   * @param {PetState} state
   * @param {(achievement) => void} onUnlock fired once per new unlock
   */
  constructor(state, onUnlock) {
    this.state = state;
    this.onUnlock = onUnlock || (() => {});
  }

  /** Check all achievements; record + announce any that just became true. */
  evaluate() {
    for (const ach of ACHIEVEMENTS) {
      if (this.state.achievements[ach.id]) continue; // already earned
      let ok = false;
      try {
        ok = ach.check(this.state);
      } catch {
        ok = false;
      }
      if (ok) {
        this.state.achievements[ach.id] = Date.now();
        this.onUnlock(ach);
      }
    }
  }

  /** Convenience view for the dashboard: [{...def, unlockedAt|null}]. */
  list() {
    return ACHIEVEMENTS.map((a) => ({
      ...a,
      unlockedAt: this.state.achievements[a.id] || null,
    }));
  }

  unlockedCount() {
    return Object.keys(this.state.achievements).length;
  }
  total() {
    return ACHIEVEMENTS.length;
  }
}
