/**
 * achievements.js
 * ----------------------------------------------------------------------------
 * Declarative list of achievements. Each `check(state)` is a pure predicate
 * over the live PetState, so adding a new achievement is a one-liner and the
 * manager stays generic.
 */

export const ACHIEVEMENTS = [
  {
    id: 'first_meal',
    name: 'First Meal',
    desc: 'Feed your pet for the first time.',
    icon: '🍽️',
    check: (s) => s.stats.totalFood >= 1,
  },
  {
    id: 'hydrated',
    name: 'Stay Hydrated',
    desc: 'Give water 10 times.',
    icon: '💧',
    check: (s) => s.stats.totalWater >= 10,
  },
  {
    id: 'hundred_pats',
    name: '100 Head Pats',
    desc: 'Pet your companion 100 times.',
    icon: '✋',
    check: (s) => s.stats.totalPats >= 100,
  },
  {
    id: 'playful',
    name: 'Playtime',
    desc: 'Play 25 times.',
    icon: '🎾',
    check: (s) => s.stats.totalPlay >= 25,
  },
  {
    id: 'one_week',
    name: 'One Week Owner',
    desc: 'Keep a care streak of 7 days.',
    icon: '📅',
    check: (s) => s.stats.careStreak >= 7 || s.stats.longestStreak >= 7,
  },
  {
    id: 'marathon',
    name: 'Marathon Caregiver',
    desc: 'Reach a 30-day care streak.',
    icon: '🏅',
    check: (s) => s.stats.longestStreak >= 30,
  },
  {
    id: 'healthy',
    name: 'Healthy Pet',
    desc: 'Keep health at 100 while well-fed.',
    icon: '❤️',
    check: (s) => s.needs.health >= 100 && s.needs.hunger >= 70,
  },
  {
    id: 'best_friend',
    name: 'Best Friend',
    desc: 'Max out affection.',
    icon: '🤝',
    check: (s) => s.needs.affection >= 100,
  },
  {
    id: 'level_five',
    name: 'Growing Up',
    desc: 'Reach level 5.',
    icon: '⭐',
    check: (s) => s.level >= 5,
  },
  {
    id: 'level_ten',
    name: 'Seasoned Companion',
    desc: 'Reach level 10.',
    icon: '🌟',
    check: (s) => s.level >= 10,
  },
  {
    id: 'old_friend',
    name: 'Old Friend',
    desc: 'Care for your pet for 30 days.',
    icon: '🎂',
    check: (s) => s.ageDays() >= 30,
  },
];
