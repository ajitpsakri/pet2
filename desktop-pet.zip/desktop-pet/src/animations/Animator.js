/**
 * Animator.js
 * ----------------------------------------------------------------------------
 * Drives the pet's animation without any external sprite-sheet assets. Instead
 * of swapping bitmap frames, we keep a small set of *pose parameters* (how open
 * the eyes are, how much the body leans, etc.) and smoothly interpolate them
 * toward per-animation targets every frame. Cyclic motion (bobbing, walk cycle,
 * hops) is layered on top from a continuous time accumulator.
 *
 * Result: genuinely smooth transitions between any two states, tiny footprint,
 * and 100% offline (the whole pet is math + canvas paths). Swapping in real
 * sprite sheets later only requires changing sprites.js, not this file.
 */

// Per-animation pose targets + motion descriptors.
// eyeOpen/mouthOpen/earPerk/blush/droop: 0..1   lean: radians   freq: Hz
const ANIMS = {
  idle:     { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.6, blush: 0,    lean: 0,     droop: 0,   freq: 0.6, bob: 2,  hop: 0,  leg: 0 },
  sit:      { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.5, blush: 0,    lean: 0,     droop: 0.3, freq: 0.4, bob: 1,  hop: 0,  leg: 0 },
  look:     { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.9, blush: 0,    lean: 0.05,  droop: 0,   freq: 0.5, bob: 1.5,hop: 0,  leg: 0 },
  stretch:  { eyeOpen: 0.6, mouthOpen: 0.3,  earPerk: 0.3, blush: 0,    lean: 0.18,  droop: 0,   freq: 0.8, bob: 1,  hop: 0,  leg: 0 },
  walking:  { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.7, blush: 0,    lean: 0.04,  droop: 0,   freq: 2.4, bob: 3,  hop: 0,  leg: 1 },
  running:  { eyeOpen: 1,   mouthOpen: 0.2,  earPerk: 0.9, blush: 0.1,  lean: 0.12,  droop: 0,   freq: 4.5, bob: 4,  hop: 0,  leg: 1.4 },
  jumping:  { eyeOpen: 1,   mouthOpen: 0.4,  earPerk: 1,   blush: 0.3,  lean: 0,     droop: 0,   freq: 1.6, bob: 0,  hop: 22, leg: 0 },
  happy:    { eyeOpen: 0.85,mouthOpen: 0.45, earPerk: 1,   blush: 0.5,  lean: 0,     droop: 0,   freq: 2.2, bob: 4,  hop: 6,  leg: 0 },
  excited:  { eyeOpen: 1,   mouthOpen: 0.6,  earPerk: 1,   blush: 0.6,  lean: 0,     droop: 0,   freq: 3.2, bob: 5,  hop: 10, leg: 0 },
  sad:      { eyeOpen: 0.7, mouthOpen: 0,    earPerk: 0.1, blush: 0,    lean: -0.04, droop: 0.7, freq: 0.5, bob: 1,  hop: 0,  leg: 0 },
  sick:     { eyeOpen: 0.5, mouthOpen: 0.1,  earPerk: 0.05,blush: 0,    lean: -0.06, droop: 0.9, freq: 0.4, bob: 1,  hop: 0,  leg: 0 },
  sleeping: { eyeOpen: 0.02,mouthOpen: 0,    earPerk: 0.1, blush: 0,    lean: 0.02,  droop: 1,   freq: 0.35,bob: 1.5,hop: 0,  leg: 0 },
  eating:   { eyeOpen: 0.9, mouthOpen: 0.7,  earPerk: 0.7, blush: 0.2,  lean: 0.04,  droop: 0,   freq: 6.0, bob: 1,  hop: 0,  leg: 0 },
  drinking: { eyeOpen: 0.9, mouthOpen: 0.5,  earPerk: 0.6, blush: 0.1,  lean: 0.08,  droop: 0,   freq: 3.0, bob: 1,  hop: 0,  leg: 0 },
  petted:   { eyeOpen: 0.4, mouthOpen: 0.2,  earPerk: 0.8, blush: 0.7,  lean: 0,     droop: 0,   freq: 1.0, bob: 2,  hop: 0,  leg: 0 },
};

const POSE_KEYS = ['eyeOpen', 'mouthOpen', 'earPerk', 'blush', 'lean', 'droop'];
const lerp = (a, b, t) => a + (b - a) * t;

export class Animator {
  constructor() {
    this.name = 'idle';
    this.time = 0; // continuous phase clock (seconds, speed-scaled)
    // Live, smoothly-interpolated pose.
    this.pose = { eyeOpen: 1, mouthOpen: 0, earPerk: 0.6, blush: 0, lean: 0, droop: 0 };
    // Cyclic outputs recomputed each frame.
    this.bobY = 0;
    this.legPhase = 0;
    this.hopY = 0;
    this.tailWag = 0;
  }

  /** Switch animation. No-op if already playing it. */
  play(name) {
    if (ANIMS[name] && name !== this.name) this.name = name;
  }

  isPlaying(name) {
    return this.name === name;
  }

  /**
   * @param {number} dt seconds since last frame
   * @param {number} speed user animation-speed multiplier (0.5..2)
   */
  update(dt, speed = 1) {
    const def = ANIMS[this.name] || ANIMS.idle;
    this.time += dt * speed;

    // Smoothly approach the target static pose. The 1 - e^{-k dt} form gives a
    // framerate-independent ease.
    const k = 10; // higher = snappier transitions
    const t = 1 - Math.exp(-k * dt);
    for (const key of POSE_KEYS) {
      this.pose[key] = lerp(this.pose[key], def[key], t);
    }

    // Cyclic motion layered on top.
    const ph = this.time * def.freq * Math.PI * 2;
    this.bobY = -Math.abs(Math.sin(ph)) * def.bob;
    this.legPhase = Math.sin(ph) * def.leg;
    this.hopY = def.hop ? -Math.abs(Math.sin(ph)) * def.hop : 0;
    // Tail wags faster when happy/excited.
    const wagFreq = this.name === 'happy' || this.name === 'excited' ? 6 : 2;
    this.tailWag = Math.sin(this.time * wagFreq) * (def.earPerk * 0.4 + 0.2);
  }

  /** Snapshot of everything sprites.js needs to draw a frame. */
  frame() {
    return {
      name: this.name,
      pose: this.pose,
      bobY: this.bobY,
      hopY: this.hopY,
      legPhase: this.legPhase,
      tailWag: this.tailWag,
    };
  }
}
