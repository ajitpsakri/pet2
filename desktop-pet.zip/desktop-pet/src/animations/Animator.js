/**
 * Animator.js
 * ----------------------------------------------------------------------------
 * Drives the pet's animation without any external sprite-sheet assets. Instead
 * of swapping bitmap frames, we keep a small set of *pose parameters* (how open
 * the eyes are, how much the body leans, etc.) and smoothly interpolate them
 * toward per-animation targets every frame. Cyclic motion (bobbing, walk cycle,
 * hops) is layered on top from a continuous time accumulator.
 *
 * Result: genuinely smooth transitions between any two states, tiny footprint,
 * and 100% offline (the whole pet is math + canvas paths). Swapping in real
 * sprite sheets later only requires changing sprites.js, not this file.
 */

// Per-animation pose targets + motion descriptors.
// eyeOpen/mouthOpen/earPerk/blush/droop: 0..1   lean: radians   freq: Hz
const ANIMS = {
  idle:     { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.6, blush: 0,    lean: 0,     droop: 0,   freq: 0.6, bob: 2,  hop: 0,  leg: 0 },
  sit:      { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.5, blush: 0,    lean: 0,     droop: 0.3, freq: 0.4, bob: 1,  hop: 0,  leg: 0 },
  look:     { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.9, blush: 0,    lean: 0.05,  droop: 0,   freq: 0.5, bob: 1.5,hop: 0,  leg: 0 },
  stretch:  { eyeOpen: 0.6, mouthOpen: 0.3,  earPerk: 0.3, blush: 0,    lean: 0.18,  droop: 0,   freq: 0.8, bob: 1,  hop: 0,  leg: 0 },
  walking:  { eyeOpen: 1,   mouthOpen: 0,    earPerk: 0.7, blush: 0,    lean: 0.04,  droop: 0,   freq: 2.4, bob: 3,  hop: 0,  leg: 1 },
  running:  { eyeOpen: 1,   mouthOpen: 0.2,  earPerk: 0.9, blush: 0.1,  lean: 0.12,  droop: 0,   freq: 4.5, bob: 4,  hop: 0,  leg: 1.4 },
  jumping:  { eyeOpen: 1,   mouthOpen: 0.4,  earPerk: 1,   blush: 0.3,  lean: 0,     droop: 0,   freq: 1.6, bob: 0,  hop: 22, leg: 0 },
  happy:    { eyeOpen: 0.85,mouthOpen: 0.45, earPerk: 1,   blush: 0.5,  lean: 0,     droop: 0,   freq: 2.2, bob: 4,  hop: 6,  leg: 0 },
  excited:  { eyeOpen: 1,   mouthOpen: 0.6,  earPerk: 1,   blush: 0.6,  lean: 0,     droop: 0,   freq: 3.2, bob: 5,  hop: 10, leg: 0 },
  sad:      { eyeOpen: 0.7, mouthOpen: 0,    earPerk: 0.1, blush: 0,    lean: -0.04, droop: 0.7, freq: 0.5, bob: 1,  hop: 0,  leg: 0 },
  sick:     { eyeOpen: 0.5, mouthOpen: 0.1,  earPerk: 0.05,blush: 0,    lean: -0.06, droop: 0.9, freq: 0.4, bob: 1,  hop: 0,  leg: 0 },
  sleeping: { eyeOpen: 0.02,mouthOpen: 0,    earPerk: 0.1, blush: 0,    lean: 0.02,  droop: 1,   freq: 0.35,bob: 1.5,hop: 0,  leg: 0 },
  eating:   { eyeOpen: 0.9, mouthOpen: 0.7,  earPerk: 0.7, blush: 0.2,  lean: 0.04,  droop: 0,   freq: 6.0, bob: 1,  hop: 0,  leg: 0 },
  drinking: { eyeOpen: 0.9, mouthOpen: 0.5,  earPerk: 0.6, blush: 0.1,  lean: 0.08,  droop: 0,   freq: 3.0, bob: 1,  hop: 0,  leg: 0 },
  petted:   { eyeOpen: 0.4, mouthOpen: 0.2,  earPerk: 0.8, blush: 0.7,  lean: 0,     droop: 0,   freq: 1.0, bob: 2,  hop: 0,  leg: 0 },
  earscratch:{ eyeOpen: 0.25,mouthOpen: 0.15, earPerk: 0.2, blush: 0.6,  lean: 0.16,  droop: 0,   freq: 1.2, bob: 2,  hop: 0,  leg: 0 },
  bellyrub: { eyeOpen: 0.3, mouthOpen: 0.5,  earPerk: 0.9, blush: 0.8,  lean: 0,     droop: 0,   freq: 2.6, bob: 1,  hop: 3,  leg: 0 },
  boop:     { eyeOpen: 1,   mouthOpen: 0.1,  earPerk: 1,   blush: 0.4,  lean: -0.04, droop: 0,   freq: 0.8, bob: 1,  hop: 0,  leg: 0 },
  bark:     { eyeOpen: 1,   mouthOpen: 0.7,  earPerk: 1,   blush: 0.1,  lean: 0.05,  droop: 0,   freq: 5.0, bob: 2,  hop: 4,  leg: 0 },
};

const POSE_KEYS = ['eyeOpen', 'mouthOpen', 'earPerk', 'blush', 'lean', 'droop'];
const lerp = (a, b, t) => a + (b - a) * t;

export class Animator {
  constructor() {
    this.name = 'idle';
    // Live, smoothly-interpolated static pose.
    this.pose = { eyeOpen: 1, mouthOpen: 0, earPerk: 0.6, blush: 0, lean: 0, droop: 0 };
    // Live, smoothly-interpolated MOTION descriptors. Blending these (not just
    // snapping to the new animation's values) keeps bobbing/hopping/leg-swing
    // amplitudes from jumping when the state changes.
    this.motion = { freq: 0.6, bob: 2, hop: 0, leg: 0 };
    this._wagFreq = 2;
    // Continuous phase accumulators. Advancing phase incrementally (rather than
    // time × freq) means a change in frequency alters the RATE, never causing a
    // discontinuous jump in the current cycle position.
    this.phase = 0;
    this.wagPhase = 0;
    this.breathPhase = 0;
    // Cyclic outputs recomputed each frame.
    this.bobY = 0;
    this.legPhase = 0;
    this.hopY = 0;
    this.tailWag = 0;
    this.breath = 0; // subtle body scale oscillation
    this.blink = 1; // 1 = eyes open, dips to 0 on a blink
    this._blinkTimer = 2 + Math.random() * 4;
  }

  /** Switch animation. No-op if already playing it. */
  play(name) {
    if (ANIMS[name] && name !== this.name) this.name = name;
  }

  isPlaying(name) {
    return this.name === name;
  }

  /**
   * @param {number} dt seconds since last frame
   * @param {number} speed user animation-speed multiplier (0.5..2)
   */
  update(dt, speed = 1) {
    const def = ANIMS[this.name] || ANIMS.idle;
    const TAU = Math.PI * 2;

    // Ease the static pose toward its target. 1 - e^{-k dt} is framerate-independent.
    const t = 1 - Math.exp(-10 * dt);
    for (const key of POSE_KEYS) this.pose[key] = lerp(this.pose[key], def[key], t);

    // Ease the motion descriptors too, so amplitudes ramp instead of snapping.
    const mt = 1 - Math.exp(-8 * dt);
    this.motion.freq = lerp(this.motion.freq, def.freq, mt);
    this.motion.bob = lerp(this.motion.bob, def.bob, mt);
    this.motion.hop = lerp(this.motion.hop, def.hop, mt);
    this.motion.leg = lerp(this.motion.leg, def.leg, mt);
    const wagTarget = this.name === 'happy' || this.name === 'excited' ? 6 : 2;
    this._wagFreq = lerp(this._wagFreq, wagTarget, mt);

    // Advance continuous phases by the CURRENT (blended) rate, then wrap. Because
    // we integrate rate over time, changing freq can never jump the cycle.
    this.phase = (this.phase + dt * speed * this.motion.freq * TAU) % TAU;
    this.wagPhase = (this.wagPhase + dt * speed * this._wagFreq * TAU) % TAU;
    this.breathPhase = (this.breathPhase + dt * 1.5) % TAU; // steady, not speed-scaled

    const s = Math.sin(this.phase);
    this.bobY = -Math.abs(s) * this.motion.bob;
    this.legPhase = s * this.motion.leg;
    this.hopY = this.motion.hop > 0.05 ? -Math.abs(s) * this.motion.hop : 0;
    this.tailWag = Math.sin(this.wagPhase) * (this.pose.earPerk * 0.4 + 0.2);
    this.breath = Math.sin(this.breathPhase) * 0.025;

    // Occasional natural blink: a quick close every few seconds.
    this._blinkTimer -= dt;
    if (this._blinkTimer <= 0) {
      const since = -this._blinkTimer; // seconds into the blink
      if (since < 0.14) {
        this.blink = Math.abs(Math.cos((since / 0.14) * Math.PI)); // 1 -> 0 -> 1
      } else {
        this.blink = 1;
        this._blinkTimer = 2 + Math.random() * 4;
      }
    } else {
      this.blink = 1;
    }
  }

  /** Snapshot of everything sprites.js needs to draw a frame. */
  frame() {
    return {
      name: this.name,
      pose: this.pose,
      bobY: this.bobY,
      hopY: this.hopY,
      legPhase: this.legPhase,
      tailWag: this.tailWag,
      breath: this.breath,
      blink: this.blink,
    };
  }
}
