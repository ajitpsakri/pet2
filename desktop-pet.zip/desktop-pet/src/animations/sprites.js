/**
 * sprites.js
 * ----------------------------------------------------------------------------
 * Draws the creature on a 2D canvas from the pose produced by Animator. Pure
 * canvas paths — no image files — so the whole pet ships inside the JS bundle
 * and works with zero assets / zero network.
 *
 * Everything is drawn in a local space centred on the creature; the caller is
 * responsible for translating to the on-screen position. The base creature is
 * ~64px tall at scale 1.
 */

const PALETTE = {
  body: '#6fd3c7',
  bodyDark: '#4bb3a6',
  belly: '#d8f5f0',
  ear: '#5cc4b7',
  outline: '#2d6b63',
  cheek: '#ff9aa2',
  eye: '#23423d',
  white: '#ffffff',
};

const SICK_TINT = '#a9c6a0';

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {object} opts { x, y, scale, facing, frame, accessory, mood }
 */
export function drawPet(ctx, opts) {
  const { x, y, scale = 1, facing = 1, frame, accessory = 'none', mood } = opts;
  const f = frame;
  const sick = mood === 'sick';
  const body = sick ? SICK_TINT : PALETTE.body;

  ctx.save();
  ctx.translate(x, y + f.hopY);
  ctx.scale(facing * scale, scale);
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = PALETTE.outline;
  ctx.lineJoin = 'round';

  // --- soft contact shadow (drawn in screen space, not flipped vertically) --
  ctx.save();
  ctx.scale(1, 1);
  ctx.globalAlpha = 0.18;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(0, 30 - f.hopY, 22, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Apply lean + vertical bob for the whole body.
  ctx.rotate(f.pose.lean);
  ctx.translate(0, f.bobY);

  // --- tail (behind body) ---
  ctx.save();
  ctx.translate(-16, 8);
  ctx.rotate(f.tailWag);
  ctx.fillStyle = PALETTE.bodyDark;
  ctx.beginPath();
  ctx.ellipse(-6, 0, 9, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  // --- back legs / feet (simple, animate with legPhase) ---
  const legSwing = f.legPhase * 6;
  ctx.fillStyle = PALETTE.bodyDark;
  for (const [lx, dir] of [[-9, 1], [9, -1]]) {
    ctx.save();
    ctx.translate(lx, 22 + legSwing * dir * 0.3);
    ctx.beginPath();
    ctx.ellipse(0, 0, 6, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // --- body ---
  const droop = f.pose.droop;
  ctx.fillStyle = body;
  ctx.beginPath();
  ctx.ellipse(0, 6 + droop * 4, 20, 22 - droop * 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // belly
  ctx.fillStyle = PALETTE.belly;
  ctx.beginPath();
  ctx.ellipse(0, 12 + droop * 3, 12, 13, 0, 0, Math.PI * 2);
  ctx.fill();

  // --- ears ---
  const perk = f.pose.earPerk;
  ctx.fillStyle = sick ? SICK_TINT : PALETTE.ear;
  for (const side of [-1, 1]) {
    ctx.save();
    ctx.translate(side * 11, -14);
    ctx.rotate(side * (0.5 - perk * 0.6));
    ctx.beginPath();
    ctx.moveTo(0, 6);
    ctx.quadraticCurveTo(side * 3, -12, side * 9, -6);
    ctx.quadraticCurveTo(side * 4, 2, 0, 6);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // --- head/face region (the body top doubles as the face) ---
  // eyes
  const eo = f.pose.eyeOpen;
  ctx.fillStyle = PALETTE.eye;
  for (const ex of [-7, 7]) {
    if (eo < 0.12) {
      // closed -> gentle arc
      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = PALETTE.eye;
      ctx.arc(ex, -2, 3.4, 0.15 * Math.PI, 0.85 * Math.PI);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.ellipse(ex, -2, 3, 3.6 * eo, 0, 0, Math.PI * 2);
      ctx.fill();
      // catch-light
      ctx.fillStyle = PALETTE.white;
      ctx.beginPath();
      ctx.arc(ex + 1, -3.4 * eo, 1, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = PALETTE.eye;
    }
  }

  // cheeks / blush
  if (f.pose.blush > 0.02) {
    ctx.globalAlpha = f.pose.blush * 0.8;
    ctx.fillStyle = PALETTE.cheek;
    for (const cx of [-11, 11]) {
      ctx.beginPath();
      ctx.ellipse(cx, 3, 3.5, 2.2, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // mouth
  const mo = f.pose.mouthOpen;
  ctx.strokeStyle = PALETTE.eye;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  if (mo > 0.15) {
    ctx.fillStyle = '#bf5b63';
    ctx.ellipse(0, 6, 2.6 + mo * 2, 1.6 + mo * 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (droop > 0.5) {
    ctx.arc(0, 9, 3, 1.15 * Math.PI, 1.85 * Math.PI); // frown
    ctx.stroke();
  } else {
    ctx.arc(0, 4, 3, 0.15 * Math.PI, 0.85 * Math.PI); // smile
    ctx.stroke();
  }

  drawAccessory(ctx, accessory, f);

  ctx.restore();
}

/** Overlay an unlockable accessory anchored to the head/body. */
function drawAccessory(ctx, id, f) {
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = PALETTE.outline;
  switch (id) {
    case 'bowtie':
      ctx.fillStyle = '#e4572e';
      ctx.beginPath();
      ctx.moveTo(0, 18);
      ctx.lineTo(-7, 14);
      ctx.lineTo(-7, 22);
      ctx.closePath();
      ctx.moveTo(0, 18);
      ctx.lineTo(7, 14);
      ctx.lineTo(7, 22);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 18, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = '#b8431f';
      ctx.fill();
      break;
    case 'glasses':
      ctx.strokeStyle = '#222';
      ctx.lineWidth = 1.6;
      for (const gx of [-7, 7]) {
        ctx.beginPath();
        ctx.arc(gx, -2, 4.6, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(-2.4, -2);
      ctx.lineTo(2.4, -2);
      ctx.stroke();
      break;
    case 'tophat':
      ctx.fillStyle = '#222';
      rr(ctx, -10, -26, 20, 4, 2); // brim
      ctx.fill();
      ctx.stroke();
      rr(ctx, -7, -40, 14, 16, 2); // crown
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = '#e4572e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-7, -28);
      ctx.lineTo(7, -28);
      ctx.stroke();
      break;
    case 'party':
      ctx.fillStyle = '#ffb703';
      ctx.beginPath();
      ctx.moveTo(0, -40);
      ctx.lineTo(-9, -22);
      ctx.lineTo(9, -22);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fb8500';
      ctx.beginPath();
      ctx.arc(0, -40, 2.4, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'cape':
      ctx.fillStyle = '#c1121f';
      ctx.beginPath();
      ctx.moveTo(-14, -4);
      ctx.quadraticCurveTo(-20, 24, -8, 30 + f.tailWag * 4);
      ctx.lineTo(8, 30 - f.tailWag * 4);
      ctx.quadraticCurveTo(20, 24, 14, -4);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    default:
      break; // 'none'
  }
  ctx.restore();
}
