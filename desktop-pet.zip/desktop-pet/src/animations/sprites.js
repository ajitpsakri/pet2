/**
 * sprites.js
 * ----------------------------------------------------------------------------
 * Draws the companion — a cute golden puppy — on a 2D canvas from the pose
 * produced by Animator. Pure canvas paths, no image files, so the whole dog
 * ships inside the JS and works with zero assets / zero network.
 *
 * Everything is drawn in a local space centred on the dog; the caller
 * translates to the on-screen position. The dog is ~70px tall at scale 1.
 *
 * Expression is driven by the smoothly-interpolated pose (eyeOpen, mouthOpen,
 * earPerk, blush, lean, droop) PLUS the current animation name and mood, which
 * together pick eyebrow angle, tongue, and (for a playful "bark") tiny teeth —
 * so the dog can look happy, sad, sleepy, sick, or feisty, all still cute.
 *
 * GEOM and PALETTE are exported so an offline preview renderer can mirror the
 * exact proportions without duplicating numbers.
 */

export const PALETTE = {
  body: '#edae5b',
  bodyDark: '#d9933f',
  belly: '#fff2d8', // cream chest + muzzle
  ear: '#c97f33',
  outline: '#7c4a22',
  nose: '#3a2820',
  eye: '#241712',
  cheek: '#ff9aa2',
  tongue: '#fb6f86',
  white: '#ffffff',
};

const SICK_TINT = '#bcc08a';

/** Key proportions (local space; +y is down). Shared with the preview tool. */
export const GEOM = {
  shadowY: 33,
  body: { cx: 0, cy: 13, rx: 18, ry: 19 },
  belly: { cx: 0, cy: 17, rx: 11, ry: 13 },
  head: { cx: 0, cy: -11, rx: 16, ry: 15 },
  eye: { dx: 6.5, y: -12, r: 3.1 },
  brow: { dx: 6.5, y: -18 },
  snout: { cx: 0, cy: -5, rx: 9, ry: 7 },
  nose: { cx: 0, cy: -8, rx: 3.2, ry: 2.5 },
  earPivot: { dx: 12, y: -20 },
  cheek: { dx: 11.5, y: -5 },
};

/** Ellipse containment test in local model space. */
function inEllipse(lx, ly, cx, cy, rx, ry) {
  const a = (lx - cx) / rx;
  const b = (ly - cy) / ry;
  return a * a + b * b <= 1;
}

/**
 * Which body part is at local point (lx, ly)? Local space is the un-scaled,
 * facing-normalized model space (same coordinates as GEOM). Returns one of
 * 'ear' | 'snout' | 'head' | 'tail' | 'belly' | 'back', or null if outside.
 * Pure and exported so the petting interaction can be unit-tested.
 */
export function regionAt(lx, ly) {
  // Ears hang at the top sides of the head — check before head.
  if (ly < -12 && ly > -28 && Math.abs(lx) >= 7 && Math.abs(lx) <= 22) return 'ear';
  // Snout/nose sit low-center on the face — check before the broader head.
  if (inEllipse(lx, ly, GEOM.snout.cx, GEOM.snout.cy, GEOM.snout.rx + 1, GEOM.snout.ry + 1)) return 'snout';
  if (inEllipse(lx, ly, GEOM.head.cx, GEOM.head.cy, GEOM.head.rx, GEOM.head.ry)) return 'head';
  // Tail is drawn behind the body at roughly (-15, 6) reaching back/up.
  if (lx < -13 && ly > -12 && ly < 14) return 'tail';
  // Body: lower-front is the belly, upper is the back.
  if (inEllipse(lx, ly, GEOM.body.cx, GEOM.body.cy, GEOM.body.rx, GEOM.body.ry)) {
    return ly >= 12 ? 'belly' : 'back';
  }
  if (inEllipse(lx, ly, GEOM.belly.cx, GEOM.belly.cy, GEOM.belly.rx, GEOM.belly.ry)) return 'belly';
  return null;
}

function rr(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/**
 * Pick an eyebrow angle (radians, applied mirrored per side) and whether to
 * show teeth, from the animation name + mood. Furrowed inner-down brows read as
 * "feisty/alert"; outer-down brows read as "worried/sad".
 *  > 0  => inner ends down  (determined, feisty)
 *  < 0  => outer ends down  (worried, sad)
 */
function expressionFor(name, mood, droop) {
  const feisty = name === 'bark' || name === 'excited' || mood === 'excited';
  const worried = mood === 'sad' || mood === 'sick' || droop > 0.5;
  let brow = 0;
  if (feisty) brow = 0.5;
  else if (worried) brow = -0.45;
  const teeth = name === 'bark';
  return { brow, teeth, feisty };
}

/**
 * @param {CanvasRenderingContext2D} ctx
 * @param {object} opts { x, y, scale, facing, frame, accessory, mood }
 */
export function drawPet(ctx, opts) {
  const { x, y, scale = 1, facing = 1, frame, accessory = 'none', mood } = opts;
  const f = frame;
  const sick = mood === 'sick';
  const bodyCol = sick ? SICK_TINT : PALETTE.body;
  const earCol = sick ? SICK_TINT : PALETTE.ear;
  const expr = expressionFor(f.name, mood, f.pose.droop);
  const breath = (f.breath || 0) * (opts.reduceMotion ? 0 : 1);
  const blink = f.blink == null ? 1 : f.blink;
  const shScale = opts.shadowScale || 1;
  const shAlpha = opts.shadowAlpha == null ? 0.18 : opts.shadowAlpha;

  ctx.save();
  ctx.translate(x, y + f.hopY);

  // --- soft contact shadow (screen space, before facing/lean) --------------
  ctx.save();
  ctx.globalAlpha = shAlpha;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(0, GEOM.shadowY - f.hopY * 0.6, 23 * shScale, 6 * shScale, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.scale(facing * scale, scale);
  ctx.lineWidth = 2.4;
  ctx.strokeStyle = PALETTE.outline;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  ctx.rotate(f.pose.lean);
  ctx.translate(0, f.bobY);
  // Breathing: a tiny, ever-present body scale so the dog never looks frozen.
  ctx.scale(1 + breath * 0.4, 1 + breath);

  const droop = f.pose.droop;

  // --- tail (behind body), wags ---
  ctx.save();
  ctx.translate(-15, 6);
  ctx.rotate(-0.5 + f.tailWag * 1.2 - droop * 0.6);
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-10, -2, -16, -10);
  ctx.quadraticCurveTo(-9, -1, -2, 5);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  // --- hind legs / paws (animate subtly with legPhase) ---
  const swing = f.legPhase * 5;
  ctx.fillStyle = bodyCol;
  for (const [lx, dir] of [[-12, 1], [12, -1]]) {
    ctx.save();
    ctx.translate(lx, 27 + swing * dir * 0.25);
    ctx.beginPath();
    ctx.ellipse(0, 0, 6.5, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // --- body ---
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.ellipse(GEOM.body.cx, GEOM.body.cy + droop * 3, GEOM.body.rx, GEOM.body.ry - droop * 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // chest / belly
  ctx.fillStyle = PALETTE.belly;
  ctx.beginPath();
  ctx.ellipse(GEOM.belly.cx, GEOM.belly.cy + droop * 2, GEOM.belly.rx, GEOM.belly.ry, 0, 0, Math.PI * 2);
  ctx.fill();

  // --- front paws (in front of body) ---
  ctx.fillStyle = PALETTE.belly;
  for (const px of [-7, 7]) {
    ctx.beginPath();
    ctx.ellipse(px, 30, 6, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  // --- ears (behind head), floppy; earPerk lifts the tips ---
  const perk = f.pose.earPerk;
  ctx.fillStyle = earCol;
  for (const side of [-1, 1]) {
    ctx.save();
    ctx.translate(side * GEOM.earPivot.dx, GEOM.earPivot.y);
    // hang down by default; lift outward as perk increases
    ctx.rotate(side * (0.7 - perk * 0.9));
    ctx.beginPath();
    ctx.moveTo(0, -2);
    ctx.quadraticCurveTo(side * 11, 2, side * 8, 18);
    ctx.quadraticCurveTo(side * 2, 16, 0, 8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }

  // --- head ---
  ctx.fillStyle = bodyCol;
  ctx.beginPath();
  ctx.ellipse(GEOM.head.cx, GEOM.head.cy, GEOM.head.rx, GEOM.head.ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // muzzle / snout (cream)
  ctx.fillStyle = PALETTE.belly;
  ctx.beginPath();
  ctx.ellipse(GEOM.snout.cx, GEOM.snout.cy, GEOM.snout.rx, GEOM.snout.ry, 0, 0, Math.PI * 2);
  ctx.fill();

  // --- eyes ---
  const eo = f.pose.eyeOpen * blink;
  for (const sx of [-1, 1]) {
    const ex = sx * GEOM.eye.dx;
    if (eo < 0.12) {
      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = PALETTE.eye;
      ctx.arc(ex, GEOM.eye.y, 3.4, 0.15 * Math.PI, 0.85 * Math.PI);
      ctx.stroke();
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = PALETTE.outline;
    } else {
      ctx.fillStyle = PALETTE.eye;
      ctx.beginPath();
      ctx.ellipse(ex, GEOM.eye.y, GEOM.eye.r, GEOM.eye.r * 1.15 * eo, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = PALETTE.white;
      ctx.beginPath();
      ctx.arc(ex + sx * 1, GEOM.eye.y - 1.4 * eo, 1.1, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // --- eyebrows (expression) ---
  if (Math.abs(expr.brow) > 0.01 && eo >= 0.12) {
    ctx.strokeStyle = PALETTE.outline;
    ctx.lineWidth = 1.8;
    for (const sx of [-1, 1]) {
      const bx = sx * GEOM.brow.dx;
      // inner point toward centre, outer away; brow>0 => inner lower (furrow)
      const inner = [bx - sx * 2.4, GEOM.brow.y + expr.brow * 2];
      const outer = [bx + sx * 2.4, GEOM.brow.y - expr.brow * 2];
      ctx.beginPath();
      ctx.moveTo(inner[0], inner[1]);
      ctx.lineTo(outer[0], outer[1]);
      ctx.stroke();
    }
    ctx.lineWidth = 2.4;
  }

  // --- nose ---
  ctx.fillStyle = PALETTE.nose;
  ctx.beginPath();
  ctx.ellipse(GEOM.nose.cx, GEOM.nose.cy, GEOM.nose.rx, GEOM.nose.ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.5)';
  ctx.beginPath();
  ctx.arc(GEOM.nose.cx - 1, GEOM.nose.cy - 1, 0.8, 0, Math.PI * 2);
  ctx.fill();

  // --- blush ---
  if (f.pose.blush > 0.02) {
    ctx.globalAlpha = f.pose.blush * 0.8;
    ctx.fillStyle = PALETTE.cheek;
    for (const sx of [-1, 1]) {
      ctx.beginPath();
      ctx.ellipse(sx * GEOM.cheek.dx, GEOM.cheek.y, 3.6, 2.3, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // --- mouth + tongue ---
  const mo = f.pose.mouthOpen;
  const ny = GEOM.nose.cy + GEOM.nose.ry;
  ctx.strokeStyle = PALETTE.outline;
  ctx.lineWidth = 1.8;
  if (mo > 0.18) {
    // open mouth
    ctx.fillStyle = '#7a3b3b';
    ctx.beginPath();
    ctx.ellipse(0, ny + 3 + mo * 1.5, 3 + mo * 2.2, 2 + mo * 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // tongue (panting / happy)
    if (mo > 0.3 || expr.feisty) {
      ctx.fillStyle = PALETTE.tongue;
      ctx.beginPath();
      ctx.ellipse(0, ny + 5 + mo * 2, 2.2 + mo, 2.4 + mo * 2.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
    // tiny teeth for a playful bark
    if (expr.teeth) {
      ctx.fillStyle = PALETTE.white;
      for (const tx of [-2.2, 2.2]) {
        ctx.beginPath();
        ctx.moveTo(tx - 1.2, ny + 1.5);
        ctx.lineTo(tx + 1.2, ny + 1.5);
        ctx.lineTo(tx, ny + 4);
        ctx.closePath();
        ctx.fill();
      }
    }
  } else {
    // closed: a gentle two-arc puppy smile under the nose
    ctx.beginPath();
    ctx.arc(-2.6, ny + 1, 2.8, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(2.6, ny + 1, 2.8, 0.1 * Math.PI, 0.9 * Math.PI);
    ctx.stroke();
  }
  ctx.lineWidth = 2.4;

  drawAccessory(ctx, accessory, f);

  ctx.restore();
}

/** Overlay an unlockable accessory anchored to the head/neck. */
function drawAccessory(ctx, id, f) {
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = PALETTE.outline;
  switch (id) {
    case 'bowtie':
      ctx.fillStyle = '#e4572e';
      ctx.beginPath();
      ctx.moveTo(0, 22);
      ctx.lineTo(-7, 18);
      ctx.lineTo(-7, 26);
      ctx.closePath();
      ctx.moveTo(0, 22);
      ctx.lineTo(7, 18);
      ctx.lineTo(7, 26);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 22, 2.2, 0, Math.PI * 2);
      ctx.fillStyle = '#b8431f';
      ctx.fill();
      break;
    case 'glasses':
      ctx.strokeStyle = '#222';
      ctx.lineWidth = 1.6;
      for (const gx of [-6.5, 6.5]) {
        ctx.beginPath();
        ctx.arc(gx, -12, 4.6, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(-2, -12);
      ctx.lineTo(2, -12);
      ctx.stroke();
      break;
    case 'tophat':
      ctx.fillStyle = '#222';
      rr(ctx, -12, -30, 24, 4, 2); // brim
      ctx.fill();
      ctx.stroke();
      rr(ctx, -8, -44, 16, 16, 2); // crown
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = '#e4572e';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-8, -32);
      ctx.lineTo(8, -32);
      ctx.stroke();
      break;
    case 'party':
      ctx.fillStyle = '#ffb703';
      ctx.beginPath();
      ctx.moveTo(0, -46);
      ctx.lineTo(-10, -26);
      ctx.lineTo(10, -26);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fb8500';
      ctx.beginPath();
      ctx.arc(0, -46, 2.6, 0, Math.PI * 2);
      ctx.fill();
      break;
    case 'cape':
      ctx.fillStyle = '#c1121f';
      ctx.beginPath();
      ctx.moveTo(-15, 0);
      ctx.quadraticCurveTo(-22, 26, -9, 32 + f.tailWag * 4);
      ctx.lineTo(9, 32 - f.tailWag * 4);
      ctx.quadraticCurveTo(22, 26, 15, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      break;
    default:
      break;
  }
  ctx.restore();
}
