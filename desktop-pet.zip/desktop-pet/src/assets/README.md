# assets/

Intentionally (almost) empty.

The pet is **drawn procedurally** on an HTML canvas (see `src/animations/sprites.js`),
so there are no sprite sheets, images, or audio files to ship — which is part of
how the app stays fully offline and self-contained. Sounds are synthesized at
runtime with the Web Audio API (`src/ui/Sound.js`).

Drop your own PNGs/audio here only if you decide to swap the procedural art for
image-based sprites.
