/**
 * constants.js
 * ----------------------------------------------------------------------------
 * Central place for all tuning values. Keeping these in one module makes the
 * simulation easy to balance without hunting through the codebase.
 *
 * This module is imported by the *renderer* (ES module) only. The main process
 * deliberately knows nothing about game balance — it only persists raw bytes.
 */

// ---------------------------------------------------------------------------
// Needs / stats
// ---------------------------------------------------------------------------

/** All the 0..100 needs the pet tracks. Order here drives the dashboard order. */
export const NEEDS = [
  'hunger',
  'thirst',
  'happiness',
  'energy',
  'cleanliness',
  'health',
  'affection',
];

/**
 * Natural decay per real second for each need (points / second).
 * Tuned so the pet is comfortable for hours of light attention rather than
 * demanding constant babysitting — it should never feel like a chore.
 */
export const DECAY_PER_SEC = {
  hunger: 100 / (6 * 3600), // ~empty after 6h untended
  thirst: 100 / (4 * 3600), // thirst drops a bit faster than hunger
  happiness: 100 / (8 * 3600),
  energy: 100 / (10 * 3600), // energy drains slowly while awake
  cleanliness: 100 / (12 * 3600),
  affection: 100 / (9 * 3600),
  // health is derived/affected by other needs rather than decaying directly
  health: 0,
};

/** Energy *regenerates* while the pet is asleep (points / second). */
export const ENERGY_REGEN_PER_SEC = 100 / (45 * 60); // full recharge ~45 min asleep

/**
 * Health logic: health slowly drifts toward a target computed from the other
 * needs. If the pet is starving/filthy it gets sick; if well cared for it heals.
 */
export const HEALTH_DRIFT_PER_SEC = 100 / (60 * 60); // up to full swing over ~1h
export const SICK_THRESHOLD = 35; // health below this => "sick" behaviours

// ---------------------------------------------------------------------------
// Interactions — how much each action changes needs
// ---------------------------------------------------------------------------

export const FOODS = {
  kibble: { label: 'Kibble', hunger: 25, happiness: 3, emoji: '🍖' },
  fish: { label: 'Fish', hunger: 35, happiness: 6, emoji: '🐟' },
  veggies: { label: 'Veggies', hunger: 18, happiness: 1, health: 4, emoji: '🥦' },
  feast: { label: 'Feast', hunger: 60, happiness: 10, emoji: '🍱', unlockLevel: 5 },
};

export const TREATS = {
  cookie: { label: 'Cookie', happiness: 12, affection: 4, emoji: '🍪' },
  candy: { label: 'Candy', happiness: 18, affection: 2, energy: 6, emoji: '🍬' },
};

export const INTERACTION_EFFECTS = {
  water: { thirst: 40, emoji: '💧' },
  pet: { affection: 8, happiness: 5 },
  play: { happiness: 15, affection: 6, energy: -8 },
  clean: { cleanliness: 60, happiness: 4 },
  sleepTick: {}, // handled via ENERGY_REGEN_PER_SEC
};

// ---------------------------------------------------------------------------
// Experience & leveling
// ---------------------------------------------------------------------------

export const XP = {
  feed: 6,
  water: 3,
  pet: 4,
  play: 10,
  clean: 5,
  treat: 4,
  perMinuteAlive: 1,
};

/** XP required to advance FROM the given level (index 0 == level 1). */
export function xpForLevel(level) {
  // Gentle quadratic curve: 100, 250, 450, 700, ...
  return Math.round(50 * level * (level + 1));
}

// ---------------------------------------------------------------------------
// Unlocks keyed by level
// ---------------------------------------------------------------------------

export const ACCESSORIES = {
  none: { label: 'None', unlockLevel: 1 },
  bowtie: { label: 'Bow Tie', unlockLevel: 2, type: 'neck' },
  glasses: { label: 'Glasses', unlockLevel: 3, type: 'face' },
  tophat: { label: 'Top Hat', unlockLevel: 4, type: 'head' },
  party: { label: 'Party Hat', unlockLevel: 6, type: 'head' },
  cape: { label: 'Hero Cape', unlockLevel: 8, type: 'body' },
};

// ---------------------------------------------------------------------------
// Mood engine
// ---------------------------------------------------------------------------

/**
 * Moods are evaluated in priority order — the first matching rule wins. This is
 * more expressive than a single numeric sum because a pet can be "well fed but
 * exhausted". The raw sum is still exposed for the dashboard.
 */
export const MOODS = [
  'sick',
  'sleepy',
  'lonely',
  'hungry',
  'thirsty',
  'bored',
  'sad',
  'relaxed',
  'happy',
  'excited',
];

// ---------------------------------------------------------------------------
// Behaviour / timing (milliseconds unless noted)
// ---------------------------------------------------------------------------

export const TICK_MS = 1000; // simulation tick (needs decay) — 1Hz is plenty
export const SAVE_INTERVAL_MS = 60 * 1000; // autosave cadence
export const SPEECH_MIN_GAP_MS = 25 * 1000; // don't nag: min gap between idle lines
export const SPEECH_CHANCE = 0.18; // probability of an idle line when eligible
export const BEHAVIOR_MIN_MS = 4000; // min duration of an autonomous behaviour
export const BEHAVIOR_MAX_MS = 12000; // max duration before picking a new one

/** Movement speeds in pixels / second. */
export const SPEED = { walk: 35, run: 120, chase: 90 };

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

export const DEFAULT_SETTINGS = {
  scale: 1.0, // pet size multiplier (0.5 .. 2.0)
  opacity: 1.0, // 0.2 .. 1.0
  volume: 0.5, // 0 .. 1 (reserved for sound; offline beeps via WebAudio)
  animationSpeed: 1.0, // 0.5 .. 2.0
  alwaysOnTop: true,
  // When false (default) the pet body captures clicks so you can interact with
  // it; empty desktop space is ALWAYS click-through either way. When true the
  // pet becomes purely decorative (interact via the tray only).
  clickThrough: false,
  startOnBoot: false,
  muted: true, // start muted so we never surprise an office
  ambiance: true, // soft day/night glow + dynamic shadow around the dog
  localAI: false, // OPT-IN: use a local Ollama model to phrase lines (localhost only)
};

export const SETTINGS_BOUNDS = {
  scale: [0.5, 2.0],
  opacity: [0.2, 1.0],
  volume: [0.0, 1.0],
  animationSpeed: [0.5, 2.0],
};
