/**
 * core/Clock.js
 * ----------------------------------------------------------------------------
 * The single source of "what time is it and how much time passed". Keeps the
 * frame delta in one place (so every system sees a consistent, sanitised dt)
 * and exposes coarse time-of-day context used by the companion's personality.
 *
 * Pure and dependency-free so it is trivial to unit test with an injected
 * `nowFn` instead of the real wall clock.
 */

export class Clock {
  /**
   * @param {() => number} [nowFn] returns ms since epoch (injectable for tests)
   * @param {number} [maxDt] clamp for the per-frame delta, seconds
   */
  constructor(nowFn = Date.now, maxDt = 0.5) {
    this._now = nowFn;
    this._maxDt = maxDt;
    this._last = this._now();
    this._bucket = this.bucket();
  }

  /**
   * Advance the clock to the current instant and return the elapsed seconds
   * since the previous call, clamped so a backgrounded tab can't produce a
   * giant jump that destabilises the simulation.
   * @returns {number} dt in seconds (>= 0)
   */
  tick() {
    const now = this._now();
    let dt = (now - this._last) / 1000;
    this._last = now;
    if (!Number.isFinite(dt) || dt < 0) dt = 0;
    if (dt > this._maxDt) dt = this._maxDt;
    return dt;
  }

  /** Current epoch ms. */
  now() {
    return this._now();
  }

  /**
   * Coarse part-of-day label. Deliberately blunt — used for greetings and
   * gentle context, never for surveillance.
   * @param {Date} [d]
   * @returns {'morning'|'day'|'evening'|'late'}
   */
  bucket(d = new Date(this._now())) {
    const h = d.getHours();
    if (h >= 5 && h < 12) return 'morning';
    if (h >= 12 && h < 17) return 'day';
    if (h >= 17 && h < 22) return 'evening';
    return 'late';
  }

  /** True on Saturday/Sunday. */
  isWeekend(d = new Date(this._now())) {
    const day = d.getDay();
    return day === 0 || day === 6;
  }

  /** YYYY-MM-DD in local time — the key used for daily streaks/rollups. */
  dayKey(d = new Date(this._now())) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /**
   * If the part-of-day bucket changed since the last call, return the new one
   * (otherwise null). Lets the bootstrapper emit a `context:bucket` event.
   */
  bucketChanged() {
    const b = this.bucket();
    if (b !== this._bucket) {
      this._bucket = b;
      return b;
    }
    return null;
  }
}
