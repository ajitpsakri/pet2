/**
 * core/EventBus.js
 * ----------------------------------------------------------------------------
 * A tiny synchronous publish/subscribe hub. Systems never reference each other
 * directly — they emit named events and subscribe to the ones they care about.
 * This is the only coupling between systems, which is what lets us add a dozen
 * features without `renderer.js` turning into a wiring nightmare.
 *
 * Design notes:
 *   • `on()` returns an unsubscribe function (so callers don't need to keep a
 *     reference to the exact handler to remove it).
 *   • Handlers are snapshotted before dispatch, so a handler may safely
 *     subscribe/unsubscribe during emit without corrupting the iteration.
 *   • One throwing handler never prevents the others from running.
 */

export class EventBus {
  constructor() {
    /** @type {Map<string, Set<Function>>} */
    this._map = new Map();
  }

  /**
   * Subscribe to an event.
   * @param {string} type
   * @param {(payload:any, type:string) => void} fn
   * @returns {() => void} unsubscribe
   */
  on(type, fn) {
    if (typeof fn !== 'function') throw new TypeError('handler must be a function');
    let set = this._map.get(type);
    if (!set) {
      set = new Set();
      this._map.set(type, set);
    }
    set.add(fn);
    return () => this.off(type, fn);
  }

  /** Subscribe for a single delivery, then auto-unsubscribe. */
  once(type, fn) {
    const off = this.on(type, (payload, t) => {
      off();
      fn(payload, t);
    });
    return off;
  }

  /** Remove a specific handler. */
  off(type, fn) {
    const set = this._map.get(type);
    if (set) {
      set.delete(fn);
      if (set.size === 0) this._map.delete(type);
    }
  }

  /**
   * Emit an event to all subscribers of `type` and all wildcard `*` listeners.
   * @param {string} type
   * @param {any} [payload]
   */
  emit(type, payload) {
    const direct = this._map.get(type);
    if (direct) {
      for (const fn of [...direct]) this._safe(fn, payload, type);
    }
    const wild = this._map.get('*');
    if (wild) {
      for (const fn of [...wild]) this._safe(fn, payload, type);
    }
  }

  _safe(fn, payload, type) {
    try {
      fn(payload, type);
    } catch (err) {
      // Never let one bad listener break dispatch to the rest.
      console.error(`[EventBus] handler for "${type}" threw:`, err);
    }
  }

  /** Drop every listener (used on teardown). */
  clear() {
    this._map.clear();
  }
}
