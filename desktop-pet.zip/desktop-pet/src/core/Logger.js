/**
 * core/Logger.js
 * ----------------------------------------------------------------------------
 * Lightweight diagnostics so that when something goes wrong, you can SEE it
 * instead of staring at a frozen pet. Keeps a capped in-memory ring buffer of
 * recent log lines, captures uncaught errors and promise rejections, and
 * (optionally) forwards lines to the main process to be written to a log file.
 *
 * The buffer logic is pure and unit-tested; the global hooks are installed only
 * in the browser/renderer via install().
 */

export class Logger {
  /** @param {number} [capacity] max retained lines */
  constructor(capacity = 300) {
    this.capacity = capacity;
    this.entries = [];
    this._sinks = [];
  }

  /** Add a sink (e.g. forward to main for file logging). */
  addSink(fn) {
    if (typeof fn === 'function') this._sinks.push(fn);
  }

  record(level, ...args) {
    const msg = args
      .map((a) => {
        if (a instanceof Error) return `${a.message}\n${a.stack || ''}`;
        if (typeof a === 'object') {
          try { return JSON.stringify(a); } catch { return String(a); }
        }
        return String(a);
      })
      .join(' ');
    const entry = { t: Date.now(), level, msg };
    this.entries.push(entry);
    if (this.entries.length > this.capacity) this.entries.shift();
    for (const s of this._sinks) {
      try { s(entry); } catch { /* never let logging break the app */ }
    }
    return entry;
  }

  info(...a) { return this.record('info', ...a); }
  warn(...a) { return this.record('warn', ...a); }
  error(...a) { return this.record('error', ...a); }

  /** Recent entries, newest last. */
  recent(n = 50) {
    return this.entries.slice(-n);
  }

  /** A copy-pasteable diagnostics dump. */
  dump() {
    return this.entries
      .map((e) => `[${new Date(e.t).toISOString()}] ${e.level.toUpperCase()}: ${e.msg}`)
      .join('\n');
  }

  /** Install global capture in the renderer. Safe to call once. */
  install(globalObj = typeof window !== 'undefined' ? window : null) {
    if (!globalObj || this._installed) return;
    this._installed = true;

    const origError = (globalObj.console && globalObj.console.error) || (() => {});
    if (globalObj.console) {
      globalObj.console.error = (...args) => {
        this.record('error', ...args);
        origError.apply(globalObj.console, args);
      };
    }
    globalObj.addEventListener &&
      globalObj.addEventListener('error', (e) => {
        this.record('error', e.message || 'window error', e.filename ? `(${e.filename}:${e.lineno})` : '');
      });
    globalObj.addEventListener &&
      globalObj.addEventListener('unhandledrejection', (e) => {
        this.record('error', 'Unhandled promise rejection:', e.reason || e);
      });
  }
}
