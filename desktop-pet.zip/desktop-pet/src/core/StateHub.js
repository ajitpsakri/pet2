/**
 * core/StateHub.js
 * ----------------------------------------------------------------------------
 * The single owner of the persisted save model in the renderer. It loads and
 * migrates the save on boot, and assembles a fresh snapshot on demand by
 * letting every registered system write its own slice. Unknown/future keys in
 * the loaded file are preserved across a save cycle, so a newer build's data
 * survives being opened by an older one.
 *
 * Actual disk I/O stays in the main process (via window.petAPI); this class is
 * pure orchestration so it can be unit tested with a fake api.
 */

import { SCHEMA_VERSION, migrate } from '../storage/schema.js';

export class StateHub {
  /** @param {object|null} api window.petAPI (or null when running headless/tests) */
  constructor(api) {
    this.api = api || null;
    /** the migrated, current-version save root */
    this.root = null;
  }

  /** Load + migrate the save. Falls back to a fresh default on any failure. */
  async load() {
    let raw = null;
    try {
      raw = this.api ? await this.api.loadState() : null;
    } catch (err) {
      console.error('[StateHub] load failed, starting fresh:', err);
    }
    this.root = migrate(raw);
    return this.root;
  }

  /**
   * Build a complete, current-version save object from the registry. Starts
   * from a shallow clone of the last-known root (to keep analytics + any
   * unknown keys) and lets each system overwrite its own slice.
   * @param {import('./SystemRegistry.js').SystemRegistry} registry
   * @param {object} extra additional top-level slices (e.g. { settings })
   */
  snapshot(registry, extra = {}) {
    const base = this.root ? { ...this.root } : {};
    base.systems = { ...(base.systems || {}) }; // preserve slices of systems not re-serialized this cycle
    const snap = { ...base, ...extra, version: SCHEMA_VERSION };
    registry.serializeInto(snap);
    // Remember it so the next snapshot continues to preserve unknown keys.
    this.root = snap;
    return snap;
  }
}
