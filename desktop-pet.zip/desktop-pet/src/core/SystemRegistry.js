/**
 * core/SystemRegistry.js
 * ----------------------------------------------------------------------------
 * Owns the lifecycle of every System: registration, init, per-tick dispatch,
 * context fan-out, save/restore, and — crucially — clean disposal so no system
 * can leak a timer or listener. Adding a feature in a later phase is one
 * `register()` call; the loop and persistence pick it up automatically.
 */

export class SystemRegistry {
  constructor() {
    /** @type {import('../systems/System.js').System[]} */
    this._systems = [];
    this._byId = new Map();
    this._inited = false;
  }

  /**
   * Register a system instance. Must be called before init().
   * @param {import('../systems/System.js').System} system
   */
  register(system) {
    const id = system.constructor.id;
    if (!id) throw new Error('System is missing a static `id`');
    if (this._byId.has(id)) throw new Error(`Duplicate system id: ${id}`);
    this._systems.push(system);
    this._byId.set(id, system);
    if (this._inited && typeof system.init === 'function') system.init();
    return system;
  }

  /** Look up a registered system by its static id. */
  get(id) {
    return this._byId.get(id) || null;
  }

  /** All registered systems, in registration order. */
  all() {
    return [...this._systems];
  }

  /** Call init() on every system once. */
  init() {
    this._inited = true;
    for (const s of this._systems) {
      if (typeof s.init === 'function') s.init();
    }
  }

  /** Restore each system's slice from a migrated save root. */
  hydrateAll(root) {
    for (const s of this._systems) {
      if (typeof s.hydrateFrom === 'function') s.hydrateFrom(root);
    }
  }

  /** Let each system write its slice into a save root being assembled. */
  serializeInto(root) {
    for (const s of this._systems) {
      if (typeof s.serializeInto === 'function') s.serializeInto(root);
    }
    return root;
  }

  /**
   * Advance every system's logic.
   * @param {number} dt seconds
   * @param {number} now epoch ms
   * @param {object} [frame] shared per-frame context (e.g. { cursor })
   */
  tick(dt, now, frame) {
    for (const s of this._systems) {
      if (typeof s.tick === 'function') s.tick(dt, now, frame);
    }
  }

  /** Fan a context signal (idle/active/focus/bucket) out to all systems. */
  context(signal) {
    for (const s of this._systems) {
      if (typeof s.onContext === 'function') s.onContext(signal);
    }
  }

  /** Collect dashboard view descriptors contributed by systems. */
  views() {
    const out = [];
    for (const s of this._systems) {
      if (typeof s.views === 'function') out.push(...s.views());
    }
    return out;
  }

  /** Tear everything down (reverse order), guaranteeing listener/timer cleanup. */
  dispose() {
    for (let i = this._systems.length - 1; i >= 0; i--) {
      const s = this._systems[i];
      if (typeof s.dispose === 'function') {
        try {
          s.dispose();
        } catch (err) {
          console.error(`[SystemRegistry] dispose of ${s.constructor.id} threw:`, err);
        }
      }
    }
    this._systems = [];
    this._byId.clear();
    this._inited = false;
  }
}
