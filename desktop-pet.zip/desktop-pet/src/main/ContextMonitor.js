/**
 * main/ContextMonitor.js
 * ----------------------------------------------------------------------------
 * Emits COARSE, privacy-preserving activity signals so the companion can know
 * when to stay quiet. It uses only what Electron already exposes — no extra npm
 * packages, no screenshots, no window titles, no app names, no microphone, no
 * camera. Everything here is safe to run on a locked-down corporate laptop.
 *
 * Signals pushed to the renderer on 'context:signal':
 *   idleSec        seconds since last input (powerMonitor.getSystemIdleTime)
 *   windowFocused  is OUR overlay focused (true) or is the user in another app
 *   activeElsewhere user is active (low idle) AND our window is blurred -> busy
 *   screenLocked   the workstation is locked
 *
 * From these the renderer infers "deep work / probably in a call" without ever
 * inspecting what the user is actually doing.
 */

const { powerMonitor } = require('electron');

const POLL_MS = 5000; // gentle 5s heartbeat; focus/blur/lock push immediately

class ContextMonitor {
  /** @param {(payload:object)=>void} send  pushes a signal to the renderer */
  constructor(send) {
    this.send = send;
    this._timer = null;
    this._locked = false;
    this._focused = false;
    this._onLock = () => { this._locked = true; this._push(); };
    this._onUnlock = () => { this._locked = false; this._push(); };
  }

  /** Call once the BrowserWindow exists; wires window focus + system events. */
  start(win) {
    this._win = win;
    if (win) {
      win.on('focus', () => { this._focused = true; this._push(); });
      win.on('blur', () => { this._focused = false; this._push(); });
      this._focused = win.isFocused();
    }
    // Lock-screen events aren't available on every OS; guard each registration.
    try { powerMonitor.on('lock-screen', this._onLock); } catch { /* not supported */ }
    try { powerMonitor.on('unlock-screen', this._onUnlock); } catch { /* not supported */ }

    this._timer = setInterval(() => this._push(), POLL_MS);
    if (this._timer.unref) this._timer.unref();
    this._push();
  }

  _idleSec() {
    try {
      return powerMonitor.getSystemIdleTime(); // integer seconds
    } catch {
      return 0; // be optimistic if unavailable: treat as active
    }
  }

  _push() {
    const idleSec = this._idleSec();
    const windowFocused = !!this._focused;
    // "Busy elsewhere": the user is clearly present (recent input) but our
    // overlay is not focused -> they're working in another app / likely a call.
    const activeElsewhere = !windowFocused && idleSec < 30;
    this.send({ idleSec, windowFocused, activeElsewhere, screenLocked: this._locked });
  }

  dispose() {
    if (this._timer) clearInterval(this._timer);
    this._timer = null;
    try { powerMonitor.removeListener('lock-screen', this._onLock); } catch { /* ignore */ }
    try { powerMonitor.removeListener('unlock-screen', this._onUnlock); } catch { /* ignore */ }
  }
}

module.exports = { ContextMonitor };
