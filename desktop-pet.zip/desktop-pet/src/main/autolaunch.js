'use strict';
/**
 * autolaunch.js (main process)
 * ----------------------------------------------------------------------------
 * Thin wrapper over Electron's built-in login-item API so we don't need a
 * third-party dependency (keeps the bundle small and fully offline).
 *
 * On Windows this writes the standard "run at login" registry entry for the
 * current user. `--autostart` is passed so the app can start hidden/minimised.
 */

const { app } = require('electron');

function isEnabled() {
  try {
    return app.getLoginItemSettings().openAtLogin;
  } catch {
    return false;
  }
}

function setEnabled(enabled) {
  try {
    app.setLoginItemSettings({
      openAtLogin: !!enabled,
      openAsHidden: false,
      args: ['--autostart'],
    });
    return true;
  } catch (err) {
    console.error('[autolaunch] failed to update login item:', err);
    return false;
  }
}

/** True when the process was launched by the OS at login. */
function launchedAtStartup() {
  try {
    return app.getLoginItemSettings().wasOpenedAtLogin || process.argv.includes('--autostart');
  } catch {
    return process.argv.includes('--autostart');
  }
}

module.exports = { isEnabled, setEnabled, launchedAtStartup };
