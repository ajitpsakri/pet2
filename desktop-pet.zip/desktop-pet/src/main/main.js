'use strict';
/**
 * main.js (Electron main process)
 * ----------------------------------------------------------------------------
 * Responsibilities:
 *  - Create a single, transparent, frameless, always-on-top overlay window that
 *    spans the work area so the pet can roam the whole desktop.
 *  - Manage *click-through*: the window ignores the mouse by default; the
 *    renderer toggles it off only while the cursor is over the pet or a panel.
 *  - Persist state: keep the latest snapshot the renderer pushes, autosave it
 *    to disk on a timer, and flush synchronously on quit / OS shutdown.
 *  - Single-instance lock so we never run two pets at once.
 */

const { app, BrowserWindow, ipcMain, screen, powerMonitor } = require('electron');
const path = require('path');

const { Store } = require('../storage/store');
const { createTray } = require('./tray');
const autolaunch = require('./autolaunch');

// --- single instance --------------------------------------------------------
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
}

// Transparent windows can show GPU artefacts on some Windows drivers; this is
// the standard, widely-used workaround and keeps the overlay clean.
app.disableHardwareAcceleration();

let win = null;
let tray = null;
let store = null;

/** The most recent state snapshot pushed from the renderer (for shutdown save). */
let latestState = null;
let saveTimer = null;
let isQuitting = false;

function createWindow() {
  const primary = screen.getPrimaryDisplay();
  const { x, y, width, height } = primary.workArea;

  win = new BrowserWindow({
    x,
    y,
    width,
    height,
    transparent: true,
    frame: false,
    resizable: false,
    movable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true, // no taskbar entry — it's an overlay, reach it via tray
    hasShadow: false,
    focusable: true, // needed so panels (settings) can receive input
    alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      backgroundThrottling: false, // keep animating when not focused
    },
  });

  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  // Start in click-through mode; forward:true still lets the renderer receive
  // mousemove so it can detect when the cursor enters the pet's hitbox.
  win.setIgnoreMouseEvents(true, { forward: true });

  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));

  win.on('closed', () => {
    win = null;
  });

  // Hide instead of close when the user hits a stray close path.
  win.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      win.hide();
    }
  });
}

// --- IPC: state persistence -------------------------------------------------

function registerIpc() {
  // Renderer asks for the saved state on boot.
  ipcMain.handle('state:load', async () => {
    const raw = await store.load();
    latestState = raw; // may be null -> renderer seeds defaults
    return raw;
  });

  // Renderer pushes the current snapshot frequently (cheap; just caches it).
  ipcMain.on('state:update', (_evt, state) => {
    latestState = state;
  });

  // Explicit save request (e.g. before unload, after important interactions).
  ipcMain.handle('state:save', async (_evt, state) => {
    latestState = state || latestState;
    if (latestState) await store.save(latestState);
    return true;
  });

  // Click-through control: renderer enables hit-testing only when needed.
  ipcMain.on('window:setIgnoreMouse', (_evt, ignore) => {
    if (!win) return;
    win.setIgnoreMouseEvents(!!ignore, { forward: true });
  });

  // Settings that affect the native window.
  ipcMain.on('window:setAlwaysOnTop', (_evt, onTop) => {
    if (win) win.setAlwaysOnTop(!!onTop, 'screen-saver');
  });

  ipcMain.handle('autolaunch:get', () => autolaunch.isEnabled());
  ipcMain.handle('autolaunch:set', (_evt, enabled) => autolaunch.setEnabled(enabled));

  // Report the available work area so the renderer can clamp the pet on screen.
  ipcMain.handle('display:workArea', () => {
    return screen.getPrimaryDisplay().workArea;
  });

  // Renderer -> open a panel (used by tray menu round-trips).
  ipcMain.on('panel:open', (_evt, name) => sendToRenderer('panel:open', name));
}

function sendToRenderer(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

// --- autosave lifecycle -----------------------------------------------------

function startAutosave() {
  const SAVE_MS = 60 * 1000;
  saveTimer = setInterval(() => {
    if (latestState) store.save(latestState);
  }, SAVE_MS);
}

function flushSync(reason) {
  if (latestState) {
    const ok = store.saveSync(latestState);
    console.log(`[main] flushed save on ${reason}: ${ok ? 'ok' : 'failed'}`);
  }
}

// --- app lifecycle ----------------------------------------------------------

app.on('second-instance', () => {
  if (win) {
    win.show();
    win.focus();
  }
});

app.whenReady().then(async () => {
  store = new Store(path.join(app.getPath('userData'), 'save'));
  await store.init();

  registerIpc();
  createWindow();
  startAutosave();

  tray = createTray({
    onToggleShow: () => {
      if (!win) return;
      win.isVisible() ? win.hide() : win.show();
    },
    onFeed: () => sendToRenderer('action:feed'),
    onDashboard: () => sendToRenderer('panel:open', 'dashboard'),
    onSettings: () => sendToRenderer('panel:open', 'settings'),
    onQuit: () => {
      isQuitting = true;
      app.quit();
    },
  });

  // Save when the OS is shutting down / logging off (Windows fires this).
  powerMonitor.on('shutdown', () => flushSync('shutdown'));
  powerMonitor.on('suspend', () => flushSync('suspend'));
});

// Keep running in the tray even with no windows (overlay app).
app.on('window-all-closed', (e) => {
  // Do nothing: lifecycle is driven by the tray's Quit item.
});

app.on('before-quit', () => {
  isQuitting = true;
  if (saveTimer) clearInterval(saveTimer);
  flushSync('quit');
});

process.on('uncaughtException', (err) => {
  console.error('[main] uncaught exception:', err);
  flushSync('crash');
});
