'use strict';
/**
 * preload.js (runs in an isolated context with Node access)
 * ----------------------------------------------------------------------------
 * Exposes a tiny, explicit API to the renderer via contextBridge. The renderer
 * itself has no Node access (contextIsolation + nodeIntegration:false), so this
 * is the only bridge — keeping the attack surface minimal even though the app
 * is fully offline.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('petAPI', {
  // --- persistence ---
  loadState: () => ipcRenderer.invoke('state:load'),
  saveState: (state) => ipcRenderer.invoke('state:save', state),
  pushState: (state) => ipcRenderer.send('state:update', state),

  // --- native window control ---
  setIgnoreMouse: (ignore) => ipcRenderer.send('window:setIgnoreMouse', ignore),
  setAlwaysOnTop: (onTop) => ipcRenderer.send('window:setAlwaysOnTop', onTop),
  getWorkArea: () => ipcRenderer.invoke('display:workArea'),

  // --- autostart ---
  getAutoLaunch: () => ipcRenderer.invoke('autolaunch:get'),
  setAutoLaunch: (enabled) => ipcRenderer.invoke('autolaunch:set', enabled),

  // --- events from main (tray menu, etc.) ---
  onPanelOpen: (cb) => ipcRenderer.on('panel:open', (_e, name) => cb(name)),
  onFeed: (cb) => ipcRenderer.on('action:feed', () => cb()),
});
