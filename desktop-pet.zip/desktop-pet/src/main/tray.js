'use strict';
/**
 * tray.js (main process)
 * ----------------------------------------------------------------------------
 * Builds the system-tray icon and its menu. The tray is the primary way to
 * reach the pet when click-through is on, and to quit the app, since the
 * overlay window has no taskbar entry or title bar.
 */

const { Tray, Menu, nativeImage } = require('electron');
const path = require('path');

/**
 * @param {object} handlers callbacks wired to menu items
 * @param {() => void} handlers.onToggleShow
 * @param {() => void} handlers.onDashboard
 * @param {() => void} handlers.onSettings
 * @param {() => void} handlers.onFeed
 * @param {() => void} handlers.onQuit
 * @returns {Tray}
 */
function createTray(handlers) {
  const iconPath = path.join(__dirname, '..', '..', 'build', 'icon.png');
  let image = nativeImage.createFromPath(iconPath);
  if (image.isEmpty()) {
    // Fallback so the app still launches even if the icon wasn't generated.
    image = nativeImage.createEmpty();
  } else {
    image = image.resize({ width: 18, height: 18 });
  }

  const tray = new Tray(image);
  tray.setToolTip('Desktop Pet');

  const menu = Menu.buildFromTemplate([
    { label: 'Show / Hide Pet', click: () => handlers.onToggleShow() },
    { type: 'separator' },
    { label: 'Feed', click: () => handlers.onFeed() },
    { label: 'Statistics…', click: () => handlers.onDashboard() },
    { label: 'Settings…', click: () => handlers.onSettings() },
    { type: 'separator' },
    { label: 'Quit', click: () => handlers.onQuit() },
  ]);

  tray.setContextMenu(menu);
  // Single click toggles visibility; convenient on Windows.
  tray.on('click', () => handlers.onToggleShow());
  return tray;
}

module.exports = { createTray };
