/**
 * Behavior.js
 * ----------------------------------------------------------------------------
 * The pet's "free will". A small weighted state machine decides what the pet
 * does when you're not interacting with it: wandering, sitting, stretching,
 * looking around, napping, and occasionally noticing the cursor.
 *
 * It owns the pet's on-screen position and facing, and reports back which
 * animation should play plus any thought bubble. All coordinates are window-
 * local (the overlay window spans the desktop work area).
 *
 * Guiding principle from the brief: "Pet should never become annoying." So
 * attention-seeking behaviours are rate-limited and gentle, and the pet mostly
 * minds its own business near where you left it.
 */

import { SPEED } from '../config/constants.js';

const rand = (a, b) => a + Math.random() * (b - a);
const choice = (arr) => arr[(Math.random() * arr.length) | 0];

export class Behavior {
  constructor(startPos, bounds) {
    this.bounds = bounds; // { w, h }
    this.pos = startPos || { x: bounds.w * 0.5, y: bounds.h * 0.72 };
    this.facing = 1; // 1 = right, -1 = left
    this.asleep = false;
    this.thought = null; // transient emoji/hint for a thought bubble

    this.current = 'idle';
    this.timeLeft = 1.5;
    this.target = null;

    this.dragStress = 0; // climbs while being dragged; triggers a flee
    this._sinceCursorInterest = 0; // throttle cursor chasing
  }

  setBounds(bounds) {
    this.bounds = bounds;
    // Keep the pet inside the new bounds.
    this.pos.x = Math.max(40, Math.min(bounds.w - 40, this.pos.x));
    this.pos.y = Math.max(40, Math.min(bounds.h - 40, this.pos.y));
  }

  /** Externally nudge the pet (drag). Accumulates stress so it may flee. */
  dragTo(x, y) {
    this.pos.x = x;
    this.pos.y = y;
    this.dragStress = Math.min(this.dragStress + 0.4, 5);
    this.asleep = false;
    this._enter('idle', 0.5);
  }

  _enter(name, seconds, target = null) {
    this.current = name;
    this.timeLeft = seconds;
    this.target = target;
    this.thought = null;
    this.asleep = name === 'sleep';
  }

  _randomGroundTarget() {
    return {
      x: rand(60, this.bounds.w - 60),
      y: rand(this.bounds.h * 0.45, this.bounds.h - 60),
    };
  }

  _moveToward(target, speed, dt) {
    const dx = target.x - this.pos.x;
    const dy = target.y - this.pos.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 4) return true;
    const step = Math.min(dist, speed * dt);
    this.pos.x += (dx / dist) * step;
    this.pos.y += (dy / dist) * step;
    if (Math.abs(dx) > 1) this.facing = dx > 0 ? 1 : -1;
    return false;
  }

  /**
   * Choose the next autonomous behaviour, weighted by the pet's mood.
   * @param {object} ctx { mood, energy }
   */
  _pickNext(ctx) {
    const { mood, energy } = ctx;

    // Hard overrides first — these reflect strong needs.
    if (mood === 'sleepy' || energy < 12) {
      return this._enter('sleep', rand(20, 40));
    }
    if (mood === 'sick') {
      return Math.random() < 0.6
        ? this._enter('idle', rand(4, 8))
        : this._enter('walk', rand(3, 6), this._randomGroundTarget());
    }

    // Weighted menu of ordinary activities. Tuned to feel calm.
    const menu = [
      ['idle', 4],
      ['sit', 3],
      ['look', 2],
      ['stretch', 1.5],
      ['walk', 4],
    ];
    if (mood === 'lonely') menu.push(['approach', 5]);
    if (mood === 'bored') menu.push(['walk', 3], ['look', 2]);
    if (mood === 'happy' || mood === 'excited') menu.push(['play', 4], ['walk', 2]);

    // Occasional spontaneous cursor chase, but only if we haven't recently.
    if (this._sinceCursorInterest > 18 && Math.random() < 0.25) {
      this._sinceCursorInterest = 0;
      return this._enter('chase', rand(2.5, 5));
    }

    const total = menu.reduce((s, [, w]) => s + w, 0);
    let r = Math.random() * total;
    let pick = 'idle';
    for (const [name, w] of menu) {
      r -= w;
      if (r <= 0) {
        pick = name;
        break;
      }
    }

    switch (pick) {
      case 'walk':
        return this._enter('walk', rand(4, 9), this._randomGroundTarget());
      case 'approach':
        return this._enter('approach', rand(3, 6));
      case 'chase':
        return this._enter('chase', rand(2.5, 5));
      case 'play':
        return this._enter('play', rand(3, 6));
      case 'sit':
        return this._enter('sit', rand(5, 10));
      case 'look':
        return this._enter('look', rand(3, 6));
      case 'stretch':
        return this._enter('stretch', rand(2, 4));
      default:
        return this._enter('idle', rand(4, 9));
    }
  }

  /**
   * Advance behaviour by dt seconds.
   * @param {number} dt seconds
   * @param {object} ctx { mood, energy, cursor:{x,y}|null }
   * @returns {{ animation, facing, asleep, thought }}
   */
  update(dt, ctx) {
    this.timeLeft -= dt;
    this._sinceCursorInterest += dt;
    this.dragStress = Math.max(0, this.dragStress - dt * 0.5);

    // Being dragged a lot? Bolt away once, then settle.
    if (this.dragStress >= 3 && this.current !== 'flee') {
      this.dragStress = 0;
      const away = {
        x: rand(60, this.bounds.w - 60),
        y: rand(this.bounds.h * 0.45, this.bounds.h - 60),
      };
      this._enter('flee', 2.5, away);
    }

    const cursor = ctx.cursor;
    let animation = 'idle';

    switch (this.current) {
      case 'sleep':
        animation = 'sleeping';
        // Wake early if fully rested.
        if (ctx.energy > 96) this.timeLeft = Math.min(this.timeLeft, 0.5);
        break;

      case 'walk': {
        const slow = ctx.mood === 'hungry' || ctx.mood === 'sick';
        const arrived = this._moveToward(
          this.target,
          slow ? SPEED.walk * 0.6 : SPEED.walk,
          dt
        );
        animation = ctx.mood === 'sick' ? 'sick' : 'walking';
        if (ctx.mood === 'hungry') this.thought = '🍖';
        else if (ctx.mood === 'thirsty') this.thought = '💧';
        if (arrived) this.timeLeft = Math.min(this.timeLeft, 0.3);
        break;
      }

      case 'chase':
        if (cursor) {
          this._moveToward(cursor, SPEED.chase, dt);
          animation = 'running';
        } else {
          this.timeLeft = 0;
        }
        break;

      case 'approach':
        if (cursor) {
          const arrived = this._moveToward(
            { x: cursor.x, y: cursor.y + 30 },
            SPEED.walk,
            dt
          );
          animation = arrived ? 'happy' : 'walking';
          this.thought = '❤️';
        } else {
          animation = 'sad';
        }
        break;

      case 'flee':
        this._moveToward(this.target, SPEED.run, dt);
        animation = 'running';
        break;

      case 'play':
        animation = 'jumping';
        break;

      case 'stretch':
        animation = 'stretch';
        break;

      case 'look':
        animation = 'look';
        // Glance around by flipping facing now and then.
        if (Math.random() < dt * 0.6) this.facing *= -1;
        break;

      case 'sit':
        animation = 'sit';
        break;

      case 'idle':
      default:
        animation = 'idle';
        break;
    }

    if (this.timeLeft <= 0) this._pickNext(ctx);

    // Clamp inside bounds at all times.
    this.pos.x = Math.max(36, Math.min(this.bounds.w - 36, this.pos.x));
    this.pos.y = Math.max(36, Math.min(this.bounds.h - 36, this.pos.y));

    return {
      animation,
      facing: this.facing,
      asleep: this.asleep,
      thought: this.thought,
    };
  }
}
