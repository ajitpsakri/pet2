/**
 * MoodEngine.js
 * ----------------------------------------------------------------------------
 * Translates raw needs into a single expressive mood. Rather than a flat sum
 * (which can't tell "starving" from "exhausted"), we evaluate prioritized rules
 * and return the first match. The numeric sum is still exposed for the
 * dashboard's "overall wellbeing" readout.
 */

import { SICK_THRESHOLD } from '../config/constants.js';

export class MoodEngine {
  /**
   * @param {object} needs  the 0..100 needs object
   * @param {boolean} asleep whether the pet is currently sleeping
   * @returns {string} one of the mood ids
   */
  static evaluate(needs, asleep = false) {
    const { hunger, thirst, happiness, energy, health, affection } = needs;

    if (health < SICK_THRESHOLD) return 'sick';
    if (asleep || energy < 20) return 'sleepy';
    if (affection < 25) return 'lonely';
    if (hunger < 25) return 'hungry';
    if (thirst < 25) return 'thirsty';

    const avg = (hunger + thirst + happiness + energy + health + affection) / 6;
    if (happiness < 35) return 'sad';
    if (happiness < 55) return 'bored';
    if (avg > 85 && happiness > 80) return 'excited';
    if (avg > 70) return 'happy';
    return 'relaxed';
  }

  /** Raw wellbeing score 0..100 (mean of all needs) for the dashboard. */
  static wellbeing(needs) {
    const vals = Object.values(needs);
    return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
  }

  /**
   * Map a mood to the animation that best expresses it while idling.
   * Behaviour.js can override this with action animations (eating, etc.).
   */
  static idleAnimationFor(mood) {
    switch (mood) {
      case 'sick':
        return 'sick';
      case 'sleepy':
        return 'sleeping';
      case 'sad':
      case 'lonely':
        return 'sad';
      case 'hungry':
      case 'thirsty':
        return 'sad';
      case 'excited':
        return 'excited';
      case 'happy':
        return 'happy';
      default:
        return 'idle';
    }
  }
}
