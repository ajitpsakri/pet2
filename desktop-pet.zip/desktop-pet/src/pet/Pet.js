/**
 * Pet.js
 * ----------------------------------------------------------------------------
 * Conductor that binds the model (PetState), the will (Behavior), and the body
 * (Animator + sprites). renderer.js drives it with a fixed-timestep simulation
 * tick and a per-frame animation/render pass.
 *
 * It also handles short-lived "action overrides" — when you feed the pet we
 * want it to *stop and eat* for a moment regardless of what it was doing.
 */

import { Animator } from '../animations/Animator.js';
import { drawPet, regionAt } from '../animations/sprites.js';
import { Behavior } from './Behavior.js';
import { MoodEngine } from './MoodEngine.js';

export class Pet {
  /**
   * @param {PetState} state
   * @param {{w:number,h:number}} bounds window-local bounds
   */
  constructor(state, bounds) {
    this.state = state;
    this.bounds = bounds;
    this.animator = new Animator();
    this.behavior = new Behavior(state.position, bounds);

    this.mood = 'relaxed';
    this.actionAnim = null;
    this.actionUntil = 0;
    this.thought = null;
  }

  setBounds(bounds) {
    this.bounds = bounds;
    this.behavior.setBounds(bounds);
  }

  get position() {
    return this.behavior.pos;
  }
  get facing() {
    return this.behavior.facing;
  }

  /** Play a fixed reaction animation for `ms`, pausing wandering in place. */
  triggerAction(anim, ms) {
    this.actionAnim = anim;
    this.actionUntil = performance.now() + ms;
    // Freeze movement so the pet visibly performs the action.
    this.behavior._enter('idle', ms / 1000);
  }

  /** Drag handling delegated to behaviour (accumulates flee stress). */
  dragTo(x, y) {
    this.behavior.dragTo(x, y);
  }

  /** Is the pointer over the pet's hitbox? Window-local coords. */
  hitTest(px, py, scale) {
    const dx = px - this.behavior.pos.x;
    const dy = py - this.behavior.pos.y;
    const r = 34 * scale;
    return dx * dx + dy * dy <= r * r;
  }

  /**
   * Which body part is under the cursor ('head','ear','snout','back','belly',
   * 'tail') or null. Converts window coords into the dog's local, facing-
   * normalized model space (the inverse of the draw transform).
   */
  regionAtPoint(px, py, scale) {
    const lx = (px - this.behavior.pos.x) / (this.facing * scale);
    const ly = (py - this.behavior.pos.y) / scale;
    return regionAt(lx, ly);
  }

  /**
   * Simulation tick.
   * @param {number} dt seconds
   * @param {{x,y}|null} cursor window-local cursor (null if unknown)
   */
  tick(dt, cursor) {
    const asleepPrev = this.behavior.asleep;
    this.mood = MoodEngine.evaluate(this.state.needs, asleepPrev);

    // Advance needs (energy regen depends on sleeping).
    this.state.tick(dt, this.behavior.asleep);

    // Advance free will.
    const bres = this.behavior.update(dt, {
      mood: this.mood,
      energy: this.state.needs.energy,
      cursor,
    });
    this.thought = bres.thought;

    // Persist position back into the model.
    this.state.position = { x: this.behavior.pos.x, y: this.behavior.pos.y };

    // Decide the animation to display this frame.
    const now = performance.now();
    let anim;
    if (this.actionAnim && now < this.actionUntil) {
      anim = this.actionAnim;
    } else {
      this.actionAnim = null;
      anim = bres.animation === 'idle'
        ? MoodEngine.idleAnimationFor(this.mood)
        : bres.animation;
    }
    this.animator.play(anim);
  }

  /** Per-frame animation update (decoupled from sim tick). */
  animate(dt, speed) {
    this.animator.update(dt, speed);
  }

  /** Draw the pet (and any thought bubble) onto the canvas. */
  render(ctx, scale, env = {}) {
    const { x, y } = this.behavior.pos;
    drawPet(ctx, {
      x,
      y,
      scale,
      facing: this.facing,
      frame: this.animator.frame(),
      accessory: this.state.accessory,
      mood: this.mood,
      shadowScale: env.shadowScale,
      shadowAlpha: env.shadowAlpha,
      reduceMotion: env.reduceMotion,
    });

    if (this.thought) this._drawThought(ctx, x, y, scale);
  }

  _drawThought(ctx, x, y, scale) {
    ctx.save();
    const bx = x + 26 * scale;
    const by = y - 34 * scale;
    ctx.globalAlpha = 0.95;
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#cfd8d6';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(bx, by, 15, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // little tail bubbles
    ctx.beginPath();
    ctx.arc(bx - 12, by + 12, 3.5, 0, Math.PI * 2);
    ctx.arc(bx - 18, by + 18, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.font = `${14 * 1}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(this.thought, bx, by + 1);
    ctx.restore();
  }
}
