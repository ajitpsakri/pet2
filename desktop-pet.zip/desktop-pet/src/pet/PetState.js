/**
 * PetState.js
 * ----------------------------------------------------------------------------
 * The authoritative, *serializable* model of the pet. It deliberately knows
 * nothing about rendering or DOM — it just holds numbers and the rules for
 * changing them. This separation keeps the simulation testable and makes
 * save/restore trivial (the saved JSON *is* this object's fields).
 */

import {
  NEEDS,
  DECAY_PER_SEC,
  ENERGY_REGEN_PER_SEC,
  HEALTH_DRIFT_PER_SEC,
  FOODS,
  TREATS,
  INTERACTION_EFFECTS,
  XP,
  xpForLevel,
  ACCESSORIES,
} from '../config/constants.js';

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

export class PetState {
  /** @param {object} saved  a migrated save object (see schema.js) */
  constructor(saved) {
    this.name = saved.pet.name;
    this.bornAt = saved.pet.bornAt;
    this.needs = { ...saved.pet.needs };
    this.level = saved.pet.level;
    this.xp = saved.pet.xp;
    this.accessory = saved.pet.accessory || 'none';
    this.position = saved.pet.position || null;

    this.stats = { ...saved.stats };
    this.achievements = { ...saved.achievements };

    /** transient (not persisted): listeners fire when something noteworthy happens */
    this._events = [];
  }

  // --- event helper so other systems (achievements, speech) can react -------
  emit(type, detail) {
    this._events.push({ type, detail });
  }
  drainEvents() {
    const e = this._events;
    this._events = [];
    return e;
  }

  // --- time-based simulation ------------------------------------------------

  /**
   * Advance the simulation by `dt` seconds.
   * @param {number} dt seconds elapsed since last tick
   * @param {boolean} asleep whether the pet is currently sleeping
   */
  tick(dt, asleep) {
    for (const n of NEEDS) {
      if (n === 'health' || n === 'energy') continue;
      this.needs[n] = clamp(this.needs[n] - DECAY_PER_SEC[n] * dt);
    }

    if (asleep) {
      this.needs.energy = clamp(this.needs.energy + ENERGY_REGEN_PER_SEC * dt);
    } else {
      this.needs.energy = clamp(this.needs.energy - DECAY_PER_SEC.energy * dt);
    }

    // Health drifts toward a target derived from the worst-cared-for needs.
    const target = this._healthTarget();
    const dir = Math.sign(target - this.needs.health);
    this.needs.health = clamp(
      this.needs.health + dir * HEALTH_DRIFT_PER_SEC * dt
    );

    // Passive XP for simply staying alive and tended.
    this.addXp(XP.perMinuteAlive * (dt / 60), false);
  }

  /** Where health "wants" to be given current care. */
  _healthTarget() {
    const { hunger, thirst, cleanliness, happiness } = this.needs;
    // If basics are neglected, health target sinks; if all good, it climbs to 100.
    const basics = (hunger + thirst + cleanliness) / 3;
    const penalty = basics < 30 ? -40 : basics < 50 ? -10 : 0;
    return clamp((basics * 0.7 + happiness * 0.3) + penalty);
  }

  // --- interactions ---------------------------------------------------------

  _apply(effects) {
    for (const [k, v] of Object.entries(effects)) {
      if (k in this.needs) this.needs[k] = clamp(this.needs[k] + v);
    }
  }

  feed(foodId) {
    const food = FOODS[foodId];
    if (!food) return false;
    if (food.unlockLevel && this.level < food.unlockLevel) return false;
    this._apply(food);
    this.stats.totalFood++;
    this.addXp(XP.feed);
    this._markCaredToday();
    this.emit('feed', { foodId });
    return true;
  }

  giveWater() {
    this._apply(INTERACTION_EFFECTS.water);
    this.stats.totalWater++;
    this.addXp(XP.water);
    this._markCaredToday();
    this.emit('water');
    return true;
  }

  pet() {
    this._apply(INTERACTION_EFFECTS.pet);
    this.stats.totalPats++;
    this.addXp(XP.pet);
    this._markCaredToday();
    this.emit('pet');
    return true;
  }

  play() {
    this._apply(INTERACTION_EFFECTS.play);
    this.stats.totalPlay++;
    this.addXp(XP.play);
    this._markCaredToday();
    this.emit('play');
    return true;
  }

  clean() {
    this._apply(INTERACTION_EFFECTS.clean);
    this.stats.totalCleans++;
    this.addXp(XP.clean);
    this._markCaredToday();
    this.emit('clean');
    return true;
  }

  treat(treatId) {
    const t = TREATS[treatId];
    if (!t) return false;
    this._apply(t);
    this.addXp(XP.treat);
    this._markCaredToday();
    this.emit('treat', { treatId });
    return true;
  }

  // --- progression ----------------------------------------------------------

  addXp(amount, allowLevelUp = true) {
    this.xp += amount;
    if (!allowLevelUp) return;
    let leveled = false;
    while (this.xp >= xpForLevel(this.level)) {
      this.xp -= xpForLevel(this.level);
      this.level++;
      leveled = true;
    }
    if (leveled) this.emit('levelup', { level: this.level });
  }

  /** Accessory ids the pet has earned at its current level. */
  unlockedAccessories() {
    return Object.entries(ACCESSORIES)
      .filter(([, a]) => this.level >= (a.unlockLevel || 1))
      .map(([id]) => id);
  }

  setAccessory(id) {
    if (this.unlockedAccessories().includes(id)) {
      this.accessory = id;
      return true;
    }
    return false;
  }

  // --- daily streak ---------------------------------------------------------

  _today() {
    return new Date().toISOString().slice(0, 10); // YYYY-MM-DD (local-ish)
  }

  _markCaredToday() {
    const today = this._today();
    if (this.stats.lastCareDay === today) return;

    if (this.stats.lastCareDay) {
      const prev = new Date(this.stats.lastCareDay);
      const diffDays = Math.round((new Date(today) - prev) / 86400000);
      this.stats.careStreak = diffDays === 1 ? this.stats.careStreak + 1 : 1;
    } else {
      this.stats.careStreak = 1;
    }
    this.stats.lastCareDay = today;
    this.stats.longestStreak = Math.max(
      this.stats.longestStreak,
      this.stats.careStreak
    );
    this.emit('careday', { streak: this.stats.careStreak });
  }

  // --- derived --------------------------------------------------------------

  ageDays() {
    return Math.floor((Date.now() - this.bornAt) / 86400000);
  }

  xpToNext() {
    return xpForLevel(this.level);
  }

  // --- (de)serialization ----------------------------------------------------

  /** Produce a plain object matching the schema's `pet`/`stats`/`achievements`. */
  toJSON() {
    return {
      pet: {
        name: this.name,
        bornAt: this.bornAt,
        needs: { ...this.needs },
        level: this.level,
        xp: this.xp,
        accessory: this.accessory,
        position: this.position,
      },
      stats: { ...this.stats },
      achievements: { ...this.achievements },
    };
  }
}
