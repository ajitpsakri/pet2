/**
 * plugins/PluginLoader.js
 * ----------------------------------------------------------------------------
 * Loads drop-in feature modules. A plugin is just a System subclass plus a
 * manifest declaring its id, version, apiVersion, and the capabilities it needs
 * ('clock', 'nudge', 'celebrate', 'menu'). The loader validates the manifest,
 * builds a context that exposes ONLY the declared capabilities, instantiates
 * the plugin, and registers it in the normal SystemRegistry — so plugins tick,
 * persist (under systems[id]), and dispose exactly like built-in systems.
 *
 * The bus a plugin receives is wrapped: it may freely subscribe to anything and
 * emit its own `plugin:<id>:*` events, but may only emit 'celebrate'/'nudge'
 * if it declared those capabilities, and can never emit core events (no
 * spoofing pet:* / coding:* etc.). One misbehaving plugin can't take others
 * down — each load is isolated.
 */

export const PLUGIN_API_VERSION = 1;

/** Wrap the real bus so a plugin can only emit what it's allowed to. */
export function makePluginBus(realBus, perms, pluginId) {
  const ownPrefix = `plugin:${pluginId}:`;
  return {
    on: (type, fn) => realBus.on(type, fn),
    once: (type, fn) => realBus.once(type, fn),
    off: (type, fn) => realBus.off(type, fn),
    emit: (type, payload) => {
      const allowed =
        type.startsWith(ownPrefix) ||
        (type === 'celebrate' && perms.includes('celebrate')) ||
        (type === 'nudge' && perms.includes('nudge'));
      if (!allowed) {
        console.warn(`[plugin:${pluginId}] blocked emit of "${type}" (missing capability)`);
        return;
      }
      realBus.emit(type, payload);
    },
  };
}

/** Build the capability-filtered context handed to a plugin. */
export function makePluginContext(services, manifest) {
  const perms = manifest.permissions || [];
  const ctx = { manifest, bus: makePluginBus(services.bus, perms, manifest.id) };
  if (perms.includes('clock')) ctx.clock = services.clock;
  if (perms.includes('nudge')) ctx.nudge = services.nudge;
  return ctx;
}

function validateManifest(m) {
  if (!m || typeof m !== 'object') throw new Error('missing manifest');
  if (!m.id || typeof m.id !== 'string') throw new Error('manifest.id required');
  if (!m.name || typeof m.name !== 'string') throw new Error('manifest.name required');
  if (typeof m.apiVersion !== 'number') throw new Error('manifest.apiVersion required');
  if (m.permissions && !Array.isArray(m.permissions)) throw new Error('permissions must be an array');
}

export class PluginLoader {
  /**
   * @param {object} args
   * @param {Array<{manifest:object, Plugin:Function}>} args.descriptors
   * @param {object} args.services { bus, clock, nudge }
   * @param {import('../core/SystemRegistry.js').SystemRegistry} args.registry
   * @param {object} [args.logger]
   * @returns {{ loaded:Array, failed:Array, menuItems:Array }}
   */
  load({ descriptors = [], services, registry, logger }) {
    const loaded = [];
    const failed = [];

    for (const d of descriptors) {
      const id = d && d.manifest && d.manifest.id;
      try {
        validateManifest(d.manifest);
        const m = d.manifest;
        if (m.apiVersion !== PLUGIN_API_VERSION) {
          throw new Error(`apiVersion ${m.apiVersion} unsupported (need ${PLUGIN_API_VERSION})`);
        }
        if (typeof d.Plugin !== 'function') throw new Error('Plugin class missing');
        if (d.Plugin.id !== m.id) throw new Error(`Plugin.id "${d.Plugin.id}" != manifest.id "${m.id}"`);

        const ctx = makePluginContext(services, m);
        const instance = new d.Plugin(ctx);
        registry.register(instance); // throws on duplicate id -> caught below

        const menu =
          (m.permissions || []).includes('menu') && typeof instance.menuItems === 'function'
            ? instance.menuItems().map((mi) => ({ pluginId: m.id, ...mi }))
            : [];
        loaded.push({ id: m.id, instance, perms: m.permissions || [], menu });
      } catch (err) {
        failed.push({ id, error: String((err && err.message) || err) });
        if (logger && logger.error) logger.error(`[plugin] failed to load "${id}":`, err);
      }
    }

    return { loaded, failed, menuItems: loaded.flatMap((l) => l.menu) };
  }
}
