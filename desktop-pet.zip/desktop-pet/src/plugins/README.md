# Writing a plugin

A plugin is just a **`System`** with a **manifest**. It plugs into the same
lifecycle as the built-in features (tick, save, dispose) and talks to the app
only through a capability-limited context — so it can't reach into core or other
plugins. Everything stays local and offline, like the rest of the app.

## 1. Create a folder + `plugin.js`

```js
import { System } from '../../systems/System.js';

export const manifest = {
  id: 'my-plugin',          // unique; must equal Plugin.id below
  name: 'My Plugin',
  version: '1.0.0',
  apiVersion: 1,            // must match PLUGIN_API_VERSION
  permissions: ['clock', 'nudge', 'celebrate', 'menu'],
};

export class Plugin extends System {
  static id = 'my-plugin';
  init() { /* subscribe to this.ctx.bus, set up timers */ }
  tick(dt) { /* called each frame; use this.ctx.clock if granted */ }
  menuItems() { return [{ label: '✨ Do thing', action: 'go' }]; } // needs 'menu'
  serialize() { return { /* your slice */ }; }
  hydrate(d) { /* restore */ }
  dispose() { /* remove listeners */ }
}
```

## 2. Register it (the only shared file you touch)

In `src/plugins/registry.js`:

```js
import { manifest as myManifest, Plugin as MyPlugin } from './my-plugin/plugin.js';
export const BUILTIN_PLUGINS = [
  { manifest: habitManifest, Plugin: HabitPlugin },
  { manifest: myManifest, Plugin: MyPlugin }, // <- add this
];
```

That's it — no core/renderer changes.

## Capabilities (`permissions`)

You receive **only** what you declare in `ctx`:

| Permission | Grants |
|---|---|
| `clock` | `ctx.clock` — `dayKey()`, `bucket()`, etc. |
| `nudge` | `ctx.nudge` — the shared reminder budget, and the right to emit `nudge` |
| `celebrate` | the right to emit `celebrate` (confetti + XP) |
| `menu` | your `menuItems()` appear in the pet's click menu |

The bus you get (`ctx.bus`) can **subscribe** to anything (read), and **emit**:
- your own `plugin:<id>:*` events, always;
- `celebrate` / `nudge`, only if declared.

It can **never** emit core events (`pet:*`, `coding:*`, …) — no spoofing.

## Persistence

Whatever `serialize()` returns is saved under `systems.<your-id>` in the local
save file and passed back to `hydrate()` next launch. You get durable storage
for free; no extra permission needed.

## Menu actions

A `menuItems()` entry `{ label, action }` renders a button. When tapped, the app
emits `plugin:<your-id>:<action>` on the bus — subscribe to it in `init()`:

```js
this.ctx.bus.on('plugin:my-plugin:go', () => this.doThing());
```

See **`habit-tracker/`** for a complete, working example.
