/**
 * plugins/habit-tracker/plugin.js
 * ----------------------------------------------------------------------------
 * Example drop-in plugin. Proves the framework end-to-end: it's a normal System
 * subclass that declares the capabilities it needs and nothing more. Tracks one
 * configurable daily habit (default "Take a walk") with a streak, a gentle
 * reminder, a celebration on completion, and a context-menu button — all
 * through the permission-filtered context, never reaching into core directly.
 *
 * Copy this folder, change the manifest id + habit, add it to ../registry.js,
 * and you have a new feature without touching any core file.
 */

import { System } from '../../systems/System.js';
import { nextStreak } from '../../systems/streakUtil.js';

export const manifest = {
  id: 'habit-tracker',
  name: 'Habit Tracker',
  version: '1.0.0',
  apiVersion: 1,
  permissions: ['clock', 'nudge', 'celebrate', 'menu'],
  habit: 'Take a walk', // plugin-specific config the plugin reads from ctx.manifest
};

export class Plugin extends System {
  static id = 'habit-tracker';

  constructor(ctx) {
    super(ctx);
    this.label = (ctx.manifest && ctx.manifest.habit) || 'Daily habit';
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastDay = null;
    this.doneToday = false;
    this._today = null;
    this._offs = [];
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('habit', 180);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
    // Listen for the menu button (renderer emits this on the real bus).
    if (this.ctx.bus) this._offs.push(this.ctx.bus.on('plugin:habit-tracker:done', () => this.markDone()));
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const k = this.ctx.clock.dayKey();
    if (k !== this._today) {
      this._today = k;
      this.doneToday = false;
    }
  }

  markDone() {
    this._rollover();
    if (this.doneToday) return false;
    this.doneToday = true;
    this.streakDays = nextStreak(this.streakDays, this.lastDay, this._today);
    if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
    this.lastDay = this._today;
    if (this.ctx.nudge) this.ctx.nudge.acted('habit');
    if (this.ctx.bus) {
      this.ctx.bus.emit('plugin:habit-tracker:completed', { streak: this.streakDays });
      this.ctx.bus.emit('celebrate', { kind: 'default', text: `${this.label} ✓`, xp: 5, n: this.streakDays });
    }
    return true;
  }

  tick() {
    this._rollover();
    if (this.doneToday) return;
    if (this.ctx.nudge && this.ctx.nudge.request('habit') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'habit', context: 'encourage' });
    }
  }

  menuItems() {
    return [{ label: `🐾 ${this.label}`, action: 'done' }];
  }

  status() {
    return { label: this.label, doneToday: this.doneToday, streakDays: this.streakDays };
  }

  serialize() {
    return {
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastDay: this.lastDay,
      doneToday: this.doneToday,
      today: this._today,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastDay = d.lastDay ?? null;
    this.doneToday = d.doneToday ?? false;
    this._today = d.today ?? this._today;
  }

  dispose() {
    this._offs.forEach((off) => off());
    this._offs = [];
  }
}
