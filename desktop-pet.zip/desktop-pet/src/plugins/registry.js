/**
 * plugins/registry.js
 * ----------------------------------------------------------------------------
 * The single list of built-in plugins. Because the renderer loads ES modules
 * directly (no bundler, and no filesystem access in the browser context),
 * plugins are enumerated here rather than scanned from disk. Adding a plugin is
 * one import + one array entry — and crucially, NO core file changes.
 */

import { manifest as habitManifest, Plugin as HabitPlugin } from './habit-tracker/plugin.js';

export const BUILTIN_PLUGINS = [
  { manifest: habitManifest, Plugin: HabitPlugin },
];
