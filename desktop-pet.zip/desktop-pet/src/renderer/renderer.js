/**
 * renderer.js
 * ----------------------------------------------------------------------------
 * Bootstrapper for the overlay window. As of Phase 0 the simulation no longer
 * lives directly in here — it runs inside a SystemRegistry, with the pet
 * wrapped as `PetSystem`. This file now only:
 *   1. loads + migrates the save (via StateHub),
 *   2. builds the core (EventBus, Clock, SystemRegistry) and registers systems,
 *   3. wires the existing UI (menu, panels, speech, sound, achievements),
 *   4. runs one requestAnimationFrame loop that ticks the registry and renders,
 *   5. manages click-through and persistence.
 *
 * Behaviour is intentionally identical to the pre-Phase-0 app. New companion
 * features will arrive as additional `registry.register(...)` calls plus a
 * dashboard tab — without touching the pet simulation or this loop.
 *
 * Loaded as an ES module from index.html, so it imports /src modules directly
 * with no bundler — keeping the build trivial and fully offline.
 */

import { EventBus } from '../core/EventBus.js';
import { Clock } from '../core/Clock.js';
import { SystemRegistry } from '../core/SystemRegistry.js';
import { StateHub } from '../core/StateHub.js';
import { PetSystem } from '../systems/pet/PetSystem.js';
import { RelationshipSystem } from '../systems/relationship/RelationshipSystem.js';
import { CodingSystem } from '../systems/coding/CodingSystem.js';
import { AnkiSystem } from '../systems/habits/AnkiSystem.js';
import { HydrationSystem } from '../systems/wellness/HydrationSystem.js';
import { MovementSystem } from '../systems/wellness/MovementSystem.js';
import { TasksSystem } from '../systems/tasks/TasksSystem.js';
import { LearningSystem } from '../systems/learning/LearningSystem.js';
import { PresentationSystem } from '../systems/presentation/PresentationSystem.js';
import { AttentionSystem } from '../systems/attention/AttentionSystem.js';
import { AICompanionSystem } from '../systems/ai/AICompanionSystem.js';
import { KnowledgeSystem } from '../systems/knowledge/KnowledgeSystem.js';
import { ProjectSystem } from '../systems/projects/ProjectSystem.js';
import { FlashcardSystem } from '../systems/flashcards/FlashcardSystem.js';
import { TimelineSystem } from '../systems/timeline/TimelineSystem.js';
import { FetchSystem } from '../systems/fetch/FetchSystem.js';
import { UnoSystem } from '../systems/uno/UnoSystem.js';
import { CricketSystem } from '../systems/cricket/CricketSystem.js';
import { CoworkerSystem } from '../systems/coworker/CoworkerSystem.js';
import { AIPanel } from '../ui/AIPanel.js';
import { KnowledgePanel } from '../ui/KnowledgePanel.js';
import { ProjectPanel } from '../ui/ProjectPanel.js';
import { FlashcardPanel } from '../ui/FlashcardPanel.js';
import { TimelinePanel } from '../ui/TimelinePanel.js';
import { Diagnostics } from '../services/Diagnostics.js';
import { DiagnosticsPanel } from '../ui/DiagnosticsPanel.js';
import { UnoPanel } from '../ui/UnoPanel.js';
import { CricketPanel } from '../ui/CricketPanel.js';
import { CoworkerPanel } from '../ui/CoworkerPanel.js';
import { PettingController } from '../ui/Petting.js';
import { NudgeEngine } from '../services/NudgeEngine.js';
import { DialogueService } from '../services/DialogueService.js';
import { Logger } from '../core/Logger.js';
import { Celebration } from '../ui/Celebration.js';

import { Settings } from '../settings/Settings.js';
import { AchievementManager } from '../achievements/AchievementManager.js';
import { ContextMenu } from '../ui/ContextMenu.js';
import { Dashboard } from '../ui/Dashboard.js';
import { SettingsPanel } from '../ui/SettingsPanel.js';
import { TasksPanel } from '../ui/TasksPanel.js';
import { LearningPanel } from '../ui/LearningPanel.js';
import { PresentationPanel } from '../ui/PresentationPanel.js';
import { CompanionDeck } from '../ui/CompanionDeck.js';
import { themeFor, rgba } from '../ui/Theme.js';
import { PluginLoader } from '../plugins/PluginLoader.js';
import { BUILTIN_PLUGINS } from '../plugins/registry.js';
import { NullProvider } from '../services/ai/Provider.js';
import { OllamaProvider } from '../services/ai/OllamaProvider.js';
import { AIService } from '../services/ai/AIService.js';
import { SpeechBubble } from '../ui/SpeechBubble.js';
import { Toast } from '../ui/Toast.js';
import { Sound } from '../ui/Sound.js';
import { FOODS } from '../config/constants.js';

const api = window.petAPI;

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

async function boot() {
  // --- core ----------------------------------------------------------------
  const bus = new EventBus();
  const clock = new Clock();
  const registry = new SystemRegistry();
  const stateHub = new StateHub(api);
  const logger = new Logger();
  logger.install();
  if (api && api.logWrite) logger.addSink((e) => api.logWrite(e));

  // Runtime health + debug snapshots (in-process, local only).
  const diagnostics = new Diagnostics({ bus });
  logger.addSink((e) => { if (e && e.level === 'error') diagnostics.noteError(e.msg || 'error'); });

  // --- shared services -----------------------------------------------------
  const nudge = new NudgeEngine();
  const dialogue = new DialogueService();

  // --- load + migrate save -------------------------------------------------
  const root = await stateHub.load();

  // --- register systems ----------------------------------------------------
  // The pet is the first System; the companion features register beside it.
  registry.register(
    new PetSystem({
      bus,
      getBounds: () => ({ w: window.innerWidth, h: window.innerHeight }),
    })
  );
  registry.register(new RelationshipSystem({ bus }));
  registry.register(new CodingSystem({ bus, clock, nudge }));
  registry.register(new AnkiSystem({ bus, clock, nudge }));
  registry.register(new HydrationSystem({ bus, clock, nudge }));
  registry.register(new MovementSystem({ bus, clock, nudge }));
  registry.register(new TasksSystem({ bus, clock, nudge }));
  registry.register(new LearningSystem({ bus, clock, nudge }));
  registry.register(new PresentationSystem({ bus, clock, nudge }));
  registry.register(new AttentionSystem({ bus, clock }));
  registry.register(new AICompanionSystem({ bus, clock }));
  registry.register(new KnowledgeSystem({ bus, clock }));
  registry.register(new ProjectSystem({ bus, clock, nudge }));
  registry.register(new FlashcardSystem({ bus, clock, nudge }));
  registry.register(new TimelineSystem({ bus, clock }));
  registry.register(new FetchSystem({ bus, clock }));
  registry.register(new UnoSystem({ bus, clock }));
  registry.register(new CricketSystem({ bus, clock }));
  registry.register(new CoworkerSystem({ bus, clock }));

  // Drop-in plugins: registered into the same lifecycle, with a context limited
  // to the capabilities each one declares.
  const pluginLoader = new PluginLoader();
  const pluginResult = pluginLoader.load({
    descriptors: BUILTIN_PLUGINS,
    services: { bus, clock, nudge },
    registry,
    logger,
  });
  if (pluginResult.failed.length) logger.warn('[plugins] some failed to load', pluginResult.failed);
  diagnostics.setPlugins(pluginResult);

  registry.init();
  registry.hydrateAll(root);
  diagnostics.setSystemsCount(registry.all().length);

  const petSystem = registry.get('pet');
  const pet = petSystem.pet; // the existing Pet object (rendering/input)
  const state = petSystem.state; // the existing PetState model
  const relationship = registry.get('relationship');
  const coding = registry.get('coding');
  const anki = registry.get('anki');
  const hydration = registry.get('hydration');
  const movement = registry.get('movement');
  const tasks = registry.get('tasks');
  const learning = registry.get('learning');
  const presentation = registry.get('presentation');
  const attention = registry.get('attention');
  const aiCompanion = registry.get('ai');
  const knowledge = registry.get('knowledge');
  const projects = registry.get('projects');
  const flashcards = registry.get('flashcards');
  const timeline = registry.get('timeline');
  const fetch = registry.get('fetch');
  const uno = registry.get('uno');
  const cricket = registry.get('cricket');
  const coworker = registry.get('coworker');

  // --- settings ------------------------------------------------------------
  const settings = new Settings(root.settings, () => requestSave());
  await settings.syncFromSystem();
  if (api) api.setAlwaysOnTop(settings.get('alwaysOnTop'));

  // --- supporting UI/services ----------------------------------------------
  const toast = new Toast(document.getElementById('toasts'));
  const sound = new Sound(settings);
  const celebration = new Celebration();

  const achievements = new AchievementManager(state, (ach) => {
    toast.show(ach.icon, `Achievement: ${ach.name}`);
    sound.play('achievement');
  });

  const speech = new SpeechBubble(document.getElementById('bubble'));
  const dashboard = new Dashboard(
    document.getElementById('dashboard'),
    state,
    achievements,
    (accId) => {
      state.setAccessory(accId);
      requestSave();
    }
  );
  const settingsPanel = new SettingsPanel(document.getElementById('settings'), settings);

  // Optional local AI (off by default). Ollama talks to localhost only; if the
  // setting is off or Ollama isn't installed, phrase() returns the template.
  const aiService = new AIService(new OllamaProvider(), () => settings.get('localAI'));
  void NullProvider; // available as the explicit "no AI" default if ever needed

  // Respect the OS "reduce motion" preference for accessibility.
  const reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const tasksPanel = new TasksPanel(document.getElementById('tasks'), tasks, () => requestSave());
  const learningPanel = new LearningPanel(document.getElementById('learning'), learning, () => requestSave());
  const presentationPanel = new PresentationPanel(document.getElementById('presentation'), presentation, () => requestSave());
  const deck = new CompanionDeck(document.getElementById('deck'), {
    coding, hydration, movement, tasks, learning, presentation, relationship, state,
  });

  // Snapshot of live context fed to the local model (no re-explaining needed).
  function aiStats() {
    const c = coding.status(), t = tasks.status(), l = learning.status(), p = presentation.status();
    const main = tasks.mainGoal && tasks.mainGoal();
    return {
      timeBucket: clock.bucket ? clock.bucket() : '',
      focusStreak: c.streakDays, focusMin: c.focusMinToday,
      tasksDone: t.done, tasksTotal: t.total, mainGoal: main ? main.text : null,
      learnStreak: l.streakDays, learnMin: l.todayMinutes,
      nextTalk: p.next || null,
      project: projects.nextDeadline(),
    };
  }

  const aiPanel = new AIPanel(document.getElementById('ai'), aiCompanion, {
    onChange: () => requestSave(),
    generate: async (text) => {
      // Thinking animation: the dog settles and shows it's pondering.
      pet.triggerAction('sit', 60000);
      speech.say('💭', 60000, true);
      const stats = aiStats();
      // Pull the most relevant vault notes so the dog can answer "what did I
      // learn about X?" without the user pasting anything.
      stats.relevantNotes = knowledge.search(text, 2).map((n) => ({ title: n.title, body: n.body.slice(0, 240) }));
      const reply = await aiService.generate(aiCompanion.buildPrompt(text, stats), { maxTokens: 220 });
      pet.triggerAction('happy', 1200); // ease out of the thinking pose
      speech.say(reply ? 'There you go! 🐾' : 'Enable Local AI in Settings 🙂', 2600, true);
      return reply;
    },
  });
  const knowledgePanel = new KnowledgePanel(document.getElementById('knowledge'), knowledge, () => requestSave());
  const projectPanel = new ProjectPanel(document.getElementById('projects'), projects, () => requestSave());
  const flashcardPanel = new FlashcardPanel(document.getElementById('flashcards'), flashcards, () => requestSave());
  const timelinePanel = new TimelinePanel(document.getElementById('timeline'), timeline, clock);
  const diagnosticsPanel = new DiagnosticsPanel(document.getElementById('diagnostics'), diagnostics, {
    onOpenLogs: () => { if (api && api.openLogs) api.openLogs(); },
    onRestore: (snap) => {
      try {
        registry.hydrateAll(snap);
        if (snap && snap.settings) settings.replace ? settings.replace(snap.settings) : null;
        requestSave();
        speech.say('Restored an earlier snapshot ⏪', 2400, true);
        toast.show('⏪', 'Snapshot restored');
      } catch (e) {
        console.error('restore failed', e);
      }
    },
  });

  const cricketPanel = new CricketPanel(document.getElementById('cricket'), cricket, {
    requestSave: () => requestSave(),
    onDogReact: (kind) => {
      switch (kind) {
        case 'six': pet.triggerAction('running', 1400); break; // chase the ball to the fence
        case 'dogsix': pet.triggerAction('excited', 1600); break;
        case 'dive': pet.triggerAction('jumping', 1200); speech.say('Got it! 🤾', 1400, true); break;
        case 'drop': pet.triggerAction('boop', 900); speech.say('Oops! 🐶', 1200, true); break;
        case 'wicket': pet.triggerAction('happy', 1100); break;
        case 'victory': pet.triggerAction('excited', 2200); speech.say('We won! 🏏🐾', 1900, true); break;
        case 'lose': pet.triggerAction('sad', 1600); break;
        case 'think': pet.triggerAction('look', 800); break;
        default: break;
      }
    },
  });

  // Surface the unlocked-trophy moment as a toast.
  bus.on('cricket:trophy', (p = {}) => { if (p.trophies && p.trophies.length) toast.show('🏆', 'Trophy unlocked!'); });

  const coworkerPanel = new CoworkerPanel(document.getElementById('coworker'), coworker, {
    onPlay: (game) => {
      coworker.startBreak(game);
      if (game === 'fetch') handleAction('play_fetch');
      else handleAction('panel', game); // 'uno' | 'cricket'
    },
  });

  // --- "dog as coworker" loop ------------------------------------------------
  // A finished focus sprint earns a treat and may prompt a break-time game.
  bus.on('coding:focus:done', () => {
    const idleSec = attention && attention.idleSeconds ? attention.idleSeconds() : 0;
    coworker.afterSprint({ quiet: attention.quiet, hour: new Date().getHours(), idleSec, now: Date.now() });
  });
  // The dog offers a break (already gated to non-quiet moments by the system).
  bus.on('coworker:suggest', (s = {}) => {
    if (attention.quiet || !s.text) return;
    speech.say(s.text, 3600, true);
    pet.triggerAction('bark', 700);
  });
  // Mini-games finishing counts toward the coworker tally.
  bus.on('uno:gameover', () => coworker.recordGameOver());
  bus.on('cricket:matchover', () => coworker.recordGameOver());
  bus.on('fetch:caught', () => coworker.recordGameOver());

  const unoPanel = new UnoPanel(document.getElementById('uno'), uno, {
    requestSave: () => requestSave(),
    onDogReact: (kind) => {
      switch (kind) {
        case 'play': pet.triggerAction('happy', 900); break; // wag after a play
        case 'uno': pet.triggerAction('bark', 800); speech.say('UNO! 🐶', 1500, true); break;
        case 'think': pet.triggerAction('look', 700); break;
        case 'surprised': pet.triggerAction('boop', 900); speech.say('?!', 1200, true); break;
        case 'disappointed': pet.triggerAction('sad', 1200); break;
        case 'win': pet.triggerAction('excited', 2000); speech.say('I win! 🐾', 1800, true); break;
        case 'lose': pet.triggerAction('sad', 1600); break;
        default: break;
      }
    },
  });

  const menu = new ContextMenu(document.getElementById('menu'), (action, payload) =>
    handleAction(action, payload)
  );
  menu.setPluginItems(pluginResult.menuItems);
  menu.setAttentionProvider(() => attention.status());

  // --- companion event wiring ----------------------------------------------
  const ICON = { focus: '🎯', anki: '🧠', streak: '🔥', friendship: '💛', levelup: '⬆️', hydration: '💧', movement: '🤸', task: '✓', maingoal: '🏆', learning: '📚', learngoal: '🌟', present: '🎤', project: '🗂️', milestone: '✅', cards: '🃏', fetch: '🦴', uno: '🎴', cricket: '🏏', six: '💥', default: '🎉' };
  const CTX = { focus: 'focus_done', anki: 'anki_done', streak: 'streak', friendship: 'friendship', levelup: 'levelup', hydration: 'hydrate_done', movement: 'move_done', task: 'task_done', maingoal: 'maingoal_done', learning: 'learn_done', learngoal: 'learngoal_done', present: 'present_done', project: 'project_done', milestone: 'milestone_done', cards: 'cards_done', fetch: 'fetch_done', uno: 'uno_done', cricket: 'cricket_done', six: 'cricket_done' };

  // The single "make it feel good" path: confetti + sound + toast + reward XP.
  bus.on('celebrate', (p = {}) => {
    const kind = p.kind || 'default';
    celebration.trigger({ x: pet.position.x, y: pet.position.y, kind, text: p.text, xp: p.xp, reduceMotion });
    toast.show(ICON[kind] || ICON.default, p.text || 'Nice!');
    sound.play('celebrate');
    const line = dialogue.pick(CTX[kind] || 'encourage', { friendship: relationship.friendship, n: p.n });
    if (line) speech.say(line, 2800, true);
    if (p.xp) state.addXp(p.xp); // integrates with the existing level system
  });

  // Gentle reminders (already rate-limited by the NudgeEngine). When local AI is
  // enabled it may reword the line; otherwise the template is used unchanged.
  bus.on('nudge', async (p = {}) => {
    // Adaptive attention: stay quiet during deep work / meetings / focus, except
    // for higher-priority reminders that are allowed to break through.
    if (!attention.allow(p.category)) return;
    const base = dialogue.pick(p.context || 'encourage', { friendship: relationship.friendship });
    if (!base) return;
    const line = await aiService.phrase(`Reword warmly and briefly (under 8 words), keep the meaning: "${base}"`, base);
    speech.say(line, 3200, true);
    if (!attention.quiet) pet.triggerAction('bark', 700); // no barking while quiet
  });

  // Level-ups: celebrate visually (XP already granted by addXp), no re-reward.
  bus.on('pet:levelup', (detail) => {
    celebration.trigger({ x: pet.position.x, y: pet.position.y, kind: 'levelup', text: `Level ${detail.level}!`, n: detail.level, reduceMotion });
    toast.show('⬆️', `Level ${detail.level}!`);
    sound.play('levelup');
    const line = dialogue.pick('levelup', { friendship: relationship.friendship, n: detail.level });
    if (line) speech.say(line, 2800, true);
  });

  // --- canvas --------------------------------------------------------------
  const canvas = document.getElementById('stage');
  const ctx = canvas.getContext('2d');
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    petSystem.setBounds({ w: window.innerWidth, h: window.innerHeight });
  }
  window.addEventListener('resize', resize);
  resize();

  // ---------------------------------------------------------------------------
  // Interaction routing
  // ---------------------------------------------------------------------------

  function handleAction(action, payload) {
    let ok = true;
    switch (action) {
      case 'feed':
        ok = state.feed(payload);
        if (ok) { pet.triggerAction('eating', 1600); sound.play('feed'); speech.react('thanks_feed'); }
        break;
      case 'water':
        state.giveWater(); pet.triggerAction('drinking', 1400); sound.play('water'); speech.react('thirsty'); break;
      case 'pet':
        state.pet(); pet.triggerAction('petted', 1000); sound.play('pet'); speech.react('thanks_pet'); break;
      case 'play':
        state.play(); pet.triggerAction('jumping', 1800); sound.play('play'); speech.react('thanks_play'); break;
      case 'play_fetch':
        if (fetch.active) break;
        fetchArmed = true;
        stickPos = { x: pet.position.x, y: pet.position.y - 30 };
        stickVel = { x: 0, y: 0 };
        sound.play('play');
        speech.say('Throw the stick — flick and release! 🦴', 2600, true);
        updateIgnore();
        break;
      case 'clean':
        state.clean(); pet.triggerAction('happy', 1600); sound.play('clean'); break;
      case 'sleep':
        pet.behavior._enter('sleep', 25); break;
      case 'treat':
        state.treat(payload); pet.triggerAction('happy', 1400); sound.play('pet'); speech.react('happy'); break;
      case 'focus_toggle':
        coding.toggleFocus();
        if (coding.running) { pet.triggerAction('bark', 600); speech.say('Focus mode — let\u2019s go!', 2600, true); }
        else { speech.say('Sprint paused.', 2000, true); }
        break;
      case 'anki_done':
        if (!anki.markDone()) speech.say('Already done today — nice!', 2400, true);
        break;
      case 'hydrate':
        hydration.drink(); pet.triggerAction('drinking', 1400); sound.play('water');
        speech.say('Glug glug! 💧', 1800, true); break;
      case 'stretch':
        movement.did('stretch'); pet.triggerAction('stretch', 1600); speech.say('Big stretch! 🧘', 1800, true); break;
      case 'stand':
        movement.did('stand'); pet.triggerAction('happy', 1200); sound.play('play'); speech.say('Up we go! 🧍', 1800, true); break;
      case 'eye':
        movement.did('eye'); pet.triggerAction('look', 1200); speech.say('Eyes resting… 👁️', 1800, true); break;
      case 'plugin':
        // A plugin's menu button -> emit on the real bus; the plugin handles it.
        if (payload && payload.pluginId && payload.action) {
          bus.emit(`plugin:${payload.pluginId}:${payload.action}`, {});
        }
        break;
      case 'attention': {
        const what = payload && payload.what;
        if (what === 'deepwork') {
          attention.setDeepWork(!attention.deepWork);
          speech.say(attention.deepWork ? 'Deep work — I\u2019ll keep quiet 🤫' : 'Welcome back! 🐾', 2400, true);
        } else if (what === 'meeting') {
          attention.setMeeting(!attention.meeting);
          speech.say(attention.meeting ? 'Meeting mode — staying silent 📵' : 'Meeting over — hi again! 🐾', 2400, true);
        }
        break;
      }
      case 'panel':
        dashboard.hide(); settingsPanel.hide(); tasksPanel.hide(); learningPanel.hide(); presentationPanel.hide(); deck.hide(); aiPanel.hide(); knowledgePanel.hide(); projectPanel.hide(); flashcardPanel.hide(); timelinePanel.hide(); diagnosticsPanel.hide(); unoPanel.hide(); cricketPanel.hide(); coworkerPanel.hide();
        if (payload === 'dashboard') dashboard.show();
        else if (payload === 'tasks') tasksPanel.show();
        else if (payload === 'learning') learningPanel.show();
        else if (payload === 'presentation') presentationPanel.show();
        else if (payload === 'deck') deck.show();
        else if (payload === 'ai') aiPanel.show();
        else if (payload === 'knowledge') knowledgePanel.show();
        else if (payload === 'projects') projectPanel.show();
        else if (payload === 'flashcards') flashcardPanel.show();
        else if (payload === 'timeline') timelinePanel.show();
        else if (payload === 'diagnostics') diagnosticsPanel.show();
        else if (payload === 'uno') unoPanel.show();
        else if (payload === 'cricket') cricketPanel.show();
        else if (payload === 'coworker') coworkerPanel.show();
        else settingsPanel.show();
        break;
    }
    // Level-up (and other model events) surface on the next registry tick via
    // the bus; we just persist the interaction here.
    if (ok) requestSave();
  }

  // --- tray-driven commands ------------------------------------------------
  if (api) {
    api.onPanelOpen((name) => handleAction('panel', name));
    api.onFeed(() => handleAction('feed', defaultFood(state.level)));
    // Privacy-safe activity signals -> adaptive attention.
    if (api.onContext) api.onContext((sig) => attention.onSignal(sig));
  }

  // ---------------------------------------------------------------------------
  // Pointer input: hover reaction, click -> menu, drag -> move
  // ---------------------------------------------------------------------------

  const cursor = { x: -999, y: -999, known: false };
  let ignoring = true; // mirror of native ignoreMouseEvents
  let dragging = false;
  let downPos = null;
  let lastHoverReact = 0;
  let wasOverPet = false;
  let prevX = null;
  let prevY = null;
  const petting = new PettingController(pet, { sound, speech, state, bus });

  // --- fetch mini-game state ---
  let fetchArmed = false; // a stick is in hand, following the cursor
  let stickPos = null;
  let stickVel = { x: 0, y: 0 };
  let fetchWasActive = false;
  let lastMoveT = 0;

  function petInteractive() {
    return !settings.get('clickThrough');
  }

  function updateIgnore() {
    const scale = settings.get('scale');
    const overPet = petInteractive() && cursor.known && pet.hitTest(cursor.x, cursor.y, scale);
    const wantMouse = menu.open || dashboard.visible || settingsPanel.visible || tasksPanel.visible || learningPanel.visible || presentationPanel.visible || deck.visible || aiPanel.visible || knowledgePanel.visible || projectPanel.visible || flashcardPanel.visible || timelinePanel.visible || diagnosticsPanel.visible || unoPanel.visible || cricketPanel.visible || coworkerPanel.visible || dragging || overPet || fetchArmed || fetch.active;
    const desired = !wantMouse;
    if (desired !== ignoring && api) {
      api.setIgnoreMouse(desired);
      ignoring = desired;
    }
  }

  window.addEventListener('mousemove', (e) => {
    cursor.x = e.clientX;
    cursor.y = e.clientY;
    cursor.known = true;

    // Fetch: while a stick is in hand, it tracks the cursor and we sample its
    // velocity so a flick imparts a throw.
    if (fetchArmed && !fetch.active) {
      const now = performance.now();
      const dtv = lastMoveT ? Math.max(0.001, (now - lastMoveT) / 1000) : 0.016;
      if (stickPos) {
        stickVel = { x: (e.clientX - stickPos.x) / dtv, y: (e.clientY - stickPos.y) / dtv };
      }
      stickPos = { x: e.clientX, y: e.clientY };
      lastMoveT = now;
      prevX = e.clientX; prevY = e.clientY;
      updateIgnore();
      return; // don't pet/drag while aiming a throw
    }

    if (dragging) pet.dragTo(e.clientX, e.clientY);

    // Region-aware petting: stroking different body parts feels different.
    const scale = settings.get('scale');
    const over = !fetch.active && petInteractive() && pet.hitTest(cursor.x, cursor.y, scale);
    const dist = prevX == null ? 0 : Math.hypot(e.clientX - prevX, e.clientY - prevY);
    if (over && !dragging) {
      petting.move(pet.regionAtPoint(cursor.x, cursor.y, scale), dist, Date.now());
    } else {
      petting.move(null, 0, Date.now());
    }
    prevX = e.clientX;
    prevY = e.clientY;
    wasOverPet = over;

    updateIgnore();
  });

  window.addEventListener('pointerdown', (e) => {
    if (fetchArmed) return; // aiming a throw; release will fling it
    if (!pet.hitTest(e.clientX, e.clientY, settings.get('scale'))) return;
    if (menu.open) { menu.hide(); return; }
    downPos = { x: e.clientX, y: e.clientY };
    dragging = false;
  });

  window.addEventListener('pointermove', (e) => {
    if (!downPos) return;
    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    if (dist > 6) dragging = true;
  });

  window.addEventListener('pointerup', (e) => {
    // Fetch: releasing throws the stick with the cursor's recent velocity (or a
    // gentle default toss if you barely moved).
    if (fetchArmed) {
      const from = stickPos || { x: e.clientX, y: e.clientY };
      let vel = stickVel;
      if (Math.hypot(vel.x, vel.y) < 140) vel = { x: pet.facing * 520, y: -120 };
      fetch.throwStick(from, vel, pet.mood, state.needs.energy);
      fetchArmed = false;
      stickVel = { x: 0, y: 0 };
      updateIgnore();
      return;
    }
    if (!downPos) return;
    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    if (dragging || dist > 6) {
      requestSave(); // finished a drag -> remember new location
    } else {
      menu.show(e.clientX, e.clientY, state.level); // a click opens the menu
    }
    downPos = null;
    dragging = false;
    updateIgnore();
  });

  // Close panels with Escape.
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { menu.hide(); dashboard.hide(); settingsPanel.hide(); tasksPanel.hide(); learningPanel.hide(); presentationPanel.hide(); deck.hide(); aiPanel.hide(); knowledgePanel.hide(); projectPanel.hide(); flashcardPanel.hide(); timelinePanel.hide(); diagnosticsPanel.hide(); unoPanel.hide(); cricketPanel.hide(); coworkerPanel.hide(); updateIgnore(); }
  });

  // ---------------------------------------------------------------------------
  // Persistence
  // ---------------------------------------------------------------------------

  // StateHub assembles the full save: PetSystem writes the legacy top-level
  // pet/stats/achievements, settings are passed in, and any system slices +
  // analytics + unknown future keys are preserved across the cycle.
  function snapshot() {
    return stateHub.snapshot(registry, { settings: settings.all() });
  }

  let savePending = false;
  function requestSave() {
    savePending = true; // coalesced; flushed by the loop
  }
  async function flushSave(force = false) {
    if (!api) return;
    if (!savePending && !force) return;
    savePending = false;
    const snap = snapshot();
    try {
      await api.saveState(snap);
      diagnostics.noteSave(true);
      diagnostics.captureSnapshot(snap);
    } catch (e) {
      diagnostics.noteSave(false);
      console.error('save failed', e);
    }
  }

  // Push a snapshot to main frequently so it can save on shutdown even if our
  // explicit save didn't fire.
  setInterval(() => { if (api) api.pushState(snapshot()); }, 3000);
  setInterval(() => flushSave(), 15000);

  window.addEventListener('beforeunload', () => { if (api) api.pushState(snapshot()); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(true); });

  // ---------------------------------------------------------------------------
  // Main loop
  // ---------------------------------------------------------------------------

  speech.maybeGreet();

  let achTimer = 0;
  let speechTimer = 0;

  function frame() {
    // Performance: when the overlay is hidden (minimised to tray / occluded),
    // do no work at all. clock.tick() clamps the gap so nothing jumps on return.
    if (document.hidden) {
      requestAnimationFrame(frame);
      return;
    }

    const dt = clock.tick(); // sanitised, clamped delta in seconds
    diagnostics.recordFrame();
    const now = clock.now();
    const cur = cursor.known ? { x: cursor.x, y: cursor.y } : null;

    // Fetch mini-game: drive the dog toward the stick / back home. Done before
    // the sim tick so the held pose and position are current this frame.
    if (fetch.active) {
      const g = fetch.update(dt, pet.position);
      pet.hold(true, g.anim || 'look');
      if (g.target) {
        pet.faceToward(g.target.x);
        pet.moveToward(g.target, fetch.speed(), dt);
      }
    } else if (fetchWasActive) {
      pet.hold(false); // hand control back to free will
    }
    fetchWasActive = fetch.active;

    // Advance all systems (PetSystem ticks the pet and emits model events).
    registry.tick(dt, now, { cursor: cur });
    // Calm the dog down during deep work / meetings (slower, settled motion).
    const animSpeed = settings.get('animationSpeed') * (attention.quiet ? 0.5 : 1);
    petSystem.animate(dt, animSpeed);

    // Periodic, cheap checks.
    achTimer += dt;
    if (achTimer > 2) { achTimer = 0; achievements.evaluate(); }
    speechTimer += dt;
    if (speechTimer > 6) { speechTimer = 0; if (!attention.quiet && !fetch.active) speech.maybeIdle(pet.mood); }

    // Render.
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

    // Optional day/night ambiance: a soft localized glow behind the dog plus a
    // dynamic shadow. Subtle and translucent, so the desktop is never blocked.
    let env = { reduceMotion };
    if (settings.get('ambiance')) {
      const theme = themeFor();
      env = { shadowScale: theme.shadowScale, shadowAlpha: theme.shadowAlpha, reduceMotion };
      const px = pet.position.x;
      const py = pet.position.y;
      const R = 78 * settings.get('scale');
      const grad = ctx.createRadialGradient(px, py, 0, px, py, R);
      grad.addColorStop(0, rgba(theme.glow, theme.glowAlpha));
      grad.addColorStop(1, rgba(theme.glow, 0));
      ctx.fillStyle = grad;
      ctx.fillRect(px - R, py - R, R * 2, R * 2);
    }

    ctx.globalAlpha = settings.get('opacity');
    petSystem.render(ctx, settings.get('scale'), env);
    ctx.globalAlpha = 1;

    // Fetch stick: in hand (armed) it follows the cursor; otherwise it's the
    // flying / carried stick the system tracks.
    {
      let sp = null;
      if (fetch.active && fetch.stick) sp = fetch.stick;
      else if (fetchArmed && stickPos) sp = stickPos;
      if (sp) drawStick(ctx, sp.x, sp.y, sp.spin || 0, settings.get('scale'));
    }

    speech.update(pet.position.x, pet.position.y, settings.get('scale'));

    // Celebrations draw on top of the pet, at full opacity.
    if (celebration.active) {
      celebration.update(dt);
      celebration.draw(ctx);
    }

    if (dashboard.visible) dashboard.render(); // live-refresh bars
    if (presentationPanel.visible) presentationPanel.syncTimer(); // live rehearsal clock
    updateIgnore(); // catch panel/menu open-close transitions

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Draw a little brown stick (a canvas path — no image asset). */
function drawStick(ctx, x, y, spin, scale = 1) {
  const len = 26 * scale;
  const w = 4.5 * scale;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(spin);
  ctx.strokeStyle = '#9b6b3a';
  ctx.lineCap = 'round';
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(-len / 2, 0);
  ctx.lineTo(len / 2, 0);
  ctx.stroke();
  // a small knot/branch for character
  ctx.lineWidth = w * 0.7;
  ctx.beginPath();
  ctx.moveTo(len * 0.12, 0);
  ctx.lineTo(len * 0.3, -w * 1.3);
  ctx.stroke();
  ctx.restore();
}

function defaultFood(level) {
  // Pick the best unlocked everyday food.
  const ids = Object.entries(FOODS)
    .filter(([, f]) => !f.unlockLevel || level >= f.unlockLevel)
    .map(([id]) => id);
  return ids.includes('fish') ? 'fish' : ids[0] || 'kibble';
}

boot().catch((e) => console.error('boot failed', e));
