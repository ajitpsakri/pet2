/**
 * renderer.js
 * ----------------------------------------------------------------------------
 * Bootstrapper for the overlay window. v3 is a pure desktop puppy + light
 * coding-companion presence: it loads + migrates the save, builds the core
 * (EventBus, Clock, SystemRegistry), registers the pet and a small set of
 * companion systems, wires the UI (menu, a few panels, speech, sound), runs one
 * requestAnimationFrame loop, and manages click-through + persistence.
 *
 * Loaded as a native ES module from index.html (no bundler, fully offline).
 */

import { EventBus } from '../core/EventBus.js';
import { Clock } from '../core/Clock.js';
import { SystemRegistry } from '../core/SystemRegistry.js';
import { StateHub } from '../core/StateHub.js';
import { Logger } from '../core/Logger.js';

import { PetSystem } from '../systems/pet/PetSystem.js';
import { RelationshipSystem } from '../systems/relationship/RelationshipSystem.js';
import { CodingSystem } from '../systems/coding/CodingSystem.js';
import { AICompanionSystem } from '../systems/ai/AICompanionSystem.js';
import { TimelineSystem } from '../systems/timeline/TimelineSystem.js';
import { FetchSystem } from '../systems/fetch/FetchSystem.js';
import { FeedingSystem } from '../systems/feeding/FeedingSystem.js';

import { Diagnostics } from '../services/Diagnostics.js';
import { NudgeEngine } from '../services/NudgeEngine.js';
import { DialogueService } from '../services/DialogueService.js';
import { NullProvider } from '../services/ai/Provider.js';
import { OllamaProvider } from '../services/ai/OllamaProvider.js';
import { AIService } from '../services/ai/AIService.js';

import { AIPanel } from '../ui/AIPanel.js';
import { TimelinePanel } from '../ui/TimelinePanel.js';
import { DiagnosticsPanel } from '../ui/DiagnosticsPanel.js';
import { SettingsPanel } from '../ui/SettingsPanel.js';
import { ContextMenu } from '../ui/ContextMenu.js';
import { PettingController } from '../ui/Petting.js';
import { Celebration } from '../ui/Celebration.js';
import { SpeechBubble } from '../ui/SpeechBubble.js';
import { Toast } from '../ui/Toast.js';
import { Sound } from '../ui/Sound.js';
import { themeFor, rgba } from '../ui/Theme.js';

import { Settings } from '../settings/Settings.js';
import { AchievementManager } from '../achievements/AchievementManager.js';
import { PluginLoader } from '../plugins/PluginLoader.js';
import { BUILTIN_PLUGINS } from '../plugins/registry.js';

const api = window.petAPI;

async function boot() {
  // --- core ----------------------------------------------------------------
  const bus = new EventBus();
  const clock = new Clock();
  const registry = new SystemRegistry();
  const stateHub = new StateHub(api);
  const logger = new Logger();
  logger.install();
  if (api && api.logWrite) logger.addSink((e) => api.logWrite(e));

  const diagnostics = new Diagnostics({ bus });
  logger.addSink((e) => { if (e && e.level === 'error') diagnostics.noteError(e.msg || 'error'); });

  const nudge = new NudgeEngine();
  const dialogue = new DialogueService();

  // --- load + migrate save -------------------------------------------------
  const root = await stateHub.load();

  // --- register systems (the puppy first, companions beside it) ------------
  registry.register(new PetSystem({ bus, getBounds: () => ({ w: window.innerWidth, h: window.innerHeight }) }));
  registry.register(new RelationshipSystem({ bus }));
  registry.register(new CodingSystem({ bus, clock, nudge }));
  registry.register(new AICompanionSystem({ bus, clock }));
  registry.register(new TimelineSystem({ bus, clock }));
  registry.register(new FetchSystem({ bus, clock }));
  registry.register(new FeedingSystem({ bus, clock }));

  // Drop-in plugins, capability-limited to what each declares.
  const pluginLoader = new PluginLoader();
  const pluginResult = pluginLoader.load({ descriptors: BUILTIN_PLUGINS, services: { bus, clock, nudge }, registry, logger });
  if (pluginResult.failed.length) logger.warn('[plugins] some failed to load', pluginResult.failed);
  diagnostics.setPlugins(pluginResult);

  registry.init();
  registry.hydrateAll(root);
  diagnostics.setSystemsCount(registry.all().length);

  const petSystem = registry.get('pet');
  const pet = petSystem.pet;
  const state = petSystem.state;
  const relationship = registry.get('relationship');
  const coding = registry.get('coding');
  const aiCompanion = registry.get('ai');
  const timeline = registry.get('timeline');
  const fetch = registry.get('fetch');
  const feeding = registry.get('feeding');

  // --- settings ------------------------------------------------------------
  const settings = new Settings(root.settings, () => requestSave());
  await settings.syncFromSystem();
  if (api) api.setAlwaysOnTop(settings.get('alwaysOnTop'));

  // --- supporting UI/services ----------------------------------------------
  const toast = new Toast(document.getElementById('toasts'));
  const sound = new Sound(settings);
  const celebration = new Celebration();
  const speech = new SpeechBubble(document.getElementById('bubble'));
  const reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  const achievements = new AchievementManager(state, (ach) => {
    toast.show(ach.icon, `Achievement: ${ach.name}`);
    sound.play('achievement');
  });

  const settingsPanel = new SettingsPanel(document.getElementById('settings'), settings);
  const timelinePanel = new TimelinePanel(document.getElementById('timeline'), timeline, clock);

  // Optional local AI (off by default; localhost Ollama only).
  const aiService = new AIService(new OllamaProvider(), () => settings.get('localAI'));
  void NullProvider;

  function aiStats() {
    return {
      timeBucket: clock.bucket ? clock.bucket() : '',
      mood: pet.mood,
      level: state.level,
      friendship: relationship.friendship,
      daysTogether: state.ageDays ? state.ageDays() : undefined,
    };
  }

  const aiPanel = new AIPanel(document.getElementById('ai'), aiCompanion, {
    onChange: () => requestSave(),
    generate: async (text) => {
      pet.triggerAction('sit', 60000);
      speech.say('💭', 60000, true);
      const reply = await aiService.generate(aiCompanion.buildPrompt(text, aiStats()), { maxTokens: 220 });
      pet.triggerAction('happy', 1200);
      speech.say(reply ? 'There you go! 🐾' : 'Enable Local AI in Settings 🙂', 2600, true);
      return reply;
    },
  });

  const diagnosticsPanel = new DiagnosticsPanel(document.getElementById('diagnostics'), diagnostics, {
    onOpenLogs: () => { if (api && api.openLogs) api.openLogs(); },
    onRestore: (snap) => {
      try {
        registry.hydrateAll(snap);
        requestSave();
        speech.say('Restored an earlier snapshot ⏪', 2400, true);
        toast.show('⏪', 'Snapshot restored');
      } catch (e) { console.error('restore failed', e); }
    },
  });

  const menu = new ContextMenu(document.getElementById('menu'), (action, payload) => handleAction(action, payload));
  menu.setPluginItems(pluginResult.menuItems);
  menu.setFeedingProvider(() => feeding.status());

  // --- companion event wiring ----------------------------------------------
  const ICON = { friendship: '💛', levelup: '⬆️', fetch: '🦴', meal: '🍽️', milestone: '🎉', default: '🎉' };
  const CTX = { friendship: 'friendship', levelup: 'levelup', fetch: 'fetch_done', meal: 'feed_done', milestone: 'levelup' };

  bus.on('celebrate', (p = {}) => {
    const kind = p.kind || 'default';
    celebration.trigger({ x: pet.position.x, y: pet.position.y, kind, text: p.text, xp: p.xp, reduceMotion });
    toast.show(ICON[kind] || ICON.default, p.text || 'Nice!');
    sound.play('celebrate');
    const line = dialogue.pick(CTX[kind] || 'encourage', { friendship: relationship.friendship, n: p.n });
    if (line) speech.say(line, 2800, true);
    if (p.xp) state.addXp(p.xp);
  });

  // Gentle reminders (rate-limited by the NudgeEngine). The puppy stays quiet
  // while sleeping — no separate work modes needed.
  bus.on('nudge', async (p = {}) => {
    if (pet.behavior && pet.behavior.asleep) return;
    const base = dialogue.pick(p.context || 'encourage', { friendship: relationship.friendship });
    if (!base) return;
    const line = await aiService.phrase(`Reword warmly and briefly (under 8 words), keep the meaning: "${base}"`, base);
    speech.say(line, 3200, true);
    pet.triggerAction('bark', 700);
  });

  bus.on('pet:levelup', (detail) => {
    celebration.trigger({ x: pet.position.x, y: pet.position.y, kind: 'levelup', text: `Level ${detail.level}!`, n: detail.level, reduceMotion });
    toast.show('⬆️', `Level ${detail.level}!`);
    sound.play('levelup');
    const line = dialogue.pick('levelup', { friendship: relationship.friendship, n: detail.level });
    if (line) speech.say(line, 2800, true);
  });

  // --- canvas --------------------------------------------------------------
  const canvas = document.getElementById('stage');
  const ctx = canvas.getContext('2d');
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    petSystem.setBounds({ w: window.innerWidth, h: window.innerHeight });
  }
  window.addEventListener('resize', resize);
  resize();

  // --- interaction routing -------------------------------------------------
  function handleAction(action, payload) {
    let ok = true;
    switch (action) {
      case 'feed': {
        const meal = payload || 'breakfast';
        if (feeding.feed(meal)) { state.feed('kibble'); pet.triggerAction('eating', 1600); sound.play('feed'); speech.react('thanks_feed'); }
        else { speech.say('Already had that meal today 🐶', 2200, true); ok = false; }
        break;
      }
      case 'pet':
        state.pet(); pet.triggerAction('petted', 1000); sound.play('pet'); speech.react('thanks_pet'); break;
      case 'play':
        state.play(); pet.triggerAction('jumping', 1800); sound.play('play'); speech.react('thanks_play'); break;
      case 'play_fetch':
        if (fetch.active) break;
        fetchArmed = true;
        aimPos = null;
        if (pet.behavior && pet.behavior.asleep) pet.behavior._enter('idle', 1); // wake up to play
        sound.play('play');
        speech.say('Click anywhere to throw the stick! 🦴', 2800, true);
        updateIgnore();
        break;
      case 'treat':
        state.treat(payload); pet.triggerAction('happy', 1400); sound.play('pet'); speech.react('happy'); break;
      case 'sleep':
        pet.behavior._enter('sleep', 25); speech.say('Nap time… 💤', 2000, true); break;
      case 'focus_toggle':
        coding.toggleFocus();
        if (coding.running) { pet.triggerAction('bark', 600); speech.say('I\u2019ll keep you company — let\u2019s focus! 🐾', 2600, true); }
        else { speech.say('Break time!', 2000, true); }
        break;
      case 'plugin':
        if (payload && payload.pluginId && payload.action) bus.emit(`plugin:${payload.pluginId}:${payload.action}`, {});
        break;
      case 'panel':
        settingsPanel.hide(); aiPanel.hide(); timelinePanel.hide(); diagnosticsPanel.hide();
        if (payload === 'ai') aiPanel.show();
        else if (payload === 'timeline') timelinePanel.show();
        else if (payload === 'diagnostics') diagnosticsPanel.show();
        else settingsPanel.show();
        break;
    }
    if (ok) requestSave();
  }

  if (api) {
    api.onPanelOpen((name) => handleAction('panel', name));
    api.onFeed(() => handleAction('feed', feeding.status().breakfast ? (feeding.status().lunch ? 'dinner' : 'lunch') : 'breakfast'));
  }

  // --- pointer input -------------------------------------------------------
  const cursor = { x: -999, y: -999, known: false };
  let ignoring = true;
  let dragging = false;
  let downPos = null;
  let prevX = null;
  let prevY = null;
  const petting = new PettingController(pet, { sound, speech, state, bus });

  // fetch mini-game state
  let fetchArmed = false;
  let aimPos = null;
  let fetchWasActive = false;

  function petInteractive() { return !settings.get('clickThrough'); }

  function updateIgnore() {
    const scale = settings.get('scale');
    const overPet = petInteractive() && cursor.known && pet.hitTest(cursor.x, cursor.y, scale);
    const wantMouse = menu.open || settingsPanel.visible || aiPanel.visible || timelinePanel.visible || diagnosticsPanel.visible || dragging || overPet || fetchArmed || fetch.active;
    const desired = !wantMouse;
    if (desired !== ignoring && api) { api.setIgnoreMouse(desired); ignoring = desired; }
  }

  window.addEventListener('mousemove', (e) => {
    cursor.x = e.clientX; cursor.y = e.clientY; cursor.known = true;

    if (fetchArmed && !fetch.active) {
      aimPos = { x: e.clientX, y: e.clientY }; // where the stick will be thrown
      updateIgnore();
      return; // don't pet/drag while aiming a throw
    }

    if (dragging) pet.dragTo(e.clientX, e.clientY);

    const scale = settings.get('scale');
    const over = !fetch.active && petInteractive() && pet.hitTest(cursor.x, cursor.y, scale);
    const dist = prevX == null ? 0 : Math.hypot(e.clientX - prevX, e.clientY - prevY);
    if (over && !dragging) petting.move(pet.regionAtPoint(cursor.x, cursor.y, scale), dist, Date.now());
    else petting.move(null, 0, Date.now());
    prevX = e.clientX; prevY = e.clientY;
    updateIgnore();
  });

  window.addEventListener('pointerdown', (e) => {
    if (fetchArmed) return;
    if (!pet.hitTest(e.clientX, e.clientY, settings.get('scale'))) return;
    if (menu.open) { menu.hide(); return; }
    downPos = { x: e.clientX, y: e.clientY };
    dragging = false;
  });

  window.addEventListener('pointermove', (e) => {
    if (!downPos) return;
    if (Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y) > 6) dragging = true;
  });

  window.addEventListener('pointerup', (e) => {
    if (fetchArmed) {
      const aim = aimPos || { x: e.clientX, y: e.clientY };
      const from = { x: pet.position.x, y: pet.position.y };
      const dx = aim.x - from.x;
      const dy = aim.y - from.y;
      const d = Math.hypot(dx, dy);
      let vel;
      if (d < 30) vel = { x: pet.facing * 520, y: -120 }; // tapped on the pup: gentle forward toss
      else {
        const speed = Math.min(1100, d * 2.8 + 120); // friction-tuned so it lands near the click
        vel = { x: (dx / d) * speed, y: (dy / d) * speed };
      }
      fetch.throwStick(from, vel, pet.mood, state.needs.energy);
      fetchArmed = false; aimPos = null;
      updateIgnore();
      return;
    }
    if (!downPos) return;
    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    if (dragging || dist > 6) requestSave();
    else menu.show(e.clientX, e.clientY, state.level);
    downPos = null; dragging = false;
    updateIgnore();
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { menu.hide(); settingsPanel.hide(); aiPanel.hide(); timelinePanel.hide(); diagnosticsPanel.hide(); updateIgnore(); }
  });

  // --- persistence ---------------------------------------------------------
  function snapshot() { return stateHub.snapshot(registry, { settings: settings.all() }); }
  let savePending = false;
  function requestSave() { savePending = true; }
  async function flushSave(force = false) {
    if (!api) return;
    if (!savePending && !force) return;
    savePending = false;
    const snap = snapshot();
    try { await api.saveState(snap); diagnostics.noteSave(true); diagnostics.captureSnapshot(snap); }
    catch (e) { diagnostics.noteSave(false); console.error('save failed', e); }
  }
  setInterval(() => { if (api) api.pushState(snapshot()); }, 3000);
  setInterval(() => flushSave(), 15000);
  window.addEventListener('beforeunload', () => { if (api) api.pushState(snapshot()); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(true); });

  // --- main loop -----------------------------------------------------------
  speech.maybeGreet();
  let achTimer = 0;
  let speechTimer = 0;
  let dayTimer = 0;
  let lastDays = state.ageDays ? state.ageDays() : 0;

  function frame() {
    if (document.hidden) { requestAnimationFrame(frame); return; }

    const dt = clock.tick();
    diagnostics.recordFrame();
    const now = clock.now();
    const cur = cursor.known ? { x: cursor.x, y: cursor.y } : null;

    // Fetch: drive the dog toward the stick / back home before the sim tick.
    if (fetch.active) {
      const g = fetch.update(dt, pet.position);
      pet.hold(true, g.anim || 'look');
      if (g.target) { pet.faceToward(g.target.x); pet.moveToward(g.target, fetch.speed(), dt); }
    } else if (fetchWasActive) {
      pet.hold(false);
    }
    fetchWasActive = fetch.active;

    registry.tick(dt, now, { cursor: cur });
    petSystem.animate(dt, settings.get('animationSpeed'));

    achTimer += dt;
    if (achTimer > 2) { achTimer = 0; achievements.evaluate(); }
    speechTimer += dt;
    const asleep = !!(pet.behavior && pet.behavior.asleep);
    if (speechTimer > 6) { speechTimer = 0; if (!asleep && !fetch.active) speech.maybeIdle(pet.mood); }
    // Anniversary check (cheap, ~once a minute).
    dayTimer += dt;
    if (dayTimer > 60) {
      dayTimer = 0;
      const d = state.ageDays ? state.ageDays() : 0;
      if (d !== lastDays) { lastDays = d; timeline.noteDaysTogether(d); }
    }

    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

    let env = { reduceMotion };
    if (settings.get('ambiance')) {
      const theme = themeFor();
      env = { shadowScale: theme.shadowScale, shadowAlpha: theme.shadowAlpha, reduceMotion };
      const px = pet.position.x, py = pet.position.y;
      const R = 78 * settings.get('scale');
      const grad = ctx.createRadialGradient(px, py, 0, px, py, R);
      grad.addColorStop(0, rgba(theme.glow, theme.glowAlpha));
      grad.addColorStop(1, rgba(theme.glow, 0));
      ctx.fillStyle = grad;
      ctx.fillRect(px - R, py - R, R * 2, R * 2);
    }

    ctx.globalAlpha = settings.get('opacity');
    petSystem.render(ctx, settings.get('scale'), env);
    ctx.globalAlpha = 1;

    {
      let sp = null;
      if (fetch.active && fetch.stick) sp = fetch.stick;
      else if (fetchArmed) sp = { x: pet.position.x + pet.facing * 10, y: pet.position.y - 22 };
      if (sp) drawStick(ctx, sp.x, sp.y, sp.spin || 0, settings.get('scale'));
      // Aim marker while you choose where to throw.
      if (fetchArmed && aimPos) {
        ctx.save();
        ctx.strokeStyle = 'rgba(155,107,58,0.8)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(aimPos.x, aimPos.y, 9, 0, Math.PI * 2);
        ctx.moveTo(aimPos.x - 13, aimPos.y);
        ctx.lineTo(aimPos.x + 13, aimPos.y);
        ctx.moveTo(aimPos.x, aimPos.y - 13);
        ctx.lineTo(aimPos.x, aimPos.y + 13);
        ctx.stroke();
        ctx.restore();
      }
    }

    speech.update(pet.position.x, pet.position.y, settings.get('scale'));

    if (celebration.active) { celebration.update(dt); celebration.draw(ctx); }

    updateIgnore();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Draw a little brown stick (a canvas path — no image asset). */
function drawStick(ctx, x, y, spin, scale = 1) {
  const len = 26 * scale;
  const w = 4.5 * scale;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(spin);
  ctx.strokeStyle = '#9b6b3a';
  ctx.lineCap = 'round';
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(-len / 2, 0);
  ctx.lineTo(len / 2, 0);
  ctx.stroke();
  ctx.lineWidth = w * 0.7;
  ctx.beginPath();
  ctx.moveTo(len * 0.12, 0);
  ctx.lineTo(len * 0.3, -w * 1.3);
  ctx.stroke();
  ctx.restore();
}

boot().catch((e) => console.error('boot failed', e));
