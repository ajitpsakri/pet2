/**
 * renderer.js
 * ----------------------------------------------------------------------------
 * The conductor for everything that runs inside the overlay window. It:
 *   1. Loads + migrates the save, applying gentle "while you were away" decay.
 *   2. Wires the pet, UI panels, achievements, speech, and sound together.
 *   3. Runs a single requestAnimationFrame loop (sim tick + animate + render).
 *   4. Manages click-through so empty desktop space never blocks your work.
 *   5. Persists state continuously and on exit.
 *
 * Loaded as an ES module from index.html, so it can import the /src modules
 * directly with no bundler — keeping the build trivial and offline.
 */

import { SCHEMA_VERSION, migrate } from '../storage/schema.js';
import { PetState } from '../pet/PetState.js';
import { Pet } from '../pet/Pet.js';
import { Settings } from '../settings/Settings.js';
import { AchievementManager } from '../achievements/AchievementManager.js';
import { ContextMenu } from '../ui/ContextMenu.js';
import { Dashboard } from '../ui/Dashboard.js';
import { SettingsPanel } from '../ui/SettingsPanel.js';
import { SpeechBubble } from '../ui/SpeechBubble.js';
import { Toast } from '../ui/Toast.js';
import { Sound } from '../ui/Sound.js';
import { FOODS } from '../config/constants.js';

const api = window.petAPI;

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

async function boot() {
  // --- load + migrate save -------------------------------------------------
  let raw = null;
  try {
    raw = api ? await api.loadState() : null;
  } catch (e) {
    console.error('load failed, starting fresh', e);
  }
  const saved = migrate(raw);

  const state = new PetState(saved);
  applyAwayDecay(state, saved.stats.lastSeen);

  // --- bounds (window spans the desktop work area) -------------------------
  let bounds = { w: window.innerWidth, h: window.innerHeight };

  const pet = new Pet(state, bounds);

  // --- settings ------------------------------------------------------------
  const settings = new Settings(saved.settings, () => requestSave());
  await settings.syncFromSystem();
  if (api) api.setAlwaysOnTop(settings.get('alwaysOnTop'));

  // --- supporting systems --------------------------------------------------
  const toast = new Toast(document.getElementById('toasts'));
  const sound = new Sound(settings);

  const achievements = new AchievementManager(state, (ach) => {
    toast.show(ach.icon, `Achievement: ${ach.name}`);
    sound.play('achievement');
  });

  const speech = new SpeechBubble(document.getElementById('bubble'));
  const dashboard = new Dashboard(
    document.getElementById('dashboard'),
    state,
    achievements,
    (accId) => {
      state.setAccessory(accId);
      requestSave();
    }
  );
  const settingsPanel = new SettingsPanel(document.getElementById('settings'), settings);

  const menu = new ContextMenu(document.getElementById('menu'), (action, payload) =>
    handleAction(action, payload)
  );

  // --- canvas --------------------------------------------------------------
  const canvas = document.getElementById('stage');
  const ctx = canvas.getContext('2d');
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(window.innerWidth * dpr);
    canvas.height = Math.floor(window.innerHeight * dpr);
    canvas.style.width = `${window.innerWidth}px`;
    canvas.style.height = `${window.innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    bounds = { w: window.innerWidth, h: window.innerHeight };
    pet.setBounds(bounds);
  }
  window.addEventListener('resize', resize);
  resize();

  // ---------------------------------------------------------------------------
  // Interaction routing
  // ---------------------------------------------------------------------------

  function handleAction(action, payload) {
    let ok = true;
    switch (action) {
      case 'feed':
        ok = state.feed(payload);
        if (ok) { pet.triggerAction('eating', 1600); sound.play('feed'); speech.react('thanks_feed'); }
        break;
      case 'water':
        state.giveWater(); pet.triggerAction('drinking', 1400); sound.play('water'); speech.react('thirsty'); break;
      case 'pet':
        state.pet(); pet.triggerAction('petted', 1000); sound.play('pet'); speech.react('thanks_pet'); break;
      case 'play':
        state.play(); pet.triggerAction('jumping', 1800); sound.play('play'); speech.react('thanks_play'); break;
      case 'clean':
        state.clean(); pet.triggerAction('happy', 1600); sound.play('clean'); break;
      case 'sleep':
        pet.behavior._enter('sleep', 25); break;
      case 'treat':
        state.treat(payload); pet.triggerAction('happy', 1400); sound.play('pet'); speech.react('happy'); break;
      case 'panel':
        if (payload === 'dashboard') { settingsPanel.hide(); dashboard.show(); }
        else { dashboard.hide(); settingsPanel.show(); }
        break;
    }
    if (ok) { drainEvents(); requestSave(); }
  }

  // Surface model events (levelups etc.) into toasts/sound.
  function drainEvents() {
    for (const ev of state.drainEvents()) {
      if (ev.type === 'levelup') {
        toast.show('⬆️', `Level ${ev.detail.level}!`);
        sound.play('levelup');
        speech.react('levelup');
      }
    }
  }

  // --- tray-driven commands ------------------------------------------------
  if (api) {
    api.onPanelOpen((name) => handleAction('panel', name));
    api.onFeed(() => handleAction('feed', defaultFood(state.level)));
  }

  // ---------------------------------------------------------------------------
  // Pointer input: hover reaction, click → menu, drag → move
  // ---------------------------------------------------------------------------

  const cursor = { x: -999, y: -999, known: false };
  let ignoring = true; // mirror of native ignoreMouseEvents
  let dragging = false;
  let downPos = null;
  let movedWhileDown = 0;
  let lastHoverReact = 0;
  let wasOverPet = false;

  function petInteractive() {
    return !settings.get('clickThrough');
  }

  function updateIgnore() {
    const scale = settings.get('scale');
    const overPet = petInteractive() && cursor.known && pet.hitTest(cursor.x, cursor.y, scale);
    const wantMouse = menu.open || dashboard.visible || settingsPanel.visible || dragging || overPet;
    const desired = !wantMouse;
    if (desired !== ignoring && api) {
      api.setIgnoreMouse(desired);
      ignoring = desired;
    }
  }

  window.addEventListener('mousemove', (e) => {
    cursor.x = e.clientX;
    cursor.y = e.clientY;
    cursor.known = true;

    if (dragging) {
      pet.dragTo(e.clientX, e.clientY);
      movedWhileDown += 1;
    }

    // Gentle reaction when the cursor first touches the pet.
    const over = petInteractive() && pet.hitTest(cursor.x, cursor.y, settings.get('scale'));
    if (over && !wasOverPet && Date.now() - lastHoverReact > 2500 && !dragging) {
      lastHoverReact = Date.now();
      if (!pet.actionAnim) pet.triggerAction('petted', 500);
    }
    wasOverPet = over;

    updateIgnore();
  });

  window.addEventListener('pointerdown', (e) => {
    if (!pet.hitTest(e.clientX, e.clientY, settings.get('scale'))) return;
    if (menu.open) { menu.hide(); return; }
    downPos = { x: e.clientX, y: e.clientY };
    movedWhileDown = 0;
    dragging = false;
  });

  window.addEventListener('pointermove', (e) => {
    if (!downPos) return;
    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    if (dist > 6) dragging = true;
  });

  window.addEventListener('pointerup', (e) => {
    if (!downPos) return;
    const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
    if (dragging || dist > 6) {
      // Finished a drag — remember new location.
      requestSave();
    } else {
      // A click on the pet opens the interaction menu.
      menu.show(e.clientX, e.clientY, state.level);
    }
    downPos = null;
    dragging = false;
    updateIgnore();
  });

  // Close panels with Escape.
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { menu.hide(); dashboard.hide(); settingsPanel.hide(); updateIgnore(); }
  });

  // ---------------------------------------------------------------------------
  // Persistence
  // ---------------------------------------------------------------------------

  function snapshot() {
    const j = state.toJSON();
    j.stats.lastSeen = Date.now();
    state.stats.lastSeen = j.stats.lastSeen;
    return {
      version: SCHEMA_VERSION,
      pet: j.pet,
      stats: j.stats,
      achievements: j.achievements,
      settings: settings.all(),
    };
  }

  let savePending = false;
  function requestSave() {
    savePending = true; // coalesced; flushed by the loop every few seconds
  }
  async function flushSave(force = false) {
    if (!api) return;
    if (!savePending && !force) return;
    savePending = false;
    try {
      await api.saveState(snapshot());
    } catch (e) {
      console.error('save failed', e);
    }
  }

  // Push a lightweight snapshot to main frequently so it can save on shutdown
  // even if our explicit save didn't fire.
  setInterval(() => { if (api) api.pushState(snapshot()); }, 3000);
  // Explicit durable save cadence.
  setInterval(() => flushSave(), 15000);

  window.addEventListener('beforeunload', () => { if (api) api.pushState(snapshot()); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushSave(true); });

  // ---------------------------------------------------------------------------
  // Main loop
  // ---------------------------------------------------------------------------

  speech.maybeGreet();

  let last = performance.now();
  let achTimer = 0;
  let speechTimer = 0;

  function frame(now) {
    let dt = (now - last) / 1000;
    last = now;
    if (dt > 0.5) dt = 0.5; // guard against tab-throttle jumps

    const cur = cursor.known ? { x: cursor.x, y: cursor.y } : null;

    pet.tick(dt, cur);
    drainEvents();
    pet.animate(dt, settings.get('animationSpeed'));

    // Periodic, cheap checks.
    achTimer += dt;
    if (achTimer > 2) { achTimer = 0; achievements.evaluate(); }
    speechTimer += dt;
    if (speechTimer > 6) { speechTimer = 0; speech.maybeIdle(pet.mood); }

    // Render.
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    ctx.globalAlpha = settings.get('opacity');
    pet.render(ctx, settings.get('scale'));
    ctx.globalAlpha = 1;

    speech.update(pet.position.x, pet.position.y, settings.get('scale'));

    if (dashboard.visible) dashboard.render(); // live-refresh bars
    updateIgnore(); // catch panel/menu open-close transitions

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Apply gentle decay for the time the app was closed (capped, never lethal). */
function applyAwayDecay(state, lastSeen) {
  if (!lastSeen) return;
  let elapsed = (Date.now() - lastSeen) / 1000;
  if (elapsed <= 0) return;
  const CAP = 12 * 3600; // never punish a long weekend too harshly
  elapsed = Math.min(elapsed, CAP);
  state.tick(elapsed, false);
}

function defaultFood(level) {
  // Pick the best unlocked everyday food.
  const ids = Object.entries(FOODS)
    .filter(([, f]) => !f.unlockLevel || level >= f.unlockLevel)
    .map(([id]) => id);
  return ids.includes('fish') ? 'fish' : ids[0] || 'kibble';
}

boot().catch((e) => console.error('boot failed', e));
