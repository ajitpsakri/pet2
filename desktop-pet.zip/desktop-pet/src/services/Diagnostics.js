/**
 * services/Diagnostics.js
 * ----------------------------------------------------------------------------
 * Lightweight runtime health + a debug aid, all in-process and local. It tallies
 * event-bus traffic, samples FPS and (where available) JS heap usage, tracks the
 * last save's integrity, and keeps a small ring of recent state snapshots for
 * "time-travel" inspection / restore. Cheap enough to run continuously.
 *
 * SnapshotRing is a pure ring buffer, exported for tests.
 */

export class SnapshotRing {
  constructor(capacity = 20) {
    this.capacity = Math.max(1, capacity);
    this.items = []; // { ts, state }
  }
  push(state, ts = Date.now()) {
    this.items.push({ ts, state });
    while (this.items.length > this.capacity) this.items.shift();
  }
  /** Newest first. */
  list() {
    return [...this.items].reverse();
  }
  latest() {
    return this.items.length ? this.items[this.items.length - 1] : null;
  }
  get size() {
    return this.items.length;
  }
}

export class Diagnostics {
  constructor({ bus, snapshots = 20 } = {}) {
    this.start = Date.now();
    this.events = { total: 0, byType: Object.create(null) };
    this.fps = 0;
    this._frames = 0;
    this._fpsStart = this.start;
    this.lastSave = { ok: null, ts: null };
    this.plugins = { loaded: 0, failed: 0 };
    this.systemsCount = 0;
    this.lastError = null;
    this.snapshots = new SnapshotRing(snapshots);

    if (bus && bus.on) {
      bus.on('*', (_payload, type) => {
        this.events.total += 1;
        this.events.byType[type] = (this.events.byType[type] || 0) + 1;
      });
    }
  }

  /** Call once per rendered frame; recomputes FPS about twice a second. */
  recordFrame(now = Date.now()) {
    this._frames += 1;
    const elapsed = now - this._fpsStart;
    if (elapsed >= 500) {
      this.fps = Math.round((this._frames * 1000) / elapsed);
      this._frames = 0;
      this._fpsStart = now;
    }
  }

  noteSave(ok) {
    this.lastSave = { ok: !!ok, ts: Date.now() };
  }
  noteError(msg) {
    this.lastError = { msg: String(msg), ts: Date.now() };
  }
  setPlugins(p) {
    this.plugins = { loaded: (p && p.loaded && p.loaded.length) || 0, failed: (p && p.failed && p.failed.length) || 0 };
  }
  setSystemsCount(n) {
    this.systemsCount = n | 0;
  }
  captureSnapshot(state) {
    try {
      // Store a deep-ish copy so later mutations don't change history.
      this.snapshots.push(JSON.parse(JSON.stringify(state)));
    } catch {
      /* non-serializable — skip */
    }
  }

  _memoryMB() {
    const m = typeof performance !== 'undefined' && performance.memory;
    return m && m.usedJSHeapSize ? Math.round(m.usedJSHeapSize / 1048576) : null;
  }

  topEvents(n = 6) {
    return Object.entries(this.events.byType)
      .sort((a, b) => b[1] - a[1])
      .slice(0, n)
      .map(([type, count]) => ({ type, count }));
  }

  report(now = Date.now()) {
    const uptimeSec = Math.round((now - this.start) / 1000);
    const minutes = Math.max(1 / 60, uptimeSec / 60);
    return {
      uptimeSec,
      fps: this.fps,
      memoryMB: this._memoryMB(),
      events: this.events.total,
      eventsPerMin: Math.round(this.events.total / minutes),
      topEvents: this.topEvents(),
      systems: this.systemsCount,
      plugins: this.plugins,
      lastSave: this.lastSave,
      lastError: this.lastError,
      snapshots: this.snapshots.size,
    };
  }
}
