/**
 * services/DialogueService.js
 * ----------------------------------------------------------------------------
 * Chooses *what* the companion says. Lines are grouped by context and may
 * require a minimum friendship level, so the dog unlocks warmer, more familiar
 * lines as your bond grows. The voice is intentionally encouraging, upbeat, and
 * never harsh — important for an ADHD-friendly companion where the felt reward
 * matters more than the reminder itself.
 *
 * This service only *picks* a string; SpeechBubble handles showing it.
 */

const LINES = {
  // reminders (gentle, never guilt-trippy)
  anki_due: [
    { t: "Anki's waiting whenever you are 🐾" },
    { t: 'A few flashcards? I believe in you!' },
    { t: 'Quick Anki round? Future-you says thanks.', min: 2 },
  ],
  focus_nudge: [
    { t: 'Want to start a focus sprint?' },
    { t: "Let's lock in for a bit?" },
  ],
  break_nudge: [
    { t: 'Stretch break? Just a minute.' },
    { t: "You've earned a breather." },
  ],
  water_nudge: [
    { t: 'Hydration check 💧' },
    { t: 'A glass of water would be great right now.' },
    { t: 'Sip sip! Water time?' },
  ],
  stretch_nudge: [
    { t: 'Time to stretch those shoulders 🧘' },
    { t: 'Quick stretch? Your back says thanks.' },
  ],
  stand_nudge: [
    { t: "Let's stand up for a minute 🧍" },
    { t: 'Up and about? Just a moment.' },
  ],
  eye_nudge: [
    { t: '20-second eye break? Look far away 👁️' },
    { t: 'Rest your eyes — find something distant.' },
  ],
  hydrate_done: [
    { t: 'Hydration goal hit! 💧✨' },
    { t: 'Fully watered — nice work!' },
    { t: "That's a hydrated brain right there.", min: 2 },
  ],
  move_done: [
    { t: 'Move goal done — body happy! 🤸' },
    { t: "You kept moving today. Proud of you!" },
  ],
  plan_prompt: [
    { t: "What's the most important thing today?" },
    { t: 'Pick one main goal — I\u2019ll cheer you on 🏆' },
  ],
  task_done: [
    { t: 'Nice, one down! ✓' },
    { t: 'Progress! Keep rolling.' },
  ],
  maingoal_done: [
    { t: 'MAIN GOAL DONE! 🏆 Huge.' },
    { t: 'You did the big one today — amazing!' },
  ],
  learn_prompt: [
    { t: 'What did you learn today? 📚' },
    { t: 'Teach me one thing you picked up today!' },
  ],
  learn_done: [
    { t: 'Learning streak! 📚🔥' },
    { t: 'Brain a little bigger today. Love it.' },
  ],
  learngoal_done: [
    { t: 'Learning goal smashed! 🌟' },
    { t: 'You finished what you set out to learn 🎉' },
  ],
  present_nudge: [
    { t: 'Talk coming up — quick rehearsal? 🎤' },
    { t: 'Want to practice your talk a little?' },
  ],
  present_done: [
    { t: 'Great rehearsal! You sounded sharp 🎤' },
    { t: "Practice pays off — you've got this." },
  ],
  project_nudge: [
    { t: 'A project deadline is close — want to chip at it?' },
    { t: 'Deadline soon. One milestone today? 🗂️' },
  ],
  milestone_done: [
    { t: 'Milestone done! ✅' },
    { t: 'Another piece in place 👏' },
  ],
  project_done: [
    { t: 'PROJECT COMPLETE! 🗂️🎉 So proud.' },
    { t: 'You shipped it! Amazing work.' },
  ],
  cards_due: [
    { t: 'Some flashcards are due — quick review? 🃏' },
    { t: 'Cards waiting. Five minutes of review?' },
  ],
  cards_done: [
    { t: 'Reviews done — memory locked in! 🧠' },
    { t: 'Nice studying! 🃏🔥' },
  ],
  fetch_done: [
    { t: 'Good boy! 🦴 Again, again!' },
    { t: '*drops stick proudly* 🐶' },
  ],
  uno_done: [
    { t: 'Good game! 🎴' },
    { t: 'Rematch? 🐾' },
    { t: 'gg! 🎴🐶' },
  ],
  cricket_done: [
    { t: 'What a match! 🏏' },
    { t: 'Howzat! 🐶' },
    { t: 'Another over? 🏏🐾' },
  ],
  // celebrations (big, warm payoff)
  focus_done: [
    { t: 'Sprint done! That was awesome 🎉' },
    { t: 'You focused the whole time — proud of you!' },
    { t: "Look at you go. We're unstoppable.", min: 3 },
  ],
  anki_done: [
    { t: 'Cards crushed! 🧠✨' },
    { t: 'Reviews done — brain gains!' },
    { t: 'That streak is ALL you. Amazing.', min: 2 },
  ],
  streak: [
    { t: '{n}-day streak! 🔥' },
    { t: '{n} days strong — incredible!' },
  ],
  levelup: [
    { t: 'Level {n}! We leveled up together 🎉' },
    { t: 'Level {n}! I feel stronger!' },
  ],
  friendship: [
    { t: "We're closer than ever 💛" },
    { t: 'Best friends level up!', min: 1 },
  ],
  // ambient encouragement
  encourage: [
    { t: 'You got this.' },
    { t: 'One small step counts.' },
    { t: "I'm right here with you." },
  ],
};

export class DialogueService {
  /** @param {() => number} [rng] */
  constructor(rng = Math.random) {
    this.rng = rng;
  }

  /**
   * Pick a line for a context, honouring friendship gating and filling {n}.
   * @param {string} context
   * @param {object} [opts] { friendship=0, n }
   * @returns {string|null}
   */
  pick(context, { friendship = 0, n } = {}) {
    const pool = (LINES[context] || []).filter((l) => (l.min || 0) <= friendship);
    if (!pool.length) return null;
    const line = pool[(this.rng() * pool.length) | 0];
    return line.t.replace('{n}', n != null ? String(n) : '');
  }

  /** Test/introspection helper. */
  contexts() {
    return Object.keys(LINES);
  }
}
