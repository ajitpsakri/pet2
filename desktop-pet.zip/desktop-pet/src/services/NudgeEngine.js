/**
 * services/NudgeEngine.js
 * ----------------------------------------------------------------------------
 * The reason the companion can remind you about Anki, breaks, focus — and never
 * feel naggy. Every system that wants to interrupt asks here first. The engine
 * enforces a global attention budget plus per-category adaptive backoff:
 *
 *   • Hard floor: never two nudges within `minGapMs`.
 *   • Hourly cap: at most `maxPerHour` nudges across ALL categories.
 *   • Adaptive: a category ignored/dismissed backs off (interval grows); one
 *     that gets acted on relaxes back toward its base interval.
 *   • Do-Not-Disturb: one switch silences everything non-critical.
 *
 * Pure and clock-injectable, so the whole policy is unit-tested without timers.
 */

export class NudgeEngine {
  /**
   * @param {object} [opts]
   * @param {() => number} [opts.now]
   * @param {number} [opts.maxPerHour]
   * @param {number} [opts.minGapMs] hard quiet floor between any two nudges
   */
  constructor({ now = Date.now, maxPerHour = 3, minGapMs = 8 * 60 * 1000 } = {}) {
    this._now = now;
    this.maxPerHour = maxPerHour;
    this.minGapMs = minGapMs;
    this.dnd = false;
    this._recent = []; // timestamps of recent shown nudges (within the hour)
    this._cat = new Map(); // category -> { baseMs, intervalMs, lastMs }
  }

  /** Register a category with its base reminder interval (minutes). */
  configure(category, baseMinutes) {
    const baseMs = baseMinutes * 60 * 1000;
    this._cat.set(category, { baseMs, intervalMs: baseMs, lastMs: null });
  }

  setDND(on) {
    this.dnd = !!on;
  }

  /** Internal: drop timestamps older than an hour. */
  _prune(t) {
    const cutoff = t - 3600_000;
    this._recent = this._recent.filter((ts) => ts >= cutoff);
  }

  /**
   * May `category` nudge right now? If yes, records the nudge and returns true
   * (so the caller can show it). If the category was never configured it is
   * registered lazily with a 30-minute base.
   */
  request(category) {
    const t = this._now();
    if (this.dnd) return false;

    if (!this._cat.has(category)) this.configure(category, 30);
    const c = this._cat.get(category);

    // Per-category interval (with adaptive backoff already baked into intervalMs)
    if (c.lastMs !== null && t - c.lastMs < c.intervalMs) return false;

    // Global hard floor between any two nudges.
    this._prune(t);
    if (this._recent.length > 0) {
      const lastAny = this._recent[this._recent.length - 1];
      if (t - lastAny < this.minGapMs) return false;
    }

    // Hourly budget.
    if (this._recent.length >= this.maxPerHour) return false;

    // Allowed — record it.
    c.lastMs = t;
    this._recent.push(t);
    return true;
  }

  /** The user acted on the last nudge: relax this category back toward base. */
  acted(category) {
    const c = this._cat.get(category);
    if (!c) return;
    c.intervalMs = Math.max(c.baseMs, c.intervalMs * 0.6);
  }

  /** The user ignored/dismissed it: back off (interval grows, capped at 4x). */
  dismissed(category) {
    const c = this._cat.get(category);
    if (!c) return;
    c.intervalMs = Math.min(c.baseMs * 4, c.intervalMs * 1.6);
  }

  /** For diagnostics/tests. */
  intervalMinutes(category) {
    const c = this._cat.get(category);
    return c ? Math.round(c.intervalMs / 60000) : null;
  }
}
