/**
 * services/ai/AIService.js
 * ----------------------------------------------------------------------------
 * The single safe entry point the rest of the app uses for AI. Its contract:
 * **it never breaks the offline experience.** If AI is disabled, the provider
 * is unavailable, or anything throws, `phrase()` returns the templated fallback
 * unchanged. Callers therefore always get a usable line, with or without AI.
 */

export class AIService {
  /**
   * @param {import('./Provider.js').AIProvider} provider
   * @param {boolean | (() => boolean)} isEnabled live flag (default off)
   */
  constructor(provider, isEnabled = false) {
    this.provider = provider;
    this.isEnabled = typeof isEnabled === 'function' ? isEnabled : () => !!isEnabled;
  }

  async available() {
    if (!this.isEnabled() || !this.provider) return false;
    try {
      return await this.provider.available();
    } catch {
      return false;
    }
  }

  /**
   * Return a (possibly AI-rephrased) line. ALWAYS resolves to a string:
   * the fallback if AI is off/unavailable/slow/erroring.
   * @param {string} prompt
   * @param {string} fallback
   */
  async phrase(prompt, fallback) {
    if (!this.isEnabled() || !this.provider) return fallback;
    try {
      if (!(await this.provider.available())) return fallback;
      const out = await this.provider.complete(prompt);
      const text = out && String(out).trim();
      return text || fallback;
    } catch {
      return fallback;
    }
  }

  /**
   * Free-form generation for chat/rubber-duck/quiz. Returns the model's text,
   * or `null` if AI is off/unavailable/slow/erroring — callers show a friendly
   * "enable Local AI" hint rather than a fake answer.
   * @param {string} prompt
   * @param {{maxTokens?:number}} [opts]
   * @returns {Promise<string|null>}
   */
  async generate(prompt, opts = {}) {
    if (!this.isEnabled() || !this.provider) return null;
    try {
      if (!(await this.provider.available())) return null;
      const out = await this.provider.complete(prompt, opts);
      const text = out && String(out).trim();
      return text || null;
    } catch {
      return null;
    }
  }
}
