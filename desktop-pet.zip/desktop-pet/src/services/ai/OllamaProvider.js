/**
 * services/ai/OllamaProvider.js
 * ----------------------------------------------------------------------------
 * Optional, LOCAL-ONLY AI via Ollama (https://ollama.com) running on your own
 * machine. It talks exclusively to 127.0.0.1 (localhost) — never any external
 * server — and is only ever called when you switch on "Local AI" in Settings
 * AND have Ollama installed. If it's off, or Ollama isn't there, the app silently
 * uses its built-in templated lines instead. Nothing leaves your computer.
 */

import { AIProvider } from './Provider.js';

export class OllamaProvider extends AIProvider {
  constructor({ host = 'http://127.0.0.1:11434', model = 'llama3.2', timeoutMs = 1500 } = {}) {
    super();
    this.host = host;
    this.model = model;
    this.timeoutMs = timeoutMs;
  }

  async _withTimeout(promise) {
    const ctl = new AbortController();
    const id = setTimeout(() => ctl.abort(), this.timeoutMs);
    try {
      return await promise(ctl.signal);
    } finally {
      clearTimeout(id);
    }
  }

  async available() {
    try {
      const r = await this._withTimeout((signal) => fetch(`${this.host}/api/tags`, { signal }));
      return !!r && r.ok;
    } catch {
      return false;
    }
  }

  async complete(prompt, { maxTokens = 48 } = {}) {
    const r = await this._withTimeout((signal) =>
      fetch(`${this.host}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: this.model, prompt, stream: false, options: { num_predict: maxTokens } }),
        signal,
      })
    );
    if (!r || !r.ok) throw new Error(`ollama ${r ? r.status : 'no-response'}`);
    const j = await r.json();
    return (j && j.response) || '';
  }
}
