/**
 * services/ai/Provider.js
 * ----------------------------------------------------------------------------
 * The AI abstraction. The whole app runs perfectly with NO AI — that's the
 * default (NullProvider). A provider only ever does anything when the user
 * explicitly enables local AI in Settings. There is no cloud option here.
 */

export class AIProvider {
  /** Is a model reachable right now? */
  async available() {
    return false;
  }
  /** Generate a short completion for `prompt`. */
  async complete(/* prompt, opts */) {
    throw new Error('AIProvider.complete not implemented');
  }
}

/** The default: no AI at all. Guarantees the app is fully functional offline. */
export class NullProvider extends AIProvider {
  async available() {
    return false;
  }
}
