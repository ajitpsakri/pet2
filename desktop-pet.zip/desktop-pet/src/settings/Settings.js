/**
 * Settings.js
 * ----------------------------------------------------------------------------
 * Holds and validates user-configurable settings. Settings live inside the save
 * file, so this just owns the in-memory copy plus the rules for clamping values
 * and pushing window-affecting changes (always-on-top, startup) to the main
 * process via the preload bridge.
 */

import { DEFAULT_SETTINGS, SETTINGS_BOUNDS } from '../config/constants.js';

const clamp = (v, [lo, hi]) => Math.max(lo, Math.min(hi, v));

export class Settings {
  /**
   * @param {object} initial settings loaded from save
   * @param {(settings) => void} onChange called after any successful change
   */
  constructor(initial, onChange) {
    this.values = { ...DEFAULT_SETTINGS, ...(initial || {}) };
    this.onChange = onChange || (() => {});
  }

  get(key) {
    return this.values[key];
  }
  all() {
    return { ...this.values };
  }

  /** Update one setting with validation; returns the stored value. */
  set(key, value) {
    if (!(key in this.values)) return undefined;

    if (SETTINGS_BOUNDS[key]) {
      value = clamp(Number(value), SETTINGS_BOUNDS[key]);
    } else if (typeof DEFAULT_SETTINGS[key] === 'boolean') {
      value = !!value;
    }
    this.values[key] = value;

    // Side effects for settings the native window cares about.
    if (key === 'alwaysOnTop' && window.petAPI) {
      window.petAPI.setAlwaysOnTop(value);
    }
    if (key === 'startOnBoot' && window.petAPI) {
      window.petAPI.setAutoLaunch(value);
    }

    this.onChange(this.all());
    return value;
  }

  /** Sync the startup toggle from the OS truth on launch. */
  async syncFromSystem() {
    if (!window.petAPI) return;
    try {
      this.values.startOnBoot = await window.petAPI.getAutoLaunch();
    } catch {
      /* ignore */
    }
  }
}
