/**
 * schema.js
 * ----------------------------------------------------------------------------
 * Owns the *shape* of the saved game and how to bring an old/partial/corrupt
 * save up to the current version. The main process stores raw bytes only; all
 * meaning lives here so there is a single source of truth.
 */

import { NEEDS, DEFAULT_SETTINGS } from '../config/constants.js';

/** Bump when the persisted shape changes; add a migration step below. */
export const SCHEMA_VERSION = 1;

/** Build a brand-new save for a freshly hatched pet. */
export function defaultState() {
  const now = Date.now();
  const needs = {};
  for (const n of NEEDS) needs[n] = 80; // start content, not perfect
  needs.energy = 90;
  needs.health = 100;

  return {
    version: SCHEMA_VERSION,
    pet: {
      name: 'Pixel',
      bornAt: now,
      needs,
      level: 1,
      xp: 0,
      accessory: 'none',
      // last known on-screen position (null => center on first run)
      position: null,
    },
    stats: {
      lastSeen: now,
      lastCareDay: null, // YYYY-MM-DD of the last day the pet was cared for
      careStreak: 0,
      longestStreak: 0,
      totalFood: 0,
      totalPlay: 0,
      totalPats: 0,
      totalWater: 0,
      totalCleans: 0,
    },
    achievements: {}, // id -> unlockedAt (ms)
    settings: { ...DEFAULT_SETTINGS },
  };
}

/**
 * Deep-merge a loaded object onto a fresh default so missing keys are filled in
 * (handles partial/older saves gracefully) without clobbering existing values.
 */
function fillDefaults(target, defaults) {
  if (target === null || typeof target !== 'object' || Array.isArray(target)) {
    return target === undefined ? defaults : target;
  }
  const out = Array.isArray(defaults) ? [...defaults] : { ...defaults };
  for (const key of Object.keys(defaults)) {
    out[key] = fillDefaults(target[key], defaults[key]);
  }
  // Preserve any extra keys the loaded object had (e.g. future fields)
  for (const key of Object.keys(target)) {
    if (!(key in out)) out[key] = target[key];
  }
  return out;
}

/**
 * Turn whatever we read from disk (possibly null, partial, or from an older
 * version) into a valid, current-version state object. Never throws.
 */
export function migrate(raw) {
  let state = raw;
  if (!state || typeof state !== 'object') {
    return defaultState();
  }

  // --- versioned migrations would chain here -------------------------------
  // Example for the future:
  // if ((state.version ?? 0) < 2) { ...transform...; state.version = 2; }

  // Always backfill against the current default shape.
  const merged = fillDefaults(state, defaultState());

  // Clamp every need into range in case a save was hand-edited or corrupted.
  for (const n of NEEDS) {
    const v = Number(merged.pet.needs[n]);
    merged.pet.needs[n] = Number.isFinite(v) ? Math.max(0, Math.min(100, v)) : 80;
  }
  merged.version = SCHEMA_VERSION;
  return merged;
}
