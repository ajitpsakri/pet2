/**
 * schema.js
 * ----------------------------------------------------------------------------
 * Owns the *shape* of the saved game and how to bring an old/partial/corrupt
 * save up to the current version. The main process stores raw bytes only; all
 * meaning lives here so there is a single source of truth.
 */

import { NEEDS, DEFAULT_SETTINGS } from '../config/constants.js';

/** Bump when the persisted shape changes; add a migration step in MIGRATIONS. */
export const SCHEMA_VERSION = 2;

/** Build a brand-new save for a freshly hatched pet. */
export function defaultState() {
  const now = Date.now();
  const needs = {};
  for (const n of NEEDS) needs[n] = 80; // start content, not perfect
  needs.energy = 90;
  needs.health = 100;

  return {
    version: SCHEMA_VERSION,
    pet: {
      name: 'Pixel',
      bornAt: now,
      needs,
      level: 1,
      xp: 0,
      accessory: 'none',
      // last known on-screen position (null => center on first run)
      position: null,
    },
    stats: {
      lastSeen: now,
      lastCareDay: null, // YYYY-MM-DD of the last day the pet was cared for
      careStreak: 0,
      longestStreak: 0,
      totalFood: 0,
      totalPlay: 0,
      totalPats: 0,
      totalWater: 0,
      totalCleans: 0,
    },
    achievements: {}, // id -> unlockedAt (ms)
    settings: { ...DEFAULT_SETTINGS },

    // --- companion expansion (v2) -------------------------------------------
    // Each future System owns one namespaced slice under `systems[<id>]`.
    systems: {},
    // Append-only local event log + daily rollups for the dashboards. Stays on
    // this PC; pruned/rolled by the Analytics system in a later phase.
    analytics: { events: [], rollups: {} },
  };
}

/**
 * Deep-merge a loaded object onto a fresh default so missing keys are filled in
 * (handles partial/older saves gracefully) without clobbering existing values.
 */
function fillDefaults(target, defaults) {
  // No object-shaped default to merge against (e.g. a field that defaults to
  // null like `position`): keep the loaded value, or the default if absent.
  // Without this guard, a saved object sitting under a null default would hit
  // Object.keys(null) below and throw — crashing load after the pet is moved.
  if (defaults === null || typeof defaults !== 'object') {
    return target === undefined ? defaults : target;
  }
  if (target === null || typeof target !== 'object' || Array.isArray(target)) {
    return target === undefined ? defaults : target;
  }
  const out = Array.isArray(defaults) ? [...defaults] : { ...defaults };
  for (const key of Object.keys(defaults)) {
    out[key] = fillDefaults(target[key], defaults[key]);
  }
  // Preserve any extra keys the loaded object had (e.g. future fields)
  for (const key of Object.keys(target)) {
    if (!(key in out)) out[key] = target[key];
  }
  return out;
}

/**
 * Ordered migration steps. Each key N is a pure function that upgrades a save
 * from version N-1 to version N, mutating/returning the state. Adding a future
 * schema change is one new entry here plus a bump to SCHEMA_VERSION — small,
 * isolated, and unit-testable, instead of editing one monolithic function.
 */
const MIGRATIONS = {
  // v1 -> v2: introduce the companion expansion keys and the new water stat.
  2: (s) => {
    if (!s.systems || typeof s.systems !== 'object') s.systems = {};
    if (!s.analytics || typeof s.analytics !== 'object') {
      s.analytics = { events: [], rollups: {} };
    }
    if (s.stats && typeof s.stats.totalWater !== 'number') s.stats.totalWater = 0;
    return s;
  },
};

/**
 * Turn whatever we read from disk (possibly null, partial, or from an older
 * version) into a valid, current-version state object. Never throws.
 *
 * Strategy: run the ordered migration steps from the save's version up to the
 * current one, then backfill any still-missing keys against the default shape,
 * then clamp needs. Unknown/future keys are preserved throughout.
 */
export function migrate(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return defaultState();

  let state = raw;
  let from = Number.isFinite(state.version) ? state.version : 1;

  for (let target = from + 1; target <= SCHEMA_VERSION; target++) {
    const step = MIGRATIONS[target];
    if (step) {
      try {
        state = step(state) || state;
      } catch (err) {
        console.error(`[schema] migration to v${target} failed:`, err);
      }
    }
    state.version = target;
  }

  // Backfill against the current default shape so missing keys are filled in
  // without clobbering existing values or dropping unknown ones.
  const merged = fillDefaults(state, defaultState());

  // Clamp every need into range in case a save was hand-edited or corrupted.
  for (const n of NEEDS) {
    const v = Number(merged.pet.needs[n]);
    merged.pet.needs[n] = Number.isFinite(v) ? Math.max(0, Math.min(100, v)) : 80;
  }
  merged.version = SCHEMA_VERSION;
  return merged;
}
