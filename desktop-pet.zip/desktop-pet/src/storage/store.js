'use strict';
/**
 * store.js  (main process / CommonJS)
 * ----------------------------------------------------------------------------
 * Durable, crash-safe persistence for the pet's save file.
 *
 * Design goals:
 *  - Atomic writes: write to a temp file then rename, so a power cut can never
 *    leave a half-written save.
 *  - Backup rotation: keep the previous good save as `.bak` for recovery.
 *  - Self-healing reads: if the primary file is corrupt, transparently fall
 *    back to the backup. If both fail, return null and let the renderer seed
 *    a fresh default.
 *
 * The main process treats the payload as opaque JSON — all schema knowledge
 * lives in the renderer (src/storage/schema.js).
 */

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

class Store {
  /** @param {string} dir  directory to keep save files in (created if missing) */
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'pet-save.json');
    this.backup = path.join(dir, 'pet-save.bak.json');
    this.tmp = path.join(dir, 'pet-save.tmp.json');
    this._writing = Promise.resolve(); // serialize writes to avoid races
  }

  /** Ensure the storage directory exists. Safe to call repeatedly. */
  async init() {
    await fsp.mkdir(this.dir, { recursive: true });
  }

  /** Parse a file, returning null on any error (missing / corrupt / empty). */
  async _tryRead(file) {
    try {
      const txt = await fsp.readFile(file, 'utf8');
      if (!txt.trim()) return null;
      return JSON.parse(txt);
    } catch {
      return null;
    }
  }

  /**
   * Load the saved state. Tries the primary file first, then the backup.
   * @returns {Promise<object|null>} parsed object, or null if nothing valid.
   */
  async load() {
    const primary = await this._tryRead(this.file);
    if (primary) return primary;

    const backup = await this._tryRead(this.backup);
    if (backup) {
      // Primary was unreadable but backup is good — promote the backup.
      try {
        await fsp.copyFile(this.backup, this.file);
      } catch {
        /* non-fatal */
      }
      return backup;
    }
    return null;
  }

  /**
   * Persist state atomically. Writes are serialized so two rapid saves cannot
   * interleave. Returns a promise that resolves once bytes are on disk.
   * @param {object} state
   */
  save(state) {
    // Chain onto the previous write so they run strictly in order.
    this._writing = this._writing.then(() => this._doSave(state)).catch((err) => {
      // Swallow but log — a failed save must never crash the app.
      console.error('[store] save failed:', err);
    });
    return this._writing;
  }

  async _doSave(state) {
    const json = JSON.stringify(state, null, 2);

    // Rotate the current good file to backup before overwriting.
    try {
      await fsp.copyFile(this.file, this.backup);
    } catch {
      /* first run: no primary yet — fine */
    }

    // Atomic replace: write temp, fsync, rename over the real file.
    const fh = await fsp.open(this.tmp, 'w');
    try {
      await fh.writeFile(json, 'utf8');
      await fh.sync(); // flush to physical storage
    } finally {
      await fh.close();
    }
    await fsp.rename(this.tmp, this.file);
  }

  /** Synchronous best-effort save for shutdown / quit handlers. */
  saveSync(state) {
    try {
      const json = JSON.stringify(state, null, 2);
      try {
        if (fs.existsSync(this.file)) fs.copyFileSync(this.file, this.backup);
      } catch {
        /* ignore */
      }
      fs.writeFileSync(this.tmp, json, 'utf8');
      fs.renameSync(this.tmp, this.file);
      return true;
    } catch (err) {
      console.error('[store] sync save failed:', err);
      return false;
    }
  }
}

module.exports = { Store };
