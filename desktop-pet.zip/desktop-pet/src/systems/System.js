/**
 * systems/System.js
 * ----------------------------------------------------------------------------
 * The contract every feature implements — core or plugin. Keeping this surface
 * tiny is what lets the registry treat the pet, a Pomodoro timer, and a future
 * third-party plugin identically.
 *
 * A System receives a shared `ctx` at construction:
 *   { bus, clock, settings, ... }  (more services added in later phases)
 *
 * By convention each system stores its persisted slice under
 * `root.systems[<id>]`. The two helpers below implement that default; the pet
 * overrides them because it keeps its legacy top-level shape.
 */

export class System {
  /** Unique id; subclasses MUST override. */
  static id = '';
  /** Version of this system's own save slice (for future per-system migration). */
  static schemaVersion = 1;

  constructor(ctx = {}) {
    this.ctx = ctx;
  }

  /** Subscribe to bus events / set up timers here. */
  init() {}

  /** Advance logic. dt seconds, now epoch ms, frame = shared per-frame context. */
  tick(_dt, _now, _frame) {}

  /** React to a coarse context signal (idle/active/focus/bucket/suspend). */
  onContext(_signal) {}

  /** Return this system's persisted slice (plain JSON). */
  serialize() {
    return {};
  }

  /** Restore from a previously serialized slice. */
  hydrate(_data) {}

  /** Dashboard tab descriptors this system contributes (optional). */
  views() {
    return [];
  }

  /** Remove every listener/timer created in init(). */
  dispose() {}

  // --- save plumbing (default convention: namespaced under systems[id]) -----

  serializeInto(root) {
    if (!root.systems) root.systems = {};
    root.systems[this.constructor.id] = this.serialize();
  }

  hydrateFrom(root) {
    const slice = root && root.systems ? root.systems[this.constructor.id] : undefined;
    if (slice !== undefined) this.hydrate(slice);
  }
}

/**
 * TimedHabitSystem
 * ----------------------------------------------------------------------------
 * Shared base for the "reminder + daily goal + streak" features (hydration,
 * stretch, eye-breaks, learning...). Phase 0 only establishes the shape; the
 * concrete habits arrive in Phase 2. Subclasses set static `id` and tune the
 * fields in their constructor / hydrate.
 */
export class TimedHabitSystem extends System {
  constructor(ctx) {
    super(ctx);
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastDayKey = null;
  }

  /** Call when the habit is satisfied for "today" to advance the streak. */
  recordDay(dayKey) {
    if (dayKey === this.lastDayKey) return; // already counted today
    // Consecutive-day check is left to subclasses that know their cadence;
    // the simple default just increments and tracks the best run.
    this.streakDays += 1;
    if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
    this.lastDayKey = dayKey;
  }

  serialize() {
    return {
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastDayKey: this.lastDayKey,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastDayKey = d.lastDayKey ?? null;
  }
}
