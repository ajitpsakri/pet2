/**
 * systems/ai/AICompanionSystem.js
 * ----------------------------------------------------------------------------
 * Gives the dog a local memory and the ability to hold a context-aware
 * conversation — rubber-duck debugging, quick explanations, quizzing, day
 * planning. EVERYTHING is local: memories and the recent transcript live in the
 * save file, and replies come from a local Ollama model only when you enable
 * "Local AI" in Settings. With AI off, the panel still stores your memories and
 * simply explains how to turn the model on; nothing ever leaves your machine.
 *
 * This system owns the testable pieces — memory list, transcript, and prompt
 * assembly. The actual model call lives in AIService; the renderer wires them.
 */

import { System } from '../System.js';

const MAX_MEMORIES = 40;
const MAX_TURNS = 12; // how much conversation we keep / feed back as context

const PERSONA =
  "You are the user's friendly desk-dog companion: warm, encouraging, a little " +
  'playful, and concise. You help with coding (including C/C++/embedded), planning, ' +
  'learning, and presentations. Prefer short, practical answers. If you are unsure, ' +
  'say so briefly. Never invent personal facts beyond what is provided.';

export class AICompanionSystem extends System {
  static id = 'ai';

  constructor(ctx) {
    super(ctx);
    this.memories = []; // { id, text, ts }
    this.transcript = []; // { role:'user'|'assistant', text, ts }
    this._seq = 0;
  }

  addMemory(text) {
    const clean = String(text || '').trim();
    if (!clean) return null;
    const m = { id: `m${++this._seq}`, text: clean, ts: Date.now() };
    this.memories.push(m);
    while (this.memories.length > MAX_MEMORIES) this.memories.shift();
    return m;
  }

  removeMemory(id) {
    this.memories = this.memories.filter((m) => m.id !== id);
  }

  pushTurn(role, text) {
    const clean = String(text || '').trim();
    if (!clean) return;
    this.transcript.push({ role, text: clean, ts: Date.now() });
    while (this.transcript.length > MAX_TURNS) this.transcript.shift();
  }

  clearTranscript() {
    this.transcript = [];
  }

  recentTranscript(n = MAX_TURNS) {
    return this.transcript.slice(-n);
  }

  /** Compact context block from live stats (assembled by the renderer). */
  _contextBlock(stats = {}) {
    const lines = [];
    if (stats.timeBucket) lines.push(`- Time of day: ${stats.timeBucket}`);
    if (stats.focusStreak != null) lines.push(`- Focus streak: ${stats.focusStreak} days; today ${stats.focusMin || 0} min`);
    if (stats.tasksTotal != null) {
      const main = stats.mainGoal ? `; main goal: "${stats.mainGoal}"` : '';
      lines.push(`- Tasks today: ${stats.tasksDone || 0}/${stats.tasksTotal}${main}`);
    }
    if (stats.learnStreak != null) lines.push(`- Learning streak: ${stats.learnStreak} days; today ${stats.learnMin || 0} min`);
    if (stats.nextTalk) lines.push(`- Next talk: "${stats.nextTalk.title}" in ${stats.nextTalk.days} day(s)`);
    if (stats.project) lines.push(`- Project "${stats.project.name}" due in ${stats.project.days} day(s)`);
    return lines.join('\n');
  }

  /**
   * Assemble the full local-model prompt. Pure and deterministic given inputs,
   * so it can be unit-tested without any model.
   * @param {string} userMsg
   * @param {object} stats live snapshot from other systems
   */
  buildPrompt(userMsg, stats = {}) {
    const parts = [PERSONA, ''];
    const ctx = this._contextBlock(stats);
    if (ctx) parts.push('Current context:', ctx, '');
    if (this.memories.length) {
      parts.push('Things to remember about the user:');
      for (const m of this.memories) parts.push(`- ${m.text}`);
      parts.push('');
    }
    if (Array.isArray(stats.relevantNotes) && stats.relevantNotes.length) {
      parts.push("Relevant notes from the user's vault:");
      for (const n of stats.relevantNotes) parts.push(`- ${n.title}: ${n.body}`);
      parts.push('');
    }
    const recent = this.recentTranscript();
    if (recent.length) {
      parts.push('Recent conversation:');
      for (const t of recent) parts.push(`${t.role === 'user' ? 'User' : 'Buddy'}: ${t.text}`);
    }
    parts.push(`User: ${String(userMsg || '').trim()}`, 'Buddy:');
    return parts.join('\n');
  }

  status() {
    return { memories: this.memories.length, turns: this.transcript.length };
  }

  serialize() {
    return { memories: this.memories, transcript: this.transcript, seq: this._seq };
  }

  hydrate(d) {
    if (!d) return;
    this.memories = Array.isArray(d.memories) ? d.memories : [];
    this.transcript = Array.isArray(d.transcript) ? d.transcript : [];
    this._seq = d.seq ?? this.memories.length;
  }
}
