/**
 * systems/attention/AttentionSystem.js
 * ----------------------------------------------------------------------------
 * The "know when to stay quiet" brain. It turns coarse, privacy-safe signals
 * (idle time, our-window focus, screen lock) plus our own state (focus timer,
 * manual Deep Work / Meeting toggles) into a single decision: may the companion
 * interrupt right now, and for what?
 *
 * Design: context gating lives here; frequency gating stays in NudgeEngine. So
 * a reminder must pass BOTH "is now an OK moment?" (this) and "have we nudged
 * too recently?" (NudgeEngine). The result is a pet that disappears during deep
 * work and meetings and only resurfaces for things that matter.
 *
 * The scoring functions are pure and exported for tests.
 */

import { System } from '../System.js';

// How important each reminder category is. Higher = more likely to break through.
//   3 critical (health)  2 high (eye strain, end-of-break)  1 medium  0 low
const CATEGORY_PRIORITY = {
  health: 3,
  eye: 2,
  break: 2,
  water: 1,
  stand: 1,
  stretch: 1,
  anki: 1,
  present: 1,
  plan: 0,
  learn: 0,
  habit: 0,
  focus: 0,
};

export function categoryPriority(cat) {
  return CATEGORY_PRIORITY[cat] != null ? CATEGORY_PRIORITY[cat] : 0;
}

/**
 * Quiet level for the current context:
 *   0 normal · 1 soft (medium+) · 2 deep (high+ only) · 3 silent (nothing now)
 * @param {object} s
 */
export function quietLevel(s = {}) {
  if (s.screenLocked) return 3; // locked workstation: never
  if (s.idleSec != null && s.idleSec > 600) return 3; // away ~10min: hold it
  if (s.meeting) return 2; // manual "I'm in a meeting"
  if (s.deepWork) return 2; // manual Deep Work mode
  if (s.focusRunning) return 1; // our Pomodoro is running
  if (s.activeElsewhere) return 1; // busy in another app (likely a call/coding)
  return 0;
}

/** Minimum category priority required to interrupt at a given quiet level. */
export function requiredPriority(level) {
  return [0, 1, 2, 99][level] ?? 0;
}

/** May a reminder of `category` interrupt given context `s`? */
export function allowInterruption(s, category) {
  return categoryPriority(category) >= requiredPriority(quietLevel(s));
}

/** A 0–100 "how OK to interrupt" score, for dashboards/debugging (not gating). */
export function interruptionScore(s = {}) {
  let score = 60;
  if (s.focusRunning) score -= 30;
  if (s.deepWork) score -= 45;
  if (s.meeting) score -= 55;
  if (s.activeElsewhere) score -= 25;
  if (s.idleSec != null && s.idleSec > 600) score -= 60;
  if (s.screenLocked) score -= 100;
  if (s.mood === 'sick' || s.mood === 'sad') score -= 10;
  return Math.max(0, Math.min(100, score));
}

export class AttentionSystem extends System {
  static id = 'attention';

  constructor(ctx) {
    super(ctx);
    this.deepWork = false;
    this.meeting = false;
    this._focusRunning = false;
    this._signal = { idleSec: 0, windowFocused: true, activeElsewhere: false, screenLocked: false };
    this._offs = [];
  }

  init() {
    const bus = this.ctx.bus;
    if (!bus) return;
    this._offs.push(
      bus.on('coding:focus:start', () => (this._focusRunning = true)),
      bus.on('coding:focus:done', () => (this._focusRunning = false)),
      bus.on('attention:setDeepWork', (p) => (this.deepWork = !!(p && p.on))),
      bus.on('attention:setMeeting', (p) => (this.meeting = !!(p && p.on))),
      bus.on('attention:toggleDeepWork', () => this.setDeepWork(!this.deepWork)),
      bus.on('attention:toggleMeeting', () => this.setMeeting(!this.meeting))
    );
  }

  /** Merge a coarse signal from the main process. */
  onSignal(sig) {
    if (!sig || typeof sig !== 'object') return;
    this._signal = {
      idleSec: sig.idleSec ?? this._signal.idleSec,
      windowFocused: sig.windowFocused ?? this._signal.windowFocused,
      activeElsewhere: sig.activeElsewhere ?? this._signal.activeElsewhere,
      screenLocked: sig.screenLocked ?? this._signal.screenLocked,
    };
  }

  setDeepWork(on) {
    this.deepWork = !!on;
    if (this.ctx.bus) this.ctx.bus.emit('attention:changed', this.status());
  }
  setMeeting(on) {
    this.meeting = !!on;
    if (this.ctx.bus) this.ctx.bus.emit('attention:changed', this.status());
  }

  /** Full context snapshot used by the scoring functions. */
  state() {
    return {
      focusRunning: this._focusRunning,
      deepWork: this.deepWork,
      meeting: this.meeting,
      activeElsewhere: this._signal.activeElsewhere,
      idleSec: this._signal.idleSec,
      screenLocked: this._signal.screenLocked,
    };
  }

  /** Public gate the renderer consults before showing a reminder. */
  allow(category) {
    return allowInterruption(this.state(), category);
  }

  get level() {
    return quietLevel(this.state());
  }

  /** True when the companion should calm down (no idle chatter, slower motion). */
  get quiet() {
    return this.level >= 1;
  }

  get score() {
    return interruptionScore(this.state());
  }

  status() {
    const level = this.level;
    const reason = this._signal.screenLocked
      ? 'screen locked'
      : this.meeting
        ? 'meeting'
        : this.deepWork
          ? 'deep work'
          : this._focusRunning
            ? 'focus sprint'
            : this._signal.activeElsewhere
              ? 'busy elsewhere'
              : 'available';
    return { quiet: level >= 1, level, score: this.score, deepWork: this.deepWork, meeting: this.meeting, reason };
  }

  // Deep Work / Meeting are transient session modes: they intentionally reset
  // to OFF on each launch so the companion never starts up unexpectedly silent.
  serialize() {
    return {};
  }

  hydrate() {}

  dispose() {
    this._offs.forEach((off) => off && off());
    this._offs = [];
  }
}
