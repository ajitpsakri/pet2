/**
 * systems/coding/CodingSystem.js
 * ----------------------------------------------------------------------------
 * The coding buddy. Runs Pomodoro-style focus sprints, accumulates focus time
 * for the day, tracks a day-over-day focus streak and session count, and fires
 * a big celebration when a sprint completes (the dopamine payoff). It also asks
 * the NudgeEngine — gently — whether it may suggest starting a sprint.
 *
 * Time is driven by the frame `dt`, and the day rollover uses the injected
 * Clock, so the whole thing is deterministic and unit-tested without timers.
 *
 * Emits on the bus:
 *   coding:focus:start            a sprint began
 *   coding:focus:milestone {min}  every 5 focused minutes within a sprint
 *   coding:focus:done {sec}       a work sprint completed  (+ a `celebrate`)
 *   coding:break:done             a break finished
 *   nudge {category,text}         a gentle suggestion to start focusing
 */

import { System } from '../System.js';

const WORK_LEN = 25 * 60;
const BREAK_LEN = 5 * 60;
const FOCUS_GOAL_SEC = 20 * 60; // a day with >= this counts toward the streak

export class CodingSystem extends System {
  static id = 'coding';

  constructor(ctx) {
    super(ctx);
    this.workLen = WORK_LEN;
    this.breakLen = BREAK_LEN;
    this.running = false;
    this.phase = 'idle'; // 'idle' | 'work' | 'break'
    this.remaining = 0;
    this.todayFocusSec = 0;
    this.sessionsToday = 0;
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastFocusDay = null;
    this._today = null;
    this._milestoneAcc = 0;
    this._countedToday = false; // streak counted for today already?
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('focus', 45);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  /** Begin (or restart) a focus sprint. */
  startFocus() {
    this.running = true;
    this.phase = 'work';
    this.remaining = this.workLen;
    this._milestoneAcc = 0;
    if (this.ctx.bus) this.ctx.bus.emit('coding:focus:start', {});
  }

  /** Stop the current sprint without reward. */
  stopFocus() {
    this.running = false;
    this.phase = 'idle';
    this.remaining = 0;
  }

  toggleFocus() {
    this.running ? this.stopFocus() : this.startFocus();
  }

  _rolloverIfNewDay() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key === this._today) return;
    // New day: decide streak continuity from yesterday's result.
    if (this._countedToday) {
      // had a qualifying day; streak already advanced when it qualified
    } else if (this.lastFocusDay && !this._isYesterday(this.lastFocusDay, key)) {
      this.streakDays = 0; // missed a day -> reset
    }
    this._today = key;
    this.todayFocusSec = 0;
    this.sessionsToday = 0;
    this._countedToday = false;
  }

  _isYesterday(prevKey, todayKey) {
    const d = new Date(todayKey + 'T00:00:00');
    d.setDate(d.getDate() - 1);
    const y = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return prevKey === y;
  }

  _qualifyDay() {
    if (this._countedToday) return;
    if (this.todayFocusSec < FOCUS_GOAL_SEC) return;
    // Continue or start the streak.
    const key = this._today;
    if (this.lastFocusDay && this._isYesterday(this.lastFocusDay, key)) this.streakDays += 1;
    else this.streakDays = Math.max(1, this.streakDays === 0 ? 1 : this.streakDays);
    if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
    this.lastFocusDay = key;
    this._countedToday = true;
    if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'streak', text: `${this.streakDays}-day streak!`, xp: 10, n: this.streakDays });
  }

  tick(dt) {
    this._rolloverIfNewDay();
    if (!this.running) {
      // Occasionally, gently suggest a sprint.
      if (this.ctx.nudge && this.ctx.nudge.request('focus') && this.ctx.bus) {
        this.ctx.bus.emit('nudge', { category: 'focus', context: 'focus_nudge' });
      }
      return;
    }

    this.remaining -= dt;

    if (this.phase === 'work') {
      this.todayFocusSec += dt;
      this._milestoneAcc += dt;
      if (this._milestoneAcc >= 300) {
        this._milestoneAcc -= 300;
        if (this.ctx.bus) this.ctx.bus.emit('coding:focus:milestone', { min: Math.round(this.todayFocusSec / 60) });
      }
      this._qualifyDay();
    }

    if (this.remaining > 0) return;

    // Phase finished.
    if (this.phase === 'work') {
      this.sessionsToday += 1;
      if (this.ctx.bus) {
        this.ctx.bus.emit('coding:focus:done', { sec: this.workLen });
        this.ctx.bus.emit('celebrate', { kind: 'focus', text: 'Sprint done!', xp: 20 });
      }
      this.phase = 'break';
      this.remaining = this.breakLen;
    } else {
      if (this.ctx.bus) this.ctx.bus.emit('coding:break:done', {});
      this.stopFocus();
    }
  }

  status() {
    return {
      running: this.running,
      phase: this.phase,
      remaining: Math.max(0, Math.round(this.remaining)),
      focusMinToday: Math.round(this.todayFocusSec / 60),
      sessionsToday: this.sessionsToday,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
    };
  }

  serialize() {
    return {
      todayFocusSec: this.todayFocusSec,
      sessionsToday: this.sessionsToday,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastFocusDay: this.lastFocusDay,
      today: this._today,
      countedToday: this._countedToday,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.todayFocusSec = d.todayFocusSec ?? 0;
    this.sessionsToday = d.sessionsToday ?? 0;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastFocusDay = d.lastFocusDay ?? null;
    this._today = d.today ?? this._today;
    this._countedToday = d.countedToday ?? false;
  }
}
