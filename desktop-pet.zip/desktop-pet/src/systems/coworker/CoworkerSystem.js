/**
 * systems/coworker/CoworkerSystem.js
 * ----------------------------------------------------------------------------
 * The unifying "dog as coworker" loop. The dog works beside you: it earns treats
 * for completed focus sprints, and once you've put in a couple, it gently offers
 * a break — suggesting the game that fits the moment (fetch when you've been
 * idle, cricket around lunch, a quick UNO otherwise). It never interrupts during
 * deep work or meetings (that gating is honoured by the caller via `quiet`).
 *
 * The decision logic is pure and tested; the system just keeps the tallies and
 * emits a 'coworker:suggest' event the renderer turns into a friendly nudge.
 */

import { System } from '../System.js';

const SUGGEST_COOLDOWN_MS = 8 * 60 * 1000; // don't pester more than ~once per 8 min

/** Should the dog offer a break right now? Pure. */
export function shouldOfferBreak(sprintsSinceBreak, perBreak, quiet, cooldownOk) {
  if (quiet) return false; // never during deep work / meetings
  if (!cooldownOk) return false;
  return sprintsSinceBreak >= perBreak;
}

/** Which game suits the moment? Pure. hour 0-23, idleSec seconds since activity. */
export function suggestBreakGame(hour, idleSec) {
  if (hour >= 12 && hour < 14) return { game: 'cricket', text: "Lunch break? Let's play some cricket! 🏏" };
  if (idleSec >= 90) return { game: 'fetch', text: "You stepped away — fancy a game of fetch? 🦴" };
  return { game: 'uno', text: "You've earned a breather — quick game of UNO? 🎴" };
}

export class CoworkerSystem extends System {
  static id = 'coworker';

  constructor(ctx) {
    super(ctx);
    this.treats = 0;
    this.sprintsSinceBreak = 0;
    this.sprintsTotal = 0;
    this.breaksTaken = 0;
    this.gamesPlayed = 0;
    this.perBreak = 2;
    this._lastSuggestMs = -Infinity; // first offer never waits on the cooldown
    this.mode = 'idle'; // idle | working | break
  }

  /** Record a finished focus sprint; returns a break suggestion or null. */
  afterSprint({ quiet = false, hour = 12, idleSec = 0, now = Date.now() } = {}) {
    this.treats += 1;
    this.sprintsSinceBreak += 1;
    this.sprintsTotal += 1;
    this.mode = 'working';

    const cooldownOk = now - this._lastSuggestMs >= SUGGEST_COOLDOWN_MS;
    if (!shouldOfferBreak(this.sprintsSinceBreak, this.perBreak, quiet, cooldownOk)) return null;

    this._lastSuggestMs = now;
    const s = suggestBreakGame(hour, idleSec);
    if (this.ctx.bus) this.ctx.bus.emit('coworker:suggest', s);
    return s;
  }

  /** The user accepted a break / launched a game. */
  startBreak(game) {
    this.breaksTaken += 1;
    this.sprintsSinceBreak = 0;
    this.mode = 'break';
    return game;
  }

  /** A game finished. */
  recordGameOver() {
    this.gamesPlayed += 1;
    this.mode = 'working';
  }

  status() {
    return {
      treats: this.treats,
      sprintsToday: this.sprintsSinceBreak,
      sprintsTotal: this.sprintsTotal,
      breaksTaken: this.breaksTaken,
      gamesPlayed: this.gamesPlayed,
      mode: this.mode,
    };
  }

  serialize() {
    return {
      treats: this.treats,
      sprintsTotal: this.sprintsTotal,
      breaksTaken: this.breaksTaken,
      gamesPlayed: this.gamesPlayed,
      perBreak: this.perBreak,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.treats = d.treats ?? 0;
    this.sprintsTotal = d.sprintsTotal ?? 0;
    this.breaksTaken = d.breaksTaken ?? 0;
    this.gamesPlayed = d.gamesPlayed ?? 0;
    this.perBreak = d.perBreak ?? 2;
  }
}
