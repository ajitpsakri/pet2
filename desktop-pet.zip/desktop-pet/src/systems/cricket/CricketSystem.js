/**
 * systems/cricket/CricketSystem.js
 * ----------------------------------------------------------------------------
 * Career progression for the cricket mini-game: total runs, wickets you've
 * taken, matches/wins, highest innings, best partnership, sixes, and trophies.
 * The dog's skill nudges upward as you play more matches ("improve with
 * experience"), and Challenge wins build toward the "Dog Premier League" title.
 */

import { System } from '../System.js';

const XP = { quick: 12, nets: 6, challenge: 22 };

/** Pure: derive earned trophy ids from career stats. */
export function trophiesFor(s) {
  const t = [];
  if (s.wins >= 1) t.push('first_win');
  if (s.highScore >= 50) t.push('fifty');
  if (s.sixes >= 10) t.push('big_hitter');
  if (s.wickets >= 10) t.push('bowler');
  if (s.dplWins >= 3) t.push('dpl_champion');
  if (s.matches >= 25) t.push('veteran');
  return t;
}

export const TROPHY_LABEL = {
  first_win: '🏆 First Win',
  fifty: '🌟 Half-century',
  big_hitter: '💥 Big Hitter (10 sixes)',
  bowler: '🎯 Wicket-taker (10)',
  dpl_champion: '👑 DPL Champion',
  veteran: '🏏 Veteran (25 matches)',
};

export class CricketSystem extends System {
  static id = 'cricket';

  constructor(ctx) {
    super(ctx);
    this.matches = 0;
    this.wins = 0;
    this.careerRuns = 0;
    this.wickets = 0; // wickets you've taken (dog dismissed)
    this.highScore = 0; // best single innings with the bat
    this.bestPartnership = 0;
    this.sixes = 0;
    this.dplWins = 0; // Challenge wins -> Dog Premier League ladder
    this.dogSkill = 0.45;
    this.trophies = [];
  }

  /** Dog skill creeps up with experience, capped. */
  currentDogSkill(base) {
    const growth = Math.min(0.2, this.matches * 0.01);
    return Math.min(0.95, base + growth);
  }

  noteSix() {
    this.sixes += 1;
    if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'six', text: 'SIX! 🏏💥', xp: 2 });
  }

  /**
   * Record a finished match.
   * @param {{mode:string, won:boolean, batRuns:number, wicketsTaken:number,
   *          bestPartnership:number, tie?:boolean}} r
   */
  recordMatch(r) {
    this.matches += 1;
    this.careerRuns += r.batRuns || 0;
    this.wickets += r.wicketsTaken || 0;
    if ((r.batRuns || 0) > this.highScore) this.highScore = r.batRuns;
    if ((r.bestPartnership || 0) > this.bestPartnership) this.bestPartnership = r.bestPartnership;

    if (r.won) {
      this.wins += 1;
      if (r.mode === 'challenge') this.dplWins += 1;
    }

    const before = new Set(this.trophies);
    this.trophies = trophiesFor(this);
    const fresh = this.trophies.filter((t) => !before.has(t));

    if (this.ctx.bus) {
      if (r.won) this.ctx.bus.emit('celebrate', { kind: 'cricket', text: r.mode === 'challenge' ? 'Challenge won! 🏆' : 'You win! 🏏', xp: XP[r.mode] || 10 });
      else if (!r.tie) this.ctx.bus.emit('celebrate', { kind: 'cricket', text: 'Good match! 🐶', xp: 3 });
      if (fresh.length) this.ctx.bus.emit('cricket:trophy', { trophies: fresh });
      this.ctx.bus.emit('cricket:matchover', { won: !!r.won });
    }
    return { fresh };
  }

  status() {
    return {
      matches: this.matches,
      wins: this.wins,
      careerRuns: this.careerRuns,
      wickets: this.wickets,
      highScore: this.highScore,
      bestPartnership: this.bestPartnership,
      sixes: this.sixes,
      dplWins: this.dplWins,
      trophies: this.trophies.slice(),
    };
  }

  serialize() {
    return {
      matches: this.matches, wins: this.wins, careerRuns: this.careerRuns, wickets: this.wickets,
      highScore: this.highScore, bestPartnership: this.bestPartnership, sixes: this.sixes,
      dplWins: this.dplWins, dogSkill: this.dogSkill, trophies: this.trophies,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.matches = d.matches ?? 0;
    this.wins = d.wins ?? 0;
    this.careerRuns = d.careerRuns ?? 0;
    this.wickets = d.wickets ?? 0;
    this.highScore = d.highScore ?? 0;
    this.bestPartnership = d.bestPartnership ?? 0;
    this.sixes = d.sixes ?? 0;
    this.dplWins = d.dplWins ?? 0;
    this.dogSkill = d.dogSkill ?? 0.45;
    this.trophies = Array.isArray(d.trophies) ? d.trophies : [];
  }
}
