/**
 * systems/cricket/engine.js
 * ----------------------------------------------------------------------------
 * A pure, dependency-free cricket mini-game core (no DOM; RNG injected so it's
 * deterministic in tests). Hand-cricket style:
 *   - When you BAT: pick a shot (defend/push/drive/loft) + a timing (0..1, 0.5 =
 *     perfect). The dog bowls and fields — it can take a diving catch, and will
 *     occasionally drop an easy one (more often when its skill is low).
 *   - When you BOWL (the chase): pick a delivery (normal/bouncer/yorker/spin)
 *     that throws off the dog batter's timing; the dog picks a shot.
 *
 * Outcome of a ball: { runs, out, how, fielding, six }.
 */

export function makeRng(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/** Timing quality: 1 at perfect (0.5), 0 at the extremes. */
export function timingQuality(timing) {
  return clamp(1 - 2 * Math.abs(clamp(timing, 0, 1) - 0.5), 0, 1);
}

const BASE_OUT = { defend: 0.02, push: 0.05, drive: 0.12, loft: 0.28 };
export const SHOTS = ['defend', 'push', 'drive', 'loft'];
export const DELIVERIES = ['normal', 'bouncer', 'yorker', 'spin'];

/** How much a delivery degrades the batter's timing (skill mitigates it). */
export function deliveryPenalty(delivery, batterSkill = 0.5) {
  const base = { normal: 0.0, bouncer: 0.12, yorker: 0.18, spin: 0.14 }[delivery] || 0;
  return base * (1 - 0.5 * batterSkill); // a skilled batter handles it better
}

/**
 * Resolve one ball where a batter plays `shot` with `timing`, against a fielding
 * side of skill `fieldSkill` (0..1). Pure given `rng`.
 */
export function resolveBall(shot, timing, fieldSkill, rng) {
  const q = timingQuality(timing);
  let outP = (BASE_OUT[shot] ?? 0.1) * (1.6 - q) * (0.7 + 0.6 * fieldSkill);
  outP = clamp(outP, 0, 0.92);

  if (rng() < outP) {
    const caught = shot === 'loft' || shot === 'drive';
    // Even on an "out" roll, fielders occasionally drop an easy chance —
    // more often when skill is low. This is the reprieve.
    if (caught) {
      const dropChance = 0.03 + 0.14 * (1 - fieldSkill);
      if (rng() < dropChance) return { runs: 1, out: false, how: 'dropped', fielding: 'drop', six: false };
      const fielding = rng() < 0.18 * fieldSkill ? 'dive' : 'catch';
      return { runs: 0, out: true, how: 'caught', fielding, six: false };
    }
    return { runs: 0, out: true, how: 'bowled', fielding: null, six: false };
  }

  const r = rng();
  let runs = 0;
  let six = false;
  if (shot === 'defend') runs = r < 0.6 ? 0 : 1;
  else if (shot === 'push') runs = r < 0.4 ? 1 : r < 0.8 ? 2 : 0;
  else if (shot === 'drive') runs = r < 0.3 + 0.3 * q ? 4 : r < 0.7 ? 2 : r < 0.9 ? 1 : 3;
  else if (shot === 'loft') {
    if (r < 0.25 + 0.4 * q) { runs = 6; six = true; }
    else if (r < 0.6 + 0.2 * q) runs = 4;
    else runs = r < 0.85 ? 2 : 1;
  }
  return { runs, out: false, how: 'runs', fielding: null, six };
}

/** The dog's batting choice (used during the chase). Skill improves timing + intent. */
export function dogBat(skill, rng, chasePressure = 0) {
  // Shot intent: more aggressive with skill and when chasing hard.
  const aggro = clamp(0.35 + 0.4 * skill + 0.25 * chasePressure, 0, 1);
  const r = rng();
  let shot;
  if (r < 0.25 * (1 - aggro)) shot = 'defend';
  else if (r < 0.55 - 0.2 * aggro) shot = 'push';
  else if (r < 0.85 - 0.1 * aggro) shot = 'drive';
  else shot = 'loft';
  // Timing: skilled dog times closer to perfect (0.5). Spread shrinks with skill.
  const spread = 0.5 * (1 - 0.7 * skill);
  const timing = clamp(0.5 + (rng() - 0.5) * 2 * spread, 0, 1);
  return { shot, timing };
}

// --- innings bookkeeping ----------------------------------------------------

export function newInnings({ overs = 2, wicketsAllowed = 2, target = null } = {}) {
  return {
    runs: 0,
    wickets: 0,
    balls: 0,
    overs,
    wicketsAllowed,
    partnership: 0,
    bestPartnership: 0,
    target, // chase succeeds when runs > target (i.e. >= target+1... we use >=)
    done: false,
    result: null, // 'allout' | 'overs' | 'chased'
    log: [],
  };
}

export function inningsOver(inn) {
  if (inn.wickets >= inn.wicketsAllowed) return 'allout';
  if (inn.balls >= inn.overs * 6) return 'overs';
  if (inn.target != null && inn.runs >= inn.target) return 'chased';
  return null;
}

/** Apply a resolved ball to an innings (mutates). Returns the innings. */
export function applyBall(inn, outcome) {
  if (inn.done) return inn;
  inn.balls += 1;
  if (outcome.out) {
    inn.wickets += 1;
    if (inn.partnership > inn.bestPartnership) inn.bestPartnership = inn.partnership;
    inn.partnership = 0;
  } else {
    inn.runs += outcome.runs;
    inn.partnership += outcome.runs;
  }
  inn.log.push(outcome);
  const over = inningsOver(inn);
  if (over) {
    if (inn.partnership > inn.bestPartnership) inn.bestPartnership = inn.partnership;
    inn.done = true;
    inn.result = over;
  }
  return inn;
}

export function oversText(balls) {
  return `${Math.floor(balls / 6)}.${balls % 6}`;
}

/** Difficulty presets for the three modes. */
export const MODES = {
  quick: { label: 'Quick Play', overs: 2, wicketsAllowed: 2, dogSkill: 0.45, fieldSkill: 0.5 },
  nets: { label: 'Practice Nets', overs: 4, wicketsAllowed: 99, dogSkill: 0.4, fieldSkill: 0.45 },
  challenge: { label: 'Challenge', overs: 2, wicketsAllowed: 2, dogSkill: 0.8, fieldSkill: 0.82 },
};
