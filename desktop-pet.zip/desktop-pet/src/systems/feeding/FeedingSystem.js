/**
 * systems/feeding/FeedingSystem.js
 * ----------------------------------------------------------------------------
 * A simple, pet-centric feeding routine — no hunger economy, no inventory. The
 * puppy gets three meals a day (breakfast, lunch, dinner), each given once; the
 * next day resets automatically. Feeding makes the puppy happy; that's the whole
 * point. Treats are handled separately and are unlimited.
 */

import { System } from '../System.js';

export const MEALS = ['breakfast', 'lunch', 'dinner'];

/** Which meal suits the current hour (just a friendly default). */
export function mealForHour(hour) {
  if (hour < 11) return 'breakfast';
  if (hour < 16) return 'lunch';
  return 'dinner';
}

export class FeedingSystem extends System {
  static id = 'feeding';

  constructor(ctx) {
    super(ctx);
    this.day = null;
    this.given = { breakfast: false, lunch: false, dinner: false };
    this.totalMeals = 0;
  }

  _today() {
    return this.ctx.clock && this.ctx.clock.dayKey ? this.ctx.clock.dayKey() : new Date().toISOString().slice(0, 10);
  }

  _rollover() {
    const today = this._today();
    if (this.day !== today) {
      this.day = today;
      this.given = { breakfast: false, lunch: false, dinner: false };
    }
  }

  tick() {
    this._rollover();
  }

  /** True if `meal` is still available today. */
  canFeed(meal) {
    this._rollover();
    return MEALS.includes(meal) && !this.given[meal];
  }

  /** Give a meal. Returns false if it was already given (or invalid). */
  feed(meal) {
    if (!this.canFeed(meal)) return false;
    this.given[meal] = true;
    this.totalMeals += 1;
    if (this.ctx.bus) {
      this.ctx.bus.emit('feeding:meal', { meal });
      this.ctx.bus.emit('celebrate', { kind: 'meal', text: `${meal[0].toUpperCase() + meal.slice(1)} time! 🍽️`, xp: 4 });
    }
    return true;
  }

  /** Status for the menu/UI: which meals are done today. */
  status() {
    this._rollover();
    return {
      day: this.day,
      breakfast: this.given.breakfast,
      lunch: this.given.lunch,
      dinner: this.given.dinner,
      remaining: MEALS.filter((m) => !this.given[m]).length,
      totalMeals: this.totalMeals,
    };
  }

  serialize() {
    return { day: this.day, given: this.given, totalMeals: this.totalMeals };
  }

  hydrate(d) {
    if (!d) return;
    this.day = d.day ?? null;
    this.given = { breakfast: false, lunch: false, dinner: false, ...(d.given || {}) };
    this.totalMeals = d.totalMeals ?? 0;
    this._rollover();
  }
}
