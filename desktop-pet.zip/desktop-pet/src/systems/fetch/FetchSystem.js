/**
 * systems/fetch/FetchSystem.js
 * ----------------------------------------------------------------------------
 * "Play fetch with the puppy." You grab a stick and fling it across the desktop;
 * the dog notices, sprints after it, picks it up, and trots it back. How eagerly
 * it responds depends on its mood/energy (excited = fast, sleepy = slow, worn
 * out = might ignore you). Fully local, no assets — the stick is a canvas path.
 *
 * All the decision logic lives here and is pure/tested: stick flight (friction
 * until it lands), the mood→reaction mapping, the chase/return state machine,
 * and the stats. The renderer just draws the stick and steps the dog toward the
 * target this system hands back each frame.
 *
 * Emits: fetch:thrown · fetch:caught {px} · celebrate {kind:'fetch'}
 */

import { System } from '../System.js';

const REACH = 36; // px: close enough to "arrive" at the stick / home
const BASE_SPEED = 260; // px/sec at speedMult 1
const MAX_THROW = 1100; // clamp throw speed
const STOP_SPEED = 14; // px/sec below which the stick has landed

const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

/**
 * How the dog reacts to a throw, from its mood + energy. Pure + deterministic.
 * @returns {{chase:boolean, speedMult:number, delaySec:number}}
 */
export function reactionFor(mood, energy = 100) {
  if (mood === 'sleeping') return { chase: false, speedMult: 0, delaySec: 0 };
  if (mood === 'sick' || energy < 18) return { chase: false, speedMult: 0, delaySec: 0 }; // too pooped
  if (mood === 'excited') return { chase: true, speedMult: 1.6, delaySec: 0 };
  if (mood === 'happy') return { chase: true, speedMult: 1.15, delaySec: 0.1 };
  if (mood === 'sad') return { chase: true, speedMult: 0.7, delaySec: 0.8 };
  if (energy < 45) return { chase: true, speedMult: 0.65, delaySec: 1.0 }; // sleepy
  return { chase: true, speedMult: 1.0, delaySec: 0.3 };
}

/** Advance a thrown stick under friction. Mutates + returns landed boolean. */
export function stepStick(stick, dt) {
  stick.x += stick.vx * dt;
  stick.y += stick.vy * dt;
  const decay = Math.pow(0.06, dt); // strong air/ground friction
  stick.vx *= decay;
  stick.vy *= decay;
  stick.spin = (stick.spin || 0) + (stick.vx + stick.vy) * dt * 0.02;
  if (Math.hypot(stick.vx, stick.vy) < STOP_SPEED) {
    stick.vx = 0;
    stick.vy = 0;
    return true;
  }
  return false;
}

export class FetchSystem extends System {
  static id = 'fetch';

  constructor(ctx) {
    super(ctx);
    this.throws = 0;
    this.fetches = 0;
    this.ignored = 0;
    this.bestPx = 0;
    this.streak = 0;
    this.longestStreak = 0;
    this.throwDistance = 0;
    // runtime (not persisted)
    this.state = 'idle'; // idle | flying | chasing | returning | ignoring
    this.stick = null; // { x, y, vx, vy, spin }
    this.origin = null; // where to bring it back to
    this._reaction = null;
    this._delay = 0;
    this._idleHold = 0;
  }

  get active() {
    return this.state !== 'idle';
  }
  get carrying() {
    return this.state === 'returning';
  }

  /**
   * Throw a stick. `from` is where the dog should return it; `vel` is px/sec.
   */
  throwStick(from, vel, mood, energy) {
    const speed = Math.hypot(vel.x, vel.y);
    const scale = speed > MAX_THROW ? MAX_THROW / speed : 1;
    this.stick = { x: from.x, y: from.y, vx: vel.x * scale, vy: vel.y * scale, spin: 0 };
    this.origin = { x: from.x, y: from.y };
    this._reaction = reactionFor(mood, energy);
    this._delay = this._reaction.delaySec;
    this.state = 'flying';
    this.throws += 1;
    if (this.ctx.bus) this.ctx.bus.emit('fetch:thrown', {});
  }

  /** Current px/sec the dog should move while chasing/returning. */
  speed() {
    return BASE_SPEED * ((this._reaction && this._reaction.speedMult) || 1);
  }

  /**
   * Advance the game. `dogPos` is the dog's current position. Returns guidance
   * for the renderer: { target, anim, carrying } where target is where to move
   * the dog (or null to stand), and anim is the pose to show.
   */
  update(dt, dogPos) {
    switch (this.state) {
      case 'flying': {
        const landed = stepStick(this.stick, dt);
        if (landed) {
          this.throwDistance = this.origin ? Math.round(dist(this.origin, this.stick)) : 0;
          if (this.throwDistance > this.bestPx) this.bestPx = this.throwDistance;
          if (this._reaction && this._reaction.chase) {
            this.state = 'chasing';
          } else {
            this.state = 'ignoring';
            this.ignored += 1;
            this.streak = 0;
            this._idleHold = 1.6;
            if (this.ctx.bus) this.ctx.bus.emit('fetch:ignored', {});
          }
        }
        return { target: null, anim: 'look', carrying: false };
      }
      case 'chasing': {
        if (this._delay > 0) { this._delay -= dt; return { target: null, anim: 'look', carrying: false }; }
        if (dogPos && this.stick && dist(dogPos, this.stick) <= REACH) {
          this.state = 'returning';
          return { target: { ...this.origin }, anim: 'running', carrying: true };
        }
        return { target: this.stick ? { x: this.stick.x, y: this.stick.y } : null, anim: 'running', carrying: false };
      }
      case 'returning': {
        // The stick travels with the dog's mouth.
        if (this.stick && dogPos) { this.stick.x = dogPos.x; this.stick.y = dogPos.y - 6; }
        if (dogPos && this.origin && dist(dogPos, this.origin) <= REACH) {
          this._finishFetch();
          return { target: null, anim: 'happy', carrying: false };
        }
        return { target: { ...this.origin }, anim: 'running', carrying: true };
      }
      case 'ignoring': {
        this._idleHold -= dt;
        if (this._idleHold <= 0) this._reset();
        return { target: null, anim: 'idle', carrying: false };
      }
      default:
        return { target: null, anim: null, carrying: false };
    }
  }

  _finishFetch() {
    this.fetches += 1;
    this.streak += 1;
    if (this.streak > this.longestStreak) this.longestStreak = this.streak;
    if (this.ctx.bus) {
      this.ctx.bus.emit('fetch:caught', { px: this.throwDistance });
      this.ctx.bus.emit('celebrate', { kind: 'fetch', text: 'Good boy! 🦴', xp: 4, n: this.streak });
    }
    this._reset();
  }

  _reset() {
    this.state = 'idle';
    this.stick = null;
    this.origin = null;
    this._reaction = null;
    this._delay = 0;
  }

  cancel() {
    this._reset();
  }

  status() {
    return { throws: this.throws, fetches: this.fetches, ignored: this.ignored, bestPx: this.bestPx, streak: this.streak };
  }

  serialize() {
    return { throws: this.throws, fetches: this.fetches, ignored: this.ignored, bestPx: this.bestPx, longestStreak: this.longestStreak };
  }

  hydrate(d) {
    if (!d) return;
    this.throws = d.throws ?? 0;
    this.fetches = d.fetches ?? 0;
    this.ignored = d.ignored ?? 0;
    this.bestPx = d.bestPx ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
  }
}
