/**
 * systems/flashcards/FlashcardSystem.js
 * ----------------------------------------------------------------------------
 * A real spaced-repetition engine (Anki-style), fully local and dependency
 * free. Cards graduate through growing intervals based on how well you recall
 * them (Again / Hard / Good / Easy), using a simplified SM-2 algorithm. A due
 * queue surfaces what to review today; reviewing builds a daily streak.
 *
 * The scheduler (addDays + schedule) is pure and exported for thorough tests —
 * the scary part of any SRS is the interval math, so it's covered directly.
 */

import { System } from '../System.js';
import { nextStreak } from '../streakUtil.js';

export const GRADES = ['again', 'hard', 'good', 'easy'];
const MIN_EASE = 1.3;
const START_EASE = 2.5;

/** Add `n` days to an ISO 'YYYY-MM-DD' key. */
export function addDays(dateKey, n) {
  const d = new Date(dateKey + 'T00:00:00');
  if (isNaN(d)) return dateKey;
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

/**
 * Compute the next scheduling state for a card given a review grade.
 * Pure: returns only the scheduling fields. ISO date strings compare
 * chronologically, so "due <= today" is a plain string comparison.
 */
export function schedule(card, grade, today) {
  let ease = card.ease || START_EASE;
  let intervalDays = card.intervalDays || 0;
  let reps = card.reps || 0;
  let lapses = card.lapses || 0;

  switch (grade) {
    case 'again':
      reps = 0;
      lapses += 1;
      ease -= 0.2;
      intervalDays = 0; // stays due today for another attempt
      break;
    case 'hard':
      ease -= 0.15;
      intervalDays = Math.max(1, Math.round((intervalDays || 1) * 1.2));
      reps += 1;
      break;
    case 'good':
      if (reps === 0) intervalDays = 1;
      else if (reps === 1) intervalDays = 6;
      else intervalDays = Math.max(1, Math.round(intervalDays * ease));
      reps += 1;
      break;
    case 'easy':
      ease += 0.15;
      if (reps === 0) intervalDays = 4;
      else intervalDays = Math.max(1, Math.round((intervalDays || 1) * ease * 1.3));
      reps += 1;
      break;
    default:
      break;
  }
  ease = Math.max(MIN_EASE, ease);
  return { ease, intervalDays, reps, lapses, due: addDays(today, intervalDays), lastGrade: grade };
}

export class FlashcardSystem extends System {
  static id = 'flashcards';

  constructor(ctx) {
    super(ctx);
    this.cards = []; // { id, front, back, deck, ease, intervalDays, reps, lapses, due, createdAt }
    this.reviewedToday = 0;
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastReviewDay = null;
    this._today = null;
    this._seq = 0;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('cards', 240);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key !== this._today) { this._today = key; this.reviewedToday = 0; }
  }

  addCard(front, back, deck = '') {
    const f = String(front || '').trim();
    const b = String(back || '').trim();
    if (!f || !b) return null;
    const today = this.ctx.clock ? this.ctx.clock.dayKey() : '1970-01-01';
    const card = { id: `fc${++this._seq}`, front: f, back: b, deck: String(deck || '').trim(), ease: START_EASE, intervalDays: 0, reps: 0, lapses: 0, due: today, createdAt: Date.now() };
    this.cards.push(card);
    return card;
  }

  editCard(id, { front, back, deck } = {}) {
    const c = this.cards.find((x) => x.id === id);
    if (!c) return false;
    if (front != null) c.front = String(front).trim() || c.front;
    if (back != null) c.back = String(back).trim() || c.back;
    if (deck != null) c.deck = String(deck).trim();
    return true;
  }

  removeCard(id) {
    this.cards = this.cards.filter((x) => x.id !== id);
  }

  /** Cards due on/before today, most-overdue first. */
  dueCards(today = this._today) {
    const t = today || '9999-12-31';
    return this.cards.filter((c) => !c.due || c.due <= t).sort((a, b) => (a.due || '').localeCompare(b.due || ''));
  }

  nextDue() {
    return this.dueCards()[0] || null;
  }

  /** Grade a card and reschedule it. Returns the updated card or null. */
  review(id, grade) {
    this._rollover();
    const c = this.cards.find((x) => x.id === id);
    if (!c || !GRADES.includes(grade)) return null;
    Object.assign(c, schedule(c, grade, this._today));

    const firstToday = this.reviewedToday === 0;
    this.reviewedToday += 1;
    if (firstToday) {
      this.streakDays = nextStreak(this.streakDays, this.lastReviewDay, this._today);
      if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
      this.lastReviewDay = this._today;
      if (this.ctx.nudge) this.ctx.nudge.acted('cards');
      if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'cards', text: `Reviews started — ${this.streakDays}d streak! 🃏`, xp: 6, n: this.streakDays });
    }
    if (this.ctx.bus) this.ctx.bus.emit('flashcards:reviewed', { id, grade });
    return c;
  }

  tick() {
    this._rollover();
    if (this.reviewedToday > 0) return;
    if (this.dueCards().length === 0) return;
    if (this.ctx.nudge && this.ctx.nudge.request('cards') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'cards', context: 'cards_due' });
    }
  }

  status() {
    return {
      total: this.cards.length,
      due: this.dueCards().length,
      reviewedToday: this.reviewedToday,
      streakDays: this.streakDays,
    };
  }

  serialize() {
    return {
      cards: this.cards,
      reviewedToday: this.reviewedToday,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastReviewDay: this.lastReviewDay,
      today: this._today,
      seq: this._seq,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.cards = Array.isArray(d.cards) ? d.cards : [];
    this.reviewedToday = d.reviewedToday ?? 0;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastReviewDay = d.lastReviewDay ?? null;
    this._today = d.today ?? this._today;
    this._seq = d.seq ?? this.cards.length;
  }
}
