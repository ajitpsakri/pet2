/**
 * systems/habits/AnkiSystem.js
 * ----------------------------------------------------------------------------
 * Reminds you to do your Anki flashcards, tracks a daily streak, and throws a
 * little party when you mark them done — the satisfying "tick the box" moment.
 * Built on TimedHabitSystem so it shares the reminder+streak shape with future
 * wellness habits (water, stretch, eye-breaks).
 *
 * Reminders go through the NudgeEngine, so Anki can never nag — at most a gentle
 * nudge spaced out by the global attention budget, and only if not done today.
 *
 * Emits on the bus:
 *   anki:done {streak}     you finished today's reviews (+ a `celebrate`)
 *   nudge {category,text}  a gentle reminder to review
 */

import { TimedHabitSystem } from '../System.js';

export class AnkiSystem extends TimedHabitSystem {
  static id = 'anki';

  constructor(ctx) {
    super(ctx);
    this.doneToday = false;
    this._today = null;
    this.reminderMinutes = 90; // base cadence; NudgeEngine adapts from here
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('anki', this.reminderMinutes);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key !== this._today) {
      this._today = key;
      this.doneToday = false;
    }
  }

  /** Call when the user finishes their reviews. Idempotent within a day. */
  markDone() {
    this._rollover();
    if (this.doneToday) return false;
    this.doneToday = true;
    const key = this._today || (this.ctx.clock ? this.ctx.clock.dayKey() : 'day');
    this.recordDay(key); // advances streak (from TimedHabitSystem)
    if (this.ctx.nudge) this.ctx.nudge.acted('anki');
    if (this.ctx.bus) {
      this.ctx.bus.emit('anki:done', { streak: this.streakDays });
      this.ctx.bus.emit('celebrate', { kind: 'anki', text: 'Anki done!', xp: 12, n: this.streakDays });
    }
    return true;
  }

  tick() {
    this._rollover();
    if (this.doneToday) return;
    if (this.ctx.nudge && this.ctx.nudge.request('anki') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'anki', context: 'anki_due' });
    }
  }

  status() {
    return { doneToday: this.doneToday, streakDays: this.streakDays, longestStreak: this.longestStreak };
  }

  serialize() {
    return { ...super.serialize(), doneToday: this.doneToday, today: this._today };
  }

  hydrate(d) {
    super.hydrate(d);
    if (!d) return;
    this.doneToday = d.doneToday ?? false;
    this._today = d.today ?? null;
  }
}
