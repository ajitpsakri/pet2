/**
 * systems/knowledge/KnowledgeSystem.js
 * ----------------------------------------------------------------------------
 * A local "knowledge vault": notes for learning, coding, and research, with a
 * small dependency-free ranked search. Everything lives in the save file. The
 * AI chat can pull the top matches as context (e.g. "what did I learn about ARM
 * NEON last month?"), but the vault is fully usable on its own with AI off.
 *
 * The search scorer is pure and exported for tests.
 */

import { System } from '../System.js';

const MAX_NOTES = 1000;

function tokenize(s) {
  return (String(s || '').toLowerCase().match(/[a-z0-9]+/g) || []).filter(Boolean);
}

function countMatches(haystack, term) {
  if (!haystack) return 0;
  try {
    const re = new RegExp('\\b' + term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    const m = haystack.match(re);
    return m ? m.length : 0;
  } catch {
    return haystack.split(term).length - 1;
  }
}

/**
 * Rank notes against a query. Title matches weigh most, then tags, then body;
 * notes covering more distinct query terms float to the top. Empty query
 * returns the most recently updated notes. Pure + deterministic.
 */
export function searchNotes(notes, query, limit = 20) {
  const terms = [...new Set(tokenize(query))];
  if (!terms.length) {
    return [...notes].sort((a, b) => (b.updated || 0) - (a.updated || 0)).slice(0, limit);
  }
  const scored = [];
  for (const n of notes) {
    const title = String(n.title || '').toLowerCase();
    const tags = (n.tags || []).join(' ').toLowerCase();
    const body = String(n.body || '').toLowerCase();
    let score = 0;
    let covered = 0;
    for (const t of terms) {
      const inTitle = countMatches(title, t);
      const inTags = countMatches(tags, t);
      const inBody = Math.min(5, countMatches(body, t)); // cap so long notes don't dominate
      const sub = inTitle * 5 + inTags * 3 + inBody;
      if (sub > 0) covered++;
      score += sub;
    }
    if (score > 0) {
      score += covered * 10; // reward notes that match more of the query
      scored.push({ note: n, score });
    }
  }
  scored.sort((a, b) => b.score - a.score || (b.note.updated || 0) - (a.note.updated || 0));
  return scored.slice(0, limit).map((s) => s.note);
}

export class KnowledgeSystem extends System {
  static id = 'knowledge';

  constructor(ctx) {
    super(ctx);
    this.notes = []; // { id, title, body, tags[], ts, updated }
    this._seq = 0;
  }

  add({ title, body, tags } = {}) {
    const t = String(title || '').trim();
    const b = String(body || '').trim();
    if (!t && !b) return null;
    const now = Date.now();
    const note = { id: `k${++this._seq}`, title: t || '(untitled)', body: b, tags: normalizeTags(tags), ts: now, updated: now };
    this.notes.push(note);
    while (this.notes.length > MAX_NOTES) this.notes.shift();
    if (this.ctx.bus) this.ctx.bus.emit('knowledge:added', { id: note.id });
    return note;
  }

  update(id, { title, body, tags } = {}) {
    const n = this.notes.find((x) => x.id === id);
    if (!n) return false;
    if (title != null) n.title = String(title).trim() || '(untitled)';
    if (body != null) n.body = String(body).trim();
    if (tags != null) n.tags = normalizeTags(tags);
    n.updated = Date.now();
    return true;
  }

  remove(id) {
    this.notes = this.notes.filter((x) => x.id !== id);
  }

  get(id) {
    return this.notes.find((x) => x.id === id) || null;
  }

  search(query, limit = 20) {
    return searchNotes(this.notes, query, limit);
  }

  recent(n = 10) {
    return [...this.notes].sort((a, b) => (b.updated || 0) - (a.updated || 0)).slice(0, n);
  }

  allTags() {
    const set = new Set();
    for (const n of this.notes) for (const t of n.tags || []) set.add(t);
    return [...set].sort();
  }

  status() {
    return { notes: this.notes.length, tags: this.allTags().length };
  }

  serialize() {
    return { notes: this.notes, seq: this._seq };
  }

  hydrate(d) {
    if (!d) return;
    this.notes = Array.isArray(d.notes) ? d.notes : [];
    this._seq = d.seq ?? this.notes.length;
  }
}

function normalizeTags(tags) {
  if (Array.isArray(tags)) return tags.map((t) => String(t).trim().toLowerCase()).filter(Boolean);
  if (typeof tags === 'string') return tags.split(',').map((t) => t.trim().toLowerCase()).filter(Boolean);
  return [];
}
