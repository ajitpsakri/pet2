/**
 * systems/learning/LearningSystem.js
 * ----------------------------------------------------------------------------
 * A neutral professional-development / study tracker. It logs study time,
 * "what did you learn today?" reflections, technologies you're studying, and
 * personal learning goals, with a day-over-day learning streak.
 *
 * DELIBERATELY SCOPED FOR A WORK LAPTOP: this contains NO interview prep, NO
 * resume reminders, and NO job-application tracking — only ordinary upskilling.
 * Like everything else in this app, all data stays in the local save file and
 * never touches the network.
 *
 * Emits on the bus:
 *   learning:study {min} · learning:note · learning:tech {name}
 *   learning:goal {streak}      daily learning goal reached (+ celebrate)
 *   learning:goaldone {id}      a learning goal completed (+ celebrate)
 *   nudge {category:'learn',context:'learn_prompt'}   gentle evening reflection
 */

import { System } from '../System.js';
import { nextStreak } from '../streakUtil.js';

const DAILY_GOAL_MIN = 20;

export class LearningSystem extends System {
  static id = 'learning';

  constructor(ctx) {
    super(ctx);
    this.goals = []; // { id, text, done }
    this.tech = {}; // name -> times studied
    this.notes = []; // { day, text } capped
    this.todayMinutes = 0;
    this.noteToday = false;
    this.weekHistory = []; // [{ day, minutes }] capped at 7
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastLearnDay = null;
    this.qualifiedToday = false;
    this._today = null;
    this._seq = 0;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('learn', 240);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key === this._today) return;
    this.weekHistory.push({ day: this._today, minutes: this.todayMinutes });
    while (this.weekHistory.length > 7) this.weekHistory.shift();
    this.todayMinutes = 0;
    this.noteToday = false;
    this.qualifiedToday = false;
    this._today = key;
  }

  /** Log minutes of study. */
  logStudy(minutes) {
    this._rollover();
    const m = Math.max(0, Math.round(Number(minutes) || 0));
    if (!m) return;
    this.todayMinutes += m;
    if (this.ctx.bus) this.ctx.bus.emit('learning:study', { min: m });
    this._checkQualify();
  }

  /** Record a short "what did you learn today?" reflection. */
  learnedToday(text) {
    this._rollover();
    const clean = String(text || '').trim();
    if (!clean) return false;
    this.notes.push({ day: this._today, text: clean });
    while (this.notes.length > 60) this.notes.shift();
    this.noteToday = true;
    if (this.ctx.nudge) this.ctx.nudge.acted('learn');
    if (this.ctx.bus) this.ctx.bus.emit('learning:note', {});
    this._checkQualify();
    return true;
  }

  /** Note a technology/skill you studied. */
  studied(name) {
    const clean = String(name || '').trim();
    if (!clean) return;
    this.tech[clean] = (this.tech[clean] || 0) + 1;
    if (this.ctx.bus) this.ctx.bus.emit('learning:tech', { name: clean });
  }

  addGoal(text) {
    const clean = String(text || '').trim();
    if (!clean) return null;
    const g = { id: `g${++this._seq}`, text: clean, done: false };
    this.goals.push(g);
    return g;
  }

  completeGoal(id) {
    const g = this.goals.find((x) => x.id === id);
    if (!g || g.done) return false;
    g.done = true;
    if (this.ctx.bus) this.ctx.bus.emit('learning:goaldone', { id, text: g.text });
    if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'learngoal', text: 'Learning goal done! 🌟', xp: 12 });
    return true;
  }

  removeGoal(id) {
    this.goals = this.goals.filter((x) => x.id !== id);
  }

  _checkQualify() {
    if (this.qualifiedToday) return;
    if (!(this.todayMinutes >= DAILY_GOAL_MIN || this.noteToday)) return;
    this.qualifiedToday = true;
    this.streakDays = nextStreak(this.streakDays, this.lastLearnDay, this._today);
    if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
    this.lastLearnDay = this._today;
    if (this.ctx.bus) {
      this.ctx.bus.emit('learning:goal', { streak: this.streakDays });
      this.ctx.bus.emit('celebrate', { kind: 'learning', text: `Learning streak ${this.streakDays}d! 📚`, xp: 8, n: this.streakDays });
    }
  }

  weekMinutes() {
    const hist = this.weekHistory.reduce((s, h) => s + h.minutes, 0);
    return hist + this.todayMinutes;
  }

  tick() {
    this._rollover();
    const evening = this.ctx.clock && this.ctx.clock.bucket && this.ctx.clock.bucket() === 'evening';
    if (evening && !this.noteToday && this.ctx.nudge && this.ctx.nudge.request('learn') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'learn', context: 'learn_prompt' });
    }
  }

  status() {
    return {
      todayMinutes: this.todayMinutes,
      weekMinutes: this.weekMinutes(),
      streakDays: this.streakDays,
      goals: this.goals.length,
      goalsDone: this.goals.filter((g) => g.done).length,
      techCount: Object.keys(this.tech).length,
      topTech: Object.entries(this.tech).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k]) => k),
    };
  }

  serialize() {
    return {
      goals: this.goals,
      tech: this.tech,
      notes: this.notes,
      todayMinutes: this.todayMinutes,
      noteToday: this.noteToday,
      weekHistory: this.weekHistory,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastLearnDay: this.lastLearnDay,
      qualifiedToday: this.qualifiedToday,
      today: this._today,
      seq: this._seq,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.goals = Array.isArray(d.goals) ? d.goals : [];
    this.tech = d.tech && typeof d.tech === 'object' ? d.tech : {};
    this.notes = Array.isArray(d.notes) ? d.notes : [];
    this.todayMinutes = d.todayMinutes ?? 0;
    this.noteToday = d.noteToday ?? false;
    this.weekHistory = Array.isArray(d.weekHistory) ? d.weekHistory : [];
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastLearnDay = d.lastLearnDay ?? null;
    this.qualifiedToday = d.qualifiedToday ?? false;
    this._today = d.today ?? this._today;
    this._seq = d.seq ?? this.goals.length;
  }
}
