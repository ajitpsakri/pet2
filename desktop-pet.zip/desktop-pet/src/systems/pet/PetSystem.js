/**
 * systems/pet/PetSystem.js
 * ----------------------------------------------------------------------------
 * Wraps the existing pet (PetState + Pet/Behavior/Animator/sprites) in the
 * System interface so it lives inside the registry alongside everything we add
 * later. Behaviour is intentionally identical to the pre-Phase-0 app:
 *   • builds PetState from the migrated save,
 *   • applies the same capped "while you were away" decay,
 *   • ticks the pet each frame and forwards model events onto the bus,
 *   • serializes back into the LEGACY top-level shape (pet/stats/achievements)
 *     so old saves stay byte-compatible.
 *
 * Rendering and pointer hit-testing are pet-specific, so they're exposed as
 * direct methods rather than forced into the generic System surface.
 */

import { System } from '../System.js';
import { PetState } from '../../pet/PetState.js';
import { Pet } from '../../pet/Pet.js';

const AWAY_CAP_SECONDS = 12 * 3600; // never punish a long weekend too harshly

export class PetSystem extends System {
  static id = 'pet';

  /**
   * @param {object} ctx { bus, getBounds: () => ({w,h}) }
   */
  constructor(ctx) {
    super(ctx);
    this.state = null; // PetState
    this.pet = null; // Pet (view/behaviour conductor)
  }

  /** Build the model + pet from a migrated save root, then apply away-decay. */
  hydrateFrom(root) {
    this.state = new PetState(root);
    this._applyAwayDecay(root.stats ? root.stats.lastSeen : null);
    const bounds = this.ctx.getBounds ? this.ctx.getBounds() : { w: 800, h: 600 };
    this.pet = new Pet(this.state, bounds);
  }

  /** Advance the simulation; surface model events (e.g. levelup) on the bus. */
  tick(dt, _now, frame) {
    if (!this.pet) return;
    const cursor = frame && frame.cursor ? frame.cursor : null;
    this.pet.tick(dt, cursor);
    if (this.ctx.bus) {
      for (const ev of this.state.drainEvents()) {
        this.ctx.bus.emit(`pet:${ev.type}`, ev.detail);
      }
    }
  }

  /** Serialize back into the legacy top-level shape for save compatibility. */
  serializeInto(root) {
    if (!this.state) return;
    const j = this.state.toJSON();
    root.pet = j.pet;
    root.stats = { ...j.stats, lastSeen: Date.now() };
    // keep the live model's lastSeen consistent for any subsequent snapshot
    this.state.stats.lastSeen = root.stats.lastSeen;
    root.achievements = j.achievements;
  }

  _applyAwayDecay(lastSeen) {
    if (!lastSeen) return;
    let elapsed = (Date.now() - lastSeen) / 1000;
    if (elapsed <= 0) return;
    elapsed = Math.min(elapsed, AWAY_CAP_SECONDS);
    this.state.tick(elapsed, false);
  }

  // --- pass-throughs the renderer uses (rendering/input are pet-specific) ---

  animate(dt, speed) {
    if (this.pet) this.pet.animate(dt, speed);
  }
  render(ctx, scale, env) {
    if (this.pet) this.pet.render(ctx, scale, env);
  }
  setBounds(bounds) {
    if (this.pet) this.pet.setBounds(bounds);
  }
  hitTest(px, py, scale) {
    return this.pet ? this.pet.hitTest(px, py, scale) : false;
  }
  dragTo(x, y) {
    if (this.pet) this.pet.dragTo(x, y);
  }
  triggerAction(anim, ms) {
    if (this.pet) this.pet.triggerAction(anim, ms);
  }

  get position() {
    return this.pet ? this.pet.position : { x: 0, y: 0 };
  }
  get mood() {
    return this.pet ? this.pet.mood : 'relaxed';
  }
  get actionAnim() {
    return this.pet ? this.pet.actionAnim : null;
  }
  get behavior() {
    return this.pet ? this.pet.behavior : null;
  }
}
