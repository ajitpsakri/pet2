/**
 * systems/presentation/PresentationSystem.js
 * ----------------------------------------------------------------------------
 * A calm presentation coach. Track upcoming talks (with a date countdown and a
 * 1–5 confidence level), run a rehearsal timer that logs practice sessions, and
 * keep a simple prep checklist. Finishing a rehearsal celebrates; an upcoming
 * talk earns a gentle "want to practice?" nudge (rate-limited like everything).
 *
 * Fully local — talk titles/dates live only in your save file.
 *
 * Emits on the bus:
 *   present:rehearse:start · present:rehearse:done {sec,talkId}
 *   present:added {id} · nudge {category:'present',context:'present_nudge'}
 */

import { System } from '../System.js';

const DEFAULT_CHECKLIST = [
  'Practiced the opening',
  'Slides kept simple',
  'Timing rehearsed',
  'Clear takeaway / call to action',
  'Backup ready (PDF/handout)',
];
const MIN_REHEARSAL_SEC = 10;

export class PresentationSystem extends System {
  static id = 'presentation';

  constructor(ctx) {
    super(ctx);
    this.talks = []; // { id, title, date, rehearsals, confidence }
    this.sessions = []; // { id, talkId, sec, at } capped
    this.checklist = DEFAULT_CHECKLIST.map((text, i) => ({ id: `c${i + 1}`, text, done: false }));
    this.totalRehearseSec = 0;
    this._seq = 0;
    // live rehearsal timer
    this.rehearsing = false;
    this._activeTalkId = null;
    this._elapsed = 0;
    this._lastNudgeDay = null;
    this._today = null;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('present', 240);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  addTalk(title, dateKey) {
    const clean = String(title || '').trim();
    if (!clean) return null;
    const talk = { id: `p${++this._seq}`, title: clean, date: dateKey || null, rehearsals: 0, confidence: 0 };
    this.talks.push(talk);
    if (this.ctx.bus) this.ctx.bus.emit('present:added', { id: talk.id });
    return talk;
  }

  removeTalk(id) {
    this.talks = this.talks.filter((t) => t.id !== id);
    if (this._activeTalkId === id) this.stopRehearsal();
  }

  setConfidence(id, level) {
    const t = this.talks.find((x) => x.id === id);
    if (t) t.confidence = Math.max(0, Math.min(5, level | 0));
  }

  /** Days until a talk's date (negative = past). null if no date. */
  daysUntil(dateKey) {
    if (!dateKey || !this.ctx.clock) return null;
    const today = new Date(this.ctx.clock.dayKey() + 'T00:00:00');
    const d = new Date(dateKey + 'T00:00:00');
    if (isNaN(d)) return null;
    return Math.round((d - today) / 86400000);
  }

  startRehearsal(talkId = null) {
    this.rehearsing = true;
    this._activeTalkId = talkId;
    this._elapsed = 0;
    if (this.ctx.bus) this.ctx.bus.emit('present:rehearse:start', { talkId });
  }

  /** Stop the timer; logs a session if it ran long enough. Returns seconds. */
  stopRehearsal() {
    if (!this.rehearsing) return 0;
    this.rehearsing = false;
    const sec = Math.round(this._elapsed);
    const talkId = this._activeTalkId;
    this._activeTalkId = null;
    this._elapsed = 0;
    if (sec < MIN_REHEARSAL_SEC) return sec;

    this.totalRehearseSec += sec;
    this.sessions.push({ id: `s${++this._seq}`, talkId, sec, at: Date.now() });
    while (this.sessions.length > 50) this.sessions.shift();
    const talk = this.talks.find((t) => t.id === talkId);
    if (talk) talk.rehearsals += 1;
    if (this.ctx.bus) {
      this.ctx.bus.emit('present:rehearse:done', { sec, talkId });
      const xp = Math.min(20, 6 + Math.round(sec / 60) * 2);
      this.ctx.bus.emit('celebrate', { kind: 'present', text: 'Rehearsal done! 🎤', xp });
    }
    return sec;
  }

  toggleCheck(id) {
    const c = this.checklist.find((x) => x.id === id);
    if (c) c.done = !c.done;
  }

  resetChecklist() {
    this.checklist.forEach((c) => (c.done = false));
  }

  currentSeconds() {
    return this.rehearsing ? Math.round(this._elapsed) : 0;
  }

  /** The soonest upcoming talk (today or future), or null. */
  nextTalk() {
    let best = null;
    let bestD = Infinity;
    for (const t of this.talks) {
      const d = this.daysUntil(t.date);
      if (d != null && d >= 0 && d < bestD) { bestD = d; best = t; }
    }
    return best;
  }

  tick(dt) {
    if (this.rehearsing) this._elapsed += dt;
    if (!this.ctx.clock) return;
    const today = this.ctx.clock.dayKey();
    if (today !== this._today) this._today = today;

    // Gentle reminder if a talk is within 3 days, at most once/day.
    const next = this.nextTalk();
    if (next) {
      const d = this.daysUntil(next.date);
      if (d != null && d <= 3 && this._lastNudgeDay !== today) {
        if (this.ctx.nudge && this.ctx.nudge.request('present') && this.ctx.bus) {
          this._lastNudgeDay = today;
          this.ctx.bus.emit('nudge', { category: 'present', context: 'present_nudge' });
        }
      }
    }
  }

  status() {
    const next = this.nextTalk();
    return {
      talks: this.talks.length,
      next: next ? { title: next.title, days: this.daysUntil(next.date), confidence: next.confidence } : null,
      totalRehearseMin: Math.round(this.totalRehearseSec / 60),
      sessions: this.sessions.length,
      checklistDone: this.checklist.filter((c) => c.done).length,
      checklistTotal: this.checklist.length,
      rehearsing: this.rehearsing,
    };
  }

  serialize() {
    return {
      talks: this.talks,
      sessions: this.sessions,
      checklist: this.checklist,
      totalRehearseSec: this.totalRehearseSec,
      seq: this._seq,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.talks = Array.isArray(d.talks) ? d.talks : [];
    this.sessions = Array.isArray(d.sessions) ? d.sessions : [];
    if (Array.isArray(d.checklist) && d.checklist.length) this.checklist = d.checklist;
    this.totalRehearseSec = d.totalRehearseSec ?? 0;
    this._seq = d.seq ?? (this.talks.length + this.sessions.length);
  }
}
