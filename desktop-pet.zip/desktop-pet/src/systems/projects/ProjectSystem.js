/**
 * systems/projects/ProjectSystem.js
 * ----------------------------------------------------------------------------
 * Track longer-running projects: each has milestones you tick off, an optional
 * deadline with a countdown, and freeform notes. Finishing a milestone gives a
 * small celebration; finishing every milestone celebrates the whole project. A
 * conservative, once-a-day reminder surfaces a deadline that's almost here
 * (and still routes through the attention gate, so it stays quiet in deep work).
 *
 * Fully local. The deadline-countdown helper is shared with the presentation
 * coach's style and is easy to test.
 */

import { System } from '../System.js';

export class ProjectSystem extends System {
  static id = 'projects';

  constructor(ctx) {
    super(ctx);
    this.projects = []; // { id, name, deadline, notes, milestones[], archived, ts, updated }
    this._seq = 0;
    this._lastNudgeDay = null;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('project', 360);
  }

  addProject(name, deadline = null) {
    const clean = String(name || '').trim();
    if (!clean) return null;
    const now = Date.now();
    const p = { id: `pr${++this._seq}`, name: clean, deadline: deadline || null, notes: '', milestones: [], archived: false, ts: now, updated: now };
    this.projects.push(p);
    if (this.ctx.bus) this.ctx.bus.emit('project:added', { id: p.id });
    return p;
  }

  get(id) {
    return this.projects.find((p) => p.id === id) || null;
  }

  removeProject(id) {
    this.projects = this.projects.filter((p) => p.id !== id);
  }

  rename(id, name) {
    const p = this.get(id);
    if (p && String(name || '').trim()) { p.name = name.trim(); p.updated = Date.now(); }
  }

  setDeadline(id, deadline) {
    const p = this.get(id);
    if (p) { p.deadline = deadline || null; p.updated = Date.now(); }
  }

  setNotes(id, notes) {
    const p = this.get(id);
    if (p) { p.notes = String(notes || ''); p.updated = Date.now(); }
  }

  setArchived(id, archived) {
    const p = this.get(id);
    if (p) { p.archived = !!archived; p.updated = Date.now(); }
  }

  addMilestone(id, title) {
    const p = this.get(id);
    const clean = String(title || '').trim();
    if (!p || !clean) return null;
    const m = { id: `ms${++this._seq}`, title: clean, done: false };
    p.milestones.push(m);
    p.updated = Date.now();
    return m;
  }

  removeMilestone(id, milestoneId) {
    const p = this.get(id);
    if (!p) return;
    p.milestones = p.milestones.filter((m) => m.id !== milestoneId);
    p.updated = Date.now();
  }

  toggleMilestone(id, milestoneId) {
    const p = this.get(id);
    if (!p) return;
    const m = p.milestones.find((x) => x.id === milestoneId);
    if (!m) return;
    m.done = !m.done;
    p.updated = Date.now();
    if (!m.done || !this.ctx.bus) return;

    const prog = this.progress(id);
    if (prog.total > 0 && prog.done === prog.total) {
      this.ctx.bus.emit('project:done', { id, name: p.name });
      this.ctx.bus.emit('celebrate', { kind: 'project', text: `Project complete: ${p.name}! 🗂️`, xp: 20 });
    } else {
      this.ctx.bus.emit('project:milestone', { id, milestoneId });
      this.ctx.bus.emit('celebrate', { kind: 'milestone', text: 'Milestone done! ✅', xp: 5 });
    }
  }

  progress(id) {
    const p = this.get(id);
    if (!p) return { done: 0, total: 0, pct: 0 };
    const total = p.milestones.length;
    const done = p.milestones.filter((m) => m.done).length;
    return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
  }

  daysUntil(deadline) {
    if (!deadline || !this.ctx.clock) return null;
    const today = new Date(this.ctx.clock.dayKey() + 'T00:00:00');
    const d = new Date(deadline + 'T00:00:00');
    if (isNaN(d)) return null;
    return Math.round((d - today) / 86400000);
  }

  activeProjects() {
    return this.projects.filter((p) => !p.archived);
  }

  isComplete(p) {
    return p.milestones.length > 0 && p.milestones.every((m) => m.done);
  }

  /** Soonest upcoming deadline among active, incomplete projects. */
  nextDeadline() {
    let best = null;
    let bestD = Infinity;
    for (const p of this.activeProjects()) {
      if (this.isComplete(p)) continue;
      const d = this.daysUntil(p.deadline);
      if (d != null && d >= 0 && d < bestD) { bestD = d; best = p; }
    }
    return best ? { name: best.name, days: bestD } : null;
  }

  tick() {
    if (!this.ctx.clock) return;
    const today = this.ctx.clock.dayKey();
    const next = this.nextDeadline();
    if (next && next.days <= 2 && this._lastNudgeDay !== today) {
      if (this.ctx.nudge && this.ctx.nudge.request('project') && this.ctx.bus) {
        this._lastNudgeDay = today;
        this.ctx.bus.emit('nudge', { category: 'project', context: 'project_nudge' });
      }
    }
  }

  status() {
    const active = this.activeProjects();
    return {
      projects: active.length,
      done: active.filter((p) => this.isComplete(p)).length,
      nextDeadline: this.nextDeadline(),
    };
  }

  serialize() {
    return { projects: this.projects, seq: this._seq };
  }

  hydrate(d) {
    if (!d) return;
    this.projects = Array.isArray(d.projects) ? d.projects : [];
    this._seq = d.seq ?? this.projects.length;
  }
}
