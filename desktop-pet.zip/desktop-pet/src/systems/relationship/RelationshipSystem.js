/**
 * systems/relationship/RelationshipSystem.js
 * ----------------------------------------------------------------------------
 * Tracks the bond between you and the dog: a `careScore` from looking after it,
 * `trust` from following its coaching (focus sprints, Anki), time spent
 * together, and a derived integer `friendship` level that gates warmer dialogue
 * and triggers a celebration when it grows. Subscribes to bus events only — it
 * never reaches into other systems directly.
 */

import { System } from '../System.js';

/** Friendship level boundaries (sum of careScore + trust). */
const THRESHOLDS = [0, 40, 120, 280, 560, 1000];

function levelFor(points) {
  let lvl = 0;
  for (let i = 0; i < THRESHOLDS.length; i++) if (points >= THRESHOLDS[i]) lvl = i;
  return lvl;
}

export class RelationshipSystem extends System {
  static id = 'relationship';

  constructor(ctx) {
    super(ctx);
    this.careScore = 0;
    this.trust = 0;
    this.minutesTogether = 0;
    this.friendship = 0;
    this._offs = [];
  }

  init() {
    const bus = this.ctx.bus;
    if (!bus) return;
    // Caring for the dog builds the bond.
    const care = ['pet:feed', 'pet:giveWater', 'pet:water', 'pet:pet', 'pet:play', 'pet:clean', 'pet:treat'];
    for (const ev of care) this._offs.push(bus.on(ev, () => this._add({ care: 3 })));
    // Following the dog's coaching builds trust faster.
    this._offs.push(bus.on('coding:focus:done', () => this._add({ trust: 8 })));
    this._offs.push(bus.on('anki:done', () => this._add({ trust: 6 })));
    this._offs.push(bus.on('pet:levelup', () => this._add({ trust: 4 })));
  }

  _add({ care = 0, trust = 0 }) {
    this.careScore += care;
    this.trust += trust;
    this._maybeLevel();
  }

  _maybeLevel() {
    const lvl = levelFor(this.careScore + this.trust);
    if (lvl > this.friendship) {
      this.friendship = lvl;
      if (this.ctx.bus) {
        this.ctx.bus.emit('relationship:changed', { friendship: lvl });
        this.ctx.bus.emit('celebrate', { kind: 'friendship', text: 'Friendship up!', xp: 15, n: lvl });
      }
    }
  }

  tick(dt) {
    this.minutesTogether += dt / 60;
  }

  /** Read-only snapshot for dialogue gating / dashboards. */
  status() {
    return {
      friendship: this.friendship,
      trust: Math.round(this.trust),
      careScore: Math.round(this.careScore),
      minutesTogether: Math.round(this.minutesTogether),
    };
  }

  serialize() {
    return {
      careScore: this.careScore,
      trust: this.trust,
      minutesTogether: this.minutesTogether,
      friendship: this.friendship,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.careScore = d.careScore ?? 0;
    this.trust = d.trust ?? 0;
    this.minutesTogether = d.minutesTogether ?? 0;
    this.friendship = d.friendship ?? levelFor(this.careScore + this.trust);
  }

  dispose() {
    this._offs.forEach((off) => off());
    this._offs = [];
  }
}
