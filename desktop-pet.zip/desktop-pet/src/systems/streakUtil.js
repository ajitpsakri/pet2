/**
 * systems/streakUtil.js
 * ----------------------------------------------------------------------------
 * Tiny, pure helpers for day-over-day streaks shared by the habit systems
 * (hydration, movement, …). Kept separate so the streak rules are defined and
 * tested in exactly one place.
 */

/** True if `prevKey` (YYYY-MM-DD) is the calendar day before `todayKey`. */
export function isYesterday(prevKey, todayKey) {
  if (!prevKey || !todayKey) return false;
  const d = new Date(todayKey + 'T00:00:00');
  d.setDate(d.getDate() - 1);
  const y = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return prevKey === y;
}

/**
 * Given the previous streak length and the day it was last satisfied, return
 * the new streak length for satisfying it on `todayKey`:
 *   • +1 if yesterday was the last satisfied day (consecutive),
 *   • otherwise it resets to 1 (a fresh run starting today).
 */
export function nextStreak(prevStreak, lastDay, todayKey) {
  if (lastDay && isYesterday(lastDay, todayKey)) return prevStreak + 1;
  return 1;
}
