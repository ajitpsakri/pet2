/**
 * systems/tasks/TasksSystem.js
 * ----------------------------------------------------------------------------
 * A lightweight daily planner. You capture today's priorities, mark one as the
 * "main goal", and tick them off. Finishing tasks celebrates (the main goal
 * celebrates bigger), and a day counts as "productive" — advancing a streak —
 * when you finish your main goal or clear most of your list.
 *
 * On a new day, completed tasks are archived into a 7-day completion history
 * and unfinished ones carry over, so nothing silently vanishes.
 *
 * Emits on the bus:
 *   task:added {id} · task:done {id,main} · task:productive {streak}
 *   nudge {category:'plan',context:'plan_prompt'}   gentle morning planning ask
 */

import { System } from '../System.js';
import { nextStreak } from '../streakUtil.js';

const PRODUCTIVE_RATE = 0.6; // clear 60% of the list => a productive day

export class TasksSystem extends System {
  static id = 'tasks';

  constructor(ctx) {
    super(ctx);
    this.tasks = []; // { id, text, done, main, createdAt }
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastProductiveDay = null;
    this.qualifiedToday = false;
    this.recentRates = []; // [{ day, rate }] capped at 7
    this._today = null;
    this._seq = 0;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('plan', 180);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key === this._today) return;
    // Archive the finishing day's completion rate.
    this.recentRates.push({ day: this._today, rate: this.completionRate() });
    while (this.recentRates.length > 7) this.recentRates.shift();
    // Carry over only unfinished tasks into the new day.
    this.tasks = this.tasks.filter((t) => !t.done);
    this.qualifiedToday = false;
    this._today = key;
  }

  /** Add a priority. Returns the task, or null if the text was empty. */
  add(text, { main = false } = {}) {
    this._rollover();
    const clean = String(text || '').trim();
    if (!clean) return null;
    if (main) this.tasks.forEach((t) => (t.main = false));
    const task = { id: `t${++this._seq}`, text: clean, done: false, main: !!main, createdAt: Date.now() };
    this.tasks.push(task);
    if (this.ctx.bus) this.ctx.bus.emit('task:added', { id: task.id });
    return task;
  }

  complete(id) {
    this._rollover();
    const task = this.tasks.find((t) => t.id === id);
    if (!task || task.done) return false;
    task.done = true;
    if (this.ctx.bus) {
      this.ctx.bus.emit('task:done', { id, main: task.main });
      if (task.main) {
        this.ctx.bus.emit('celebrate', { kind: 'maingoal', text: 'Main goal done! 🏆', xp: 15 });
      } else {
        this.ctx.bus.emit('celebrate', { kind: 'task', text: 'Task done! ✓', xp: 4 });
      }
    }
    this._checkProductive();
    return true;
  }

  /** Toggle a task back to not-done (no celebration). */
  uncomplete(id) {
    const task = this.tasks.find((t) => t.id === id);
    if (task) task.done = false;
  }

  remove(id) {
    this.tasks = this.tasks.filter((t) => t.id !== id);
  }

  setMain(id) {
    this.tasks.forEach((t) => (t.main = t.id === id));
  }

  _checkProductive() {
    if (this.qualifiedToday) return;
    const mainDone = this.tasks.some((t) => t.main && t.done);
    const rate = this.completionRate();
    if (!(mainDone || (this.tasks.length > 0 && rate >= PRODUCTIVE_RATE))) return;
    this.qualifiedToday = true;
    this.streakDays = nextStreak(this.streakDays, this.lastProductiveDay, this._today);
    if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
    this.lastProductiveDay = this._today;
    if (this.ctx.bus) {
      this.ctx.bus.emit('task:productive', { streak: this.streakDays });
      this.ctx.bus.emit('celebrate', { kind: 'streak', text: `Productive ${this.streakDays}-day streak!`, xp: 10, n: this.streakDays });
    }
  }

  completionRate() {
    if (!this.tasks.length) return 0;
    return this.tasks.filter((t) => t.done).length / this.tasks.length;
  }

  mainGoal() {
    return this.tasks.find((t) => t.main) || null;
  }

  tick() {
    this._rollover();
    // A gentle morning nudge to set the day's main goal, if none is set yet.
    const morning = this.ctx.clock && this.ctx.clock.bucket && this.ctx.clock.bucket() === 'morning';
    if (morning && !this.mainGoal() && this.ctx.nudge && this.ctx.nudge.request('plan') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'plan', context: 'plan_prompt' });
    }
  }

  status() {
    const done = this.tasks.filter((t) => t.done).length;
    const recent = this.recentRates.concat([{ day: this._today, rate: this.completionRate() }]);
    const avg = recent.length ? recent.reduce((s, r) => s + r.rate, 0) / recent.length : 0;
    return {
      total: this.tasks.length,
      done,
      pct: Math.round(this.completionRate() * 100),
      rate7d: Math.round(avg * 100),
      streakDays: this.streakDays,
      hasMain: !!this.mainGoal(),
    };
  }

  serialize() {
    return {
      tasks: this.tasks,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastProductiveDay: this.lastProductiveDay,
      qualifiedToday: this.qualifiedToday,
      recentRates: this.recentRates,
      today: this._today,
      seq: this._seq,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.tasks = Array.isArray(d.tasks) ? d.tasks : [];
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastProductiveDay = d.lastProductiveDay ?? null;
    this.qualifiedToday = d.qualifiedToday ?? false;
    this.recentRates = Array.isArray(d.recentRates) ? d.recentRates : [];
    this._today = d.today ?? this._today;
    this._seq = d.seq ?? this.tasks.length;
  }
}
