/**
 * systems/timeline/TimelineSystem.js
 * ----------------------------------------------------------------------------
 * The puppy's long-term memory — pet moments only. It records the first day
 * together, level-ups, friendship growth, and crosses cute "together"
 * milestones as lifetime counters tick over (100 pets received, 100 fetches
 * played, one year together). Fully local; nothing leaves the machine.
 *
 * Threshold-crossing logic is a pure helper for tests.
 */

import { System } from '../System.js';

const PET_MS = [10, 50, 100, 250, 500, 1000];
const FETCH_MS = [10, 50, 100, 250, 500];
const MEAL_MS = [10, 50, 100, 365];

/** True when incrementing a counter to `value` lands exactly on a threshold. */
export function crossedThreshold(value, thresholds) {
  return thresholds.includes(value);
}

const MAX_ENTRIES = 250;

export class TimelineSystem extends System {
  static id = 'timeline';

  constructor(ctx) {
    super(ctx);
    this.entries = []; // { id, ts, day, kind, text }
    this.counters = { pets: 0, fetches: 0, meals: 0 };
    this._lastFriendship = 0;
    this._seq = 0;
    this._offs = [];
    this._greetedFirstDay = false;
  }

  init() {
    const bus = this.ctx.bus;
    if (!bus) return;
    this._offs.push(
      bus.on('pet:petted', () => this._count('pets', PET_MS, (n) => `${n} pets received! 🥰`)),
      bus.on('fetch:caught', () => this._count('fetches', FETCH_MS, (n) => `${n} games of fetch! 🦴`)),
      bus.on('feeding:meal', () => this._count('meals', MEAL_MS, (n) => `${n} meals shared! 🍽️`)),
      bus.on('pet:levelup', (p) => {
        const lvl = (p && p.level) || 0;
        this.record('level', `Reached level ${lvl} ⬆️`);
        if (lvl === 10 || lvl === 25 || lvl === 50) this._milestone(`Level ${lvl} — what a good dog! 🌟`);
      }),
      bus.on('relationship:changed', (p) => {
        const f = (p && p.friendship) || 0;
        if (f > this._lastFriendship) {
          this._lastFriendship = f;
          this.record('friendship', `Friendship reached level ${f} 💛`);
        }
      })
    );
    // Record the very first day together once.
    if (!this.entries.length && !this._greetedFirstDay) {
      this._greetedFirstDay = true;
      this.record('firstday', 'The day we met 🐾');
    }
  }

  /** Note an anniversary (called by the renderer with days-together). */
  noteDaysTogether(days) {
    if (days === 7) this.record('together', 'One week together! 🎉');
    else if (days === 30) this.record('together', 'One month together! 🎉');
    else if (days === 365) this._milestone('One year together! 🎂🐾');
  }

  _count(key, thresholds, textFn) {
    this.counters[key] = (this.counters[key] || 0) + 1;
    if (crossedThreshold(this.counters[key], thresholds)) this._milestone(textFn(this.counters[key]));
  }

  /** Record a milestone entry AND throw a little celebration for the moment. */
  _milestone(text) {
    this.record('milestone', text);
    if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'milestone', text, xp: 8 });
  }

  record(kind, text) {
    const day = this.ctx.clock && this.ctx.clock.dayKey ? this.ctx.clock.dayKey() : null;
    this.entries.push({ id: `tl${++this._seq}`, ts: Date.now(), day, kind, text });
    while (this.entries.length > MAX_ENTRIES) this.entries.shift();
    if (this.ctx.bus) this.ctx.bus.emit('timeline:added', { kind });
  }

  /** Newest first. */
  list() {
    return [...this.entries].reverse();
  }

  status() {
    return {
      moments: this.entries.length,
      pets: this.counters.pets,
      fetches: this.counters.fetches,
      meals: this.counters.meals,
      friendship: this._lastFriendship,
    };
  }

  serialize() {
    return { entries: this.entries, counters: this.counters, lastFriendship: this._lastFriendship, seq: this._seq, greeted: this._greetedFirstDay };
  }

  hydrate(d) {
    if (!d) return;
    this.entries = Array.isArray(d.entries) ? d.entries : [];
    this.counters = { pets: 0, fetches: 0, meals: 0, ...(d.counters || {}) };
    this._lastFriendship = d.lastFriendship ?? 0;
    this._seq = d.seq ?? this.entries.length;
    this._greetedFirstDay = d.greeted ?? this.entries.length > 0;
  }

  dispose() {
    this._offs.forEach((off) => off && off());
    this._offs = [];
  }
}
