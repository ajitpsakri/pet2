/**
 * systems/timeline/TimelineSystem.js
 * ----------------------------------------------------------------------------
 * The companion's long-term memory. It listens across the app and records
 * meaningful moments — projects shipped, goals learned, level-ups, friendship
 * growth — plus "together" milestones when lifetime counters cross thresholds
 * ("100 focus sprints together!"). The result is a scrollable life timeline and
 * a set of lifetime totals. Fully local; nothing is sent anywhere.
 *
 * Threshold-crossing logic is factored into a pure helper for tests.
 */

import { System } from '../System.js';

const FOCUS_MS = [1, 10, 25, 50, 100, 250, 500];
const TASK_MS = [10, 50, 100, 250, 500];
const CARD_MS = [50, 100, 250, 500, 1000];
const REHEARSAL_MS = [5, 10, 25, 50];
const PROJECT_MS = [1, 3, 5, 10, 25];
const STUDY_HOUR_MS = [10, 25, 50, 100, 250];

/** True when incrementing a counter to `value` lands exactly on a threshold. */
export function crossedThreshold(value, thresholds) {
  return thresholds.includes(value);
}

const MAX_ENTRIES = 250;

export class TimelineSystem extends System {
  static id = 'timeline';

  constructor(ctx) {
    super(ctx);
    this.entries = []; // { id, ts, day, kind, text }
    this.counters = { focus: 0, tasks: 0, cards: 0, rehearsals: 0, projects: 0, studyMin: 0 };
    this._lastFriendship = 0;
    this._lastStudyHours = 0;
    this._seq = 0;
    this._offs = [];
  }

  init() {
    const bus = this.ctx.bus;
    if (!bus) return;
    this._offs.push(
      bus.on('coding:focus:done', () => this._count('focus', FOCUS_MS, (n) => `${n} focus sprint${n === 1 ? '' : 's'} together! 🎯`)),
      bus.on('task:done', () => this._count('tasks', TASK_MS, (n) => `${n} tasks completed together! ✓`)),
      bus.on('flashcards:reviewed', () => this._count('cards', CARD_MS, (n) => `${n} flashcard reviews! 🃏`)),
      bus.on('present:rehearse:done', () => this._count('rehearsals', REHEARSAL_MS, (n) => `${n} rehearsals done! 🎤`)),
      bus.on('learning:study', (p) => this._study((p && p.min) || 0)),
      bus.on('learning:goaldone', (p) => this.record('learngoal', `Learned: ${(p && p.text) || 'a goal'} 🌟`)),
      bus.on('project:done', (p) => {
        this.counters.projects += 1;
        this.record('project', `Shipped: ${(p && p.name) || 'a project'} 🗂️`);
        if (crossedThreshold(this.counters.projects, PROJECT_MS)) {
          this._milestone(`${this.counters.projects} project${this.counters.projects === 1 ? '' : 's'} shipped together! 🚀`);
        }
      }),
      bus.on('pet:levelup', (p) => this.record('level', `Reached level ${(p && p.level) || '?'} ⬆️`)),
      bus.on('relationship:changed', (p) => {
        const f = (p && p.friendship) || 0;
        if (f > this._lastFriendship) {
          this._lastFriendship = f;
          this.record('friendship', `Friendship reached level ${f} 💛`);
        }
      })
    );
  }

  _count(key, thresholds, textFn) {
    this.counters[key] = (this.counters[key] || 0) + 1;
    if (crossedThreshold(this.counters[key], thresholds)) this._milestone(textFn(this.counters[key]));
  }

  _study(min) {
    this.counters.studyMin += Math.max(0, min);
    const hours = Math.floor(this.counters.studyMin / 60);
    for (const h of STUDY_HOUR_MS) {
      if (this._lastStudyHours < h && hours >= h) {
        this._lastStudyHours = hours;
        this._milestone(`${h} hours of study together! 📚`);
        break;
      }
    }
  }

  /** Record a milestone entry AND throw a little celebration for the moment. */
  _milestone(text) {
    this.record('milestone', text);
    if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'milestone', text, xp: 10 });
  }

  record(kind, text) {
    const day = this.ctx.clock ? this.ctx.clock.dayKey() : null;
    this.entries.push({ id: `tl${++this._seq}`, ts: Date.now(), day, kind, text });
    while (this.entries.length > MAX_ENTRIES) this.entries.shift();
    if (this.ctx.bus) this.ctx.bus.emit('timeline:added', { kind });
  }

  /** Newest first. */
  list() {
    return [...this.entries].reverse();
  }

  status() {
    return {
      moments: this.entries.length,
      focus: this.counters.focus,
      tasks: this.counters.tasks,
      cards: this.counters.cards,
      projects: this.counters.projects,
      studyHours: Math.floor(this.counters.studyMin / 60),
      friendship: this._lastFriendship,
    };
  }

  serialize() {
    return {
      entries: this.entries,
      counters: this.counters,
      lastFriendship: this._lastFriendship,
      lastStudyHours: this._lastStudyHours,
      seq: this._seq,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.entries = Array.isArray(d.entries) ? d.entries : [];
    this.counters = { focus: 0, tasks: 0, cards: 0, rehearsals: 0, projects: 0, studyMin: 0, ...(d.counters || {}) };
    this._lastFriendship = d.lastFriendship ?? 0;
    this._lastStudyHours = d.lastStudyHours ?? 0;
    this._seq = d.seq ?? this.entries.length;
  }

  dispose() {
    this._offs.forEach((off) => off && off());
    this._offs = [];
  }
}
