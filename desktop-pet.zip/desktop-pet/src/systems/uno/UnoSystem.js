/**
 * systems/uno/UnoSystem.js
 * ----------------------------------------------------------------------------
 * Persistent progression around the UNO mini-game: games played, wins, current
 * and longest win streak, your favourite colour (most played, across games),
 * and unlocked badges. The actual game is driven by engine.js + ai.js from the
 * panel; this system just records outcomes and hands out XP/badges via the bus.
 */

import { System } from '../System.js';
import { COLORS } from './engine.js';

const XP_WIN = { easy: 12, medium: 18, smart: 25 };

/** Pure: given current stats + a result, compute newly-earned badge ids. */
export function badgesFor(stats) {
  const earned = [];
  if (stats.wins >= 1) earned.push('first_win');
  if (stats.longestStreak >= 3) earned.push('streak_3');
  if (stats.beatSmart) earned.push('beat_smart');
  if (stats.wins >= 10) earned.push('games_10');
  if (stats.gamesPlayed >= 25) earned.push('regular');
  return earned;
}

export const BADGE_LABEL = {
  first_win: '🏅 First Win',
  streak_3: '🔥 Hat-trick (3 in a row)',
  beat_smart: '🧠 Outsmarted the Smart Dog',
  games_10: '🎴 Card Shark (10 wins)',
  regular: '🐾 Regular (25 games)',
};

export class UnoSystem extends System {
  static id = 'uno';

  constructor(ctx) {
    super(ctx);
    this.gamesPlayed = 0;
    this.wins = 0;
    this.streak = 0;
    this.longestStreak = 0;
    this.beatSmart = false;
    this.colorPlays = Object.create(null); // human colour usage across games
    this.badges = [];
  }

  /** Record a finished game. winner: 0 = human, 1 = dog. */
  recordGame(winner, difficulty, humanColorPlays = {}) {
    this.gamesPlayed += 1;
    for (const c of COLORS) if (humanColorPlays[c]) this.colorPlays[c] = (this.colorPlays[c] || 0) + humanColorPlays[c];

    if (winner === 0) {
      this.wins += 1;
      this.streak += 1;
      if (this.streak > this.longestStreak) this.longestStreak = this.streak;
      if (difficulty === 'smart') this.beatSmart = true;
      if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'uno', text: 'UNO! You win! 🎴', xp: XP_WIN[difficulty] || 12, n: this.streak });
    } else {
      this.streak = 0;
      if (this.ctx.bus) this.ctx.bus.emit('celebrate', { kind: 'uno', text: 'Good game! 🐶', xp: 3, n: 0 });
    }

    const before = new Set(this.badges);
    const now = badgesFor(this);
    const fresh = now.filter((b) => !before.has(b));
    this.badges = now;
    if (fresh.length && this.ctx.bus) this.ctx.bus.emit('uno:badge', { badges: fresh });
    if (this.ctx.bus) this.ctx.bus.emit('uno:gameover', { winner, streak: this.streak });
    return { fresh };
  }

  favoriteColor() {
    let best = null;
    let n = 0;
    for (const c of COLORS) if ((this.colorPlays[c] || 0) > n) { n = this.colorPlays[c]; best = c; }
    return best;
  }

  status() {
    return {
      gamesPlayed: this.gamesPlayed,
      wins: this.wins,
      streak: this.streak,
      longestStreak: this.longestStreak,
      favoriteColor: this.favoriteColor(),
      badges: this.badges.slice(),
    };
  }

  serialize() {
    return {
      gamesPlayed: this.gamesPlayed,
      wins: this.wins,
      streak: this.streak,
      longestStreak: this.longestStreak,
      beatSmart: this.beatSmart,
      colorPlays: this.colorPlays,
      badges: this.badges,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.gamesPlayed = d.gamesPlayed ?? 0;
    this.wins = d.wins ?? 0;
    this.streak = d.streak ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.beatSmart = !!d.beatSmart;
    this.colorPlays = d.colorPlays || Object.create(null);
    this.badges = Array.isArray(d.badges) ? d.badges : [];
  }
}
