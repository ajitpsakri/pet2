/**
 * systems/uno/ai.js
 * ----------------------------------------------------------------------------
 * The dog's UNO brain — pure and deterministic (RNG injected). Three levels:
 *   easy   — plays a random legal card; random-ish colour for wilds
 *   medium — matches colour, sheds high cards, saves wilds, disrupts when you're low
 *   smart  — all of the above, tuned: hoards wilds, dumps points, picks the colour
 *            it holds most of, and presses its advantage when you're near winning
 *
 * Always returns a legal action: { type:'play', index, chosenColor? } or
 * { type:'draw' }. Never returns an illegal move.
 */

import { COLORS, legalMoves } from './engine.js';

const POINTS = (c) => {
  if (c.value === 'wild4') return 50;
  if (c.value === 'wild') return 40;
  if (['skip', 'reverse', 'draw2'].includes(c.value)) return 20;
  return Number(c.value) || 0;
};
const isWild = (c) => c.color === 'wild';
const isAction = (c) => ['skip', 'reverse', 'draw2'].includes(c.value);

/** Colour the dog holds most of (ignoring wilds); falls back to red. */
function bestColor(hand) {
  const count = Object.create(null);
  for (const c of hand) if (!isWild(c)) count[c.color] = (count[c.color] || 0) + 1;
  let best = null;
  let n = -1;
  for (const c of COLORS) if ((count[c] || 0) > n) { n = count[c] || 0; best = c; }
  return best || COLORS[0];
}

export function chooseMove(hand, topColor, topValue, opponentCount, difficulty, rng = Math.random) {
  const legal = legalMoves(hand, topColor, topValue);
  if (legal.length === 0) return { type: 'draw' };

  const withColor = (idx) => {
    const c = hand[idx];
    return isWild(c) ? { type: 'play', index: idx, chosenColor: bestColor(hand) } : { type: 'play', index: idx };
  };

  if (difficulty === 'easy') {
    // Random legal card; for wilds, a random present colour.
    const idx = legal[Math.floor(rng() * legal.length)];
    const c = hand[idx];
    if (isWild(c)) {
      const present = hand.filter((x) => !isWild(x)).map((x) => x.color);
      const col = present.length ? present[Math.floor(rng() * present.length)] : COLORS[Math.floor(rng() * 4)];
      return { type: 'play', index: idx, chosenColor: col };
    }
    return { type: 'play', index: idx };
  }

  // medium + smart share a heuristic ranking; smart is more aggressive.
  const aggressive = difficulty === 'smart';
  const oppLow = opponentCount <= 2;

  // Partition legal moves.
  const wilds = legal.filter((i) => isWild(hand[i]));
  const nonWild = legal.filter((i) => !isWild(hand[i]));
  const actions = nonWild.filter((i) => isAction(hand[i]));
  const numbers = nonWild.filter((i) => !isAction(hand[i]));

  // 1) If the opponent is close to winning, disrupt with an action / draw card.
  if (oppLow && actions.length) {
    // Prefer draw2 > skip/reverse to pile on cards.
    const d2 = actions.find((i) => hand[i].value === 'draw2');
    return withColor(d2 != null ? d2 : actions[0]);
  }
  if (oppLow && aggressive) {
    const wild4 = wilds.find((i) => hand[i].value === 'wild4');
    if (wild4 != null) return withColor(wild4);
  }

  // 2) Otherwise shed the highest-value non-wild card (dump points, keep options).
  if (numbers.length) {
    numbers.sort((a, b) => POINTS(hand[b]) - POINTS(hand[a]));
    return withColor(numbers[0]);
  }
  if (actions.length) return withColor(actions[0]);

  // 3) Only resort to wilds when nothing else is legal (hoard them).
  // Prefer plain wild over wild4 unless aggressive and opponent is low.
  const plainWild = wilds.find((i) => hand[i].value === 'wild');
  if (plainWild != null && !(aggressive && oppLow)) return withColor(plainWild);
  return withColor(wilds[0]);
}
