/**
 * systems/uno/engine.js
 * ----------------------------------------------------------------------------
 * A pure, dependency-free UNO rules engine (no DOM, no randomness except via an
 * injected seedable RNG so games are deterministic in tests). Standard 108-card
 * deck, two players (you vs the dog). Reverse acts as Skip in a 2-player game,
 * and Skip / Draw Two / Wild Draw Four make the opponent miss their turn (so the
 * player goes again) — standard two-handed UNO.
 *
 * House rule kept deliberately friendly: Wild Draw Four is always playable
 * (we don't enforce the "only if you hold no matching colour" challenge rule).
 */

export const COLORS = ['red', 'yellow', 'green', 'blue'];
const ACTIONS = ['skip', 'reverse', 'draw2'];

/** Deterministic RNG (mulberry32) so tests are reproducible. */
export function makeRng(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let _id = 0;
const card = (color, value) => ({ id: ++_id, color, value });

/** Build a standard 108-card UNO deck. */
export function createDeck() {
  const deck = [];
  for (const c of COLORS) {
    deck.push(card(c, '0')); // one 0 per colour
    for (let n = 1; n <= 9; n++) { deck.push(card(c, String(n))); deck.push(card(c, String(n))); }
    for (const a of ACTIONS) { deck.push(card(c, a)); deck.push(card(c, a)); }
  }
  for (let i = 0; i < 4; i++) { deck.push(card('wild', 'wild')); deck.push(card('wild', 'wild4')); }
  return deck;
}

export function shuffle(deck, rng) {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

/** Can `c` be played on a discard whose active colour/value are given? */
export function canPlay(c, topColor, topValue) {
  if (c.color === 'wild') return true;
  return c.color === topColor || c.value === topValue;
}

/** Indices of playable cards in a hand. */
export function legalMoves(hand, topColor, topValue) {
  const out = [];
  for (let i = 0; i < hand.length; i++) if (canPlay(hand[i], topColor, topValue)) out.push(i);
  return out;
}

/** Create + deal a new game. Returns the full mutable state object. */
export function newGame(seed = Date.now()) {
  const rng = makeRng(seed);
  const drawPile = shuffle(createDeck(), rng);
  const hands = [[], []];
  for (let n = 0; n < 7; n++) { hands[0].push(drawPile.pop()); hands[1].push(drawPile.pop()); }
  // Flip a starter that isn't a wild/action, to keep the opening simple.
  let starter = drawPile.pop();
  while (starter.color === 'wild' || ACTIONS.includes(starter.value)) {
    drawPile.unshift(starter);
    starter = drawPile.pop();
  }
  return {
    rng,
    drawPile,
    discard: [starter],
    hands,
    turn: 0, // 0 = human, 1 = dog
    currentColor: starter.color,
    status: 'playing',
    winner: null,
    colorPlays: [Object.create(null), Object.create(null)], // colour usage per player
  };
}

export const top = (s) => s.discard[s.discard.length - 1];
export const other = (p) => (p === 0 ? 1 : 0);

function refill(s) {
  if (s.drawPile.length > 0) return;
  const keep = s.discard.pop();
  s.drawPile = shuffle(s.discard, s.rng);
  s.discard = [keep];
}

/** Draw `n` cards into player `p`'s hand (reshuffling if needed). */
export function draw(s, p, n) {
  const got = [];
  for (let i = 0; i < n; i++) {
    refill(s);
    if (!s.drawPile.length) break;
    const c = s.drawPile.pop();
    s.hands[p].push(c);
    got.push(c);
  }
  return got;
}

/**
 * Player `p` plays the card at `cardIdx`. `chosenColor` is required for wilds.
 * Returns an event describing what happened (for UI + dog personality), or
 * { error } if the move was illegal.
 */
export function play(s, p, cardIdx, chosenColor) {
  if (s.status !== 'playing' || s.turn !== p) return { error: 'not-your-turn' };
  const c = s.hands[p][cardIdx];
  if (!c) return { error: 'no-card' };
  if (!canPlay(c, s.currentColor, top(s).value)) return { error: 'illegal' };

  s.hands[p].splice(cardIdx, 1);
  s.discard.push(c);
  const opp = other(p);
  const ev = { type: c.value, card: c, player: p, opponent: opp, drew: 0, skipped: false, win: false, color: null };

  if (c.color === 'wild') {
    const col = COLORS.includes(chosenColor) ? chosenColor : COLORS[0];
    s.currentColor = col;
    ev.color = col;
    if (c.value === 'wild4') { ev.drew = draw(s, opp, 4).length; ev.skipped = true; }
  } else {
    s.currentColor = c.color;
    ev.color = c.color;
    s.colorPlays[p][c.color] = (s.colorPlays[p][c.color] || 0) + 1;
    if (c.value === 'draw2') { ev.drew = draw(s, opp, 2).length; ev.skipped = true; }
    else if (c.value === 'skip' || c.value === 'reverse') ev.skipped = true;
  }

  if (s.hands[p].length === 0) {
    s.status = 'won';
    s.winner = p;
    ev.win = true;
    return ev;
  }
  // Skip/draw effects mean the opponent misses a turn -> same player goes again.
  s.turn = ev.skipped ? p : opp;
  return ev;
}

/** Player `p` draws one card and ends their turn. Returns the drawn card. */
export function drawAndPass(s, p) {
  if (s.status !== 'playing' || s.turn !== p) return { error: 'not-your-turn' };
  const got = draw(s, p, 1);
  s.turn = other(p);
  return { type: 'draw', card: got[0] || null, player: p };
}

/** Most-played colour by player `p` across the current game. */
export function favoriteColor(s, p) {
  let best = null;
  let n = -1;
  for (const c of COLORS) {
    const v = s.colorPlays[p][c] || 0;
    if (v > n) { n = v; best = c; }
  }
  return n > 0 ? best : null;
}
