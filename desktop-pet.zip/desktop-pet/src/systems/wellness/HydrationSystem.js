/**
 * systems/wellness/HydrationSystem.js
 * ----------------------------------------------------------------------------
 * Keeps you hydrated without being annoying. Tracks water logged today against
 * a daily goal, fires a gentle reminder (through the NudgeEngine) when you're
 * behind, and celebrates the moment you hit your goal — with a day-over-day
 * streak. Each "drink" is one glass by default.
 *
 * Emits on the bus:
 *   hydration:drink {ml,todayMl}
 *   hydration:goal {streak}          goal reached today (+ a `celebrate`)
 *   nudge {category:'water',context} a gentle reminder
 */

import { System } from '../System.js';
import { nextStreak } from '../streakUtil.js';

export class HydrationSystem extends System {
  static id = 'hydration';

  constructor(ctx) {
    super(ctx);
    this.goalMl = 2000;
    this.glassMl = 250;
    this.todayMl = 0;
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastGoalDay = null;
    this.goalHitToday = false;
    this._today = null;
  }

  init() {
    if (this.ctx.nudge) this.ctx.nudge.configure('water', 60);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key !== this._today) {
      this._today = key;
      this.todayMl = 0;
      this.goalHitToday = false;
    }
  }

  /** Log a drink (defaults to one glass). Returns the new total in ml. */
  drink(ml = this.glassMl) {
    this._rollover();
    this.todayMl += ml;
    if (this.ctx.bus) this.ctx.bus.emit('hydration:drink', { ml, todayMl: this.todayMl });

    if (!this.goalHitToday && this.todayMl >= this.goalMl) {
      this.goalHitToday = true;
      this.streakDays = nextStreak(this.streakDays, this.lastGoalDay, this._today);
      if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
      this.lastGoalDay = this._today;
      if (this.ctx.nudge) this.ctx.nudge.acted('water');
      if (this.ctx.bus) {
        this.ctx.bus.emit('hydration:goal', { streak: this.streakDays });
        this.ctx.bus.emit('celebrate', { kind: 'hydration', text: 'Hydration goal! 💧', xp: 10, n: this.streakDays });
      }
    }
    return this.todayMl;
  }

  tick() {
    this._rollover();
    if (this.goalHitToday) return;
    if (this.ctx.nudge && this.ctx.nudge.request('water') && this.ctx.bus) {
      this.ctx.bus.emit('nudge', { category: 'water', context: 'water_nudge' });
    }
  }

  status() {
    return {
      todayMl: this.todayMl,
      goalMl: this.goalMl,
      glasses: Math.round(this.todayMl / this.glassMl),
      pct: Math.min(100, Math.round((this.todayMl / this.goalMl) * 100)),
      streakDays: this.streakDays,
      goalHitToday: this.goalHitToday,
    };
  }

  serialize() {
    return {
      goalMl: this.goalMl,
      todayMl: this.todayMl,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastGoalDay: this.lastGoalDay,
      goalHitToday: this.goalHitToday,
      today: this._today,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.goalMl = d.goalMl ?? this.goalMl;
    this.todayMl = d.todayMl ?? 0;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastGoalDay = d.lastGoalDay ?? null;
    this.goalHitToday = d.goalHitToday ?? false;
    this._today = d.today ?? this._today;
  }
}
