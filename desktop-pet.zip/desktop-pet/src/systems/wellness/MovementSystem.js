/**
 * systems/wellness/MovementSystem.js
 * ----------------------------------------------------------------------------
 * Posture & movement coach. Three sub-habits — stretch, stand, and eye-breaks
 * (the 20-20-20 rule) — each with its own gentle reminder cadence. Logging any
 * of them raises today's "movement score"; reaching the daily goal advances a
 * streak and celebrates. Reminders all funnel through the NudgeEngine, so even
 * three habits together can never spam you.
 *
 * Emits on the bus:
 *   movement:did {kind}
 *   movement:goal {streak}            daily movement goal reached (+ celebrate)
 *   nudge {category,context}          a gentle stretch/stand/eye reminder
 */

import { System } from '../System.js';
import { nextStreak } from '../streakUtil.js';

const KINDS = ['stretch', 'stand', 'eye'];
const BASE_MIN = { stretch: 45, stand: 50, eye: 20 }; // eye = 20-20-20

export class MovementSystem extends System {
  static id = 'movement';

  constructor(ctx) {
    super(ctx);
    this.counts = { stretch: 0, stand: 0, eye: 0 };
    this.goalScore = 6; // total movements that make a "good" day
    this.score = 0;
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastGoalDay = null;
    this.goalHitToday = false;
    this._today = null;
  }

  init() {
    if (this.ctx.nudge) for (const k of KINDS) this.ctx.nudge.configure(k, BASE_MIN[k]);
    this._today = this.ctx.clock ? this.ctx.clock.dayKey() : null;
  }

  _rollover() {
    if (!this.ctx.clock) return;
    const key = this.ctx.clock.dayKey();
    if (key !== this._today) {
      this._today = key;
      this.counts = { stretch: 0, stand: 0, eye: 0 };
      this.score = 0;
      this.goalHitToday = false;
    }
  }

  /** Log a movement of `kind` ('stretch' | 'stand' | 'eye'). */
  did(kind) {
    if (!KINDS.includes(kind)) return false;
    this._rollover();
    this.counts[kind] += 1;
    this.score += 1;
    if (this.ctx.nudge) this.ctx.nudge.acted(kind);
    if (this.ctx.bus) this.ctx.bus.emit('movement:did', { kind });

    if (!this.goalHitToday && this.score >= this.goalScore) {
      this.goalHitToday = true;
      this.streakDays = nextStreak(this.streakDays, this.lastGoalDay, this._today);
      if (this.streakDays > this.longestStreak) this.longestStreak = this.streakDays;
      this.lastGoalDay = this._today;
      if (this.ctx.bus) {
        this.ctx.bus.emit('movement:goal', { streak: this.streakDays });
        this.ctx.bus.emit('celebrate', { kind: 'movement', text: 'Movement goal! 🤸', xp: 8, n: this.streakDays });
      }
    }
    return true;
  }

  tick() {
    this._rollover();
    if (!this.ctx.nudge || !this.ctx.bus) return;
    // Ask per kind; the engine's global floor guarantees we don't fire several
    // at once even if multiple are due.
    for (const k of KINDS) {
      if (this.ctx.nudge.request(k)) {
        this.ctx.bus.emit('nudge', { category: k, context: `${k}_nudge` });
        break;
      }
    }
  }

  /** Compliance score 0..100 for dashboards. */
  movementScore() {
    return Math.min(100, Math.round((this.score / this.goalScore) * 100));
  }

  status() {
    return {
      counts: { ...this.counts },
      score: this.score,
      goalScore: this.goalScore,
      compliance: this.movementScore(),
      streakDays: this.streakDays,
      goalHitToday: this.goalHitToday,
    };
  }

  serialize() {
    return {
      counts: { ...this.counts },
      score: this.score,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastGoalDay: this.lastGoalDay,
      goalHitToday: this.goalHitToday,
      today: this._today,
    };
  }

  hydrate(d) {
    if (!d) return;
    this.counts = { stretch: 0, stand: 0, eye: 0, ...(d.counts || {}) };
    this.score = d.score ?? 0;
    this.streakDays = d.streakDays ?? 0;
    this.longestStreak = d.longestStreak ?? 0;
    this.lastGoalDay = d.lastGoalDay ?? null;
    this.goalHitToday = d.goalHitToday ?? false;
    this._today = d.today ?? this._today;
  }
}
