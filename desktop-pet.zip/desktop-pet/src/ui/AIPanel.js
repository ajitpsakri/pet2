/**
 * ui/AIPanel.js
 * ----------------------------------------------------------------------------
 * The "Chat" panel: talk to the dog (rubber-duck, quick explanations, quizzing,
 * day planning) using a local model, and manage what it remembers about you.
 * If Local AI is off/unavailable, sending shows a friendly hint and the rest of
 * the panel (memories) still works — everything stays on your machine.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const QUICK = [
  { label: '🦆 Rubber duck', text: "I'll explain my bug; ask me one guiding question at a time: " },
  { label: '❓ Quiz me', text: 'Quiz me with 3 short questions on what I am currently learning.' },
  { label: '🗒️ Plan my day', text: 'Help me pick the single most important task for today and why.' },
];

export class AIPanel {
  /**
   * @param {HTMLElement} el
   * @param {import('../systems/ai/AICompanionSystem.js').AICompanionSystem} ai
   * @param {{ generate:(text:string)=>Promise<string|null>, onChange:()=>void }} opts
   */
  constructor(el, ai, opts) {
    this.el = el;
    this.ai = ai;
    this.opts = opts || {};
    this.visible = false;
    this._pending = false;
    this._note = '';
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); this._focus(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }
  _focus() { const i = this.el.querySelector('.ai-input'); if (i) i.focus(); }

  async _send(text) {
    const msg = String(text || '').trim();
    if (!msg || this._pending) return;
    this.ai.pushTurn('user', msg);
    this._note = '';
    this._pending = true;
    this.render();

    let reply = null;
    try {
      reply = this.opts.generate ? await this.opts.generate(msg) : null;
    } catch {
      reply = null;
    }
    this._pending = false;
    if (reply) this.ai.pushTurn('assistant', reply);
    else this._note = 'Local AI is off or no model is running. Turn on “Local AI” in Settings and run Ollama to chat. Your memories are still saved locally.';
    if (this.opts.onChange) this.opts.onChange();
    this.render();
  }

  render() {
    const turns = this.ai.transcript
      .map((t) => `<div class="ai-msg ${t.role}"><span>${esc(t.text)}</span></div>`)
      .join('');
    const pending = this._pending ? '<div class="ai-msg assistant pending"><span>thinking…</span></div>' : '';
    const note = this._note ? `<p class="ai-note">${esc(this._note)}</p>` : '';
    const quick = QUICK.map((q, i) => `<button class="ai-quick" data-q="${i}">${q.label}</button>`).join('');

    const mems = this.ai.memories
      .map((m) => `<div class="mem-row"><span>${esc(m.text)}</span><button class="mem-del" data-del="${m.id}" title="Forget">✕</button></div>`)
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Chat</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="ai-transcript">${turns || '<p class="task-empty">Say hi, or try a shortcut below. Runs on a local model.</p>'}${pending}</div>
        ${note}
        <div class="ai-quickrow">${quick}</div>
        <div class="task-add">
          <input class="ai-input" type="text" maxlength="500" placeholder="Ask the dog… (local)"/>
          <button class="ai-send">Send</button>
        </div>

        <h3>What the dog remembers <span class="ai-local">· local only</span></h3>
        <div class="task-add">
          <input class="mem-input" type="text" maxlength="160" placeholder="e.g. I'm learning ARM assembly"/>
          <button class="mem-add">Remember</button>
        </div>
        ${mems || '<p class="task-empty">No memories yet.</p>'}
      </div>`;

    const q = (s) => this.el.querySelector(s);
    q('[data-close]').addEventListener('click', () => this.hide());

    const input = q('.ai-input');
    const send = () => { const v = input.value; input.value = ''; this._send(v); };
    q('.ai-send').addEventListener('click', send);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

    this.el.querySelectorAll('[data-q]').forEach((b) =>
      b.addEventListener('click', () => { input.value = QUICK[+b.dataset.q].text; this._focus(); })
    );

    const mem = q('.mem-input');
    const addMem = () => { if (this.ai.addMemory(mem.value)) { mem.value = ''; if (this.opts.onChange) this.opts.onChange(); this.render(); } };
    q('.mem-add').addEventListener('click', addMem);
    mem.addEventListener('keydown', (e) => { if (e.key === 'Enter') addMem(); });
    this.el.querySelectorAll('[data-del]').forEach((b) =>
      b.addEventListener('click', () => { this.ai.removeMemory(b.dataset.del); if (this.opts.onChange) this.opts.onChange(); this.render(); })
    );

    // Keep the transcript scrolled to the latest message.
    const tr = q('.ai-transcript');
    if (tr) tr.scrollTop = tr.scrollHeight;
  }
}
