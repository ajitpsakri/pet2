/**
 * ui/Celebration.js
 * ----------------------------------------------------------------------------
 * The dopamine hit. When something good happens (focus sprint done, Anki done,
 * a streak, a level-up, friendship up) we burst confetti and float a reward
 * caption right over the dog. Drawn on the existing pet canvas — no extra DOM,
 * no assets — so it stays light and fully offline.
 *
 * Designed to feel GOOD and immediate: bright colours, a little pop, "+XP".
 */

const PALETTES = {
  focus: ['#4bb3a6', '#6fd3c7', '#ffca3a', '#ffffff'],
  anki: ['#9b5de5', '#f15bb5', '#fee440', '#ffffff'],
  streak: ['#ff7a00', '#ff5d5d', '#ffca3a', '#ffffff'],
  friendship: ['#ff9aa2', '#ff5d8f', '#ffd6e0', '#ffffff'],
  levelup: ['#ffca3a', '#ffb703', '#fb8500', '#ffffff'],
  default: ['#4bb3a6', '#ffca3a', '#ff9aa2', '#9b5de5'],
};

export class Celebration {
  constructor() {
    this.parts = [];
    this.texts = [];
  }

  get active() {
    return this.parts.length > 0 || this.texts.length > 0;
  }

  /**
   * @param {object} opts { x, y, kind, text, xp }
   */
  trigger({ x, y, kind = 'default', text, xp, reduceMotion = false }) {
    const colors = PALETTES[kind] || PALETTES.default;
    const n = reduceMotion ? 0 : 42;
    for (let i = 0; i < n; i++) {
      const ang = (Math.PI * 2 * i) / n + Math.random() * 0.4;
      const spd = 90 + Math.random() * 150;
      this.parts.push({
        x, y: y - 10,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd - 60,
        size: 3 + Math.random() * 4,
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 12,
        color: colors[(Math.random() * colors.length) | 0],
        life: 0,
        ttl: 0.9 + Math.random() * 0.7,
      });
    }
    if (text) this.texts.push({ x, y: y - 36, text, life: 0, ttl: 1.6, big: true });
    if (xp) this.texts.push({ x: x + 18, y: y - 18, text: `+${xp} XP`, life: 0, ttl: 1.4, color: '#ffb703' });
  }

  update(dt) {
    const g = 320; // gravity
    for (const p of this.parts) {
      p.life += dt;
      p.vy += g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
    this.parts = this.parts.filter((p) => p.life < p.ttl);
    for (const t of this.texts) {
      t.life += dt;
      t.y -= 26 * dt;
    }
    this.texts = this.texts.filter((t) => t.life < t.ttl);
  }

  /** Draw in screen space (call with the same ctx as the pet, alpha = 1). */
  draw(ctx) {
    for (const p of this.parts) {
      const a = 1 - p.life / p.ttl;
      ctx.save();
      ctx.globalAlpha = Math.max(0, a);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 1.6);
      ctx.restore();
    }
    for (const t of this.texts) {
      const a = 1 - t.life / t.ttl;
      ctx.save();
      ctx.globalAlpha = Math.max(0, a);
      ctx.textAlign = 'center';
      ctx.font = t.big ? '700 16px "Trebuchet MS", system-ui, sans-serif' : '700 13px "Trebuchet MS", system-ui, sans-serif';
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(255,255,255,0.9)';
      ctx.fillStyle = t.color || '#2d4a45';
      ctx.strokeText(t.text, t.x, t.y);
      ctx.fillText(t.text, t.x, t.y);
      ctx.restore();
    }
  }
}
