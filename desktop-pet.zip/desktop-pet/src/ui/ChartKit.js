/**
 * ui/ChartKit.js
 * ----------------------------------------------------------------------------
 * Minimal, dependency-free charts drawn on a 2D canvas: progress rings, bar
 * charts, and sparklines. The layout math (nice axis max, bar rectangles, line
 * points) is pure and unit-tested; the draw* functions just paint those shapes.
 * No charting library, so the bundle stays tiny and fully offline.
 */

/** Round a max value up to a "nice" number (1/2/5 × 10ⁿ). */
export function niceMax(values, floor = 1) {
  const m = Math.max(floor, ...(values.length ? values : [floor]));
  const pow = 10 ** Math.floor(Math.log10(m));
  const n = m / pow;
  const nice = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return nice * pow;
}

/** Map values to bar rectangles within a w×h box (y down). */
export function barLayout(values, w, h, gap = 4) {
  const n = values.length;
  if (n === 0) return [];
  const max = niceMax(values);
  const bw = (w - gap * (n - 1)) / n;
  return values.map((v, i) => {
    const bh = Math.max(0, (v / max) * h);
    return { x: i * (bw + gap), y: h - bh, w: bw, h: bh, v };
  });
}

/** Map values to polyline points within a w×h box (y down). */
export function linePoints(values, w, h) {
  const n = values.length;
  if (n === 0) return [];
  const max = niceMax(values);
  if (n === 1) return [{ x: 0, y: h - (values[0] / max) * h }];
  return values.map((v, i) => ({ x: (i / (n - 1)) * w, y: h - (v / max) * h }));
}

// --- canvas drawing (not unit-tested; needs a real context) ---------------

/** Prepare a crisp HiDPI context sized to CSS w×h. Returns the 2D context. */
export function setupCanvas(canvas, w, h) {
  const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(h * dpr);
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return ctx;
}

export function drawRing(ctx, cx, cy, r, pct, color, track = '#e4dcc6', lineW = 9) {
  const p = Math.max(0, Math.min(1, pct / 100));
  ctx.lineWidth = lineW;
  ctx.lineCap = 'round';
  ctx.strokeStyle = track;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
  if (p > 0) {
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p);
    ctx.stroke();
  }
  ctx.fillStyle = '#294b45';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '700 15px "Trebuchet MS", system-ui, sans-serif';
  ctx.fillText(`${Math.round(pct)}%`, cx, cy);
}

export function drawBars(ctx, x, y, w, h, values, color) {
  const bars = barLayout(values, w, h, 5);
  ctx.fillStyle = color;
  for (const b of bars) {
    const r = Math.min(3, b.w / 2);
    roundRect(ctx, x + b.x, y + b.y, b.w, b.h, r);
    ctx.fill();
  }
}

export function drawSparkline(ctx, x, y, w, h, values, color) {
  const pts = linePoints(values, w, h);
  if (pts.length < 2) return;
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(x + p.x, y + p.y) : ctx.moveTo(x + p.x, y + p.y)));
  ctx.stroke();
  // dot on the last point
  const last = pts[pts.length - 1];
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x + last.x, y + last.y, 3, 0, Math.PI * 2);
  ctx.fill();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
