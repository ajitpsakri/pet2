/**
 * ui/CompanionDeck.js
 * ----------------------------------------------------------------------------
 * The "Today" dashboard: one place to see everything the companion tracks —
 * goal rings (focus/water/movement/tasks), streak chips, a weekly study-minutes
 * bar chart, a tasks completion sparkline, and friendship/level/next-talk
 * summaries. Reads each system's status() snapshot; draws charts via ChartKit.
 */

import { setupCanvas, drawRing, drawBars, drawSparkline } from './ChartKit.js';

const FOCUS_GOAL_MIN = 120; // display goal for the focus ring

export class CompanionDeck {
  /**
   * @param {HTMLElement} el
   * @param {object} sys { coding, hydration, movement, tasks, learning, presentation, relationship, state }
   */
  constructor(el, sys) {
    this.el = el;
    this.sys = sys;
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }

  _data() {
    const { coding, hydration, movement, tasks, learning, presentation, relationship, state } = this.sys;
    const c = coding.status(), h = hydration.status(), m = movement.status(), t = tasks.status(),
      l = learning.status(), p = presentation.status(), r = relationship.status();
    return {
      rings: [
        { label: 'Focus', pct: Math.min(100, Math.round((c.focusMinToday / FOCUS_GOAL_MIN) * 100)), color: '#4bb3a6', sub: `${c.focusMinToday}m` },
        { label: 'Water', pct: h.pct, color: '#4aa3e0', sub: `${h.glasses} glasses` },
        { label: 'Move', pct: m.compliance, color: '#5cc46a', sub: `${m.score}/${m.goalScore}` },
        { label: 'Tasks', pct: t.pct, color: '#ffb703', sub: `${t.done}/${t.total}` },
      ],
      streaks: [
        { icon: '🎯', n: c.streakDays }, { icon: '💧', n: h.streakDays },
        { icon: '🤸', n: m.streakDays }, { icon: '🏆', n: t.streakDays },
        { icon: '📚', n: l.streakDays },
      ],
      studyWeek: [...learning.weekHistory.map((x) => x.minutes), learning.todayMinutes],
      taskRates: [...tasks.recentRates.map((x) => Math.round(x.rate * 100)), Math.round(tasks.completionRate() * 100)],
      friendship: r.friendship,
      minutesTogether: r.minutesTogether,
      level: state.level,
      xpPct: Math.round((state.xp / Math.max(1, state.xpToNext)) * 100),
      nextTalk: p.next,
      practiceMin: p.totalRehearseMin,
    };
  }

  render() {
    const d = this._data();
    const ringCells = d.rings
      .map((r, i) => `
        <div class="ring-cell">
          <canvas class="ring-cv" data-ring="${i}"></canvas>
          <span class="ring-label">${r.label}</span>
          <span class="ring-sub">${r.sub}</span>
        </div>`)
      .join('');

    const streakChips = d.streaks
      .map((s) => `<span class="chip">${s.icon} <b>${s.n}</b></span>`)
      .join('');

    const talk = d.nextTalk
      ? `${d.nextTalk.title} · ${d.nextTalk.days === 0 ? 'today' : d.nextTalk.days === 1 ? 'tomorrow' : 'in ' + d.nextTalk.days + 'd'}`
      : 'none scheduled';

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Today</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="ring-row">${ringCells}</div>

        <h3>Streaks</h3>
        <div class="summary">${streakChips}</div>

        <h3>Study minutes (this week)</h3>
        <canvas class="chart-cv" data-chart="study"></canvas>

        <h3>Task completion (recent)</h3>
        <canvas class="chart-cv" data-chart="tasks"></canvas>

        <h3>Bond & progress</h3>
        <div class="summary">
          <span class="chip">💛 Friendship <b>L${d.friendship}</b></span>
          <span class="chip">⬆️ Level <b>${d.level}</b> (${d.xpPct}%)</span>
          <span class="chip">🕒 <b>${d.minutesTogether}</b> min together</span>
          <span class="chip">🎤 <b>${d.practiceMin}</b> min practiced</span>
        </div>
        <p class="hint">Next talk: ${talk}. All data is local to this PC.</p>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this._draw(d);
  }

  _draw(d) {
    // rings
    this.el.querySelectorAll('[data-ring]').forEach((cv) => {
      const r = d.rings[+cv.dataset.ring];
      const ctx = setupCanvas(cv, 64, 64);
      drawRing(ctx, 32, 32, 25, r.pct, r.color);
    });
    // study bars
    const studyCv = this.el.querySelector('[data-chart="study"]');
    if (studyCv) {
      const ctx = setupCanvas(studyCv, 300, 70);
      drawBars(ctx, 0, 4, 300, 62, d.studyWeek.length ? d.studyWeek : [0], '#9b5de5');
    }
    // task rates sparkline
    const taskCv = this.el.querySelector('[data-chart="tasks"]');
    if (taskCv) {
      const ctx = setupCanvas(taskCv, 300, 60);
      drawSparkline(ctx, 4, 6, 292, 48, d.taskRates.length ? d.taskRates : [0, 0], '#ffb703');
    }
  }
}
