/**
 * ContextMenu.js
 * ----------------------------------------------------------------------------
 * The interaction menu that appears when you click the puppy. Plain DOM for
 * crispness + accessibility. v3 is pet-centric: meals (breakfast/lunch/dinner,
 * once a day each), unlimited treats, petting, fetch, a little focus-companion
 * toggle, sleep, and a few panels. Choices report through one onAction callback.
 */

import { TREATS } from '../config/constants.js';

const MEAL_EMOJI = { breakfast: '🥣', lunch: '🍗', dinner: '🍖' };

export class ContextMenu {
  constructor(root, onAction) {
    this.root = root;
    this.onAction = onAction;
    this.open = false;
    this._pluginItems = [];
    this._feeding = null;
    this.root.classList.add('ctx-menu');
    document.addEventListener('pointerdown', (e) => {
      if (this.open && !this.root.contains(e.target)) this.hide();
    });
  }

  setPluginItems(items) { this._pluginItems = Array.isArray(items) ? items : []; }

  /** Getter for the feeding status so meals can show ✓ when already given. */
  setFeedingProvider(fn) { this._feeding = typeof fn === 'function' ? fn : null; }

  _btn(label, action, payload, disabled = false, title = '') {
    const b = document.createElement('button');
    b.className = 'ctx-item';
    b.textContent = label;
    if (disabled) { b.disabled = true; if (title) b.title = title; }
    else b.addEventListener('click', () => {
      this.onAction(action, payload);
      if (action === 'panel' || action === 'plugin' || action === 'play_fetch' || action === 'sleep') this.hide();
      else this._refreshMeals();
    });
    return b;
  }

  _sectionLabel(text) {
    const d = document.createElement('div');
    d.className = 'ctx-label';
    d.textContent = text;
    return d;
  }

  show(x, y) {
    this.root.innerHTML = '';
    const sections = document.createElement('div');
    sections.className = 'ctx-sections';

    // Care: pet, play, fetch, sleep
    const care = document.createElement('div');
    care.className = 'ctx-row';
    care.append(
      this._btn('✋ Pet', 'pet'),
      this._btn('🎾 Play', 'play'),
      this._btn('🦴 Fetch', 'play_fetch'),
      this._btn('😴 Sleep', 'sleep')
    );
    sections.append(this._sectionLabel('Care'), care);

    // Meals: breakfast/lunch/dinner, once a day each
    this._mealsRow = document.createElement('div');
    this._mealsRow.className = 'ctx-row';
    sections.append(this._sectionLabel('Meals'), this._mealsRow);
    this._refreshMeals();

    // Treats: unlimited
    const treats = document.createElement('div');
    treats.className = 'ctx-row';
    for (const [id, t] of Object.entries(TREATS)) {
      treats.append(this._btn(`${t.emoji} ${t.label}`, 'treat', id));
    }
    sections.append(this._sectionLabel('Treats'), treats);

    // A little coding-companion presence
    const focus = document.createElement('div');
    focus.className = 'ctx-row';
    focus.append(this._btn('🎯 Focus with me', 'focus_toggle'));
    sections.append(this._sectionLabel('Together'), focus);

    // Plugins (if any loaded)
    if (this._pluginItems.length) {
      const plugins = document.createElement('div');
      plugins.className = 'ctx-row';
      for (const it of this._pluginItems) {
        plugins.append(this._btn(it.label, 'plugin', { pluginId: it.pluginId, action: it.action }));
      }
      sections.append(this._sectionLabel('Plugins'), plugins);
    }

    // Panels
    const panels = document.createElement('div');
    panels.className = 'ctx-row';
    panels.append(
      this._btn('💬 Chat', 'panel', 'ai'),
      this._btn('📜 Timeline', 'panel', 'timeline'),
      this._btn('🩺 Health', 'panel', 'diagnostics'),
      this._btn('⚙️ Settings', 'panel', 'settings')
    );
    sections.append(panels);

    this.root.append(sections);

    this.root.style.display = 'block';
    const rect = this.root.getBoundingClientRect();
    const px = Math.min(Math.max(8, x - rect.width / 2), window.innerWidth - rect.width - 8);
    const py = Math.min(Math.max(8, y - rect.height - 16), window.innerHeight - rect.height - 8);
    this.root.style.left = `${px}px`;
    this.root.style.top = `${py}px`;
    this.open = true;
  }

  _refreshMeals() {
    if (!this._mealsRow) return;
    this._mealsRow.innerHTML = '';
    const f = this._feeding ? this._feeding() : { breakfast: false, lunch: false, dinner: false };
    for (const meal of ['breakfast', 'lunch', 'dinner']) {
      const done = !!f[meal];
      const label = `${MEAL_EMOJI[meal]} ${meal[0].toUpperCase() + meal.slice(1)}${done ? ' ✓' : ''}`;
      this._mealsRow.append(this._btn(label, 'feed', meal, done, 'Already given today'));
    }
  }

  hide() {
    this.root.style.display = 'none';
    this.open = false;
  }
}
