/**
 * ContextMenu.js
 * ----------------------------------------------------------------------------
 * The interaction menu that appears when you click the pet. Built as plain DOM
 * for crispness and accessibility. Foods/treats respect level unlocks. All
 * choices are reported through a single onAction callback so renderer.js can
 * route them to PetState.
 */

import { FOODS, TREATS } from '../config/constants.js';

export class ContextMenu {
  /**
   * @param {HTMLElement} root container element (positioned absolutely)
   * @param {(action, payload) => void} onAction
   */
  constructor(root, onAction) {
    this.root = root;
    this.onAction = onAction;
    this.open = false;
    this._buildClose();
    document.addEventListener('pointerdown', (e) => {
      if (this.open && !this.root.contains(e.target)) this.hide();
    });
  }

  _buildClose() {
    this.root.classList.add('ctx-menu');
  }

  _btn(label, action, payload, disabled = false) {
    const b = document.createElement('button');
    b.className = 'ctx-item';
    b.textContent = label;
    if (disabled) {
      b.disabled = true;
      b.title = 'Unlocks at a higher level';
    } else {
      b.addEventListener('click', () => {
        this.onAction(action, payload);
        // Keep submenu actions open-ish for rapid feeding; close for big ones.
        if (action === 'panel') this.hide();
      });
    }
    return b;
  }

  /**
   * @param {number} level pet's current level (for unlock gating)
   */
  show(x, y, level) {
    this.root.innerHTML = '';

    const sections = document.createElement('div');
    sections.className = 'ctx-sections';

    // Quick actions
    const quick = document.createElement('div');
    quick.className = 'ctx-row';
    quick.append(
      this._btn('💧 Water', 'water'),
      this._btn('✋ Pet', 'pet'),
      this._btn('🎾 Play', 'play'),
      this._btn('🧼 Clean', 'clean'),
      this._btn('😴 Sleep', 'sleep')
    );
    sections.append(this._sectionLabel('Care'), quick);

    // Foods
    const foods = document.createElement('div');
    foods.className = 'ctx-row';
    for (const [id, f] of Object.entries(FOODS)) {
      const locked = f.unlockLevel && level < f.unlockLevel;
      foods.append(this._btn(`${f.emoji} ${f.label}`, 'feed', id, locked));
    }
    sections.append(this._sectionLabel('Feed'), foods);

    // Treats
    const treats = document.createElement('div');
    treats.className = 'ctx-row';
    for (const [id, t] of Object.entries(TREATS)) {
      treats.append(this._btn(`${t.emoji} ${t.label}`, 'treat', id));
    }
    sections.append(this._sectionLabel('Treats'), treats);

    // Panels
    const panels = document.createElement('div');
    panels.className = 'ctx-row';
    panels.append(
      this._btn('📊 Stats', 'panel', 'dashboard'),
      this._btn('⚙️ Settings', 'panel', 'settings')
    );
    sections.append(panels);

    this.root.append(sections);

    // Position, keeping the menu on screen.
    this.root.style.display = 'block';
    const rect = this.root.getBoundingClientRect();
    const px = Math.min(Math.max(8, x - rect.width / 2), window.innerWidth - rect.width - 8);
    const py = Math.min(Math.max(8, y - rect.height - 16), window.innerHeight - rect.height - 8);
    this.root.style.left = `${px}px`;
    this.root.style.top = `${py}px`;
    this.open = true;
  }

  _sectionLabel(text) {
    const d = document.createElement('div');
    d.className = 'ctx-label';
    d.textContent = text;
    return d;
  }

  hide() {
    this.root.style.display = 'none';
    this.open = false;
  }
}
