/**
 * ContextMenu.js
 * ----------------------------------------------------------------------------
 * The interaction menu that appears when you click the pet. Built as plain DOM
 * for crispness and accessibility. Foods/treats respect level unlocks. All
 * choices are reported through a single onAction callback so renderer.js can
 * route them to PetState.
 */

import { FOODS, TREATS } from '../config/constants.js';

export class ContextMenu {
  /**
   * @param {HTMLElement} root container element (positioned absolutely)
   * @param {(action, payload) => void} onAction
   */
  constructor(root, onAction) {
    this.root = root;
    this.onAction = onAction;
    this.open = false;
    this._pluginItems = [];
    this._buildClose();
    document.addEventListener('pointerdown', (e) => {
      if (this.open && !this.root.contains(e.target)) this.hide();
    });
  }

  /** Provide context-menu buttons contributed by loaded plugins. */
  setPluginItems(items) {
    this._pluginItems = Array.isArray(items) ? items : [];
  }

  /** Provide a getter for current attention state to label the quiet toggles. */
  setAttentionProvider(fn) {
    this._attn = typeof fn === 'function' ? fn : null;
  }

  _buildClose() {
    this.root.classList.add('ctx-menu');
  }

  _btn(label, action, payload, disabled = false) {
    const b = document.createElement('button');
    b.className = 'ctx-item';
    b.textContent = label;
    if (disabled) {
      b.disabled = true;
      b.title = 'Unlocks at a higher level';
    } else {
      b.addEventListener('click', () => {
        this.onAction(action, payload);
        // Keep submenu actions open-ish for rapid feeding; close for big ones.
        if (action === 'panel' || action === 'plugin' || action === 'attention') this.hide();
      });
    }
    return b;
  }

  /**
   * @param {number} level pet's current level (for unlock gating)
   */
  show(x, y, level) {
    this.root.innerHTML = '';

    const sections = document.createElement('div');
    sections.className = 'ctx-sections';

    // Quick actions
    const quick = document.createElement('div');
    quick.className = 'ctx-row';
    quick.append(
      this._btn('💧 Water', 'water'),
      this._btn('✋ Pet', 'pet'),
      this._btn('🎾 Play', 'play'),
      this._btn('🧼 Clean', 'clean'),
      this._btn('😴 Sleep', 'sleep')
    );
    sections.append(this._sectionLabel('Care'), quick);

    // Foods
    const foods = document.createElement('div');
    foods.className = 'ctx-row';
    for (const [id, f] of Object.entries(FOODS)) {
      const locked = f.unlockLevel && level < f.unlockLevel;
      foods.append(this._btn(`${f.emoji} ${f.label}`, 'feed', id, locked));
    }
    sections.append(this._sectionLabel('Feed'), foods);

    // Treats
    const treats = document.createElement('div');
    treats.className = 'ctx-row';
    for (const [id, t] of Object.entries(TREATS)) {
      treats.append(this._btn(`${t.emoji} ${t.label}`, 'treat', id));
    }
    sections.append(this._sectionLabel('Treats'), treats);

    // Focus & study
    const focus = document.createElement('div');
    focus.className = 'ctx-row';
    const attn = this._attn ? this._attn() : { deepWork: false, meeting: false };
    focus.append(
      this._btn('🎯 Focus sprint', 'focus_toggle'),
      this._btn('🧠 Anki done', 'anki_done'),
      this._btn(`${attn.deepWork ? '🔔' : '🔕'} Deep Work`, 'attention', { what: 'deepwork' }),
      this._btn(`${attn.meeting ? '🔔' : '📵'} Meeting`, 'attention', { what: 'meeting' })
    );
    sections.append(this._sectionLabel('Focus'), focus);

    // Wellness
    const wellness = document.createElement('div');
    wellness.className = 'ctx-row';
    wellness.append(
      this._btn('💧 Water', 'hydrate'),
      this._btn('🧘 Stretch', 'stretch'),
      this._btn('🧍 Stand', 'stand'),
      this._btn('👁️ Eyes', 'eye')
    );
    sections.append(this._sectionLabel('Wellness'), wellness);

    // Plugins (only if any loaded plugin contributed menu items)
    if (this._pluginItems.length) {
      const plugins = document.createElement('div');
      plugins.className = 'ctx-row';
      for (const it of this._pluginItems) {
        plugins.append(this._btn(it.label, 'plugin', { pluginId: it.pluginId, action: it.action }));
      }
      sections.append(this._sectionLabel('Plugins'), plugins);
    }

    // Panels
    const panels = document.createElement('div');
    panels.className = 'ctx-row';
    panels.append(
      this._btn('📈 Today', 'panel', 'deck'),
      this._btn('💬 Chat', 'panel', 'ai'),
      this._btn('📓 Notes', 'panel', 'knowledge'),
      this._btn('🗂️ Projects', 'panel', 'projects'),
      this._btn('🃏 Cards', 'panel', 'flashcards'),
      this._btn('📜 Timeline', 'panel', 'timeline'),
      this._btn('📊 Stats', 'panel', 'dashboard'),
      this._btn('📝 Tasks', 'panel', 'tasks'),
      this._btn('📚 Learn', 'panel', 'learning'),
      this._btn('🎤 Talks', 'panel', 'presentation'),
      this._btn('🩺 Health', 'panel', 'diagnostics'),
      this._btn('⚙️ Settings', 'panel', 'settings')
    );
    sections.append(panels);

    this.root.append(sections);

    // Position, keeping the menu on screen.
    this.root.style.display = 'block';
    const rect = this.root.getBoundingClientRect();
    const px = Math.min(Math.max(8, x - rect.width / 2), window.innerWidth - rect.width - 8);
    const py = Math.min(Math.max(8, y - rect.height - 16), window.innerHeight - rect.height - 8);
    this.root.style.left = `${px}px`;
    this.root.style.top = `${py}px`;
    this.open = true;
  }

  _sectionLabel(text) {
    const d = document.createElement('div');
    d.className = 'ctx-label';
    d.textContent = text;
    return d;
  }

  hide() {
    this.root.style.display = 'none';
    this.open = false;
  }
}
