/**
 * ui/CoworkerPanel.js
 * ----------------------------------------------------------------------------
 * The dog's "coworker" home: treats earned from focus sprints, how many breaks
 * you've taken together, games played, and quick-launch buttons for the three
 * games so a break is one tap away. Ties the productivity loop and the play loop
 * together in one place.
 */

export class CoworkerPanel {
  constructor(el, coworker, opts = {}) {
    this.el = el;
    this.cw = coworker;
    this.onPlay = opts.onPlay || (() => {});
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }

  render() {
    const s = this.cw.status();
    const moodLine = {
      working: '🐶 Working alongside you',
      break: "🎾 On a break — let's play!",
      idle: '🐶 Ready when you are',
    }[s.mode] || '🐶 Ready when you are';

    this.el.innerHTML = `
      <div class="panel-head"><h2>Coworker</h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body">
        <div class="cw-status">${moodLine}</div>
        <div class="uno-stats">
          <span class="chip">🦴 <b>${s.treats}</b> treats</span>
          <span class="chip">🎯 <b>${s.sprintsTotal}</b> sprints</span>
          <span class="chip">☕ <b>${s.breaksTaken}</b> breaks</span>
          <span class="chip">🎮 <b>${s.gamesPlayed}</b> games</span>
        </div>
        <p class="hint">The dog earns a treat for every focus sprint, then offers a break-time game — fetch when you've stepped away, cricket around lunch, UNO otherwise. It stays quiet during deep work and meetings.</p>
        <h3>Take a break</h3>
        <div class="cw-games">
          <button class="cw-game" data-game="fetch">🦴 Fetch</button>
          <button class="cw-game" data-game="uno">🎴 UNO</button>
          <button class="cw-game" data-game="cricket">🏏 Cricket</button>
        </div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('[data-game]').forEach((b) =>
      b.addEventListener('click', () => { this.hide(); this.onPlay(b.dataset.game); }));
  }
}
