/**
 * ui/CricketPanel.js
 * ----------------------------------------------------------------------------
 * The cricket table. Mode select (Quick Play / Practice Nets / Challenge), then:
 *   Innings 1 — you BAT: pick a shot, then stop the timing bar (closer to the
 *   middle = better contact). The dog bowls and fields (diving catches, the odd
 *   drop). Innings 2 — you BOWL the chase: pick a delivery each ball; the dog
 *   bats automatically and you watch the run chase.
 * Personality reactions (six chase, diving catch, victory dance) route to the
 * live dog via onDogReact. Practice Nets has no chase — just rack up runs.
 */

import {
  newInnings, applyBall, resolveBall, dogBat, deliveryPenalty, oversText, MODES, DELIVERIES,
} from '../systems/cricket/engine.js';
import { TROPHY_LABEL } from '../systems/cricket/CricketSystem.js';

const SHOT_LABEL = { defend: '🛡️ Defend', push: '👉 Push', drive: '🏏 Drive', loft: '🚀 Loft' };
const DELIVERY_LABEL = { normal: 'Normal', bouncer: 'Bouncer', yorker: 'Yorker', spin: 'Spin' };

export class CricketPanel {
  constructor(el, cricket, opts = {}) {
    this.el = el;
    this.cricket = cricket;
    this.onDogReact = opts.onDogReact || (() => {});
    this.requestSave = opts.requestSave || (() => {});
    this.visible = false;
    this.mode = 'quick';
    this.reset();
  }

  reset() {
    this.phase = 'lobby'; // lobby | bat | bowl | result
    this.inn1 = null;
    this.inn2 = null;
    this.message = '';
    this.pendingShot = null; // chosen shot, waiting for timing
    this.timing = null; // active timing bar value while swinging
    this._raf = null;
    this.result = null;
    this._timers = [];
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() {
    this.visible = false;
    this.el.classList.remove('show');
    this._stopBar();
    this._timers.forEach(clearTimeout);
    this._timers = [];
  }
  toggle() { this.visible ? this.hide() : this.show(); }

  _cfg() { return MODES[this.mode]; }
  _dogSkill() { return this.cricket.currentDogSkill(this._cfg().dogSkill); }

  // --- start -----------------------------------------------------------------

  start() {
    const cfg = this._cfg();
    this.inn1 = newInnings({ overs: cfg.overs, wicketsAllowed: cfg.wicketsAllowed });
    this.inn2 = null;
    this.result = null;
    this.phase = 'bat';
    this.message = 'You bat! Pick a shot.';
    this.render();
  }

  // --- batting (you) ---------------------------------------------------------

  pickShot(shot) {
    if (this.phase !== 'bat' || this.pendingShot) return;
    this.pendingShot = shot;
    this._startBar();
    this.render();
  }

  _startBar() {
    // A timing bar sweeps 0..1..0; player taps "Hit!" to stop it.
    this.timing = 0;
    let dir = 1;
    const start = performance.now();
    const tick = (now) => {
      const t = ((now - start) / 700) % 2; // 0..2 cycle
      this.timing = t <= 1 ? t : 2 - t;
      const bar = this.el.querySelector('.ck-bar-fill');
      if (bar) bar.style.left = `${this.timing * 100}%`;
      this._raf = requestAnimationFrame(tick);
    };
    this._raf = requestAnimationFrame(tick);
  }

  _stopBar() {
    if (this._raf) cancelAnimationFrame(this._raf);
    this._raf = null;
  }

  swing() {
    if (this.phase !== 'bat' || !this.pendingShot) return;
    this._stopBar();
    const shot = this.pendingShot;
    const timing = this.timing != null ? this.timing : 0.5;
    this.pendingShot = null;
    const o = resolveBall(shot, timing, this._cfg().fieldSkill, Math.random);
    this._commentBat(o);
    applyBall(this.inn1, o);
    if (o.six) { this.cricket.noteSix(); this.onDogReact('six'); }
    if (o.fielding === 'dive') this.onDogReact('dive');
    else if (o.fielding === 'drop') this.onDogReact('drop');
    else if (o.out) this.onDogReact('wicket');

    if (this.inn1.done) return this._afterBatting();
    this.render();
  }

  _commentBat(o) {
    if (o.how === 'dropped') this.message = 'Dropped! The dog spilled it 🐶 — you survive (1 run).';
    else if (o.out && o.fielding === 'dive') this.message = 'OUT! Spectacular diving catch! 🤩';
    else if (o.out) this.message = o.how === 'caught' ? 'OUT! Caught! 🎾' : 'OUT! Bowled! 🎯';
    else if (o.six) this.message = 'SIX! Out of the park! 🚀';
    else if (o.runs === 4) this.message = 'FOUR! Cracked away 🏏';
    else this.message = `${o.runs} run${o.runs === 1 ? '' : 's'}.`;
  }

  _afterBatting() {
    const r1 = this.inn1.runs;
    if (this.mode === 'nets') { // no chase in the nets
      this._finish({ won: r1 > this.cricket.highScore, tie: false });
      return;
    }
    this.inn2 = newInnings({ overs: this._cfg().overs, wicketsAllowed: this._cfg().wicketsAllowed, target: r1 + 1 });
    this.phase = 'bowl';
    this.message = `Defend ${r1 + 1}! Pick your delivery.`;
    this.render();
  }

  // --- bowling the chase (you bowl, dog bats) --------------------------------

  bowl(delivery) {
    if (this.phase !== 'bowl' || this.inn2.done) return;
    const skill = this._dogSkill();
    const penalty = deliveryPenalty(delivery, skill);
    const pressure = this.inn2.target ? Math.min(1, (this.inn2.target - this.inn2.runs) / Math.max(1, (this.inn2.overs * 6 - this.inn2.balls))) / 2 : 0;
    const m = dogBat(skill, Math.random, pressure);
    const o = resolveBall(m.shot, m.timing - penalty, this._cfg().fieldSkill, Math.random);
    this._commentBowl(o, delivery);
    applyBall(this.inn2, o);
    if (o.six) this.onDogReact('dogsix');
    else if (o.out) this.onDogReact('wicket');

    if (this.inn2.done) return this._afterChase();
    this.render();
  }

  _commentBowl(o, delivery) {
    const d = DELIVERY_LABEL[delivery];
    if (o.out && o.fielding === 'dive') this.message = `${d} — WICKET! You take a screamer! 🤾`;
    else if (o.out) this.message = `${d} — WICKET! Dog is out! 🎯`;
    else if (o.six) this.message = `${d} — the dog launches a SIX! 🐶🚀`;
    else if (o.runs === 4) this.message = `${d} — dog finds the boundary, FOUR.`;
    else this.message = `${d} — dog takes ${o.runs}.`;
  }

  _afterChase() {
    const target = this.inn1.runs + 1;
    const chased = this.inn2.runs >= target;
    const tie = this.inn2.runs === this.inn1.runs;
    this._finish({ won: !chased && !tie, tie });
  }

  _finish({ won, tie }) {
    const wicketsTaken = this.inn2 ? this.inn2.wickets : 0;
    const bestP = Math.max(this.inn1.bestPartnership, this.inn1.runs >= this.inn1.partnership ? this.inn1.partnership : 0);
    const { fresh } = this.cricket.recordMatch({
      mode: this.mode,
      won,
      tie,
      batRuns: this.inn1.runs,
      wicketsTaken,
      bestPartnership: this.inn1.bestPartnership || this.inn1.runs,
    });
    this.result = { won, tie, fresh, batRuns: this.inn1.runs, chase: this.inn2 ? this.inn2.runs : null, target: this.inn1.runs + 1 };
    this.phase = 'result';
    this.onDogReact(won ? 'lose' : tie ? 'think' : 'victory');
    this.requestSave();
    this.render();
  }

  // --- rendering -------------------------------------------------------------

  render() {
    if (!this.visible) return;
    if (this.phase === 'lobby') this._renderLobby();
    else if (this.phase === 'result') this._renderResult();
    else this._renderPlay();
  }

  _scoreboard() {
    const i1 = this.inn1;
    const line1 = `🧑 You: <b>${i1.runs}/${i1.wickets}</b> <span class="ai-local">(${oversText(i1.balls)})</span>`;
    let line2 = '';
    if (this.inn2) {
      line2 = `🐶 Dog: <b>${this.inn2.runs}/${this.inn2.wickets}</b> <span class="ai-local">(${oversText(this.inn2.balls)})</span> · need ${Math.max(0, this.inn1.runs + 1 - this.inn2.runs)}`;
    }
    return `<div class="ck-score">${line1}${line2 ? '<br>' + line2 : ''}</div>`;
  }

  _renderLobby() {
    const s = this.cricket.status();
    const modeBtn = (id) => `<button class="uno-diff ${this.mode === id ? 'on' : ''}" data-mode="${id}">${MODES[id].label}</button>`;
    const trophies = s.trophies.length
      ? s.trophies.map((t) => `<span class="chip">${TROPHY_LABEL[t] || t}</span>`).join('')
      : '<span class="ai-local">none yet — go win the toss of fate!</span>';
    this.el.innerHTML = `
      <div class="panel-head"><h2>Cricket 🏏</h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body">
        <div class="uno-stats">
          <span class="chip">🏏 <b>${s.matches}</b> matches</span>
          <span class="chip">🏆 <b>${s.wins}</b> wins</span>
          <span class="chip">🅷🅸 <b>${s.highScore}</b></span>
          <span class="chip">🎯 <b>${s.wickets}</b> wkts</span>
          <span class="chip">💥 <b>${s.sixes}</b> sixes</span>
        </div>
        <h3>Mode</h3>
        <div class="uno-diffs">${modeBtn('quick')}${modeBtn('nets')}${modeBtn('challenge')}</div>
        <h3>Trophies</h3>
        <div class="summary">${trophies}</div>
        <div class="uno-actions"><button class="uno-deal" data-start>Take guard 🏏</button></div>
      </div>`;
    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => { this.mode = b.dataset.mode; this.render(); }));
    this.el.querySelector('[data-start]').addEventListener('click', () => this.start());
  }

  _renderPlay() {
    const batting = this.phase === 'bat';
    let controls = '';
    if (batting) {
      if (this.pendingShot) {
        controls = `
          <div class="ck-timing"><div class="ck-bar"><div class="ck-bar-zone"></div><div class="ck-bar-fill"></div></div></div>
          <div class="uno-actions"><button class="uno-deal" data-swing>Hit! 🏏</button></div>
          <p class="hint">Stop the marker in the middle for the cleanest contact.</p>`;
      } else {
        controls = `<div class="ck-shots">${['defend', 'push', 'drive', 'loft'].map((sh) => `<button class="ck-shot" data-shot="${sh}">${SHOT_LABEL[sh]}</button>`).join('')}</div>`;
      }
    } else { // bowling
      controls = `<div class="ck-shots">${DELIVERIES.map((d) => `<button class="ck-shot" data-bowl="${d}">${DELIVERY_LABEL[d]}</button>`).join('')}</div>`;
    }

    this.el.innerHTML = `
      <div class="panel-head"><h2>Cricket 🏏 <span class="ai-local">· ${MODES[this.mode].label}</span></h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body">
        ${this._scoreboard()}
        <div class="ck-pitch">${batting ? '🧑‍🦱🏏 &nbsp; vs &nbsp; 🐶' : '🐶🏏 &nbsp; vs &nbsp; 🧑‍🦱'}</div>
        <div class="uno-msg">${this.message}</div>
        ${controls}
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('[data-shot]').forEach((b) => b.addEventListener('click', () => this.pickShot(b.dataset.shot)));
    this.el.querySelectorAll('[data-bowl]').forEach((b) => b.addEventListener('click', () => this.bowl(b.dataset.bowl)));
    const sw = this.el.querySelector('[data-swing]');
    if (sw) sw.addEventListener('click', () => this.swing());
  }

  _renderResult() {
    const r = this.result;
    const head = r.tie ? '🤝 Tied match!' : r.won ? '🏆 You win!' : '🐶 The dog wins!';
    const detail = r.chase != null
      ? `You ${r.batRuns}, Dog ${r.chase} (target ${r.target}).`
      : `You scored ${r.batRuns} in the nets.`;
    const fresh = r.fresh && r.fresh.length ? `<div class="uno-fresh">Unlocked: ${r.fresh.map((t) => TROPHY_LABEL[t] || t).join(', ')}</div>` : '';
    this.el.innerHTML = `
      <div class="panel-head"><h2>Cricket 🏏</h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body">
        <div class="uno-banner ${r.won ? 'win' : 'lose'}">${head}</div>
        <p class="uno-msg">${detail}</p>
        ${fresh}
        <div class="uno-actions"><button class="uno-deal" data-again>Play again</button><button class="uno-diff" data-lobby>Change mode</button></div>
      </div>`;
    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelector('[data-again]').addEventListener('click', () => this.start());
    this.el.querySelector('[data-lobby]').addEventListener('click', () => { this.reset(); this.render(); });
  }
}
