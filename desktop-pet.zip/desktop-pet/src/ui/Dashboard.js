/**
 * Dashboard.js
 * ----------------------------------------------------------------------------
 * The statistics panel. Renders live needs as bars, mood, level/XP, lifetime
 * stats, the achievement grid, and an accessory picker (only unlocked items are
 * selectable). Re-rendered on open and lightly refreshed while visible.
 */

import { NEEDS, ACCESSORIES } from '../config/constants.js';
import { MoodEngine } from '../pet/MoodEngine.js';

const NEED_META = {
  hunger: { label: 'Hunger', color: '#f4a259' },
  thirst: { label: 'Thirst', color: '#4cc9f0' },
  happiness: { label: 'Happiness', color: '#ffca3a' },
  energy: { label: 'Energy', color: '#8ac926' },
  cleanliness: { label: 'Cleanliness', color: '#9b89f4' },
  health: { label: 'Health', color: '#ff5d8f' },
  affection: { label: 'Affection', color: '#ff6b6b' },
};

export class Dashboard {
  /**
   * @param {HTMLElement} el panel root
   * @param {PetState} state
   * @param {AchievementManager} achievements
   * @param {(accessoryId)=>void} onPickAccessory
   */
  constructor(el, state, achievements, onPickAccessory) {
    this.el = el;
    this.state = state;
    this.achievements = achievements;
    this.onPickAccessory = onPickAccessory;
    this.visible = false;
  }

  show() {
    this.visible = true;
    this.el.classList.add('show');
    this.render();
  }
  hide() {
    this.visible = false;
    this.el.classList.remove('show');
  }
  toggle() {
    this.visible ? this.hide() : this.show();
  }

  render() {
    if (!this.visible) return;
    const s = this.state;
    const mood = MoodEngine.evaluate(s.needs);
    const well = MoodEngine.wellbeing(s.needs);

    const bars = NEEDS.map((n) => {
      const m = NEED_META[n];
      const v = Math.round(s.needs[n]);
      return `
        <div class="stat-row">
          <span class="stat-name">${m.label}</span>
          <div class="bar"><div class="bar-fill" style="width:${v}%;background:${m.color}"></div></div>
          <span class="stat-val">${v}</span>
        </div>`;
    }).join('');

    const xpPct = Math.round((s.xp / s.xpToNext()) * 100);

    const ach = this.achievements
      .list()
      .map(
        (a) => `
        <div class="ach ${a.unlockedAt ? 'unlocked' : 'locked'}" title="${a.desc}">
          <div class="ach-icon">${a.icon}</div>
          <div class="ach-name">${a.name}</div>
        </div>`
      )
      .join('');

    const unlocked = s.unlockedAccessories();
    const accessoryBtns = Object.entries(ACCESSORIES)
      .map(([id, a]) => {
        const isUnlocked = unlocked.includes(id);
        const sel = s.accessory === id ? 'sel' : '';
        return `<button class="acc-btn ${sel}" data-acc="${id}" ${
          isUnlocked ? '' : 'disabled'
        } title="${isUnlocked ? a.label : 'Unlocks at level ' + a.unlockLevel}">${a.label}</button>`;
      })
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>${s.name}</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="summary">
          <div class="chip">Mood: <b>${cap(mood)}</b></div>
          <div class="chip">Level <b>${s.level}</b></div>
          <div class="chip">Age <b>${s.ageDays()}d</b></div>
          <div class="chip">Wellbeing <b>${well}</b></div>
        </div>

        <div class="xp"><div class="xp-fill" style="width:${xpPct}%"></div>
          <span>${Math.round(s.xp)} / ${s.xpToNext()} XP</span></div>

        <div class="stats">${bars}</div>

        <h3>Lifetime</h3>
        <div class="grid2">
          <div>Care streak: <b>${s.stats.careStreak}d</b></div>
          <div>Longest streak: <b>${s.stats.longestStreak}d</b></div>
          <div>Food given: <b>${s.stats.totalFood}</b></div>
          <div>Play sessions: <b>${s.stats.totalPlay}</b></div>
          <div>Head pats: <b>${s.stats.totalPats}</b></div>
          <div>Baths: <b>${s.stats.totalCleans}</b></div>
        </div>

        <h3>Accessories</h3>
        <div class="acc-row">${accessoryBtns}</div>

        <h3>Achievements <span class="muted">(${this.achievements.unlockedCount()}/${this.achievements.total()})</span></h3>
        <div class="ach-grid">${ach}</div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('.acc-btn').forEach((b) => {
      if (b.disabled) return;
      b.addEventListener('click', () => {
        this.onPickAccessory(b.dataset.acc);
        this.render();
      });
    });
  }
}

const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
