/**
 * ui/DiagnosticsPanel.js
 * ----------------------------------------------------------------------------
 * A small health dashboard: uptime, FPS, memory, event-bus traffic, save
 * integrity, plugin health, and recent state snapshots you can restore. All
 * local. Useful for debugging and for peace of mind that nothing's leaking.
 */

function fmtAgo(ts) {
  if (!ts) return 'never';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}
function fmtUptime(sec) {
  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.floor(sec / 60)}m ${sec % 60}s`;
  return `${Math.floor(sec / 3600)}h ${Math.floor((sec % 3600) / 60)}m`;
}

export class DiagnosticsPanel {
  /**
   * @param {HTMLElement} el
   * @param {import('../services/Diagnostics.js').Diagnostics} diag
   * @param {{ onRestore:(state:object)=>void, onOpenLogs:()=>void }} opts
   */
  constructor(el, diag, opts = {}) {
    this.el = el;
    this.diag = diag;
    this.opts = opts;
    this.visible = false;
    this._timer = null;
  }

  show() {
    this.visible = true;
    this.el.classList.add('show');
    this.render();
    this._timer = setInterval(() => { if (this.visible) this.render(); }, 1000);
  }
  hide() {
    this.visible = false;
    this.el.classList.remove('show');
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }
  toggle() { this.visible ? this.hide() : this.show(); }

  render() {
    const r = this.diag.report();
    const save = r.lastSave.ok == null ? 'no save yet' : r.lastSave.ok ? `ok · ${fmtAgo(r.lastSave.ts)}` : `FAILED · ${fmtAgo(r.lastSave.ts)}`;
    const mem = r.memoryMB != null ? `${r.memoryMB} MB` : 'n/a';
    const top = r.topEvents.map((e) => `<span class="chip">${e.type} <b>${e.count}</b></span>`).join('') || '<span class="ai-local">none yet</span>';
    const snaps = this.diag.snapshots.list()
      .map((s, i) => `<button class="dg-snap" data-i="${i}">${fmtAgo(s.ts)}</button>`)
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Health</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="dg-grid">
          <div class="dg-cell"><span class="dg-k">Uptime</span><span class="dg-v">${fmtUptime(r.uptimeSec)}</span></div>
          <div class="dg-cell"><span class="dg-k">FPS</span><span class="dg-v">${r.fps}</span></div>
          <div class="dg-cell"><span class="dg-k">Memory</span><span class="dg-v">${mem}</span></div>
          <div class="dg-cell"><span class="dg-k">Events/min</span><span class="dg-v">${r.eventsPerMin}</span></div>
          <div class="dg-cell"><span class="dg-k">Systems</span><span class="dg-v">${r.systems}</span></div>
          <div class="dg-cell"><span class="dg-k">Plugins</span><span class="dg-v">${r.plugins.loaded}${r.plugins.failed ? ' (' + r.plugins.failed + ' failed)' : ''}</span></div>
        </div>

        <h3>Save integrity</h3>
        <p class="dg-line ${r.lastSave.ok === false ? 'bad' : ''}">Last save: ${save}</p>
        ${r.lastError ? `<p class="dg-line bad">Last error: ${fmtAgo(r.lastError.ts)}</p>` : ''}

        <h3>Event traffic <span class="ai-local">· ${r.events} total</span></h3>
        <div class="summary">${top}</div>

        <h3>State snapshots <span class="ai-local">· ${r.snapshots}</span></h3>
        <div class="dg-snaps">${snaps || '<span class="ai-local">none yet</span>'}</div>
        <p class="hint">Tap a snapshot to restore that point. Snapshots are kept in memory only.</p>

        <div class="dg-actions">
          <button class="dg-copy">Copy report</button>
          <button class="dg-logs">Open logs folder</button>
        </div>
      </div>`;

    const q = (s) => this.el.querySelector(s);
    q('[data-close]').addEventListener('click', () => this.hide());
    q('.dg-copy').addEventListener('click', () => {
      try { navigator.clipboard.writeText(JSON.stringify(r, null, 2)); } catch { /* ignore */ }
    });
    q('.dg-logs').addEventListener('click', () => this.opts.onOpenLogs && this.opts.onOpenLogs());
    this.el.querySelectorAll('.dg-snap').forEach((b) =>
      b.addEventListener('click', () => {
        const snap = this.diag.snapshots.list()[+b.dataset.i];
        if (snap && this.opts.onRestore) this.opts.onRestore(snap.state);
      })
    );
  }
}
