/**
 * ui/FlashcardPanel.js
 * ----------------------------------------------------------------------------
 * Spaced-repetition UI: a review session (show front → reveal answer → grade
 * Again/Hard/Good/Easy) plus simple card management (add front/back/deck, list,
 * delete). Local-only; mirrors the other panels.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const GRADE_BTNS = [
  { g: 'again', label: 'Again' },
  { g: 'hard', label: 'Hard' },
  { g: 'good', label: 'Good' },
  { g: 'easy', label: 'Easy' },
];

export class FlashcardPanel {
  constructor(el, flashcards, onChange) {
    this.el = el;
    this.fc = flashcards;
    this.onChange = onChange || (() => {});
    this.visible = false;
    this.studying = false;
    this.currentId = null;
    this.revealed = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.studying = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }
  _changed() { this.onChange(); this.render(); }

  _startStudy() {
    const next = this.fc.nextDue();
    this.studying = !!next;
    this.currentId = next ? next.id : null;
    this.revealed = false;
    this.render();
  }

  _grade(g) {
    if (!this.currentId) return;
    this.fc.review(this.currentId, g);
    this.onChange();
    const next = this.fc.nextDue();
    this.currentId = next ? next.id : null;
    this.revealed = false;
    if (!next) this.studying = false;
    this.render();
  }

  _reviewArea() {
    const s = this.fc.status();
    if (this.studying && this.currentId) {
      const card = this.fc.cards.find((c) => c.id === this.currentId);
      if (!card) { this.studying = false; return this._reviewArea(); }
      const grades = this.revealed
        ? `<div class="fc-grades">${GRADE_BTNS.map((b) => `<button class="fc-grade g-${b.g}" data-grade="${b.g}">${b.label}</button>`).join('')}</div>`
        : '<button class="fc-reveal">Show answer</button>';
      return `
        <div class="fc-card">
          ${card.deck ? `<span class="fc-deck">${esc(card.deck)}</span>` : ''}
          <div class="fc-front">${esc(card.front)}</div>
          ${this.revealed ? `<div class="fc-back">${esc(card.back)}</div>` : ''}
        </div>
        ${grades}
        <p class="fc-progress">${s.due} due remaining</p>`;
    }
    if (s.due > 0) {
      return `<div class="fc-summary"><p><b>${s.due}</b> card${s.due === 1 ? '' : 's'} due today.</p>
        <button class="fc-study">Study now</button></div>`;
    }
    return `<div class="fc-summary"><p>All caught up! 🎉 Nothing due.</p></div>`;
  }

  render() {
    const s = this.fc.status();
    const list = this.fc.cards
      .slice(-40)
      .reverse()
      .map(
        (c) => `
        <div class="fc-row">
          <span class="fc-row-front">${esc(c.front)}</span>
          ${c.deck ? `<span class="fc-tag">${esc(c.deck)}</span>` : ''}
          <button class="task-del" data-del="${c.id}" title="Delete">✕</button>
        </div>`
      )
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Flashcards</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="fc-statline">📦 ${s.total} cards · 🗓️ ${s.due} due · 🔥 ${s.streakDays}d</div>
        ${this._reviewArea()}

        <h3>Add a card</h3>
        <input class="fc-front-in" type="text" maxlength="200" placeholder="Front (question)"/>
        <input class="fc-back-in" type="text" maxlength="400" placeholder="Back (answer)"/>
        <div class="task-add">
          <input class="fc-deck-in" type="text" maxlength="40" placeholder="Deck (optional)"/>
          <button class="fc-add">Add card</button>
        </div>

        <h3>All cards <span class="ai-local">· ${s.total}</span></h3>
        ${list || '<p class="task-empty">No cards yet.</p>'}
      </div>`;

    const q = (sel) => this.el.querySelector(sel);
    q('[data-close]').addEventListener('click', () => this.hide());

    const study = q('.fc-study');
    if (study) study.addEventListener('click', () => this._startStudy());
    const reveal = q('.fc-reveal');
    if (reveal) reveal.addEventListener('click', () => { this.revealed = true; this.render(); });
    this.el.querySelectorAll('[data-grade]').forEach((b) => b.addEventListener('click', () => this._grade(b.dataset.grade)));

    const f = q('.fc-front-in'), b = q('.fc-back-in'), d = q('.fc-deck-in');
    const add = () => { if (this.fc.addCard(f.value, b.value, d.value)) { this._changed(); } };
    q('.fc-add').addEventListener('click', add);
    [f, b, d].forEach((inp) => inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); }));

    this.el.querySelectorAll('[data-del]').forEach((bx) =>
      bx.addEventListener('click', () => {
        if (this.currentId === bx.dataset.del) { this.currentId = null; this.studying = false; }
        this.fc.removeCard(bx.dataset.del);
        this._changed();
      })
    );
  }
}
