/**
 * ui/KnowledgePanel.js
 * ----------------------------------------------------------------------------
 * The knowledge vault UI: a search box, a note editor (title / body / tags),
 * and a results list. Typing filters live; clicking a note loads it for edit.
 * Everything is local. Mirrors the other panels' render-on-change pattern.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const snippet = (s, n = 120) => {
  const t = String(s || '').replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n) + '…' : t;
};

export class KnowledgePanel {
  constructor(el, knowledge, onChange) {
    this.el = el;
    this.kv = knowledge;
    this.onChange = onChange || (() => {});
    this.visible = false;
    this.query = '';
    this.editing = null; // note id being edited, or null for new
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }
  _changed() { this.onChange(); this.render(); }

  _save() {
    const title = this.el.querySelector('.kv-title').value;
    const body = this.el.querySelector('.kv-body').value;
    const tags = this.el.querySelector('.kv-tagsin').value;
    if (!title.trim() && !body.trim()) return;
    if (this.editing) this.kv.update(this.editing, { title, body, tags });
    else this.kv.add({ title, body, tags });
    this.editing = null;
    this._changed();
  }

  render() {
    const results = this.kv.search(this.query, 30);
    const editingNote = this.editing ? this.kv.get(this.editing) : null;

    const rows = results
      .map((n) => {
        const tags = (n.tags || []).map((t) => `<span class="kv-tag">${esc(t)}</span>`).join('');
        return `
        <div class="kv-note">
          <div class="kv-note-main" data-edit="${n.id}">
            <span class="kv-note-title">${esc(n.title)}</span>
            <span class="kv-snippet">${esc(snippet(n.body))}</span>
            <div class="kv-tags">${tags}</div>
          </div>
          <button class="task-del" data-del="${n.id}" title="Delete">✕</button>
        </div>`;
      })
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Notes</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <input class="kv-search" type="search" placeholder="Search your notes…" value="${esc(this.query)}"/>

        <h3>${editingNote ? 'Edit note' : 'New note'}</h3>
        <input class="kv-title" type="text" maxlength="120" placeholder="Title" value="${editingNote ? esc(editingNote.title) : ''}"/>
        <textarea class="kv-body" rows="4" placeholder="Write what you learned…">${editingNote ? esc(editingNote.body) : ''}</textarea>
        <input class="kv-tagsin" type="text" maxlength="120" placeholder="tags, comma, separated" value="${editingNote ? esc((editingNote.tags || []).join(', ')) : ''}"/>
        <div class="kv-formrow">
          <button class="kv-save">${editingNote ? 'Update' : 'Save note'}</button>
          ${editingNote ? '<button class="kv-cancel">Cancel</button>' : ''}
        </div>

        <h3>${this.query ? 'Results' : 'Recent'} <span class="ai-local">· ${results.length}</span></h3>
        ${rows || '<p class="task-empty">No notes found.</p>'}
      </div>`;

    const q = (s) => this.el.querySelector(s);
    q('[data-close]').addEventListener('click', () => this.hide());

    const search = q('.kv-search');
    search.addEventListener('input', () => {
      this.query = search.value;
      // Re-render just the list area by re-rendering the panel; keep focus.
      const pos = search.selectionStart;
      this.render();
      const again = this.el.querySelector('.kv-search');
      if (again) { again.focus(); again.setSelectionRange(pos, pos); }
    });

    q('.kv-save').addEventListener('click', () => this._save());
    const cancel = q('.kv-cancel');
    if (cancel) cancel.addEventListener('click', () => { this.editing = null; this.render(); });

    this.el.querySelectorAll('[data-edit]').forEach((b) =>
      b.addEventListener('click', () => { this.editing = b.dataset.edit; this.render(); })
    );
    this.el.querySelectorAll('[data-del]').forEach((b) =>
      b.addEventListener('click', () => {
        if (this.editing === b.dataset.del) this.editing = null;
        this.kv.remove(b.dataset.del);
        this._changed();
      })
    );
  }
}
