/**
 * ui/LearningPanel.js
 * ----------------------------------------------------------------------------
 * Professional-development tracker UI: jot what you learned today, log study
 * minutes, tag technologies, and keep learning goals. Purely local, and
 * intentionally free of any job-search features. Mirrors the other panels.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export class LearningPanel {
  /**
   * @param {HTMLElement} el
   * @param {import('../systems/learning/LearningSystem.js').LearningSystem} learning
   * @param {() => void} onChange
   */
  constructor(el, learning, onChange) {
    this.el = el;
    this.learning = learning;
    this.onChange = onChange || (() => {});
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }

  _changed() { this.onChange(); this.render(); }

  render() {
    const s = this.learning.status();
    const goals = this.learning.goals
      .map(
        (g) => `
        <div class="task-row ${g.done ? 'done' : ''}">
          <input type="checkbox" class="goal-check" data-id="${g.id}" ${g.done ? 'checked' : ''}/>
          <span class="task-text">${esc(g.text)}</span>
          <button class="task-del" data-del="${g.id}" title="Remove">✕</button>
        </div>`
      )
      .join('');

    const tags = s.topTech.length
      ? s.topTech.map((t) => `<span class="learn-tag">${esc(t)}</span>`).join('')
      : '<span class="task-empty" style="padding:0">none yet</span>';

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Learning</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <h3>What did you learn today?</h3>
        <div class="task-add">
          <input class="learn-note" type="text" maxlength="160" placeholder="One thing you learned…"/>
          <button class="learn-notebtn">Save</button>
        </div>

        <h3>Log study time</h3>
        <div class="learn-quick">
          <button data-min="15">+15 min</button>
          <button data-min="30">+30 min</button>
          <button data-min="60">+60 min</button>
          <span class="learn-min">Today: ${s.todayMinutes}m · Week: ${s.weekMinutes}m</span>
        </div>

        <h3>Skills / tech studied</h3>
        <div class="task-add">
          <input class="learn-tech" type="text" maxlength="40" placeholder="e.g. Rust, SQL, Kafka…"/>
          <button class="learn-techbtn">Add</button>
        </div>
        <div class="learn-tags">${tags}</div>

        <h3>Learning goals</h3>
        <div class="task-add">
          <input class="learn-goal" type="text" maxlength="120" placeholder="e.g. Finish the algorithms course"/>
          <button class="learn-goalbtn">Add</button>
        </div>
        ${goals || '<p class="task-empty">No goals yet.</p>'}

        <div class="task-foot">
          <span>🔥 ${s.streakDays}-day learning streak</span>
          <span>${s.goalsDone}/${s.goals} goals</span>
        </div>
      </div>`;

    const q = (sel) => this.el.querySelector(sel);
    q('[data-close]').addEventListener('click', () => this.hide());

    const note = q('.learn-note');
    const saveNote = () => { if (this.learning.learnedToday(note.value)) this._changed(); };
    q('.learn-notebtn').addEventListener('click', saveNote);
    note.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveNote(); });

    this.el.querySelectorAll('[data-min]').forEach((b) =>
      b.addEventListener('click', () => { this.learning.logStudy(parseInt(b.dataset.min, 10)); this._changed(); })
    );

    const tech = q('.learn-tech');
    const addTech = () => { if (tech.value.trim()) { this.learning.studied(tech.value); tech.value = ''; this._changed(); } };
    q('.learn-techbtn').addEventListener('click', addTech);
    tech.addEventListener('keydown', (e) => { if (e.key === 'Enter') addTech(); });

    const goal = q('.learn-goal');
    const addGoal = () => { if (this.learning.addGoal(goal.value)) { goal.value = ''; this._changed(); } };
    q('.learn-goalbtn').addEventListener('click', addGoal);
    goal.addEventListener('keydown', (e) => { if (e.key === 'Enter') addGoal(); });

    this.el.querySelectorAll('.goal-check').forEach((c) =>
      c.addEventListener('change', () => { if (c.checked) this.learning.completeGoal(c.dataset.id); this._changed(); })
    );
    this.el.querySelectorAll('[data-del]').forEach((b) =>
      b.addEventListener('click', () => { this.learning.removeGoal(b.dataset.del); this._changed(); })
    );
  }
}
