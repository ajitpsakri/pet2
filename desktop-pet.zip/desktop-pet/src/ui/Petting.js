/**
 * ui/Petting.js
 * ----------------------------------------------------------------------------
 * Makes the dog feel real to pet. As you move the mouse over it, different body
 * parts react differently — scratch an ear and the back leg "thumps", boop the
 * snout, rub the belly for full zoomies. Stroking (movement) keeps the reaction
 * going, with gentle cooldowns so a single touch doesn't spam mood or sound.
 *
 * reactionFor() is a pure lookup so it can be unit-tested without a canvas.
 */

const REACTIONS = {
  head: { anim: 'petted', ms: 700, sound: 'pet', lines: ['*happy sigh* ♥', 'Mmm, right there…', 'So nice 🐶'] },
  ear: { anim: 'earscratch', ms: 800, sound: 'pet', lines: ['*thump thump thump*', 'Ohh that spot! ♥', '*back leg goes wild*'] },
  snout: { anim: 'boop', ms: 600, sound: 'pet', lines: ['Boop! 👃', '*sniff sniff*', 'Mlem'] },
  back: { anim: 'petted', ms: 700, sound: 'pet', lines: ['*content*', 'Good pats ♥', '*leans into your hand*'] },
  belly: { anim: 'bellyrub', ms: 1100, sound: 'play', lines: ['BELLY RUBS!! 🎉', '*kicky leg*', 'Best. Day. Ever.'] },
  tail: { anim: 'happy', ms: 800, sound: 'pet', lines: ['*wag wag wag*', 'Wheee!', '♥♥♥'] },
};

/** Reaction descriptor for a body region, or null if not pettable. */
export function reactionFor(region) {
  return REACTIONS[region] || null;
}

export class PettingController {
  constructor(pet, { sound, speech, state, bus } = {}) {
    this.pet = pet;
    this.sound = sound;
    this.speech = speech;
    this.state = state;
    this.bus = bus;
    this.count = 0;
    this._region = null;
    this._acc = 0;
    this._lastReact = -Infinity;
    this._lastLine = -Infinity;
    this._lastMood = -Infinity;
  }

  /**
   * Feed a mouse movement. `region` is the body part under the cursor (or null
   * when off the dog), `dist` the pixels moved since the last event.
   */
  move(region, dist, now = Date.now()) {
    if (!region) { this._region = null; this._acc = 0; return; }
    const changed = region !== this._region;
    this._acc += dist || 0;
    // React on entering a new part, or after enough stroking on the same part.
    if (!(changed || this._acc >= 16)) return;
    if (now - this._lastReact < 550) return; // paced — retry on a later move
    this._region = region;
    this._acc = 0;
    this._lastReact = now;
    this._react(region, now);
  }

  _react(region, now) {
    const r = reactionFor(region);
    if (!r) return;
    this.pet.triggerAction(r.anim, r.ms);
    if (this.sound) this.sound.play(r.sound);
    if (this.speech && now - this._lastLine > 1500) {
      this._lastLine = now;
      this.speech.say(r.lines[Math.floor(Math.random() * r.lines.length)], 1600, true);
    }
    if (this.state && this.state.pet && now - this._lastMood > 1400) {
      this._lastMood = now;
      this.state.pet(); // small mood boost, rate-limited so it can't be farmed
    }
    this.count++;
    if (this.bus) this.bus.emit('pet:petted', { region, count: this.count });
  }
}
