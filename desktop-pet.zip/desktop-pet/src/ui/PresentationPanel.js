/**
 * ui/PresentationPanel.js
 * ----------------------------------------------------------------------------
 * Presentation coach UI: add upcoming talks with a date countdown, rate your
 * confidence (1–5), run a rehearsal timer, and work a prep checklist. The timer
 * display updates live via syncTimer() from the main loop so it ticks even
 * though the rest of the panel only re-renders on changes.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const mmss = (sec) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;

export class PresentationPanel {
  constructor(el, presentation, onChange) {
    this.el = el;
    this.p = presentation;
    this.onChange = onChange || (() => {});
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }
  _changed() { this.onChange(); this.render(); }

  /** Cheap per-frame update of just the timer text (no full re-render). */
  syncTimer() {
    const t = this.el.querySelector('.present-timer');
    if (t) t.textContent = mmss(this.p.currentSeconds());
  }

  _countdownLabel(days) {
    if (days == null) return 'no date';
    if (days < 0) return 'past';
    if (days === 0) return 'today!';
    if (days === 1) return 'tomorrow';
    return `in ${days} days`;
  }

  render() {
    const talks = this.p.talks
      .map((t) => {
        const days = this.p.daysUntil(t.date);
        const stars = [1, 2, 3, 4, 5]
          .map((n) => `<button class="conf-star ${t.confidence >= n ? 'on' : ''}" data-conf="${t.id}" data-lvl="${n}">★</button>`)
          .join('');
        const active = this.p.rehearsing && this.p._activeTalkId === t.id;
        return `
        <div class="present-row">
          <div class="present-main">
            <span class="task-text">${esc(t.title)}</span>
            <span class="present-meta">${this._countdownLabel(days)} · ${t.rehearsals} rehearsals</span>
            <div class="conf-stars">${stars}</div>
          </div>
          <button class="present-go ${active ? 'on' : ''}" data-go="${t.id}">${active ? '■ Stop' : '▶ Rehearse'}</button>
          <button class="task-del" data-del="${t.id}" title="Remove">✕</button>
        </div>`;
      })
      .join('');

    const checks = this.p.checklist
      .map(
        (c) => `
        <div class="task-row ${c.done ? 'done' : ''}">
          <input type="checkbox" class="chk" data-id="${c.id}" ${c.done ? 'checked' : ''}/>
          <span class="task-text">${esc(c.text)}</span>
        </div>`
      )
      .join('');

    const s = this.p.status();
    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Talks</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="present-timerbox">
          <span class="present-timer">${mmss(this.p.currentSeconds())}</span>
          <span class="present-timerlbl">${this.p.rehearsing ? 'rehearsing…' : 'rehearsal timer'}</span>
          <button class="present-quick" data-quick>${this.p.rehearsing ? '■ Stop' : '▶ Start (no talk)'}</button>
        </div>

        <h3>Upcoming talks</h3>
        <div class="task-add">
          <input class="present-title" type="text" maxlength="80" placeholder="Talk title…"/>
          <input class="present-date" type="date"/>
          <button class="present-addbtn">Add</button>
        </div>
        ${talks || '<p class="task-empty">No talks yet. Add one to start a countdown.</p>'}

        <h3>Prep checklist</h3>
        ${checks}

        <div class="task-foot">
          <span>🎤 ${s.totalRehearseMin}m practiced · ${s.sessions} sessions</span>
          <span>✓ ${s.checklistDone}/${s.checklistTotal}</span>
        </div>
      </div>`;

    const q = (sel) => this.el.querySelector(sel);
    q('[data-close]').addEventListener('click', () => this.hide());

    q('[data-quick]').addEventListener('click', () => {
      this.p.rehearsing ? this.p.stopRehearsal() : this.p.startRehearsal(null);
      this._changed();
    });

    const title = q('.present-title');
    const date = q('.present-date');
    const add = () => { if (this.p.addTalk(title.value, date.value || null)) { title.value = ''; date.value = ''; this._changed(); } };
    q('.present-addbtn').addEventListener('click', add);
    title.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });

    this.el.querySelectorAll('[data-go]').forEach((b) =>
      b.addEventListener('click', () => {
        const id = b.dataset.go;
        if (this.p.rehearsing && this.p._activeTalkId === id) this.p.stopRehearsal();
        else { if (this.p.rehearsing) this.p.stopRehearsal(); this.p.startRehearsal(id); }
        this._changed();
      })
    );
    this.el.querySelectorAll('[data-conf]').forEach((b) =>
      b.addEventListener('click', () => { this.p.setConfidence(b.dataset.conf, parseInt(b.dataset.lvl, 10)); this._changed(); })
    );
    this.el.querySelectorAll('[data-del]').forEach((b) =>
      b.addEventListener('click', () => { this.p.removeTalk(b.dataset.del); this._changed(); })
    );
    this.el.querySelectorAll('.chk').forEach((c) =>
      c.addEventListener('change', () => { this.p.toggleCheck(c.dataset.id); this._changed(); })
    );
  }
}
