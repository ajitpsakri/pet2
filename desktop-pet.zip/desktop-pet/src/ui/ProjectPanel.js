/**
 * ui/ProjectPanel.js
 * ----------------------------------------------------------------------------
 * Project tracker UI: add projects with a deadline, expand one to manage its
 * milestones (checkboxes with a progress bar), jot notes, and watch a deadline
 * countdown. Local-only; mirrors the other panels' render-on-change pattern.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export class ProjectPanel {
  constructor(el, projects, onChange) {
    this.el = el;
    this.ps = projects;
    this.onChange = onChange || (() => {});
    this.visible = false;
    this.openId = null; // expanded project
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }
  _changed() { this.onChange(); this.render(); }

  _countdown(days) {
    if (days == null) return 'no deadline';
    if (days < 0) return 'overdue';
    if (days === 0) return 'due today';
    if (days === 1) return 'due tomorrow';
    return `${days} days left`;
  }

  _projectCard(p) {
    const prog = this.ps.progress(p.id);
    const days = this.ps.daysUntil(p.deadline);
    const open = this.openId === p.id;
    const overdue = days != null && days < 0 && !this.ps.isComplete(p);

    const milestones = open
      ? p.milestones
          .map(
            (m) => `
        <div class="ms-row ${m.done ? 'done' : ''}">
          <input type="checkbox" class="ms-check" data-pid="${p.id}" data-mid="${m.id}" ${m.done ? 'checked' : ''}/>
          <span class="ms-title">${esc(m.title)}</span>
          <button class="ms-del" data-pid="${p.id}" data-msdel="${m.id}" title="Remove">✕</button>
        </div>`
          )
          .join('') +
        `<div class="task-add ms-add">
           <input class="ms-input" type="text" maxlength="100" placeholder="Add a milestone…" data-pid="${p.id}"/>
           <button class="ms-addbtn" data-pid="${p.id}">Add</button>
         </div>
         <textarea class="pr-notes" rows="3" placeholder="Notes…" data-pid="${p.id}">${esc(p.notes || '')}</textarea>
         <div class="pr-foot">
           <input class="pr-date" type="date" value="${p.deadline || ''}" data-pid="${p.id}"/>
           <button class="pr-del" data-pid="${p.id}">Delete project</button>
         </div>`
      : '';

    return `
      <div class="pr-card ${overdue ? 'overdue' : ''}">
        <div class="pr-head" data-open="${p.id}">
          <span class="pr-name">${esc(p.name)}</span>
          <span class="pr-meta">${prog.done}/${prog.total} · ${this._countdown(days)}</span>
        </div>
        <div class="pr-bar"><div class="pr-bar-fill" style="width:${prog.pct}%"></div></div>
        ${milestones}
      </div>`;
  }

  render() {
    const cards = this.ps.activeProjects().map((p) => this._projectCard(p)).join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Projects</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="task-add">
          <input class="pr-newname" type="text" maxlength="80" placeholder="New project…"/>
          <input class="pr-newdate" type="date"/>
          <button class="pr-addbtn">Add</button>
        </div>
        ${cards || '<p class="task-empty">No projects yet. Add one to start tracking milestones.</p>'}
      </div>`;

    const q = (s) => this.el.querySelector(s);
    q('[data-close]').addEventListener('click', () => this.hide());

    const name = q('.pr-newname');
    const date = q('.pr-newdate');
    const add = () => { const p = this.ps.addProject(name.value, date.value || null); if (p) { this.openId = p.id; this._changed(); } };
    q('.pr-addbtn').addEventListener('click', add);
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });

    this.el.querySelectorAll('[data-open]').forEach((b) =>
      b.addEventListener('click', () => { this.openId = this.openId === b.dataset.open ? null : b.dataset.open; this.render(); })
    );
    this.el.querySelectorAll('.ms-check').forEach((c) =>
      c.addEventListener('change', () => { this.ps.toggleMilestone(c.dataset.pid, c.dataset.mid); this._changed(); })
    );
    this.el.querySelectorAll('[data-msdel]').forEach((b) =>
      b.addEventListener('click', () => { this.ps.removeMilestone(b.dataset.pid, b.dataset.msdel); this._changed(); })
    );
    this.el.querySelectorAll('.ms-addbtn').forEach((b) =>
      b.addEventListener('click', () => {
        const input = this.el.querySelector(`.ms-input[data-pid="${b.dataset.pid}"]`);
        if (input && this.ps.addMilestone(b.dataset.pid, input.value)) this._changed();
      })
    );
    this.el.querySelectorAll('.ms-input').forEach((inp) =>
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && this.ps.addMilestone(inp.dataset.pid, inp.value)) this._changed();
      })
    );
    this.el.querySelectorAll('.pr-notes').forEach((t) =>
      t.addEventListener('change', () => { this.ps.setNotes(t.dataset.pid, t.value); this.onChange(); })
    );
    this.el.querySelectorAll('.pr-date').forEach((d) =>
      d.addEventListener('change', () => { this.ps.setDeadline(d.dataset.pid, d.value || null); this._changed(); })
    );
    this.el.querySelectorAll('.pr-del').forEach((b) =>
      b.addEventListener('click', () => { if (this.openId === b.dataset.pid) this.openId = null; this.ps.removeProject(b.dataset.pid); this._changed(); })
    );
  }
}
