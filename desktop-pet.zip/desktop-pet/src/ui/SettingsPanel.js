/**
 * SettingsPanel.js
 * ----------------------------------------------------------------------------
 * UI for the Settings model. Sliders for continuous values, toggles for
 * booleans. Changes apply live (the pet rescales/refades immediately) and are
 * persisted through the normal save path.
 */

export class SettingsPanel {
  /**
   * @param {HTMLElement} el panel root
   * @param {Settings} settings
   */
  constructor(el, settings) {
    this.el = el;
    this.settings = settings;
    this.visible = false;
  }

  show() {
    this.visible = true;
    this.el.classList.add('show');
    this.render();
  }
  hide() {
    this.visible = false;
    this.el.classList.remove('show');
  }
  toggle() {
    this.visible ? this.hide() : this.show();
  }

  _slider(key, label, min, max, step, fmt) {
    const v = this.settings.get(key);
    return `
      <label class="set-row">
        <span>${label}</span>
        <input type="range" data-key="${key}" min="${min}" max="${max}" step="${step}" value="${v}">
        <output data-out="${key}">${fmt(v)}</output>
      </label>`;
  }

  _toggle(key, label) {
    const v = this.settings.get(key);
    return `
      <label class="set-row toggle">
        <span>${label}</span>
        <input type="checkbox" data-key="${key}" ${v ? 'checked' : ''}>
      </label>`;
  }

  render() {
    const pct = (v) => `${Math.round(v * 100)}%`;
    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Settings</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        ${this._slider('scale', 'Pet size', 0.5, 2, 0.05, (v) => `${v.toFixed(2)}×`)}
        ${this._slider('opacity', 'Transparency', 0.2, 1, 0.05, pct)}
        ${this._slider('animationSpeed', 'Animation speed', 0.5, 2, 0.05, (v) => `${v.toFixed(2)}×`)}
        ${this._slider('volume', 'Sound volume', 0, 1, 0.05, pct)}
        <hr/>
        ${this._toggle('muted', 'Mute sounds')}
        ${this._toggle('alwaysOnTop', 'Always on top')}
        ${this._toggle('clickThrough', 'Click-through when idle')}
        ${this._toggle('startOnBoot', 'Start with Windows')}
        <p class="hint">All data stays on this PC. The pet never connects to the internet.</p>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());

    this.el.querySelectorAll('input[type=range]').forEach((inp) => {
      inp.addEventListener('input', () => {
        const stored = this.settings.set(inp.dataset.key, parseFloat(inp.value));
        const out = this.el.querySelector(`[data-out="${inp.dataset.key}"]`);
        if (out) {
          const fmtPct = ['opacity', 'volume'].includes(inp.dataset.key);
          out.textContent = fmtPct
            ? `${Math.round(stored * 100)}%`
            : `${stored.toFixed(2)}×`;
        }
      });
    });

    this.el.querySelectorAll('input[type=checkbox]').forEach((inp) => {
      inp.addEventListener('change', () => {
        this.settings.set(inp.dataset.key, inp.checked);
      });
    });
  }
}
