/**
 * Sound.js
 * ----------------------------------------------------------------------------
 * Optional, fully-offline sound effects synthesised with the Web Audio API —
 * no audio files to ship. Sounds default to muted (office-friendly) and respect
 * the volume setting. Lazily creates the AudioContext on first unmuted use so
 * we never grab audio resources unnecessarily.
 */

export class Sound {
  constructor(settings) {
    this.settings = settings;
    this.ctx = null;
  }

  _ensure() {
    if (this.settings.get('muted')) return null;
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      } catch {
        this.ctx = null;
      }
    }
    return this.ctx;
  }

  _blip(freq, dur, type = 'sine') {
    const ctx = this._ensure();
    if (!ctx) return;
    const vol = this.settings.get('volume') * 0.2; // keep it gentle
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(vol, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + dur);
  }

  play(name) {
    switch (name) {
      case 'feed': return this._blip(520, 0.12, 'triangle');
      case 'water': return this._blip(380, 0.1, 'sine');
      case 'pet': return this._blip(660, 0.09, 'sine');
      case 'play': return this._blip(720, 0.12, 'square');
      case 'clean': return this._blip(900, 0.1, 'sine');
      case 'levelup': {
        this._blip(523, 0.12); setTimeout(() => this._blip(659, 0.12), 110);
        setTimeout(() => this._blip(784, 0.18), 220); return;
      }
      case 'achievement': {
        this._blip(659, 0.1); setTimeout(() => this._blip(988, 0.2), 120); return;
      }
      case 'celebrate': {
        this._blip(523, 0.1, 'triangle');
        setTimeout(() => this._blip(659, 0.1, 'triangle'), 90);
        setTimeout(() => this._blip(784, 0.1, 'triangle'), 180);
        setTimeout(() => this._blip(1047, 0.22, 'triangle'), 270);
        return;
      }
      default: return;
    }
  }
}
