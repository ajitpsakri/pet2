/**
 * SpeechBubble.js
 * ----------------------------------------------------------------------------
 * Renders a small DOM speech bubble above the pet and decides *when* the pet
 * speaks. All lines are local and predefined (no network, no API). Speech is
 * deliberately rate-limited so the pet stays charming rather than chatty.
 */

import { SPEECH_MIN_GAP_MS, SPEECH_CHANCE } from '../config/constants.js';

const LINES = {
  greeting: ['Good morning!', 'Hello again!', 'Welcome back!', 'Missed you!'],
  hungry: ["I'm hungry…", 'Snack time?', 'My tummy rumbles.'],
  thirsty: ['So thirsty…', 'Water, please?'],
  sleepy: ['*yawn*', 'So sleepy…', 'Nap time?'],
  lonely: ['Can we play?', 'Pay attention to me!', 'Over here!'],
  happy: ['This is the best!', 'Yay!', 'I love this!'],
  thanks_feed: ['Yum, thank you!', 'Delicious!', 'So good!'],
  thanks_pet: ['Hehe, that tickles!', 'More pats please.', '<3'],
  thanks_play: ['That was fun!', 'Again, again!'],
  levelup: ['I leveled up!', 'I feel stronger!'],
  idle: ['La la la~', 'Nice day.', 'Just hanging out.', 'What shall we do?'],
};

export class SpeechBubble {
  /** @param {HTMLElement} el the bubble element to position/show */
  constructor(el) {
    this.el = el;
    this.lastSpoke = 0;
    this.hideAt = 0;
    this._greeted = false;
  }

  /** Greet once shortly after launch (uses time of day). */
  maybeGreet() {
    if (this._greeted) return;
    this._greeted = true;
    const h = new Date().getHours();
    const line =
      h < 11 ? 'Good morning!' : h < 18 ? 'Welcome back!' : 'Good evening!';
    this.say(line, 4000, true);
  }

  /** Force a line from a category (used for reactions like feeding). */
  react(category) {
    const pool = LINES[category];
    if (pool) this.say(pool[(Math.random() * pool.length) | 0], 2600, true);
  }

  /**
   * Possibly say a mood-appropriate idle line. Honours the rate limit and a low
   * probability so it never nags.
   */
  maybeIdle(mood) {
    const now = Date.now();
    if (now - this.lastSpoke < SPEECH_MIN_GAP_MS) return;
    if (Math.random() > SPEECH_CHANCE) return;

    const category =
      mood === 'hungry' ? 'hungry'
      : mood === 'thirsty' ? 'thirsty'
      : mood === 'sleepy' ? 'sleepy'
      : mood === 'lonely' ? 'lonely'
      : mood === 'happy' || mood === 'excited' ? 'happy'
      : 'idle';

    const pool = LINES[category];
    this.say(pool[(Math.random() * pool.length) | 0], 2800);
  }

  say(text, ms = 2600, force = false) {
    const now = Date.now();
    if (!force && now - this.lastSpoke < SPEECH_MIN_GAP_MS) return;
    this.lastSpoke = now;
    this.hideAt = now + ms;
    this.el.textContent = text;
    this.el.classList.add('show');
  }

  /** Position above the pet and auto-hide when expired. Called each frame. */
  update(petX, petY, scale) {
    if (this.hideAt && Date.now() > this.hideAt) {
      this.el.classList.remove('show');
      this.hideAt = 0;
    }
    if (this.el.classList.contains('show')) {
      this.el.style.left = `${petX}px`;
      this.el.style.top = `${petY - 60 * scale}px`;
    }
  }
}
