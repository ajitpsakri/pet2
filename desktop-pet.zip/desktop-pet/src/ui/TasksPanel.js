/**
 * ui/TasksPanel.js
 * ----------------------------------------------------------------------------
 * The daily planner UI. Type a priority and hit Enter (or Add); tap the star to
 * mark your one main goal; check things off to celebrate and build a productive
 * streak. Mirrors the other panels: innerHTML render + .show toggle, all local.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export class TasksPanel {
  /**
   * @param {HTMLElement} el panel root
   * @param {import('../systems/tasks/TasksSystem.js').TasksSystem} tasks
   * @param {() => void} onChange called after any mutation (to persist)
   */
  constructor(el, tasks, onChange) {
    this.el = el;
    this.tasks = tasks;
    this.onChange = onChange || (() => {});
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); const i = this.el.querySelector('.task-input'); if (i) i.focus(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }

  _add() {
    const input = this.el.querySelector('.task-input');
    if (!input) return;
    const makeMain = !this.tasks.mainGoal(); // first task of the day becomes the main goal
    if (this.tasks.add(input.value, { main: makeMain })) {
      input.value = '';
      this.onChange();
      this.render();
      const again = this.el.querySelector('.task-input');
      if (again) again.focus();
    }
  }

  render() {
    const s = this.tasks.status();
    const rows = this.tasks.tasks
      .map(
        (t) => `
        <div class="task-row ${t.done ? 'done' : ''}">
          <input type="checkbox" class="task-check" data-id="${t.id}" ${t.done ? 'checked' : ''}/>
          <button class="task-star ${t.main ? 'on' : ''}" data-star="${t.id}" title="Main goal">${t.main ? '🏆' : '☆'}</button>
          <span class="task-text">${esc(t.text)}</span>
          <button class="task-del" data-del="${t.id}" title="Remove">✕</button>
        </div>`
      )
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Today</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        <div class="task-add">
          <input class="task-input" type="text" maxlength="120" placeholder="What's important today?"/>
          <button class="task-addbtn">Add</button>
        </div>
        ${rows || '<p class="task-empty">No tasks yet. Add your main goal first 🏆</p>'}
        <div class="task-foot">
          <span>${s.done}/${s.total} done · ${s.pct}%</span>
          <span>🔥 ${s.streakDays}d · 7-day ${s.rate7d}%</span>
        </div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelector('.task-addbtn').addEventListener('click', () => this._add());
    this.el.querySelector('.task-input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this._add();
    });
    this.el.querySelectorAll('.task-check').forEach((c) =>
      c.addEventListener('change', () => {
        c.checked ? this.tasks.complete(c.dataset.id) : this.tasks.uncomplete(c.dataset.id);
        this.onChange();
        this.render();
      })
    );
    this.el.querySelectorAll('[data-star]').forEach((b) =>
      b.addEventListener('click', () => { this.tasks.setMain(b.dataset.star); this.onChange(); this.render(); })
    );
    this.el.querySelectorAll('[data-del]').forEach((b) =>
      b.addEventListener('click', () => { this.tasks.remove(b.dataset.del); this.onChange(); this.render(); })
    );
  }
}
