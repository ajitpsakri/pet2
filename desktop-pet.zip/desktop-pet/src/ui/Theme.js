/**
 * ui/Theme.js
 * ----------------------------------------------------------------------------
 * Time-of-day ambiance for the dog: a soft glow colour behind it and a dynamic
 * shadow that lengthens toward evening. Returns plain values so it can be unit
 * tested; the renderer paints them. Kept subtle and localised so the overlay
 * never blocks the desktop.
 */

/** @returns {'morning'|'day'|'evening'|'night'} */
export function bucketForHour(h) {
  if (h >= 5 && h < 12) return 'morning';
  if (h >= 12 && h < 17) return 'day';
  if (h >= 17 && h < 22) return 'evening';
  return 'night';
}

const THEMES = {
  morning: { glow: '#ffe7a8', glowAlpha: 0.18, shadowScale: 1.1, shadowAlpha: 0.16 },
  day: { glow: '#ffffff', glowAlpha: 0.10, shadowScale: 0.9, shadowAlpha: 0.20 },
  evening: { glow: '#ffb37a', glowAlpha: 0.22, shadowScale: 1.45, shadowAlpha: 0.14 },
  night: { glow: '#9db4ff', glowAlpha: 0.20, shadowScale: 1.2, shadowAlpha: 0.12 },
};

/** Full theme for an hour (0–23). */
export function themeForHour(h) {
  const name = bucketForHour(h);
  return { name, ...THEMES[name] };
}

/** Convenience: theme for a Date (defaults to now). */
export function themeFor(date = new Date()) {
  return themeForHour(date.getHours());
}

/** '#rrggbb' + alpha -> 'rgba(r,g,b,a)' for canvas gradients. */
export function rgba(hex, alpha) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}
