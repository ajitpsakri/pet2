/**
 * ui/TimelinePanel.js
 * ----------------------------------------------------------------------------
 * Shows the companion's memory: lifetime totals up top, then a vertical
 * timeline of moments (newest first), grouped by day. Read-only and local.
 */

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function relDay(day, todayKey) {
  if (!day) return '';
  if (day === todayKey) return 'Today';
  // yesterday?
  const d = new Date(day + 'T00:00:00');
  const t = new Date(todayKey + 'T00:00:00');
  const diff = Math.round((t - d) / 86400000);
  if (diff === 1) return 'Yesterday';
  return day;
}

export class TimelinePanel {
  constructor(el, timeline, clock) {
    this.el = el;
    this.tl = timeline;
    this.clock = clock;
    this.visible = false;
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() { this.visible = false; this.el.classList.remove('show'); }
  toggle() { this.visible ? this.hide() : this.show(); }

  render() {
    const s = this.tl.status();
    const todayKey = this.clock ? this.clock.dayKey() : null;

    const stats = `
      <div class="tl-stats">
        <span class="chip">🎯 <b>${s.focus}</b> sprints</span>
        <span class="chip">✓ <b>${s.tasks}</b> tasks</span>
        <span class="chip">🃏 <b>${s.cards}</b> reviews</span>
        <span class="chip">🗂️ <b>${s.projects}</b> shipped</span>
        <span class="chip">📚 <b>${s.studyHours}</b>h studied</span>
        <span class="chip">💛 L<b>${s.friendship}</b></span>
      </div>`;

    let lastDay = null;
    const items = this.tl.list()
      .map((e) => {
        const label = relDay(e.day, todayKey);
        const header = e.day !== lastDay ? `<div class="tl-day">${esc(label)}</div>` : '';
        lastDay = e.day;
        return `${header}<div class="tl-item ${e.kind === 'milestone' ? 'big' : ''}"><span class="tl-dot"></span><span class="tl-text">${esc(e.text)}</span></div>`;
      })
      .join('');

    this.el.innerHTML = `
      <div class="panel-head">
        <h2>Timeline</h2>
        <button class="panel-close" data-close>✕</button>
      </div>
      <div class="panel-body">
        ${stats}
        <h3>Moments together <span class="ai-local">· ${s.moments}</span></h3>
        <div class="tl-list">${items || '<p class="task-empty">Your story starts now. Finish a focus sprint or a task to make the first memory. 🐾</p>'}</div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
  }
}
