/**
 * Toast.js
 * ----------------------------------------------------------------------------
 * Tiny, self-dismissing notifications for celebratory moments (level up,
 * achievement unlocked). Stacks at the bottom and never steals focus.
 */

export class Toast {
  /** @param {HTMLElement} container */
  constructor(container) {
    this.container = container;
  }

  show(icon, text, ms = 4000) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<span class="toast-icon">${icon}</span><span>${text}</span>`;
    this.container.appendChild(t);
    // Force reflow then animate in.
    requestAnimationFrame(() => t.classList.add('show'));
    setTimeout(() => {
      t.classList.remove('show');
      setTimeout(() => t.remove(), 400);
    }, ms);
  }
}
