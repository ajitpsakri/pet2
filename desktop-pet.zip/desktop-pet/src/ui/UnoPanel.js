/**
 * ui/UnoPanel.js
 * ----------------------------------------------------------------------------
 * The UNO table: your hand, the dog's face-down hand, the discard pile, a draw
 * pile, a wild colour picker, difficulty selection, and a running scoreline of
 * badges/streaks. Drives engine.js for rules and ai.js for the dog's moves, and
 * fires personality reactions (wag, surprised, disappointed, UNO!, win/lose)
 * back to the live dog via the injected onDogReact hook.
 */

import { newGame, play, drawAndPass, top, canPlay, legalMoves } from '../systems/uno/engine.js';
import { chooseMove } from '../systems/uno/ai.js';
import { BADGE_LABEL } from '../systems/uno/UnoSystem.js';

const GLYPH = { skip: '⊘', reverse: '⇄', draw2: '+2', wild: '★', wild4: '+4' };
const valueGlyph = (v) => GLYPH[v] || v;
const COLOR_NAME = { red: 'Red', yellow: 'Yellow', green: 'Green', blue: 'Blue' };

export class UnoPanel {
  constructor(el, uno, opts = {}) {
    this.el = el;
    this.uno = uno;
    this.onDogReact = opts.onDogReact || (() => {});
    this.requestSave = opts.requestSave || (() => {});
    this.visible = false;
    this.game = null;
    this.difficulty = 'medium';
    this.message = 'Your move!';
    this.busy = false;
    this.pendingWild = null;
    this.result = null; // { winner, fresh }
    this._timers = [];
  }

  show() { this.visible = true; this.el.classList.add('show'); this.render(); }
  hide() {
    this.visible = false;
    this.el.classList.remove('show');
    this._timers.forEach(clearTimeout);
    this._timers = [];
  }
  toggle() { this.visible ? this.hide() : this.show(); }

  // --- game flow ------------------------------------------------------------

  deal() {
    this.game = newGame();
    this.message = 'Your move!';
    this.result = null;
    this.pendingWild = null;
    this.busy = false;
    this.render();
  }

  _humanLegal() {
    if (!this.game) return [];
    return legalMoves(this.game.hands[0], this.game.currentColor, top(this.game).value);
  }

  onCardClick(idx) {
    if (!this.game || this.game.status !== 'playing' || this.game.turn !== 0 || this.busy) return;
    const c = this.game.hands[0][idx];
    if (!canPlay(c, this.game.currentColor, top(this.game).value)) {
      this.message = "Can't play that one.";
      this.render();
      return;
    }
    if (c.color === 'wild') { this.pendingWild = idx; this.render(); return; }
    this._humanPlay(idx);
  }

  chooseColor(col) {
    if (this.pendingWild == null) return;
    const idx = this.pendingWild;
    this.pendingWild = null;
    this._humanPlay(idx, col);
  }

  _humanPlay(idx, col) {
    const ev = play(this.game, 0, idx, col);
    if (ev.error) { this.render(); return; }
    if (ev.drew >= 4) this.onDogReact('surprised'); // hit by your Wild +4
    else if (ev.drew >= 2) this.onDogReact('disappointed'); // your Draw Two
    if (ev.win) return this._endGame(0);
    this.message = ev.skipped ? 'Nice — go again!' : 'Dog is thinking…';
    if (this.game.turn === 1) this._scheduleDog();
    this.render();
  }

  drawHuman() {
    if (!this.game || this.game.turn !== 0 || this.busy) return;
    drawAndPass(this.game, 0);
    this.message = 'Dog is thinking…';
    this._scheduleDog();
    this.render();
  }

  _scheduleDog() {
    this.busy = true;
    this._timers.push(setTimeout(() => this._dogStep(), 650));
  }

  _dogStep() {
    if (!this.game || this.game.status !== 'playing' || this.game.turn !== 1) { this.busy = false; this.render(); return; }
    const hand = this.game.hands[1];
    const mv = chooseMove(hand, this.game.currentColor, top(this.game).value, this.game.hands[0].length, this.difficulty);

    if (mv.type === 'draw') {
      drawAndPass(this.game, 1);
      this.onDogReact('think');
      this.message = 'Dog drew a card. Your move!';
    } else {
      const ev = play(this.game, 1, mv.index, mv.chosenColor);
      if (ev.win) { this.render(); return this._endGame(1); }
      if (ev.drew >= 4) { this.onDogReact('play'); this.message = 'Dog hit you with a Wild +4!'; }
      else if (ev.drew >= 2) { this.onDogReact('play'); this.message = 'Dog played Draw Two!'; }
      else { this.onDogReact('play'); this.message = 'Your move!'; }
      if (this.game.hands[1].length === 1) this.onDogReact('uno');
    }
    this.render();

    // Skip/draw/reverse let the dog go again — chain with a short delay.
    if (this.game.status === 'playing' && this.game.turn === 1) {
      this._timers.push(setTimeout(() => this._dogStep(), 650));
    } else {
      this.busy = false;
      this.render();
    }
  }

  _endGame(winner) {
    const humanColors = this.game.colorPlays[0];
    const { fresh } = this.uno.recordGame(winner, this.difficulty, humanColors);
    this.result = { winner, fresh };
    this.busy = false;
    this.onDogReact(winner === 1 ? 'win' : 'lose');
    this.requestSave();
    this.render();
  }

  // --- rendering ------------------------------------------------------------

  render() {
    if (!this.visible) return;
    if (!this.game || this.result) this._renderLobby();
    else this._renderTable();
  }

  _renderLobby() {
    const s = this.uno.status();
    const diffBtn = (id, label) =>
      `<button class="uno-diff ${this.difficulty === id ? 'on' : ''}" data-diff="${id}">${label}</button>`;
    const badges = s.badges.length
      ? s.badges.map((b) => `<span class="chip">${BADGE_LABEL[b] || b}</span>`).join('')
      : '<span class="ai-local">none yet — go win one!</span>';

    let banner = '';
    if (this.result) {
      const won = this.result.winner === 0;
      banner = `<div class="uno-banner ${won ? 'win' : 'lose'}">${won ? '🎉 You win!' : '🐶 The dog wins!'}</div>`;
      if (this.result.fresh && this.result.fresh.length) {
        banner += `<div class="uno-fresh">Unlocked: ${this.result.fresh.map((b) => BADGE_LABEL[b] || b).join(', ')}</div>`;
      }
    }

    this.el.innerHTML = `
      <div class="panel-head"><h2>UNO</h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body">
        ${banner}
        <div class="uno-stats">
          <span class="chip">🎴 <b>${s.gamesPlayed}</b> games</span>
          <span class="chip">🏆 <b>${s.wins}</b> wins</span>
          <span class="chip">🔥 streak <b>${s.streak}</b> (best ${s.longestStreak})</span>
          ${s.favoriteColor ? `<span class="chip uno-${s.favoriteColor}">fave: ${COLOR_NAME[s.favoriteColor]}</span>` : ''}
        </div>
        <h3>Difficulty</h3>
        <div class="uno-diffs">${diffBtn('easy', 'Easy')}${diffBtn('medium', 'Medium')}${diffBtn('smart', 'Smart Dog')}</div>
        <h3>Badges</h3>
        <div class="summary">${badges}</div>
        <div class="uno-actions"><button class="uno-deal">${this.result ? 'Play again' : 'Deal 🎴'}</button></div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('[data-diff]').forEach((b) =>
      b.addEventListener('click', () => { this.difficulty = b.dataset.diff; this.render(); }));
    this.el.querySelector('.uno-deal').addEventListener('click', () => this.deal());
  }

  _cardHtml(c, opts = {}) {
    const cls = c.color === 'wild' ? 'uno-wild' : `uno-${c.color}`;
    const playable = opts.playable ? ' playable' : '';
    const dim = opts.dim ? ' dim' : '';
    return `<div class="uno-card ${cls}${playable}${dim}" ${opts.idx != null ? `data-idx="${opts.idx}"` : ''}><span>${valueGlyph(c.value)}</span></div>`;
  }

  _renderTable() {
    const g = this.game;
    const legal = new Set(this._humanLegal());
    const myTurn = g.turn === 0 && !this.busy;

    const dogBacks = Array.from({ length: g.hands[1].length })
      .map(() => '<div class="uno-card uno-back"></div>').join('');

    const topCard = this._cardHtml(top(g));
    const colorDot = `<span class="uno-active uno-${g.currentColor}"></span>`;

    const myHand = g.hands[0]
      .map((c, i) => this._cardHtml(c, { idx: i, playable: myTurn && legal.has(i), dim: myTurn && !legal.has(i) }))
      .join('');

    const picker = this.pendingWild != null
      ? `<div class="uno-picker"><span>Pick a colour:</span>
           ${['red', 'yellow', 'green', 'blue'].map((c) => `<button class="uno-swatch uno-${c}" data-color="${c}"></button>`).join('')}
         </div>`
      : '';

    this.el.innerHTML = `
      <div class="panel-head"><h2>UNO <span class="ai-local">· ${this.difficulty}</span></h2><button class="panel-close" data-close>✕</button></div>
      <div class="panel-body uno-table">
        <div class="uno-row uno-dog"><span class="uno-label">🐶 Dog · ${g.hands[1].length} cards</span><div class="uno-hand backs">${dogBacks}</div></div>
        <div class="uno-mid">
          <div class="uno-pile"><span class="uno-label">Draw</span><button class="uno-card uno-back uno-draw" ${myTurn ? '' : 'disabled'}></button></div>
          <div class="uno-pile"><span class="uno-label">Discard ${colorDot}</span>${topCard}</div>
        </div>
        <div class="uno-msg">${this.message}</div>
        ${picker}
        <div class="uno-row uno-you"><span class="uno-label">🧑 You · ${g.hands[0].length} cards</span><div class="uno-hand">${myHand}</div></div>
      </div>`;

    this.el.querySelector('[data-close]').addEventListener('click', () => this.hide());
    this.el.querySelectorAll('.uno-hand [data-idx]').forEach((d) =>
      d.addEventListener('click', () => this.onCardClick(+d.dataset.idx)));
    const drawBtn = this.el.querySelector('.uno-draw');
    if (drawBtn) drawBtn.addEventListener('click', () => this.drawHuman());
    this.el.querySelectorAll('[data-color]').forEach((b) =>
      b.addEventListener('click', () => this.chooseColor(b.dataset.color)));
  }
}
