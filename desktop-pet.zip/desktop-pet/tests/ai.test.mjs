import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AIProvider, NullProvider } from '../src/services/ai/Provider.js';
import { AIService } from '../src/services/ai/AIService.js';

test('NullProvider is never available', async () => {
  assert.equal(await new NullProvider().available(), false);
});

test('AIProvider.complete throws by default (must be implemented)', async () => {
  await assert.rejects(() => new AIProvider().complete('hi'));
});

test('disabled service returns the fallback unchanged', async () => {
  const svc = new AIService(new NullProvider(), false);
  assert.equal(await svc.phrase('reword: hello', 'hello'), 'hello');
  assert.equal(await svc.available(), false);
});

test('enabled but unavailable provider still falls back', async () => {
  const provider = { available: async () => false, complete: async () => 'should not be used' };
  const svc = new AIService(provider, true);
  assert.equal(await svc.phrase('x', 'fallback'), 'fallback');
});

test('enabled + available provider returns the model text', async () => {
  const provider = { available: async () => true, complete: async () => '  Sip some water! ' };
  const svc = new AIService(provider, true);
  assert.equal(await svc.phrase('x', 'fallback'), 'Sip some water!');
});

test('empty model output falls back', async () => {
  const provider = { available: async () => true, complete: async () => '   ' };
  const svc = new AIService(provider, true);
  assert.equal(await svc.phrase('x', 'fallback'), 'fallback');
});

test('a throwing provider never breaks the caller', async () => {
  const provider = { available: async () => true, complete: async () => { throw new Error('model crashed'); } };
  const svc = new AIService(provider, true);
  assert.equal(await svc.phrase('x', 'safe'), 'safe');
});

test('the enabled flag can be a live function (settings-driven)', async () => {
  let on = false;
  const provider = { available: async () => true, complete: async () => 'AI line' };
  const svc = new AIService(provider, () => on);
  assert.equal(await svc.phrase('x', 'tpl'), 'tpl'); // off
  on = true;
  assert.equal(await svc.phrase('x', 'tpl'), 'AI line'); // on
});

test('generate() returns null when disabled (callers show a hint)', async () => {
  const svc = new AIService(new NullProvider(), false);
  assert.equal(await svc.generate('prompt'), null);
});

test('generate() returns model text when enabled and available', async () => {
  const provider = { available: async () => true, complete: async () => '  Try checking the NVIC.  ' };
  const svc = new AIService(provider, true);
  assert.equal(await svc.generate('prompt'), 'Try checking the NVIC.');
});

test('generate() returns null on empty output or error', async () => {
  const empty = new AIService({ available: async () => true, complete: async () => '   ' }, true);
  assert.equal(await empty.generate('p'), null);
  const boom = new AIService({ available: async () => true, complete: async () => { throw new Error('x'); } }, true);
  assert.equal(await boom.generate('p'), null);
});
