import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AICompanionSystem } from '../src/systems/ai/AICompanionSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const a = new AICompanionSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-06' } });
  a.init();
  return a;
}

test('add/remove memories with unique ids', () => {
  const a = boot();
  const m = a.addMemory('Learning ARM assembly');
  assert.ok(m && m.id);
  assert.equal(a.memories.length, 1);
  assert.equal(a.addMemory('   '), null); // empty ignored
  a.removeMemory(m.id);
  assert.equal(a.memories.length, 0);
});

test('transcript is capped and trims oldest', () => {
  const a = boot();
  for (let i = 0; i < 30; i++) a.pushTurn('user', `msg ${i}`);
  assert.ok(a.transcript.length <= 12);
  assert.equal(a.transcript[a.transcript.length - 1].text, 'msg 29');
});

test('buildPrompt includes persona, context, memories, and the user message', () => {
  const a = boot();
  a.addMemory('Working on a firmware bootloader');
  const stats = {
    timeBucket: 'morning',
    focusStreak: 3, focusMin: 25,
    tasksDone: 1, tasksTotal: 3, mainGoal: 'Fix UART driver',
    learnStreak: 5, learnMin: 20,
    nextTalk: { title: 'Team demo', days: 2 },
  };
  const p = a.buildPrompt('Why is my interrupt not firing?', stats);
  assert.match(p, /desk-dog companion/);
  assert.match(p, /morning/);
  assert.match(p, /Fix UART driver/);
  assert.match(p, /firmware bootloader/);
  assert.match(p, /Team demo/);
  assert.match(p, /User: Why is my interrupt not firing\?/);
  assert.ok(p.trimEnd().endsWith('Buddy:'));
});

test('buildPrompt works with no memories and minimal stats', () => {
  const a = boot();
  const p = a.buildPrompt('hello', {});
  assert.match(p, /User: hello/);
  assert.ok(p.trimEnd().endsWith('Buddy:'));
});

test('recent conversation is fed back into the prompt', () => {
  const a = boot();
  a.pushTurn('user', 'I prefer C over C++');
  a.pushTurn('assistant', 'Noted!');
  const p = a.buildPrompt('what did I say I prefer?', {});
  assert.match(p, /User: I prefer C over C\+\+/);
  assert.match(p, /Buddy: Noted!/);
});

test('relevant vault notes are woven into the prompt when provided', () => {
  const a = boot();
  const p = a.buildPrompt('explain NEON', {
    relevantNotes: [{ title: 'ARM NEON', body: 'SIMD intrinsics for parallel math' }],
  });
  assert.match(p, /Relevant notes from the user's vault/);
  assert.match(p, /ARM NEON: SIMD intrinsics/);
});

test('serialize/hydrate round-trips memories and transcript', () => {
  const a = boot();
  a.addMemory('keep me');
  a.pushTurn('user', 'hi');
  const slice = a.serialize();
  const b = new AICompanionSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-06' } });
  b.init();
  b.hydrate(slice);
  assert.equal(b.memories[0].text, 'keep me');
  assert.equal(b.transcript[0].text, 'hi');
  // ids keep advancing without collision
  const m = b.addMemory('another');
  assert.equal(b.memories.filter((x) => x.id === m.id).length, 1);
});
