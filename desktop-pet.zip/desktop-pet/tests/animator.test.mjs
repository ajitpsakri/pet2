import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Animator } from '../src/animations/Animator.js';

function run(a, dt, n, speed = 1) {
  for (let i = 0; i < n; i++) a.update(dt, speed);
}

test('play switches state; invalid/same names are ignored', () => {
  const a = new Animator();
  a.play('running');
  assert.equal(a.name, 'running');
  a.play('not-a-real-anim');
  assert.equal(a.name, 'running');
});

test('pose eases toward the target over time (no instant jump)', () => {
  const a = new Animator(); // starts idle, eyeOpen 1
  a.play('sad'); // sad eyeOpen 0.7, droop 0.7
  a.update(0.016, 1);
  // After one frame it has moved, but not all the way.
  assert.ok(a.pose.eyeOpen < 1 && a.pose.eyeOpen > 0.7);
  run(a, 0.016, 120);
  assert.ok(Math.abs(a.pose.eyeOpen - 0.7) < 0.02); // converged
  assert.ok(a.pose.droop > 0.6);
});

test('motion amplitude blends instead of snapping', () => {
  const a = new Animator(); // idle bob 2
  a.play('running'); // running bob 4
  a.update(0.016, 1);
  assert.ok(a.motion.bob > 2 && a.motion.bob < 4); // mid-blend, not snapped
  run(a, 0.016, 200);
  assert.ok(Math.abs(a.motion.bob - 4) < 0.1); // converged toward running
});

test('changing state never resets or jumps the cyclic phase', () => {
  const a = new Animator();
  run(a, 0.016, 20); // advance phase
  const p0 = a.phase;
  assert.ok(p0 > 0);
  a.play('running'); // switching state alone must not touch phase
  assert.equal(a.phase, p0);
  a.update(0.016, 1); // a frame advances it forward continuously
  assert.ok(a.phase > p0 || a.phase < p0); // moved (allowing wrap)
});

test('phase stays wrapped within [0, 2π)', () => {
  const a = new Animator();
  a.play('running'); // high frequency
  run(a, 0.05, 500);
  assert.ok(a.phase >= 0 && a.phase < Math.PI * 2 + 1e-9);
});

test('breathing is steady regardless of animation speed', () => {
  const a1 = new Animator();
  const a2 = new Animator();
  const seq = [0.016, 0.02, 0.018, 0.033, 0.016];
  for (const dt of seq) { a1.update(dt, 1); a2.update(dt, 4); }
  // breath depends only on real dt, not the speed multiplier
  assert.ok(Math.abs(a1.breath - a2.breath) < 1e-9);
  assert.ok(Math.abs(a1.breath) <= 0.025 + 1e-9);
});

test('hop is suppressed for non-hopping states', () => {
  const a = new Animator(); // idle: hop 0
  run(a, 0.016, 60);
  assert.equal(a.hopY, 0);
  a.play('jumping'); // hop 22
  run(a, 0.016, 120);
  assert.ok(a.hopY <= 0); // hopY is 0 or negative (upward)
  assert.ok(Math.abs(a.hopY) > 1); // actually hopping now
});

test('frame() exposes the keys sprites.js needs', () => {
  const a = new Animator();
  a.update(0.016, 1);
  const f = a.frame();
  for (const key of ['name', 'pose', 'bobY', 'hopY', 'legPhase', 'tailWag', 'breath', 'blink']) {
    assert.ok(key in f, `missing ${key}`);
  }
  assert.ok(f.blink >= 0 && f.blink <= 1);
});

test('outputs stay finite across a long varied run', () => {
  const a = new Animator();
  const states = ['idle', 'walking', 'running', 'happy', 'jumping', 'sleeping', 'bellyrub'];
  for (let i = 0; i < 400; i++) {
    if (i % 30 === 0) a.play(states[(i / 30) % states.length | 0]);
    a.update(0.016 + (i % 3) * 0.004, 1 + (i % 2));
  }
  for (const v of [a.bobY, a.hopY, a.legPhase, a.tailWag, a.breath, a.blink, a.phase]) {
    assert.ok(Number.isFinite(v));
  }
});
