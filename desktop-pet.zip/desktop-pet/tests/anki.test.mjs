import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AnkiSystem } from '../src/systems/habits/AnkiSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
function allowOnce() { let used = false; return { configure() {}, request() { if (used) return false; used = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  return { bus, clock, events };
}

test('markDone advances the streak and celebrates', () => {
  const { bus, clock, events } = boot();
  const a = new AnkiSystem({ bus, clock, nudge: { configure() {}, acted() {} } });
  a.init();
  assert.equal(a.markDone(), true);
  assert.equal(a.doneToday, true);
  assert.equal(a.streakDays, 1);
  assert.ok(events.some(([t]) => t === 'anki:done'));
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'anki'));
});

test('marking done twice in a day is a no-op', () => {
  const { bus, clock } = boot();
  const a = new AnkiSystem({ bus, clock, nudge: { configure() {}, acted() {} } });
  a.init();
  assert.equal(a.markDone(), true);
  assert.equal(a.markDone(), false);
  assert.equal(a.streakDays, 1);
});

test('tick emits a reminder when due and not done', () => {
  const { bus, clock, events } = boot();
  const a = new AnkiSystem({ bus, clock, nudge: allowOnce() });
  a.init();
  a.tick();
  assert.ok(events.some(([t, p]) => t === 'nudge' && p.category === 'anki'));
});

test('no reminder once done today', () => {
  const { bus, clock, events } = boot();
  const a = new AnkiSystem({ bus, clock, nudge: allowOnce() });
  a.init();
  a.markDone();
  events.length = 0;
  a.tick();
  assert.ok(!events.some(([t]) => t === 'nudge'));
});

test('a new day clears doneToday so reminders resume', () => {
  const { bus, clock } = boot('2026-06-06');
  const a = new AnkiSystem({ bus, clock, nudge: { configure() {}, request() { return false; }, acted() {} } });
  a.init();
  a.markDone();
  assert.equal(a.doneToday, true);
  clock.set('2026-06-07');
  a.tick();
  assert.equal(a.doneToday, false);
});

test('serialize/hydrate round-trips', () => {
  const { bus, clock } = boot();
  const a = new AnkiSystem({ bus, clock, nudge: { configure() {}, acted() {} } });
  a.init();
  a.markDone();
  const slice = a.serialize();
  const b = new AnkiSystem({ bus: new EventBus(), clock: fakeClock(), nudge: { configure() {} } });
  b.init();
  b.hydrate(slice);
  assert.equal(b.streakDays, 1);
  assert.equal(b.doneToday, true);
});
