import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  AttentionSystem,
  quietLevel,
  requiredPriority,
  categoryPriority,
  allowInterruption,
  interruptionScore,
} from '../src/systems/attention/AttentionSystem.js';
import { EventBus } from '../src/core/EventBus.js';

// --- pure logic -------------------------------------------------------------

test('quietLevel: available context is level 0', () => {
  assert.equal(quietLevel({}), 0);
});

test('quietLevel escalates: focus < deepWork/meeting < locked/away', () => {
  assert.equal(quietLevel({ focusRunning: true }), 1);
  assert.equal(quietLevel({ activeElsewhere: true }), 1);
  assert.equal(quietLevel({ deepWork: true }), 2);
  assert.equal(quietLevel({ meeting: true }), 2);
  assert.equal(quietLevel({ screenLocked: true }), 3);
  assert.equal(quietLevel({ idleSec: 9999 }), 3);
});

test('requiredPriority rises with quiet level', () => {
  assert.equal(requiredPriority(0), 0);
  assert.equal(requiredPriority(1), 1);
  assert.equal(requiredPriority(2), 2);
  assert.ok(requiredPriority(3) > 3);
});

test('health is critical, plan/learn are low priority', () => {
  assert.ok(categoryPriority('health') > categoryPriority('water'));
  assert.equal(categoryPriority('plan'), 0);
  assert.equal(categoryPriority('eye'), 2);
});

test('deep work blocks low/medium nudges but lets critical health through', () => {
  const s = { deepWork: true };
  assert.equal(allowInterruption(s, 'water'), false);
  assert.equal(allowInterruption(s, 'learn'), false);
  assert.equal(allowInterruption(s, 'eye'), true); // priority 2 >= required 2
  assert.equal(allowInterruption(s, 'health'), true);
});

test('focus sprint (level 1) allows medium reminders but not low', () => {
  const s = { focusRunning: true };
  assert.equal(allowInterruption(s, 'water'), true); // 1 >= 1
  assert.equal(allowInterruption(s, 'plan'), false); // 0 < 1
});

test('a locked screen blocks everything, even health', () => {
  const s = { screenLocked: true };
  assert.equal(allowInterruption(s, 'health'), false);
});

test('normal context allows everything', () => {
  assert.equal(allowInterruption({}, 'plan'), true);
  assert.equal(allowInterruption({}, 'health'), true);
});

test('interruptionScore drops with focus/meeting/lock', () => {
  assert.ok(interruptionScore({}) > interruptionScore({ focusRunning: true }));
  assert.ok(interruptionScore({ focusRunning: true }) > interruptionScore({ meeting: true }));
  assert.equal(interruptionScore({ screenLocked: true }), 0);
});

// --- system behavior --------------------------------------------------------

function boot() {
  const bus = new EventBus();
  const a = new AttentionSystem({ bus, clock: { dayKey: () => '2026-06-06' } });
  a.init();
  return { bus, a };
}

test('tracks our focus sprint via bus events', () => {
  const { bus, a } = boot();
  assert.equal(a.quiet, false);
  bus.emit('coding:focus:start', {});
  assert.equal(a.quiet, true);
  assert.equal(a.allow('plan'), false);
  bus.emit('coding:focus:done', {});
  assert.equal(a.quiet, false);
});

test('manual deep work + meeting toggles via bus and setters', () => {
  const { bus, a } = boot();
  bus.emit('attention:toggleDeepWork', {});
  assert.equal(a.deepWork, true);
  assert.equal(a.level, 2);
  a.setDeepWork(false);
  assert.equal(a.deepWork, false);
  bus.emit('attention:setMeeting', { on: true });
  assert.equal(a.meeting, true);
});

test('onSignal feeds coarse activity in; busy-elsewhere makes it quiet', () => {
  const { a } = boot();
  a.onSignal({ idleSec: 2, windowFocused: false, activeElsewhere: true, screenLocked: false });
  assert.equal(a.quiet, true);
  assert.equal(a.allow('learn'), false);
  assert.equal(a.allow('eye'), true); // high priority still allowed at level 1
});

test('status reports a human-readable reason', () => {
  const { a } = boot();
  a.setMeeting(true);
  assert.equal(a.status().reason, 'meeting');
  assert.equal(a.status().quiet, true);
});

test('quiet modes are transient (not persisted across launches)', () => {
  const { a } = boot();
  a.setDeepWork(true);
  assert.deepEqual(a.serialize(), {});
});

test('dispose unsubscribes (no further focus tracking)', () => {
  const { bus, a } = boot();
  a.dispose();
  bus.emit('coding:focus:start', {});
  assert.equal(a._focusRunning, false);
});
