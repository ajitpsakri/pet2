import { test } from 'node:test';
import assert from 'node:assert/strict';
import { niceMax, barLayout, linePoints } from '../src/ui/ChartKit.js';

test('niceMax rounds up to 1/2/5 x 10^n', () => {
  assert.equal(niceMax([3]), 5);
  assert.equal(niceMax([12]), 20);
  assert.equal(niceMax([47]), 50);
  assert.equal(niceMax([120]), 200);
  assert.equal(niceMax([]), 1); // floor default
});

test('barLayout fits bars within the box and scales to max', () => {
  const bars = barLayout([10, 20, 40], 100, 50, 4);
  assert.equal(bars.length, 3);
  // max -> niceMax(40) = 50; tallest bar = 40/50*50 = 40
  assert.equal(Math.round(bars[2].h), 40);
  // bars never exceed the height
  for (const b of bars) assert.ok(b.h <= 50 + 1e-9 && b.y >= -1e-9);
  // last bar ends at the right edge
  assert.ok(bars[2].x + bars[2].w <= 100 + 1e-9);
});

test('barLayout handles empty input', () => {
  assert.deepEqual(barLayout([], 100, 50), []);
});

test('linePoints spreads points across width, inverts y', () => {
  const pts = linePoints([0, 50, 100], 200, 100); // niceMax = 100
  assert.equal(pts.length, 3);
  assert.equal(pts[0].x, 0);
  assert.equal(pts[2].x, 200);
  assert.equal(Math.round(pts[0].y), 100); // value 0 -> bottom
  assert.equal(Math.round(pts[2].y), 0); // value 100 -> top
});

test('linePoints handles single value', () => {
  const pts = linePoints([5], 100, 50);
  assert.equal(pts.length, 1);
  assert.ok(pts[0].y >= 0 && pts[0].y <= 50);
});
