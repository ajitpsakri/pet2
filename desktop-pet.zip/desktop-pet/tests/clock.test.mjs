import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Clock } from '../src/core/Clock.js';

/** A controllable clock source. */
function fakeNow(start = 0) {
  let t = start;
  const fn = () => t;
  fn.set = (v) => { t = v; };
  fn.advance = (ms) => { t += ms; };
  return fn;
}

test('tick() returns elapsed seconds since last tick', () => {
  const now = fakeNow(1000);
  const c = new Clock(now, 10); // generous clamp so it doesn't interfere here
  now.advance(250);
  assert.equal(c.tick(), 0.25);
  now.advance(1000);
  assert.equal(c.tick(), 1);
});

test('tick() clamps large jumps to maxDt', () => {
  const now = fakeNow(0);
  const c = new Clock(now, 0.5);
  now.advance(10_000); // 10s real gap (e.g. tab was backgrounded)
  assert.equal(c.tick(), 0.5);
});

test('tick() never returns a negative dt', () => {
  const now = fakeNow(5000);
  const c = new Clock(now);
  now.set(0); // clock went backwards
  assert.equal(c.tick(), 0);
});

test('bucket() classifies the part of day', () => {
  const c = new Clock();
  const at = (h) => c.bucket(new Date(2026, 0, 5, h, 0, 0)); // Mon
  assert.equal(at(8), 'morning');
  assert.equal(at(11), 'morning');
  assert.equal(at(12), 'day');
  assert.equal(at(16), 'day');
  assert.equal(at(17), 'evening');
  assert.equal(at(21), 'evening');
  assert.equal(at(23), 'late');
  assert.equal(at(3), 'late');
});

test('isWeekend() is true Sat/Sun only', () => {
  const c = new Clock();
  assert.equal(c.isWeekend(new Date(2026, 0, 3)), true); // Sat
  assert.equal(c.isWeekend(new Date(2026, 0, 4)), true); // Sun
  assert.equal(c.isWeekend(new Date(2026, 0, 5)), false); // Mon
});

test('dayKey() is a stable YYYY-MM-DD', () => {
  const c = new Clock();
  assert.equal(c.dayKey(new Date(2026, 5, 6)), '2026-06-06');
  assert.equal(c.dayKey(new Date(2026, 11, 1)), '2026-12-01');
});

test('bucketChanged() reports only on transition', () => {
  const now = fakeNow(new Date(2026, 0, 5, 8).getTime()); // morning
  const c = new Clock(now);
  assert.equal(c.bucketChanged(), null); // same as constructor
  now.set(new Date(2026, 0, 5, 13).getTime()); // -> day
  assert.equal(c.bucketChanged(), 'day');
  assert.equal(c.bucketChanged(), null); // no further change
});
