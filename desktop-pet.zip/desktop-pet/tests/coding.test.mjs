import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CodingSystem } from '../src/systems/coding/CodingSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; } };

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const c = new CodingSystem({ bus, clock, nudge: noNudge });
  c.init();
  return { bus, clock, c, events };
}

test('startFocus enters a work phase and emits focus:start', () => {
  const { c, events } = boot();
  c.startFocus();
  assert.equal(c.running, true);
  assert.equal(c.phase, 'work');
  assert.ok(events.some(([t]) => t === 'coding:focus:start'));
});

test('work time accumulates while running', () => {
  const { c } = boot();
  c.startFocus();
  c.tick(60); // 1 minute
  assert.ok(c.todayFocusSec >= 60);
});

test('completing a work sprint emits done + celebrate and goes to break', () => {
  const { c, events } = boot();
  c.workLen = 2;
  c.startFocus();
  c.tick(2);
  assert.ok(events.some(([t]) => t === 'coding:focus:done'));
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'focus'));
  assert.equal(c.phase, 'break');
  assert.equal(c.sessionsToday, 1);
});

test('hitting the daily focus goal qualifies a streak', () => {
  const { c, events } = boot();
  c.startFocus();
  c.tick(1300); // > 20 min goal, sprint not yet finished
  assert.equal(c.streakDays, 1);
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'streak'));
});

test('a new day resets the daily counters', () => {
  const { c, clock } = boot('2026-06-06');
  c.startFocus();
  c.tick(120);
  assert.ok(c.todayFocusSec > 0);
  c.stopFocus();
  clock.set('2026-06-07');
  c.tick(1); // triggers rollover (not running, so no new accumulation)
  assert.equal(c.todayFocusSec, 0);
  assert.equal(c.sessionsToday, 0);
});

test('serialize/hydrate round-trips', () => {
  const { c } = boot();
  c.startFocus(); c.tick(1300);
  const slice = c.serialize();
  const c2 = new CodingSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  c2.init();
  c2.hydrate(slice);
  assert.equal(c2.streakDays, c.streakDays);
  assert.equal(c2.longestStreak, c.longestStreak);
});
