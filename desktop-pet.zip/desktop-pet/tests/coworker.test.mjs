import { test } from 'node:test';
import assert from 'node:assert/strict';
import { CoworkerSystem, shouldOfferBreak, suggestBreakGame } from '../src/systems/coworker/CoworkerSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const bus = new EventBus();
  const suggests = [];
  bus.on('coworker:suggest', (s) => suggests.push(s));
  return { bus, suggests, cw: new CoworkerSystem({ bus }) };
}

test('shouldOfferBreak respects threshold, quiet, and cooldown', () => {
  assert.equal(shouldOfferBreak(1, 2, false, true), false); // below threshold
  assert.equal(shouldOfferBreak(2, 2, false, true), true);
  assert.equal(shouldOfferBreak(2, 2, true, true), false); // quiet -> never
  assert.equal(shouldOfferBreak(2, 2, false, false), false); // cooldown not ready
});

test('suggestBreakGame picks by time of day and idle', () => {
  assert.equal(suggestBreakGame(13, 0).game, 'cricket'); // lunch
  assert.equal(suggestBreakGame(10, 120).game, 'fetch'); // idle/away
  assert.equal(suggestBreakGame(10, 0).game, 'uno'); // default
});

test('each sprint earns a treat', () => {
  const { cw } = boot();
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0 });
  assert.equal(cw.treats, 1);
  assert.equal(cw.sprintsTotal, 1);
});

test('a break is offered after the threshold and emits a suggestion', () => {
  const { cw, suggests } = boot();
  const r1 = cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 1000 });
  assert.equal(r1, null); // 1 sprint, below perBreak (2)
  const r2 = cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 2000 });
  assert.ok(r2 && r2.game === 'uno');
  assert.equal(suggests.length, 1);
});

test('no break is offered during quiet (deep work / meeting)', () => {
  const { cw, suggests } = boot();
  cw.afterSprint({ quiet: true, hour: 10, idleSec: 0, now: 1000 });
  cw.afterSprint({ quiet: true, hour: 10, idleSec: 0, now: 2000 });
  assert.equal(suggests.length, 0);
});

test('a fresh suggestion is held off by the cooldown', () => {
  const { cw, suggests } = boot();
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 1000 });
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 2000 }); // suggests (resets counter + cooldown)
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 3000 });
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 4000 }); // threshold again but within cooldown
  assert.equal(suggests.length, 1);
});

test('starting a break resets the sprint counter and counts the break', () => {
  const { cw } = boot();
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 1000 });
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 2000 });
  cw.startBreak('uno');
  assert.equal(cw.sprintsSinceBreak, 0);
  assert.equal(cw.breaksTaken, 1);
  assert.equal(cw.mode, 'break');
});

test('finishing a game is tallied', () => {
  const { cw } = boot();
  cw.recordGameOver();
  cw.recordGameOver();
  assert.equal(cw.gamesPlayed, 2);
  assert.equal(cw.mode, 'working');
});

test('serialize/hydrate round-trips the career tallies', () => {
  const { cw } = boot();
  cw.afterSprint({ quiet: false, hour: 10, idleSec: 0, now: 1000 });
  cw.startBreak('fetch');
  cw.recordGameOver();
  const slice = cw.serialize();
  const cw2 = new CoworkerSystem({ bus: new EventBus() });
  cw2.hydrate(slice);
  assert.equal(cw2.treats, cw.treats);
  assert.equal(cw2.breaksTaken, 1);
  assert.equal(cw2.gamesPlayed, 1);
});
