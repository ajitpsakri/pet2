import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  makeRng, timingQuality, resolveBall, dogBat, deliveryPenalty,
  newInnings, applyBall, inningsOver, oversText, MODES,
} from '../src/systems/cricket/engine.js';
import { CricketSystem, trophiesFor } from '../src/systems/cricket/CricketSystem.js';
import { EventBus } from '../src/core/EventBus.js';

// Run a shot many times and tally outcomes (seeded for reproducibility).
function tally(shot, timing, fieldSkill, n = 800, seed = 1) {
  const rng = makeRng(seed);
  const t = { out: 0, six: 0, four: 0, runs: 0, drop: 0, dive: 0 };
  for (let i = 0; i < n; i++) {
    const o = resolveBall(shot, timing, fieldSkill, rng);
    if (o.out) t.out++;
    if (o.six) t.six++;
    if (o.runs === 4) t.four++;
    if (o.fielding === 'drop') t.drop++;
    if (o.fielding === 'dive') t.dive++;
    t.runs += o.runs;
  }
  return t;
}

test('timingQuality peaks at 0.5 and bottoms at the extremes', () => {
  assert.equal(timingQuality(0.5), 1);
  assert.equal(timingQuality(0), 0);
  assert.equal(timingQuality(1), 0);
  assert.ok(timingQuality(0.4) > 0.5);
});

test('a perfectly-timed defend almost never gets out and never sixes', () => {
  const t = tally('defend', 0.5, 0.5);
  assert.ok(t.out < 40); // <5%
  assert.equal(t.six, 0);
});

test('a perfectly-timed loft scores boundaries often', () => {
  const t = tally('loft', 0.5, 0.5);
  assert.ok(t.six + t.four > 400); // >50% boundaries
  assert.ok(t.six > 0);
});

test('a badly-timed loft gets out frequently', () => {
  const t = tally('loft', 0.02, 0.6);
  assert.ok(t.out > 280); // >35%
});

test('weaker fielding drops more catches than strong fielding', () => {
  const weak = tally('loft', 0.1, 0.15);
  const strong = tally('loft', 0.1, 0.95);
  assert.ok(weak.drop > strong.drop);
  assert.ok(strong.dive >= weak.dive); // strong side dives more
});

test('even strong fielding still drops the occasional easy chance', () => {
  const strong = tally('drive', 0.1, 0.95, 1500);
  assert.ok(strong.drop > 0); // "miss easy catches occasionally"
});

test('deliveries throw off timing, skill mitigates', () => {
  assert.equal(deliveryPenalty('normal'), 0);
  assert.ok(deliveryPenalty('yorker', 0) > deliveryPenalty('yorker', 1));
  assert.ok(deliveryPenalty('bouncer', 0.5) > 0);
});

test('dogBat returns a valid shot and timing in range', () => {
  const rng = makeRng(7);
  for (let i = 0; i < 50; i++) {
    const m = dogBat(0.6, rng, 0.3);
    assert.ok(['defend', 'push', 'drive', 'loft'].includes(m.shot));
    assert.ok(m.timing >= 0 && m.timing <= 1);
  }
});

test('a skilled dog times the ball better on average', () => {
  const rng = makeRng(3);
  let lowErr = 0;
  let highErr = 0;
  for (let i = 0; i < 500; i++) lowErr += Math.abs(dogBat(0.1, rng).timing - 0.5);
  for (let i = 0; i < 500; i++) highErr += Math.abs(dogBat(0.95, rng).timing - 0.5);
  assert.ok(highErr < lowErr); // higher skill -> closer to perfect timing
});

test('innings ends when wickets are used up', () => {
  const inn = newInnings({ overs: 5, wicketsAllowed: 2 });
  applyBall(inn, { runs: 4, out: false });
  applyBall(inn, { runs: 0, out: true });
  assert.equal(inn.done, false);
  applyBall(inn, { runs: 0, out: true });
  assert.equal(inn.done, true);
  assert.equal(inn.result, 'allout');
  assert.equal(inn.runs, 4);
  assert.equal(inn.wickets, 2);
});

test('innings ends when overs run out', () => {
  const inn = newInnings({ overs: 1, wicketsAllowed: 5 });
  for (let i = 0; i < 6; i++) applyBall(inn, { runs: 1, out: false });
  assert.equal(inn.done, true);
  assert.equal(inn.result, 'overs');
  assert.equal(inn.runs, 6);
  assert.equal(oversText(inn.balls), '1.0');
});

test('a chase ends as soon as the target is overhauled', () => {
  const inn = newInnings({ overs: 5, wicketsAllowed: 5, target: 5 });
  applyBall(inn, { runs: 4, out: false });
  assert.equal(inn.done, false);
  applyBall(inn, { runs: 2, out: false });
  assert.equal(inn.done, true);
  assert.equal(inn.result, 'chased');
});

test('best partnership tracks the largest unbroken stand', () => {
  const inn = newInnings({ overs: 10, wicketsAllowed: 5 });
  applyBall(inn, { runs: 4, out: false });
  applyBall(inn, { runs: 6, out: false }); // partnership 10
  applyBall(inn, { runs: 0, out: true });
  applyBall(inn, { runs: 2, out: false }); // partnership 2
  assert.equal(inn.bestPartnership, 10);
});

test('MODES presets exist for the three modes', () => {
  assert.ok(MODES.quick && MODES.nets && MODES.challenge);
  assert.ok(MODES.challenge.dogSkill > MODES.quick.dogSkill);
});

// --- system ----------------------------------------------------------------

function sys() {
  const bus = new EventBus();
  const events = [];
  bus.on('celebrate', (p) => events.push(['celebrate', p]));
  bus.on('cricket:trophy', (p) => events.push(['trophy', p]));
  return { bus, events, c: new CricketSystem({ bus }) };
}

test('recording a win updates career stats and grants first-win trophy + XP', () => {
  const { c, events } = sys();
  c.recordMatch({ mode: 'quick', won: true, batRuns: 24, wicketsTaken: 2, bestPartnership: 18 });
  assert.equal(c.matches, 1);
  assert.equal(c.wins, 1);
  assert.equal(c.careerRuns, 24);
  assert.equal(c.wickets, 2);
  assert.equal(c.highScore, 24);
  assert.equal(c.bestPartnership, 18);
  assert.ok(c.trophies.includes('first_win'));
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'cricket' && p.xp > 0));
  assert.ok(events.some(([t]) => t === 'trophy'));
});

test('a half-century unlocks the fifty trophy', () => {
  const { c } = sys();
  c.recordMatch({ mode: 'nets', won: false, batRuns: 63, wicketsTaken: 0, bestPartnership: 63 });
  assert.ok(c.trophies.includes('fifty'));
  assert.equal(c.highScore, 63);
});

test('three Challenge wins crowns the DPL champion', () => {
  const { c } = sys();
  for (let i = 0; i < 3; i++) c.recordMatch({ mode: 'challenge', won: true, batRuns: 30, wicketsTaken: 2, bestPartnership: 20 });
  assert.equal(c.dplWins, 3);
  assert.ok(c.trophies.includes('dpl_champion'));
});

test('sixes accumulate and emit a celebration', () => {
  const { c, events } = sys();
  c.noteSix();
  c.noteSix();
  assert.equal(c.sixes, 2);
  assert.ok(events.filter(([t, p]) => t === 'celebrate' && p.kind === 'six').length === 2);
});

test('dog skill grows with matches but stays capped', () => {
  const { c } = sys();
  assert.equal(c.currentDogSkill(0.45), 0.45);
  c.matches = 30;
  assert.ok(c.currentDogSkill(0.45) > 0.45);
  assert.ok(c.currentDogSkill(0.9) <= 0.95);
});

test('serialize/hydrate round-trips the career', () => {
  const { c } = sys();
  c.recordMatch({ mode: 'challenge', won: true, batRuns: 55, wicketsTaken: 3, bestPartnership: 40 });
  c.noteSix();
  const slice = c.serialize();
  const c2 = new CricketSystem({ bus: new EventBus() });
  c2.hydrate(slice);
  assert.equal(c2.careerRuns, 55);
  assert.equal(c2.wickets, 3);
  assert.equal(c2.sixes, 1);
  assert.deepEqual(c2.trophies, c.trophies);
});

test('trophiesFor is pure and matches stat thresholds', () => {
  assert.deepEqual(trophiesFor({ wins: 0, highScore: 0, sixes: 0, wickets: 0, dplWins: 0, matches: 0 }), []);
  assert.ok(trophiesFor({ wins: 1, highScore: 50, sixes: 10, wickets: 10, dplWins: 3, matches: 25 }).length === 6);
});
