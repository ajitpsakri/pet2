import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Diagnostics, SnapshotRing } from '../src/services/Diagnostics.js';
import { EventBus } from '../src/core/EventBus.js';

test('SnapshotRing keeps newest-first and respects capacity', () => {
  const r = new SnapshotRing(3);
  r.push({ n: 1 }, 1);
  r.push({ n: 2 }, 2);
  r.push({ n: 3 }, 3);
  r.push({ n: 4 }, 4); // evicts n:1
  assert.equal(r.size, 3);
  assert.equal(r.list()[0].state.n, 4); // newest first
  assert.equal(r.latest().state.n, 4);
  assert.ok(!r.items.some((i) => i.state.n === 1));
});

test('Diagnostics tallies bus events by type', () => {
  const bus = new EventBus();
  const d = new Diagnostics({ bus });
  bus.emit('task:done', {});
  bus.emit('task:done', {});
  bus.emit('coding:focus:done', {});
  const r = d.report();
  assert.equal(r.events, 3);
  assert.equal(d.events.byType['task:done'], 2);
  assert.equal(r.topEvents[0].type, 'task:done'); // most frequent first
});

test('recordFrame samples FPS over the window', () => {
  const d = new Diagnostics({});
  const t0 = Date.now();
  for (let i = 0; i < 30; i++) d.recordFrame(t0 + i * 10); // 30 frames over ~300ms
  d.recordFrame(t0 + 600); // crosses the 500ms window -> sample
  assert.ok(d.fps > 0);
});

test('noteSave and noteError are reflected in the report', () => {
  const d = new Diagnostics({});
  assert.equal(d.report().lastSave.ok, null);
  d.noteSave(true);
  assert.equal(d.report().lastSave.ok, true);
  d.noteError('boom');
  assert.equal(d.report().lastError.msg, 'boom');
});

test('setPlugins and setSystemsCount surface in the report', () => {
  const d = new Diagnostics({});
  d.setPlugins({ loaded: [{}, {}], failed: [{}] });
  d.setSystemsCount(14);
  const r = d.report();
  assert.equal(r.plugins.loaded, 2);
  assert.equal(r.plugins.failed, 1);
  assert.equal(r.systems, 14);
});

test('captureSnapshot deep-copies so later mutation does not change history', () => {
  const d = new Diagnostics({});
  const state = { systems: { pet: { hp: 10 } } };
  d.captureSnapshot(state);
  state.systems.pet.hp = 999; // mutate after capture
  assert.equal(d.snapshots.latest().state.systems.pet.hp, 10);
});

test('captureSnapshot ignores non-serializable input without throwing', () => {
  const d = new Diagnostics({});
  const circular = {};
  circular.self = circular;
  assert.doesNotThrow(() => d.captureSnapshot(circular));
  assert.equal(d.snapshots.size, 0);
});

test('eventsPerMin is computed from uptime', () => {
  const d = new Diagnostics({});
  d.events.total = 120;
  d.start = Date.now() - 60000; // 1 minute ago
  assert.ok(d.report().eventsPerMin >= 100); // ~120/min
});
