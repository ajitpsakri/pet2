import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DialogueService } from '../src/services/DialogueService.js';

test('returns a string for a known context', () => {
  const d = new DialogueService(() => 0);
  const line = d.pick('anki_due');
  assert.equal(typeof line, 'string');
  assert.ok(line.length > 0);
});

test('unknown context returns null', () => {
  const d = new DialogueService(() => 0);
  assert.equal(d.pick('nope'), null);
});

test('friendship gates higher-tier lines', () => {
  // Force selection of the LAST eligible line by returning ~1 from rng.
  const d = new DialogueService(() => 0.999);
  const low = d.pick('focus_done', { friendship: 0 });
  const high = d.pick('focus_done', { friendship: 3 });
  // At friendship 3 the gated ("min:3") line becomes reachable; at 0 it isn't.
  assert.ok(low !== null && high !== null);
  assert.notEqual(high, undefined);
});

test('{n} placeholder is filled', () => {
  const d = new DialogueService(() => 0);
  const line = d.pick('streak', { n: 7 });
  assert.ok(line.includes('7'));
});

test('{n} is emptied when not provided', () => {
  const d = new DialogueService(() => 0);
  const line = d.pick('levelup');
  assert.ok(!line.includes('{n}'));
});
