import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus } from '../src/core/EventBus.js';

test('delivers events to subscribers with payload and type', () => {
  const bus = new EventBus();
  const seen = [];
  bus.on('hi', (p, t) => seen.push([p, t]));
  bus.emit('hi', 42);
  assert.deepEqual(seen, [[42, 'hi']]);
});

test('on() returns a working unsubscribe', () => {
  const bus = new EventBus();
  let n = 0;
  const off = bus.on('x', () => n++);
  bus.emit('x');
  off();
  bus.emit('x');
  assert.equal(n, 1);
});

test('once() fires exactly one time', () => {
  const bus = new EventBus();
  let n = 0;
  bus.once('x', () => n++);
  bus.emit('x');
  bus.emit('x');
  assert.equal(n, 1);
});

test('wildcard listener receives every event', () => {
  const bus = new EventBus();
  const types = [];
  bus.on('*', (_p, t) => types.push(t));
  bus.emit('a');
  bus.emit('b', 1);
  assert.deepEqual(types, ['a', 'b']);
});

test('a throwing handler does not stop the others', () => {
  const bus = new EventBus();
  let reached = false;
  bus.on('x', () => { throw new Error('boom'); });
  bus.on('x', () => { reached = true; });
  bus.emit('x'); // must not throw
  assert.equal(reached, true);
});

test('unsubscribing during emit is safe (snapshot dispatch)', () => {
  const bus = new EventBus();
  const order = [];
  const offA = bus.on('x', () => { order.push('a'); offA(); });
  bus.on('x', () => order.push('b'));
  bus.emit('x');
  bus.emit('x');
  assert.deepEqual(order, ['a', 'b', 'b']);
});

test('clear() removes all listeners', () => {
  const bus = new EventBus();
  let n = 0;
  bus.on('x', () => n++);
  bus.clear();
  bus.emit('x');
  assert.equal(n, 0);
});

test('on() rejects a non-function handler', () => {
  const bus = new EventBus();
  assert.throws(() => bus.on('x', 123), TypeError);
});
