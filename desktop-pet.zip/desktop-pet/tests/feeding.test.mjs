import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FeedingSystem, MEALS, mealForHour } from '../src/systems/feeding/FeedingSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot(day = '2026-06-08') {
  const bus = new EventBus();
  const events = [];
  bus.on('feeding:meal', (p) => events.push(['meal', p]));
  bus.on('celebrate', (p) => events.push(['celebrate', p]));
  let today = day;
  const clock = { dayKey: () => today };
  const f = new FeedingSystem({ bus, clock });
  return { bus, events, f, setDay: (d) => { today = d; } };
}

test('there are exactly three meals', () => {
  assert.deepEqual(MEALS, ['breakfast', 'lunch', 'dinner']);
});

test('mealForHour picks a sensible default', () => {
  assert.equal(mealForHour(8), 'breakfast');
  assert.equal(mealForHour(13), 'lunch');
  assert.equal(mealForHour(19), 'dinner');
});

test('each meal can be given once per day', () => {
  const { f } = boot();
  assert.equal(f.canFeed('breakfast'), true);
  assert.equal(f.feed('breakfast'), true);
  assert.equal(f.canFeed('breakfast'), false);
  assert.equal(f.feed('breakfast'), false); // already given
});

test('feeding emits a meal event and a celebration', () => {
  const { f, events } = boot();
  f.feed('lunch');
  assert.ok(events.some(([t, p]) => t === 'meal' && p.meal === 'lunch'));
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'meal'));
});

test('invalid meals are rejected', () => {
  const { f } = boot();
  assert.equal(f.feed('brunch'), false);
});

test('the next day resets all meals', () => {
  const { f, setDay } = boot('2026-06-08');
  f.feed('breakfast'); f.feed('lunch'); f.feed('dinner');
  assert.equal(f.status().remaining, 0);
  setDay('2026-06-09');
  const s = f.status();
  assert.equal(s.remaining, 3);
  assert.equal(s.breakfast, false);
});

test('totalMeals accumulates across days', () => {
  const { f, setDay } = boot('2026-06-08');
  f.feed('breakfast');
  setDay('2026-06-09');
  f.feed('breakfast');
  assert.equal(f.totalMeals, 2);
});

test('status reports which meals are done today', () => {
  const { f } = boot();
  f.feed('breakfast');
  const s = f.status();
  assert.equal(s.breakfast, true);
  assert.equal(s.lunch, false);
  assert.equal(s.remaining, 2);
});

test('serialize/hydrate round-trips the day and meals', () => {
  const { f } = boot('2026-06-08');
  f.feed('breakfast');
  const slice = f.serialize();
  const f2 = new FeedingSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-08' } });
  f2.hydrate(slice);
  assert.equal(f2.canFeed('breakfast'), false);
  assert.equal(f2.totalMeals, 1);
});
