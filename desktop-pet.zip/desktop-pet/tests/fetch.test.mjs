import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FetchSystem, reactionFor, stepStick } from '../src/systems/fetch/FetchSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const bus = new EventBus();
  const celebrations = [];
  const caught = [];
  bus.on('celebrate', (p) => celebrations.push(p));
  bus.on('fetch:caught', (p) => caught.push(p));
  const f = new FetchSystem({ bus });
  return { bus, f, celebrations, caught };
}

// Drive a throw to completion with a dog that always moves onto the target.
function playOnce(f, mood = 'excited', energy = 100) {
  f.throwStick({ x: 100, y: 100 }, { x: 500, y: 0 }, mood, energy);
  let dog = { x: 100, y: 100 };
  let guard = 0;
  while (f.active && guard++ < 5000) {
    const g = f.update(0.05, dog);
    if (g.target) dog = { x: g.target.x, y: g.target.y }; // teleport onto target
  }
  return f;
}

test('reactionFor maps moods/energy to chase behaviour', () => {
  assert.equal(reactionFor('sleeping', 100).chase, false);
  assert.equal(reactionFor('sick', 100).chase, false);
  assert.equal(reactionFor('happy', 10).chase, false); // too low energy
  assert.equal(reactionFor('excited', 100).speedMult, 1.6);
  assert.equal(reactionFor('happy', 100).speedMult, 1.15);
  const sad = reactionFor('sad', 100);
  assert.equal(sad.speedMult, 0.7);
  assert.ok(sad.delaySec > 0);
  const sleepy = reactionFor('content', 40); // neutral mood, low energy
  assert.ok(sleepy.speedMult < 1);
  assert.ok(sleepy.delaySec >= 1.0);
  assert.equal(reactionFor('content', 100).speedMult, 1.0);
});

test('stepStick decelerates and eventually lands', () => {
  const stick = { x: 0, y: 0, vx: 600, vy: 0, spin: 0 };
  let landed = false;
  let guard = 0;
  while (!landed && guard++ < 1000) landed = stepStick(stick, 0.05);
  assert.equal(landed, true);
  assert.ok(stick.x > 0); // it moved
  assert.equal(stick.vx, 0); // came to rest
});

test('a full happy fetch completes and rewards', () => {
  const { f, celebrations, caught } = boot();
  playOnce(f, 'excited', 100);
  assert.equal(f.state, 'idle');
  assert.equal(f.fetches, 1);
  assert.equal(f.throws, 1);
  assert.equal(f.streak, 1);
  assert.equal(caught.length, 1);
  assert.ok(celebrations.some((c) => c.kind === 'fetch'));
});

test('best throw distance is recorded', () => {
  const { f } = boot();
  playOnce(f, 'excited', 100);
  assert.ok(f.bestPx > 0);
});

test('streak grows across successive fetches', () => {
  const { f } = boot();
  playOnce(f, 'excited', 100);
  playOnce(f, 'excited', 100);
  playOnce(f, 'excited', 100);
  assert.equal(f.fetches, 3);
  assert.equal(f.streak, 3);
  assert.equal(f.longestStreak, 3);
});

test('a tired dog ignores the throw (no fetch, counts as ignored)', () => {
  const { f, caught } = boot();
  playOnce(f, 'happy', 8); // energy too low -> chase:false
  assert.equal(f.state, 'idle');
  assert.equal(f.fetches, 0);
  assert.equal(f.ignored, 1);
  assert.equal(caught.length, 0);
});

test('the stick is "carried" (rides the dog) while returning', () => {
  const { f } = boot();
  f.throwStick({ x: 100, y: 100 }, { x: 500, y: 0 }, 'excited', 100);
  let dog = { x: 100, y: 100 };
  let sawCarry = false;
  let guard = 0;
  while (f.active && guard++ < 5000) {
    const g = f.update(0.05, dog);
    if (g.carrying) {
      sawCarry = true;
      // stick should track the dog's mouth while carried
      assert.ok(Math.abs(f.stick.x - dog.x) < 1.0);
    }
    if (g.target) dog = { x: g.target.x, y: g.target.y };
  }
  assert.equal(sawCarry, true);
});

test('throw speed is clamped', () => {
  const { f } = boot();
  f.throwStick({ x: 0, y: 0 }, { x: 9999, y: 0 }, 'excited', 100);
  assert.ok(Math.hypot(f.stick.vx, f.stick.vy) <= 1100 + 1e-6);
});

test('cancel resets runtime without losing stats', () => {
  const { f } = boot();
  playOnce(f, 'excited', 100);
  f.throwStick({ x: 0, y: 0 }, { x: 400, y: 0 }, 'excited', 100);
  assert.equal(f.active, true);
  f.cancel();
  assert.equal(f.active, false);
  assert.equal(f.fetches, 1); // stat preserved
});

test('serialize/hydrate round-trips stats only', () => {
  const { f } = boot();
  playOnce(f, 'excited', 100);
  const slice = f.serialize();
  const f2 = new FetchSystem({ bus: new EventBus() });
  f2.hydrate(slice);
  assert.equal(f2.fetches, 1);
  assert.equal(f2.throws, 1);
  assert.equal(f2.state, 'idle'); // runtime not restored
});
