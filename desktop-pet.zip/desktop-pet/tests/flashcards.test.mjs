import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FlashcardSystem, schedule, addDays, GRADES } from '../src/systems/flashcards/FlashcardSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const fc = new FlashcardSystem({ bus, clock, nudge: noNudge });
  fc.init();
  return { bus, clock, events, fc };
}

// --- pure scheduler ---------------------------------------------------------

test('addDays advances ISO date keys', () => {
  assert.equal(addDays('2026-06-06', 1), '2026-06-07');
  assert.equal(addDays('2026-06-30', 1), '2026-07-01');
  assert.equal(addDays('2026-06-06', 0), '2026-06-06');
});

test('good grade graduates 0 -> 1 -> 6 -> interval*ease', () => {
  let c = { ease: 2.5, intervalDays: 0, reps: 0 };
  c = { ...c, ...schedule(c, 'good', '2026-06-06') };
  assert.equal(c.intervalDays, 1);
  c = { ...c, ...schedule(c, 'good', '2026-06-07') };
  assert.equal(c.intervalDays, 6);
  c = { ...c, ...schedule(c, 'good', '2026-06-13') };
  assert.equal(c.intervalDays, Math.round(6 * 2.5));
});

test('again resets reps, lowers ease, keeps card due today', () => {
  const c = { ease: 2.5, intervalDays: 30, reps: 5 };
  const r = schedule(c, 'again', '2026-06-06');
  assert.equal(r.reps, 0);
  assert.equal(r.intervalDays, 0);
  assert.equal(r.due, '2026-06-06');
  assert.ok(r.ease < 2.5);
  assert.equal(r.lapses, 1);
});

test('ease never drops below 1.3', () => {
  let c = { ease: 1.4, intervalDays: 1, reps: 1 };
  for (let i = 0; i < 5; i++) c = { ...c, ...schedule(c, 'again', '2026-06-06') };
  assert.ok(c.ease >= 1.3);
});

test('easy grows faster than good', () => {
  const base = { ease: 2.5, intervalDays: 10, reps: 3 };
  const good = schedule(base, 'good', '2026-06-06');
  const easy = schedule(base, 'easy', '2026-06-06');
  assert.ok(easy.intervalDays > good.intervalDays);
});

// --- system -----------------------------------------------------------------

test('new cards are due immediately', () => {
  const { fc } = boot('2026-06-06');
  fc.addCard('Q', 'A');
  assert.equal(fc.dueCards().length, 1);
  assert.equal(fc.nextDue().front, 'Q');
});

test('rejects cards missing a side', () => {
  const { fc } = boot();
  assert.equal(fc.addCard('only front', ''), null);
  assert.equal(fc.cards.length, 0);
});

test('reviewing good pushes the card out of today\'s queue', () => {
  const { fc } = boot('2026-06-06');
  const c = fc.addCard('Q', 'A');
  fc.review(c.id, 'good'); // interval 1 -> due tomorrow
  assert.equal(fc.dueCards().length, 0);
  assert.equal(fc.cards[0].due, '2026-06-07');
});

test('first review of the day starts a streak and celebrates', () => {
  const { fc, events } = boot('2026-06-06');
  const c = fc.addCard('Q', 'A');
  fc.review(c.id, 'good');
  assert.equal(fc.streakDays, 1);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'cards'));
});

test('streak continues across consecutive review days', () => {
  const { fc, clock } = boot('2026-06-06');
  const a = fc.addCard('Q1', 'A1');
  fc.review(a.id, 'again'); // stays due today, counts as a review day
  clock.set('2026-06-07');
  const b = fc.addCard('Q2', 'A2');
  fc.review(b.id, 'good');
  assert.equal(fc.streakDays, 2);
});

test('reviewedToday resets on a new day', () => {
  const { fc, clock } = boot('2026-06-06');
  const c = fc.addCard('Q', 'A');
  fc.review(c.id, 'again');
  assert.equal(fc.reviewedToday, 1);
  clock.set('2026-06-07');
  fc.tick(); // triggers rollover
  assert.equal(fc.reviewedToday, 0);
});

test('a due card nudges once when nothing reviewed yet', () => {
  const { fc, events } = boot('2026-06-06');
  fc.ctx.nudge = allowOnce();
  fc.addCard('Q', 'A');
  fc.tick();
  assert.ok(events.some(([e, p]) => e === 'nudge' && p.category === 'cards'));
});

test('no nudge once something has been reviewed today', () => {
  const { fc, events } = boot('2026-06-06');
  fc.ctx.nudge = allowOnce();
  const c = fc.addCard('Q', 'A');
  fc.review(c.id, 'good');
  events.length = 0;
  fc.tick();
  assert.ok(!events.some(([e]) => e === 'nudge'));
});

test('serialize/hydrate round-trips cards and scheduling', () => {
  const { fc } = boot('2026-06-06');
  const c = fc.addCard('Q', 'A', 'embedded');
  fc.review(c.id, 'good');
  const slice = fc.serialize();
  const fc2 = new FlashcardSystem({ bus: new EventBus(), clock: fakeClock('2026-06-06'), nudge: noNudge });
  fc2.init();
  fc2.hydrate(slice);
  assert.equal(fc2.cards[0].deck, 'embedded');
  assert.equal(fc2.cards[0].due, '2026-06-07');
  assert.equal(fc2.streakDays, 1);
});

test('GRADES are the four expected buttons', () => {
  assert.deepEqual(GRADES, ['again', 'hard', 'good', 'easy']);
});
