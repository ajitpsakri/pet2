import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Plugin, manifest } from '../src/plugins/habit-tracker/plugin.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const p = new Plugin({ manifest, bus, clock, nudge: noNudge });
  p.init();
  return { bus, clock, events, p };
}

test('manifest declares only the capabilities it uses', () => {
  assert.deepEqual([...manifest.permissions].sort(), ['celebrate', 'clock', 'menu', 'nudge']);
  assert.equal(manifest.apiVersion, 1);
  assert.equal(Plugin.id, manifest.id);
});

test('marking done advances the streak and celebrates', () => {
  const { p, events } = boot();
  assert.equal(p.markDone(), true);
  assert.equal(p.streakDays, 1);
  assert.ok(events.some(([e]) => e === 'celebrate'));
  assert.ok(events.some(([e]) => e === 'plugin:habit-tracker:completed'));
});

test('done is idempotent within a day', () => {
  const { p } = boot();
  p.markDone();
  assert.equal(p.markDone(), false);
  assert.equal(p.streakDays, 1);
});

test('the menu button event triggers completion', () => {
  const { bus, p } = boot();
  bus.emit('plugin:habit-tracker:done', {}); // what the renderer emits on tap
  assert.equal(p.doneToday, true);
});

test('reminder nudge fires when not done', () => {
  const bus = new EventBus();
  const events = [];
  bus.on('*', (pp, t) => events.push([t, pp]));
  const p = new Plugin({ manifest, bus, clock: fakeClock(), nudge: allowOnce() });
  p.init();
  p.tick();
  assert.ok(events.some(([e, q]) => e === 'nudge' && q.category === 'habit'));
});

test('a new day resets doneToday', () => {
  const { p, clock } = boot('2026-06-06');
  p.markDone();
  clock.set('2026-06-07');
  p.tick();
  assert.equal(p.doneToday, false);
});

test('menuItems reflects the configured habit label', () => {
  const { p } = boot();
  assert.equal(p.menuItems()[0].label, '🐾 Take a walk');
});

test('serialize/hydrate round-trips and dispose unsubscribes', () => {
  const { p, bus } = boot();
  p.markDone();
  const slice = p.serialize();
  const p2 = new Plugin({ manifest, bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  p2.init();
  p2.hydrate(slice);
  assert.equal(p2.streakDays, 1);
  assert.equal(p2.doneToday, true);

  p.dispose();
  bus.emit('plugin:habit-tracker:done', {}); // ignored after dispose (new day anyway)
  // streak unchanged because already done today / listener removed
  assert.equal(p.streakDays, 1);
});
