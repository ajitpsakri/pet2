import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HydrationSystem } from '../src/systems/wellness/HydrationSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  return { bus, clock, events };
}

test('drinking accumulates ml and reports glasses', () => {
  const { bus, clock } = boot();
  const h = new HydrationSystem({ bus, clock, nudge: noNudge });
  h.init();
  h.drink(); h.drink(); // 2 glasses = 500ml
  assert.equal(h.todayMl, 500);
  assert.equal(h.status().glasses, 2);
});

test('reaching the goal celebrates and starts a streak', () => {
  const { bus, clock, events } = boot();
  const h = new HydrationSystem({ bus, clock, nudge: noNudge });
  h.init();
  h.goalMl = 500;
  h.drink(); // 250
  h.drink(); // 500 -> goal
  assert.equal(h.goalHitToday, true);
  assert.equal(h.streakDays, 1);
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'hydration'));
  assert.ok(events.some(([t]) => t === 'hydration:goal'));
});

test('goal celebration fires only once per day', () => {
  const { bus, clock, events } = boot();
  const h = new HydrationSystem({ bus, clock, nudge: noNudge });
  h.init();
  h.goalMl = 250;
  h.drink(); // hits goal
  h.drink(); // over goal, should NOT re-celebrate
  const goals = events.filter(([t]) => t === 'hydration:goal');
  assert.equal(goals.length, 1);
});

test('reminder fires when behind and not yet at goal', () => {
  const { bus, clock, events } = boot();
  const h = new HydrationSystem({ bus, clock, nudge: allowOnce() });
  h.init();
  h.tick();
  assert.ok(events.some(([t, p]) => t === 'nudge' && p.category === 'water'));
});

test('a new day resets intake but keeps the streak across consecutive days', () => {
  const { bus, clock } = boot('2026-06-06');
  const h = new HydrationSystem({ bus, clock, nudge: noNudge });
  h.init();
  h.goalMl = 250;
  h.drink(); // day 1 goal -> streak 1
  assert.equal(h.streakDays, 1);
  clock.set('2026-06-07');
  h.drink(); // rollover resets ml, day 2 goal -> streak 2
  assert.equal(h.todayMl, 250);
  assert.equal(h.streakDays, 2);
});

test('serialize/hydrate round-trips', () => {
  const { bus, clock } = boot();
  const h = new HydrationSystem({ bus, clock, nudge: noNudge });
  h.init(); h.goalMl = 250; h.drink();
  const slice = h.serialize();
  const h2 = new HydrationSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  h2.init(); h2.hydrate(slice);
  assert.equal(h2.streakDays, 1);
  assert.equal(h2.goalHitToday, true);
});
