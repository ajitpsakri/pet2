import { test } from 'node:test';
import assert from 'node:assert/strict';
import { KnowledgeSystem, searchNotes } from '../src/systems/knowledge/KnowledgeSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const k = new KnowledgeSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-06' } });
  k.init();
  return k;
}

test('add normalizes tags and rejects fully empty notes', () => {
  const k = boot();
  const n = k.add({ title: 'ARM NEON', body: 'SIMD intrinsics', tags: 'arm, SIMD ,, neon' });
  assert.deepEqual(n.tags, ['arm', 'simd', 'neon']);
  assert.equal(k.add({ title: '   ', body: '' }), null);
});

test('update edits fields and bumps updated', () => {
  const k = boot();
  const n = k.add({ title: 'A', body: 'x' });
  const before = n.updated;
  k.update(n.id, { body: 'new body', tags: ['c', 'cpp'] });
  assert.equal(k.get(n.id).body, 'new body');
  assert.deepEqual(k.get(n.id).tags, ['c', 'cpp']);
  assert.ok(k.get(n.id).updated >= before);
});

test('remove deletes a note', () => {
  const k = boot();
  const n = k.add({ title: 'gone', body: 'soon' });
  k.remove(n.id);
  assert.equal(k.get(n.id), null);
});

test('search ranks title matches above body matches', () => {
  const notes = [
    { id: 'a', title: 'Cooking pasta', body: 'mentions kafka once', tags: [], updated: 1 },
    { id: 'b', title: 'Kafka streams', body: 'unrelated text', tags: [], updated: 2 },
  ];
  const res = searchNotes(notes, 'kafka');
  assert.equal(res[0].id, 'b'); // title match wins
});

test('search rewards covering more distinct terms', () => {
  const notes = [
    { id: 'a', title: 'arm', body: 'arm arm arm', tags: [], updated: 1 },
    { id: 'b', title: 'arm neon guide', body: 'about neon on arm', tags: [], updated: 1 },
  ];
  const res = searchNotes(notes, 'arm neon');
  assert.equal(res[0].id, 'b'); // matches both terms
});

test('tag matches count toward relevance', () => {
  const notes = [
    { id: 'a', title: 'Misc', body: 'nothing here', tags: ['embedded'], updated: 1 },
    { id: 'b', title: 'Misc', body: 'nothing here', tags: ['web'], updated: 1 },
  ];
  const res = searchNotes(notes, 'embedded');
  assert.equal(res.length, 1);
  assert.equal(res[0].id, 'a');
});

test('empty query returns most-recent notes', () => {
  const notes = [
    { id: 'a', title: 'old', body: '', tags: [], updated: 10 },
    { id: 'b', title: 'new', body: '', tags: [], updated: 99 },
  ];
  const res = searchNotes(notes, '   ');
  assert.equal(res[0].id, 'b');
});

test('word-boundary scoring avoids partial false positives', () => {
  const notes = [{ id: 'a', title: 'alarm clock', body: '', tags: [], updated: 1 }];
  // "arm" should not match inside "alarm"
  assert.equal(searchNotes(notes, 'arm').length, 0);
});

test('system.search and recent delegate correctly', () => {
  const k = boot();
  k.add({ title: 'ARM NEON', body: 'simd', tags: ['arm'] });
  k.add({ title: 'Pasta', body: 'food' });
  assert.equal(k.search('arm')[0].title, 'ARM NEON');
  assert.equal(k.recent(1).length, 1);
  assert.deepEqual(k.allTags(), ['arm']);
});

test('serialize/hydrate round-trips notes', () => {
  const k = boot();
  k.add({ title: 'keep', body: 'me', tags: ['x'] });
  const slice = k.serialize();
  const k2 = new KnowledgeSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-06' } });
  k2.init();
  k2.hydrate(slice);
  assert.equal(k2.notes[0].title, 'keep');
  const n = k2.add({ title: 'another', body: 'note' });
  assert.equal(k2.notes.filter((x) => x.id === n.id).length, 1); // no id collision
});
