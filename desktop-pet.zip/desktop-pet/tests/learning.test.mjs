import { test } from 'node:test';
import assert from 'node:assert/strict';
import { LearningSystem } from '../src/systems/learning/LearningSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06', bucket = 'day') {
  return { _d: day, _b: bucket, dayKey() { return this._d; }, bucket() { return this._b; }, set(d) { this._d = d; }, setBucket(b) { this._b = b; } };
}
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day, bucket) {
  const bus = new EventBus();
  const clock = fakeClock(day, bucket);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const l = new LearningSystem({ bus, clock, nudge: noNudge });
  l.init();
  return { bus, clock, events, l };
}

test('logging >= the daily goal qualifies a learning streak', () => {
  const { l, events } = boot();
  l.logStudy(25); // >= 20 min goal
  assert.equal(l.qualifiedToday, true);
  assert.equal(l.streakDays, 1);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'learning'));
});

test('a reflection note also qualifies the day', () => {
  const { l } = boot();
  assert.equal(l.learnedToday('closures finally clicked'), true);
  assert.equal(l.qualifiedToday, true);
  assert.equal(l.notes.length, 1);
});

test('empty note is ignored', () => {
  const { l } = boot();
  assert.equal(l.learnedToday('   '), false);
  assert.equal(l.notes.length, 0);
});

test('study minutes accumulate; week total spans history', () => {
  const { l, clock } = boot('2026-06-06');
  l.logStudy(30);
  clock.set('2026-06-07');
  l.logStudy(15); // rollover archives 30, today=15
  assert.equal(l.todayMinutes, 15);
  assert.equal(l.weekMinutes(), 45);
});

test('tech studied counts up and surfaces in status', () => {
  const { l } = boot();
  l.studied('Rust'); l.studied('Rust'); l.studied('SQL');
  assert.equal(l.tech.Rust, 2);
  assert.ok(l.status().topTech.includes('Rust'));
});

test('learning goals: add, complete (celebrates), remove', () => {
  const { l, events } = boot();
  const g = l.addGoal('Finish algorithms course');
  assert.ok(g);
  assert.equal(l.completeGoal(g.id), true);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'learngoal'));
  l.removeGoal(g.id);
  assert.equal(l.goals.length, 0);
});

test('evening reflection nudge fires when nothing logged yet', () => {
  const { l, events } = boot('2026-06-06', 'evening');
  l.ctx.nudge = allowOnce();
  l.tick();
  assert.ok(events.some(([e, p]) => e === 'nudge' && p.category === 'learn'));
});

test('no reflection nudge once a note is recorded', () => {
  const { l, events } = boot('2026-06-06', 'evening');
  l.ctx.nudge = allowOnce();
  l.learnedToday('something');
  events.length = 0;
  l.tick();
  assert.ok(!events.some(([e]) => e === 'nudge'));
});

test('streak continues across consecutive learning days', () => {
  const { l, clock } = boot('2026-06-06');
  l.logStudy(25); // day1 -> streak 1
  clock.set('2026-06-07');
  l.logStudy(25); // day2 consecutive -> streak 2
  assert.equal(l.streakDays, 2);
});

test('serialize/hydrate round-trips', () => {
  const { l } = boot();
  l.logStudy(25); l.studied('Go'); const g = l.addGoal('read DDIA');
  const slice = l.serialize();
  const l2 = new LearningSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  l2.init(); l2.hydrate(slice);
  assert.equal(l2.streakDays, 1);
  assert.equal(l2.tech.Go, 1);
  assert.equal(l2.goals[0].text, 'read DDIA');
});
