import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Logger } from '../src/core/Logger.js';

test('records entries with levels', () => {
  const l = new Logger();
  l.info('hello');
  l.warn('careful');
  l.error('boom');
  assert.equal(l.entries.length, 3);
  assert.deepEqual(l.entries.map((e) => e.level), ['info', 'warn', 'error']);
});

test('ring buffer respects capacity', () => {
  const l = new Logger(5);
  for (let i = 0; i < 20; i++) l.info('line', i);
  assert.equal(l.entries.length, 5);
  assert.ok(l.entries[l.entries.length - 1].msg.includes('19'));
});

test('serialises Error objects with stack', () => {
  const l = new Logger();
  l.error(new Error('kaboom'));
  assert.ok(l.entries[0].msg.includes('kaboom'));
});

test('sinks receive each entry but a throwing sink never breaks logging', () => {
  const l = new Logger();
  const got = [];
  l.addSink((e) => got.push(e.msg));
  l.addSink(() => { throw new Error('bad sink'); });
  l.info('x');
  assert.deepEqual(got, ['x']);
});

test('dump produces a readable multi-line string', () => {
  const l = new Logger();
  l.info('one');
  l.error('two');
  const dump = l.dump();
  assert.ok(dump.includes('INFO: one'));
  assert.ok(dump.includes('ERROR: two'));
  assert.equal(dump.split('\n').length, 2);
});
