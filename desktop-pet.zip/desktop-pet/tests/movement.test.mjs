import { test } from 'node:test';
import assert from 'node:assert/strict';
import { MovementSystem } from '../src/systems/wellness/MovementSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowAll() { return { configure() {}, request() { return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  return { bus, clock, events };
}

test('logging movements increments counts and score', () => {
  const { bus, clock } = boot();
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init();
  m.did('stretch'); m.did('eye'); m.did('eye');
  assert.equal(m.counts.stretch, 1);
  assert.equal(m.counts.eye, 2);
  assert.equal(m.score, 3);
});

test('unknown movement kind is rejected', () => {
  const { bus, clock } = boot();
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init();
  assert.equal(m.did('dance'), false);
  assert.equal(m.score, 0);
});

test('hitting the daily goal celebrates and starts a streak', () => {
  const { bus, clock, events } = boot();
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init();
  m.goalScore = 3;
  m.did('stretch'); m.did('stand'); m.did('eye'); // 3 -> goal
  assert.equal(m.goalHitToday, true);
  assert.equal(m.streakDays, 1);
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'movement'));
});

test('only one reminder fires per tick even if several are due', () => {
  const { bus, clock, events } = boot();
  const m = new MovementSystem({ bus, clock, nudge: allowAll() });
  m.init();
  m.tick();
  const nudges = events.filter(([t]) => t === 'nudge');
  assert.equal(nudges.length, 1);
});

test('compliance score is a 0..100 percentage', () => {
  const { bus, clock } = boot();
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init();
  m.goalScore = 4;
  m.did('stretch'); m.did('stand'); // 2/4
  assert.equal(m.movementScore(), 50);
});

test('a new day resets counts and score', () => {
  const { bus, clock } = boot('2026-06-06');
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init();
  m.did('stretch');
  clock.set('2026-06-07');
  m.did('eye'); // triggers rollover then logs
  assert.equal(m.counts.stretch, 0);
  assert.equal(m.counts.eye, 1);
  assert.equal(m.score, 1);
});

test('serialize/hydrate round-trips', () => {
  const { bus, clock } = boot();
  const m = new MovementSystem({ bus, clock, nudge: noNudge });
  m.init(); m.goalScore = 2; m.did('stretch'); m.did('eye');
  const slice = m.serialize();
  const m2 = new MovementSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  m2.init(); m2.hydrate(slice);
  assert.equal(m2.streakDays, 1);
  assert.equal(m2.counts.stretch, 1);
});
