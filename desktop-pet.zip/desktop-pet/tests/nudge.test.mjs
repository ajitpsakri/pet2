import { test } from 'node:test';
import assert from 'node:assert/strict';
import { NudgeEngine } from '../src/services/NudgeEngine.js';

function clk(start = 0) { let t = start; const f = () => t; f.adv = (ms) => (t += ms); return f; }
const MIN = 60_000;

test('first request for a category is allowed', () => {
  const now = clk();
  const n = new NudgeEngine({ now, minGapMs: 5 * MIN });
  n.configure('anki', 30);
  assert.equal(n.request('anki'), true);
});

test('enforces the hard gap between any two nudges', () => {
  const now = clk();
  const n = new NudgeEngine({ now, minGapMs: 8 * MIN, maxPerHour: 10 });
  n.configure('a', 1); n.configure('b', 1);
  assert.equal(n.request('a'), true);
  now.adv(2 * MIN);
  assert.equal(n.request('b'), false); // within the 8-min global floor
  now.adv(7 * MIN);
  assert.equal(n.request('b'), true);
});

test('enforces the hourly cap', () => {
  const now = clk();
  const n = new NudgeEngine({ now, minGapMs: 1 * MIN, maxPerHour: 2 });
  n.configure('a', 0); n.configure('b', 0); n.configure('c', 0);
  assert.equal(n.request('a'), true); now.adv(2 * MIN);
  assert.equal(n.request('b'), true); now.adv(2 * MIN);
  assert.equal(n.request('c'), false); // cap reached
  now.adv(60 * MIN);
  assert.equal(n.request('c'), true); // window rolled over
});

test('per-category interval blocks repeat too soon', () => {
  const now = clk();
  const n = new NudgeEngine({ now, minGapMs: 0, maxPerHour: 99 });
  n.configure('anki', 30); // 30 min base
  assert.equal(n.request('anki'), true);
  now.adv(10 * MIN);
  assert.equal(n.request('anki'), false);
  now.adv(25 * MIN);
  assert.equal(n.request('anki'), true);
});

test('DND silences everything', () => {
  const n = new NudgeEngine({ now: clk(), minGapMs: 0 });
  n.configure('a', 0);
  n.setDND(true);
  assert.equal(n.request('a'), false);
});

test('backoff grows on dismiss and relaxes on acted', () => {
  const n = new NudgeEngine({ now: clk(), minGapMs: 0 });
  n.configure('anki', 30);
  n.dismissed('anki'); // 30 -> 48
  assert.equal(n.intervalMinutes('anki'), 48);
  n.dismissed('anki'); // 48 -> ~77
  assert.ok(n.intervalMinutes('anki') > 70);
  n.acted('anki'); // relax back toward base
  assert.ok(n.intervalMinutes('anki') < 60);
});
