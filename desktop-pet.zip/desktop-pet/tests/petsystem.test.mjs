import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PetSystem } from '../src/systems/pet/PetSystem.js';
import { EventBus } from '../src/core/EventBus.js';
import { migrate } from '../src/storage/schema.js';

const bounds = { w: 800, h: 600 };

function bootPet(extraRoot = {}) {
  const bus = new EventBus();
  const ps = new PetSystem({ bus, getBounds: () => bounds });
  ps.init();
  const root = migrate({ version: 1, pet: { needs: {} }, stats: { lastSeen: Date.now() }, ...extraRoot });
  ps.hydrateFrom(root);
  return { bus, ps };
}

test('hydrates a migrated save into a live pet + model', () => {
  const { ps } = bootPet();
  assert.ok(ps.state, 'PetState created');
  assert.ok(ps.pet, 'Pet created');
  assert.equal(typeof ps.pet.hitTest, 'function');
});

test('serializeInto writes the LEGACY top-level shape (save compatibility)', () => {
  const { ps } = bootPet();
  const root = {};
  ps.serializeInto(root);
  assert.ok(root.pet && root.stats && root.achievements, 'top-level keys present');
  assert.ok(!root.systems || !root.systems.pet, 'pet is NOT nested under systems');
  assert.equal(typeof root.stats.lastSeen, 'number');
  assert.ok(Array.isArray(Object.keys(root.pet.needs)) && 'hunger' in root.pet.needs);
});

test('interactions persist through serialize', () => {
  const { ps } = bootPet();
  const before = ps.state.stats.totalPats;
  ps.state.pet(); // a head pat
  const root = {};
  ps.serializeInto(root);
  assert.equal(root.stats.totalPats, before + 1);
});

test('model events surface on the bus during tick (e.g. levelup)', () => {
  const { bus, ps } = bootPet();
  let leveled = null;
  bus.on('pet:levelup', (d) => { leveled = d; });

  // Pile on XP, then tick so PetSystem drains the queued events to the bus.
  for (let i = 0; i < 60; i++) ps.state.play();
  ps.tick(0.016, Date.now(), { cursor: null });

  assert.ok(leveled && typeof leveled.level === 'number', 'pet:levelup emitted with a level');
  assert.ok(ps.state.level >= 2);
});

test('away-decay is applied but never lethal', () => {
  // Pretend the app was closed for 3 days.
  const threeDaysAgo = Date.now() - 3 * 24 * 3600 * 1000;
  const { ps } = bootPet({ stats: { lastSeen: threeDaysAgo } });
  for (const n of Object.keys(ps.state.needs)) {
    assert.ok(ps.state.needs[n] >= 0, `${n} stayed >= 0`);
  }
});
