import { test } from 'node:test';
import assert from 'node:assert/strict';
import { regionAt } from '../src/animations/sprites.js';
import { reactionFor, PettingController } from '../src/ui/Petting.js';
import { EventBus } from '../src/core/EventBus.js';

// --- region hit-testing (pure) ----------------------------------------------

test('regionAt maps local points to body parts', () => {
  assert.equal(regionAt(0, -20), 'head'); // top of head
  assert.equal(regionAt(0, -5), 'snout'); // muzzle
  assert.equal(regionAt(12, -18), 'ear'); // side-top
  assert.equal(regionAt(0, 5), 'back'); // upper body
  assert.equal(regionAt(0, 17), 'belly'); // lower body
  assert.equal(regionAt(-18, 6), 'tail'); // behind the body
  assert.equal(regionAt(100, 100), null); // off the dog
});

// --- reaction map -----------------------------------------------------------

test('reactionFor returns a distinct reaction per region', () => {
  assert.equal(reactionFor('belly').anim, 'bellyrub');
  assert.equal(reactionFor('ear').anim, 'earscratch');
  assert.equal(reactionFor('snout').anim, 'boop');
  assert.equal(reactionFor('head').sound, 'pet');
  assert.equal(reactionFor('belly').sound, 'play');
  assert.equal(reactionFor('nope'), null);
});

// --- controller pacing ------------------------------------------------------

function harness() {
  const pet = { actionAnim: null, last: null, triggerAction(a) { this.last = a; } };
  const sound = { s: null, play(s) { this.s = s; } };
  const speech = { said: null, say(t) { this.said = t; } };
  const state = { n: 0, pet() { this.n++; } };
  const bus = new EventBus();
  const events = [];
  bus.on('pet:petted', (p) => events.push(p));
  return { pet, sound, speech, state, bus, events, c: new PettingController(pet, { sound, speech, state, bus }) };
}

test('entering a new region reacts immediately', () => {
  const h = harness();
  h.c.move('head', 0, 1000);
  assert.equal(h.pet.last, 'petted');
  assert.equal(h.sound.s, 'pet');
  assert.equal(h.c.count, 1);
});

test('small movement on the same region does not re-trigger; stroking does', () => {
  const h = harness();
  h.c.move('head', 0, 1000); // react
  h.c.move('head', 5, 1100); // acc 5 -> no
  assert.equal(h.c.count, 1);
  h.c.move('head', 20, 1700); // acc>=16 and past cooldown -> react
  assert.equal(h.c.count, 2);
});

test('reactions are paced (cooldown blocks rapid re-trigger)', () => {
  const h = harness();
  h.c.move('head', 0, 1000);
  h.c.move('belly', 0, 1200); // changed but only 200ms later -> blocked
  assert.equal(h.c.count, 1);
  h.c.move('belly', 0, 1600); // 600ms after last react -> ok
  assert.equal(h.c.count, 2);
  assert.equal(h.pet.last, 'bellyrub');
});

test('mood boost is rate-limited so petting cannot be farmed', () => {
  const h = harness();
  h.c.move('head', 0, 1000); // mood +1
  h.c.move('head', 20, 1700); // 700ms later -> reacts but mood within 1400ms window
  h.c.move('belly', 0, 2300);
  assert.equal(h.state.n, 1);
});

test('leaving the dog resets, and emits petted events with region', () => {
  const h = harness();
  h.c.move('ear', 0, 1000);
  h.c.move(null, 0, 1100); // off the dog
  h.c.move('ear', 0, 1600); // fresh entry after the cooldown -> reacts again
  assert.equal(h.events.length, 2);
  assert.equal(h.events[0].region, 'ear');
});
