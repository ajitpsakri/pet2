import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PluginLoader, makePluginBus, makePluginContext, PLUGIN_API_VERSION } from '../src/plugins/PluginLoader.js';
import { SystemRegistry } from '../src/core/SystemRegistry.js';
import { System } from '../src/systems/System.js';
import { EventBus } from '../src/core/EventBus.js';

function services() {
  return { bus: new EventBus(), clock: { dayKey: () => '2026-06-06' }, nudge: { configure() {}, request() { return false; } } };
}
function descriptor(id, perms, extra = {}) {
  class P extends System {
    static id = id;
    constructor(ctx) { super(ctx); this.ctx = ctx; }
    menuItems() { return [{ label: id, action: 'go' }]; }
  }
  Object.assign(P.prototype, extra);
  return { manifest: { id, name: id, version: '1.0.0', apiVersion: 1, permissions: perms }, Plugin: P };
}

test('loads a valid plugin and registers it', () => {
  const reg = new SystemRegistry();
  const r = new PluginLoader().load({ descriptors: [descriptor('a', [])], services: services(), registry: reg });
  assert.equal(r.loaded.length, 1);
  assert.equal(r.failed.length, 0);
  assert.ok(reg.get('a'));
});

test('rejects an unsupported apiVersion', () => {
  const reg = new SystemRegistry();
  const d = descriptor('a', []);
  d.manifest.apiVersion = 999;
  const r = new PluginLoader().load({ descriptors: [d], services: services(), registry: reg });
  assert.equal(r.loaded.length, 0);
  assert.equal(r.failed.length, 1);
  assert.equal(reg.get('a'), null);
});

test('rejects manifest/Plugin id mismatch', () => {
  const reg = new SystemRegistry();
  const d = descriptor('a', []);
  d.manifest.id = 'b'; // mismatch with Plugin.id 'a'
  const r = new PluginLoader().load({ descriptors: [d], services: services(), registry: reg });
  assert.equal(r.failed.length, 1);
});

test('permission filtering: clock/nudge only present when declared', () => {
  const reg = new SystemRegistry();
  let withCtx, withoutCtx;
  const d1 = descriptor('has', ['clock', 'nudge'], { init() { withCtx = this.ctx; } });
  const d2 = descriptor('hasnot', [], { init() { withoutCtx = this.ctx; } });
  new PluginLoader().load({ descriptors: [d1, d2], services: services(), registry: reg });
  reg.init();
  assert.ok(withCtx.clock && withCtx.nudge);
  assert.equal(withoutCtx.clock, undefined);
  assert.equal(withoutCtx.nudge, undefined);
});

test('capability bus blocks disallowed emits, allows own namespace + granted', () => {
  const real = new EventBus();
  const seen = [];
  real.on('*', (p, t) => seen.push(t));
  const bus = makePluginBus(real, ['celebrate'], 'x');
  bus.emit('plugin:x:hello'); // own namespace -> allowed
  bus.emit('celebrate', {}); // granted -> allowed
  bus.emit('nudge', {}); // not granted -> blocked
  bus.emit('pet:levelup', {}); // core event -> blocked
  assert.deepEqual(seen, ['plugin:x:hello', 'celebrate']);
});

test('a plugin can still subscribe to anything (read) through its bus', () => {
  const real = new EventBus();
  const bus = makePluginBus(real, [], 'x');
  let got = 0;
  bus.on('pet:levelup', () => got++);
  real.emit('pet:levelup', {});
  assert.equal(got, 1);
});

test('menu items are aggregated only for plugins with the menu permission', () => {
  const reg = new SystemRegistry();
  const r = new PluginLoader().load({
    descriptors: [descriptor('m', ['menu']), descriptor('n', [])],
    services: services(),
    registry: reg,
  });
  assert.equal(r.menuItems.length, 1);
  assert.equal(r.menuItems[0].pluginId, 'm');
});

test('one bad plugin does not stop the others', () => {
  const reg = new SystemRegistry();
  const bad = descriptor('bad', []);
  bad.Plugin = null; // invalid
  const r = new PluginLoader().load({
    descriptors: [bad, descriptor('good', [])],
    services: services(),
    registry: reg,
  });
  assert.equal(r.failed.length, 1);
  assert.ok(reg.get('good'));
});

test('PLUGIN_API_VERSION is exported', () => {
  assert.equal(typeof PLUGIN_API_VERSION, 'number');
});
