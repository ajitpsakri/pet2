import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PresentationSystem } from '../src/systems/presentation/PresentationSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const p = new PresentationSystem({ bus, clock, nudge: noNudge });
  p.init();
  return { bus, clock, events, p };
}

test('adds talks and computes a day countdown', () => {
  const { p } = boot('2026-06-06');
  const t = p.addTalk('Team demo', '2026-06-09');
  assert.ok(t);
  assert.equal(p.daysUntil('2026-06-09'), 3);
  assert.equal(p.daysUntil('2026-06-06'), 0);
});

test('confidence clamps to 0..5', () => {
  const { p } = boot();
  const t = p.addTalk('X', null);
  p.setConfidence(t.id, 9);
  assert.equal(t.confidence, 5);
  p.setConfidence(t.id, -3);
  assert.equal(t.confidence, 0);
});

test('a rehearsal of sufficient length logs a session and celebrates', () => {
  const { p, events } = boot();
  const t = p.addTalk('Pitch', null);
  p.startRehearsal(t.id);
  p.tick(120); // 2 minutes
  const sec = p.stopRehearsal();
  assert.equal(sec, 120);
  assert.equal(t.rehearsals, 1);
  assert.equal(p.sessions.length, 1);
  assert.ok(events.some(([e, q]) => e === 'celebrate' && q.kind === 'present'));
});

test('a too-short rehearsal is discarded (no session, no celebrate)', () => {
  const { p, events } = boot();
  p.startRehearsal(null);
  p.tick(3);
  const sec = p.stopRehearsal();
  assert.equal(sec, 3);
  assert.equal(p.sessions.length, 0);
  assert.ok(!events.some(([e]) => e === 'celebrate'));
});

test('currentSeconds reflects the running timer', () => {
  const { p } = boot();
  assert.equal(p.currentSeconds(), 0);
  p.startRehearsal(null);
  p.tick(45);
  assert.equal(p.currentSeconds(), 45);
});

test('nextTalk picks the soonest upcoming (ignores past)', () => {
  const { p } = boot('2026-06-06');
  p.addTalk('past', '2026-06-01');
  p.addTalk('soon', '2026-06-08');
  p.addTalk('later', '2026-06-20');
  assert.equal(p.nextTalk().title, 'soon');
});

test('checklist toggles and reset work', () => {
  const { p } = boot();
  const id = p.checklist[0].id;
  p.toggleCheck(id);
  assert.equal(p.checklist[0].done, true);
  p.resetChecklist();
  assert.equal(p.checklist[0].done, false);
});

test('an imminent talk triggers a gentle nudge, at most once per day', () => {
  const { p, events } = boot('2026-06-06');
  p.ctx.nudge = allowOnce();
  p.addTalk('soon', '2026-06-07'); // tomorrow
  p.tick(1);
  p.tick(1); // second tick same day should not nudge again
  const nudges = events.filter(([e, q]) => e === 'nudge' && q.category === 'present');
  assert.equal(nudges.length, 1);
});

test('serialize/hydrate round-trips talks, sessions, checklist', () => {
  const { p } = boot();
  const t = p.addTalk('Keynote', '2026-07-01');
  p.setConfidence(t.id, 4);
  p.startRehearsal(t.id); p.tick(60); p.stopRehearsal();
  p.toggleCheck(p.checklist[0].id);
  const slice = p.serialize();

  const p2 = new PresentationSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  p2.init(); p2.hydrate(slice);
  assert.equal(p2.talks.length, 1);
  assert.equal(p2.talks[0].confidence, 4);
  assert.equal(p2.talks[0].rehearsals, 1);
  assert.equal(p2.sessions.length, 1);
  assert.equal(p2.checklist[0].done, true);
});
