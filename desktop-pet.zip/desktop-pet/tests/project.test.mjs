import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ProjectSystem } from '../src/systems/projects/ProjectSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06') { return { _d: day, dayKey() { return this._d; }, set(d) { this._d = d; } }; }
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day) {
  const bus = new EventBus();
  const clock = fakeClock(day);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const ps = new ProjectSystem({ bus, clock, nudge: noNudge });
  ps.init();
  return { bus, clock, events, ps };
}

test('add project and milestones; progress tracks completion', () => {
  const { ps } = boot();
  const p = ps.addProject('Firmware v2', '2026-06-20');
  assert.ok(p);
  const m1 = ps.addMilestone(p.id, 'Bring-up board');
  ps.addMilestone(p.id, 'Write driver');
  assert.equal(ps.progress(p.id).total, 2);
  ps.toggleMilestone(p.id, m1.id);
  assert.equal(ps.progress(p.id).done, 1);
  assert.equal(ps.progress(p.id).pct, 50);
});

test('completing a milestone celebrates; finishing all celebrates the project', () => {
  const { ps, events } = boot();
  const p = ps.addProject('X');
  const a = ps.addMilestone(p.id, 'a');
  const b = ps.addMilestone(p.id, 'b');
  ps.toggleMilestone(p.id, a.id);
  assert.ok(events.some(([e, q]) => e === 'celebrate' && q.kind === 'milestone'));
  ps.toggleMilestone(p.id, b.id);
  assert.ok(events.some(([e, q]) => e === 'celebrate' && q.kind === 'project'));
  assert.ok(events.some(([e]) => e === 'project:done'));
});

test('deadline countdown computes days', () => {
  const { ps } = boot('2026-06-06');
  assert.equal(ps.daysUntil('2026-06-09'), 3);
  assert.equal(ps.daysUntil(null), null);
});

test('nextDeadline ignores complete and archived projects', () => {
  const { ps } = boot('2026-06-06');
  const a = ps.addProject('soon', '2026-06-07');
  const m = ps.addMilestone(a.id, 'only');
  ps.toggleMilestone(a.id, m.id); // a is now complete -> excluded
  ps.addProject('later', '2026-06-10');
  assert.equal(ps.nextDeadline().name, 'later');
});

test('an imminent deadline nudges once per day, via the budget', () => {
  const { ps, events } = boot('2026-06-06');
  ps.ctx.nudge = allowOnce();
  const p = ps.addProject('crunch', '2026-06-07'); // tomorrow
  ps.addMilestone(p.id, 'todo'); // incomplete
  ps.tick();
  ps.tick();
  const n = events.filter(([e, q]) => e === 'nudge' && q.category === 'project');
  assert.equal(n.length, 1);
});

test('notes, rename, deadline edits, and removal', () => {
  const { ps } = boot();
  const p = ps.addProject('Name');
  ps.setNotes(p.id, 'remember the watchdog');
  ps.rename(p.id, 'New name');
  ps.setDeadline(p.id, '2026-07-01');
  assert.equal(ps.get(p.id).notes, 'remember the watchdog');
  assert.equal(ps.get(p.id).name, 'New name');
  assert.equal(ps.get(p.id).deadline, '2026-07-01');
  ps.removeProject(p.id);
  assert.equal(ps.get(p.id), null);
});

test('archived projects drop out of the active list', () => {
  const { ps } = boot();
  const p = ps.addProject('Old');
  ps.setArchived(p.id, true);
  assert.equal(ps.activeProjects().length, 0);
});

test('serialize/hydrate round-trips projects and milestones', () => {
  const { ps } = boot();
  const p = ps.addProject('keep', '2026-06-30');
  ps.addMilestone(p.id, 'm');
  const slice = ps.serialize();
  const ps2 = new ProjectSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  ps2.init();
  ps2.hydrate(slice);
  assert.equal(ps2.projects[0].name, 'keep');
  assert.equal(ps2.projects[0].milestones.length, 1);
  const np = ps2.addProject('another');
  assert.equal(ps2.projects.filter((x) => x.id === np.id).length, 1); // no id collision
});
