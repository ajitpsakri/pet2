import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SystemRegistry } from '../src/core/SystemRegistry.js';
import { System } from '../src/systems/System.js';

/** Minimal instrumented system for lifecycle assertions. */
function makeSystem(id) {
  class S extends System {
    static id = id;
    constructor(ctx) {
      super(ctx);
      this.log = { init: 0, tick: 0, ctx: 0, dispose: 0 };
      this.lastFrame = null;
    }
    init() { this.log.init++; }
    tick(dt, now, frame) { this.log.tick++; this.lastFrame = frame; }
    onContext() { this.log.ctx++; }
    dispose() { this.log.dispose++; }
    views() { return [{ id, tab: id }]; }
  }
  return new S({});
}

test('register/get and duplicate-id protection', () => {
  const r = new SystemRegistry();
  const a = makeSystem('a');
  r.register(a);
  assert.equal(r.get('a'), a);
  assert.throws(() => r.register(makeSystem('a')), /Duplicate system id/);
});

test('init() runs once per system; tick fans out with frame ctx', () => {
  const r = new SystemRegistry();
  const a = makeSystem('a');
  const b = makeSystem('b');
  r.register(a); r.register(b);
  r.init();
  r.tick(0.016, 123, { cursor: { x: 1, y: 2 } });
  assert.equal(a.log.init, 1);
  assert.equal(b.log.init, 1);
  assert.equal(a.log.tick, 1);
  assert.deepEqual(b.lastFrame, { cursor: { x: 1, y: 2 } });
});

test('systems registered after init() are initialised immediately', () => {
  const r = new SystemRegistry();
  r.init();
  const late = makeSystem('late');
  r.register(late);
  assert.equal(late.log.init, 1);
});

test('context() fans a signal to all systems', () => {
  const r = new SystemRegistry();
  const a = makeSystem('a');
  r.register(a); r.init();
  r.context({ kind: 'idle' });
  assert.equal(a.log.ctx, 1);
});

test('views() aggregates across systems', () => {
  const r = new SystemRegistry();
  r.register(makeSystem('a'));
  r.register(makeSystem('b'));
  assert.deepEqual(r.views().map((v) => v.id), ['a', 'b']);
});

test('dispose() tears down every system and clears the registry (leak-safety)', () => {
  const r = new SystemRegistry();
  const a = makeSystem('a');
  const b = makeSystem('b');
  r.register(a); r.register(b); r.init();
  r.dispose();
  assert.equal(a.log.dispose, 1);
  assert.equal(b.log.dispose, 1);
  assert.equal(r.get('a'), null);
  assert.equal(r.all().length, 0);
});

test('a throwing dispose does not prevent others from disposing', () => {
  const r = new SystemRegistry();
  const bad = makeSystem('bad');
  bad.dispose = () => { throw new Error('boom'); };
  const good = makeSystem('good');
  r.register(bad); r.register(good); r.init();
  r.dispose(); // must not throw
  assert.equal(good.log.dispose, 1);
});
