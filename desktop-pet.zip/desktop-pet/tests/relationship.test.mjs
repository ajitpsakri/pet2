import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RelationshipSystem } from '../src/systems/relationship/RelationshipSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const bus = new EventBus();
  const r = new RelationshipSystem({ bus });
  r.init();
  return { bus, r };
}

test('caring for the dog raises careScore', () => {
  const { bus, r } = boot();
  bus.emit('pet:pet');
  bus.emit('pet:play');
  assert.ok(r.careScore >= 6);
});

test('following coaching raises trust faster', () => {
  const { bus, r } = boot();
  bus.emit('coding:focus:done');
  assert.equal(r.trust, 8);
  bus.emit('anki:done');
  assert.equal(r.trust, 14);
});

test('friendship levels up and announces a celebration', () => {
  const { bus, r } = boot();
  let celebrated = null;
  bus.on('celebrate', (p) => { celebrated = p; });
  // Push enough points to cross the first threshold (40).
  for (let i = 0; i < 6; i++) bus.emit('coding:focus:done'); // 48 trust
  assert.ok(r.friendship >= 1);
  assert.ok(celebrated && celebrated.kind === 'friendship');
});

test('tick accrues minutes together', () => {
  const { r } = boot();
  r.tick(120); // 2 minutes
  assert.equal(Math.round(r.minutesTogether), 2);
});

test('serialize/hydrate round-trips and dispose unsubscribes', () => {
  const { bus, r } = boot();
  bus.emit('pet:feed');
  const slice = r.serialize();
  const r2 = new RelationshipSystem({ bus });
  r2.hydrate(slice);
  assert.equal(r2.careScore, r.careScore);

  r.dispose();
  const before = r.careScore;
  bus.emit('pet:feed'); // should no longer affect r
  assert.equal(r.careScore, before);
});
