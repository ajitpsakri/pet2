import { test } from 'node:test';
import assert from 'node:assert/strict';
import { migrate, defaultState, SCHEMA_VERSION } from '../src/storage/schema.js';
import { NEEDS } from '../src/config/constants.js';

test('null/garbage input yields a fresh current-version default', () => {
  for (const bad of [null, undefined, 42, 'x', []]) {
    const s = migrate(bad);
    assert.equal(s.version, SCHEMA_VERSION);
    assert.ok(s.pet && s.stats && s.settings);
  }
});

test('default save includes the v2 companion keys', () => {
  const s = defaultState();
  assert.equal(s.version, 2);
  assert.deepEqual(s.systems, {});
  assert.deepEqual(s.analytics, { events: [], rollups: {} });
  assert.equal(typeof s.stats.totalWater, 'number');
});

test('a v1 save is upgraded to v2 with new keys added', () => {
  // A minimal, realistic v1 save (no systems/analytics/totalWater).
  const v1 = {
    version: 1,
    pet: { name: 'Pixel', bornAt: 1, needs: {}, level: 3, xp: 10, accessory: 'bowtie', position: { x: 5, y: 6 } },
    stats: { lastSeen: 1, careStreak: 2, longestStreak: 4, totalFood: 7 },
    achievements: { first_meal: 123 },
    settings: { scale: 1.5 },
  };
  for (const n of NEEDS) v1.pet.needs[n] = 50;

  const s = migrate(v1);
  assert.equal(s.version, 2);
  assert.deepEqual(s.systems, {});
  assert.deepEqual(s.analytics, { events: [], rollups: {} });
  assert.equal(s.stats.totalWater, 0); // backfilled
  // Existing values are preserved, not reset.
  assert.equal(s.pet.level, 3);
  assert.equal(s.pet.accessory, 'bowtie');
  assert.deepEqual(s.pet.position, { x: 5, y: 6 });
  assert.equal(s.stats.careStreak, 2);
  assert.equal(s.achievements.first_meal, 123);
  assert.equal(s.settings.scale, 1.5);
  // Settings not present in the old save are filled from defaults.
  assert.equal(typeof s.settings.opacity, 'number');
});

test('out-of-range / corrupt needs are clamped to 0..100', () => {
  const save = defaultState();
  save.pet.needs.hunger = 999;
  save.pet.needs.thirst = -50;
  save.pet.needs.energy = 'NaN-ish';
  const s = migrate(save);
  assert.equal(s.pet.needs.hunger, 100);
  assert.equal(s.pet.needs.thirst, 0);
  assert.equal(s.pet.needs.energy, 80); // non-finite -> safe default
});

test('unknown/future keys are preserved (forward-compatible)', () => {
  const save = defaultState();
  save.futureFeature = { hello: 'world' };
  save.systems.somePlugin = { count: 5 };
  const s = migrate(save);
  assert.deepEqual(s.futureFeature, { hello: 'world' });
  assert.deepEqual(s.systems.somePlugin, { count: 5 });
});

test('migrate is idempotent on an already-current save', () => {
  const once = migrate(defaultState());
  const twice = migrate(once);
  assert.deepEqual(twice, once);
});
