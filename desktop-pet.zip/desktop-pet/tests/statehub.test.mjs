import { test } from 'node:test';
import assert from 'node:assert/strict';
import { StateHub } from '../src/core/StateHub.js';
import { SystemRegistry } from '../src/core/SystemRegistry.js';
import { System } from '../src/systems/System.js';
import { SCHEMA_VERSION } from '../src/storage/schema.js';

/** A fake main-process API that returns a preset save. */
function fakeApi(save) {
  return { loadState: async () => save };
}

test('load() migrates an old save up to the current version', async () => {
  const hub = new StateHub(fakeApi({ version: 1, pet: { needs: {} }, stats: { lastSeen: 1 } }));
  const root = await hub.load();
  assert.equal(root.version, SCHEMA_VERSION);
  assert.deepEqual(root.analytics, { events: [], rollups: {} });
});

test('load() falls back to a fresh default if the api throws', async () => {
  const hub = new StateHub({ loadState: async () => { throw new Error('disk gone'); } });
  const root = await hub.load();
  assert.equal(root.version, SCHEMA_VERSION);
  assert.ok(root.pet);
});

test('snapshot() writes system slices and passed-in extras', async () => {
  const hub = new StateHub(fakeApi(null));
  await hub.load();

  class Coding extends System {
    static id = 'coding';
    serialize() { return { streakDays: 4 }; }
  }
  const reg = new SystemRegistry();
  reg.register(new Coding({}));
  reg.init();

  const snap = hub.snapshot(reg, { settings: { scale: 1.25 } });
  assert.deepEqual(snap.systems.coding, { streakDays: 4 });
  assert.equal(snap.settings.scale, 1.25);
  assert.equal(snap.version, SCHEMA_VERSION);
});

test('snapshot() preserves analytics and unknown keys across a save cycle', async () => {
  const preset = {
    version: 2,
    pet: { needs: {} },
    stats: { lastSeen: 1 },
    achievements: {},
    settings: {},
    systems: { plugin: { keep: true } },
    analytics: { events: [{ t: 1, type: 'x', v: 2 }], rollups: { '2026-06-06': { focusSec: 60 } } },
    futureKey: 'survive-me',
  };
  const hub = new StateHub(fakeApi(preset));
  await hub.load();

  const reg = new SystemRegistry(); // no systems re-serialize the 'plugin' slice
  const snap = hub.snapshot(reg, { settings: {} });

  assert.equal(snap.futureKey, 'survive-me');
  assert.deepEqual(snap.systems.plugin, { keep: true });
  assert.equal(snap.analytics.events.length, 1);
  assert.deepEqual(snap.analytics.rollups['2026-06-06'], { focusSec: 60 });
});
