import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isYesterday, nextStreak } from '../src/systems/streakUtil.js';

test('isYesterday handles normal and month/year boundaries', () => {
  assert.equal(isYesterday('2026-06-05', '2026-06-06'), true);
  assert.equal(isYesterday('2026-05-31', '2026-06-01'), true);
  assert.equal(isYesterday('2025-12-31', '2026-01-01'), true);
  assert.equal(isYesterday('2026-06-04', '2026-06-06'), false);
  assert.equal(isYesterday(null, '2026-06-06'), false);
});

test('nextStreak continues on consecutive days, resets otherwise', () => {
  assert.equal(nextStreak(3, '2026-06-05', '2026-06-06'), 4); // consecutive
  assert.equal(nextStreak(3, '2026-06-03', '2026-06-06'), 1); // gap -> reset
  assert.equal(nextStreak(0, null, '2026-06-06'), 1); // first ever
});
