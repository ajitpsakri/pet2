import { test } from 'node:test';
import assert from 'node:assert/strict';
import { System, TimedHabitSystem } from '../src/systems/System.js';

test('default serializeInto namespaces under systems[id]', () => {
  class Demo extends System {
    static id = 'demo';
    serialize() { return { a: 1 }; }
  }
  const root = {};
  new Demo({}).serializeInto(root);
  assert.deepEqual(root.systems, { demo: { a: 1 } });
});

test('default hydrateFrom reads its own slice and ignores others', () => {
  let got = null;
  class Demo extends System {
    static id = 'demo';
    hydrate(d) { got = d; }
  }
  new Demo({}).hydrateFrom({ systems: { demo: { a: 1 }, other: { b: 2 } } });
  assert.deepEqual(got, { a: 1 });
});

test('hydrateFrom is a no-op when the slice is absent', () => {
  let called = false;
  class Demo extends System {
    static id = 'demo';
    hydrate() { called = true; }
  }
  new Demo({}).hydrateFrom({ systems: {} });
  new Demo({}).hydrateFrom({});
  assert.equal(called, false);
});

test('TimedHabitSystem advances a streak once per day and tracks the best run', () => {
  class Water extends TimedHabitSystem { static id = 'water'; }
  const w = new Water({});
  w.recordDay('2026-06-01');
  w.recordDay('2026-06-01'); // same day -> ignored
  w.recordDay('2026-06-02');
  w.recordDay('2026-06-03');
  assert.equal(w.streakDays, 3);
  assert.equal(w.longestStreak, 3);
});

test('TimedHabitSystem serialize/hydrate round-trips', () => {
  class Water extends TimedHabitSystem { static id = 'water'; }
  const a = new Water({});
  a.recordDay('2026-06-01');
  a.recordDay('2026-06-02');
  const slice = a.serialize();

  const b = new Water({});
  b.hydrate(slice);
  assert.equal(b.streakDays, 2);
  assert.equal(b.longestStreak, 2);
  assert.equal(b.lastDayKey, '2026-06-02');
});
