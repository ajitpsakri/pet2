import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TasksSystem } from '../src/systems/tasks/TasksSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function fakeClock(day = '2026-06-06', bucket = 'day') {
  return { _d: day, _b: bucket, dayKey() { return this._d; }, bucket() { return this._b; }, set(d) { this._d = d; } };
}
const noNudge = { configure() {}, request() { return false; }, acted() {} };
function allowOnce() { let u = false; return { configure() {}, request() { if (u) return false; u = true; return true; }, acted() {} }; }

function boot(day, bucket) {
  const bus = new EventBus();
  const clock = fakeClock(day, bucket);
  const events = [];
  bus.on('*', (p, t) => events.push([t, p]));
  const t = new TasksSystem({ bus, clock, nudge: noNudge });
  t.init();
  return { bus, clock, events, t };
}

test('adds tasks; empty text is ignored', () => {
  const { t } = boot();
  assert.ok(t.add('Write report'));
  assert.equal(t.add('   '), null);
  assert.equal(t.tasks.length, 1);
});

test('first task becomes main only when explicitly set; setMain is exclusive', () => {
  const { t } = boot();
  const a = t.add('A', { main: true });
  const b = t.add('B');
  assert.equal(a.main, true);
  t.setMain(b.id);
  assert.equal(t.mainGoal().id, b.id);
  assert.equal(t.tasks.find((x) => x.id === a.id).main, false);
});

test('completing a task celebrates; main goal celebrates bigger', () => {
  const { t, events } = boot();
  const a = t.add('normal');
  t.complete(a.id);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'task'));

  const m = t.add('big', { main: true });
  t.complete(m.id);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'maingoal'));
});

test('finishing the main goal makes the day productive and starts a streak', () => {
  const { t, events } = boot();
  const m = t.add('ship it', { main: true });
  t.complete(m.id);
  assert.equal(t.qualifiedToday, true);
  assert.equal(t.streakDays, 1);
  assert.ok(events.some(([e, p]) => e === 'celebrate' && p.kind === 'streak'));
});

test('clearing 60% of tasks also qualifies the day', () => {
  const { t } = boot();
  const a = t.add('a'); const b = t.add('b'); t.add('c');
  t.complete(a.id); t.complete(b.id); // 2/3 = 66%
  assert.equal(t.qualifiedToday, true);
});

test('completionRate reflects done/total', () => {
  const { t } = boot();
  const a = t.add('a'); t.add('b');
  assert.equal(t.completionRate(), 0);
  t.complete(a.id);
  assert.equal(t.completionRate(), 0.5);
});

test('a new day carries over unfinished tasks and archives the rate', () => {
  const { t, clock } = boot('2026-06-06');
  const a = t.add('done-one'); t.add('left-over');
  t.complete(a.id); // 1/2 rate = 0.5 for the day
  clock.set('2026-06-07');
  t.add('new-day-task'); // triggers rollover
  // completed task dropped, unfinished carried, new added => 2 tasks
  assert.equal(t.tasks.length, 2);
  assert.ok(t.tasks.some((x) => x.text === 'left-over'));
  assert.ok(!t.tasks.some((x) => x.text === 'done-one'));
  assert.equal(t.recentRates[0].rate, 0.5);
});

test('morning planning nudge fires when no main goal is set', () => {
  const { t, events } = boot('2026-06-06', 'morning');
  t.ctx.nudge = allowOnce();
  t.tick();
  assert.ok(events.some(([e, p]) => e === 'nudge' && p.category === 'plan'));
});

test('no planning nudge once a main goal exists', () => {
  const { t, events } = boot('2026-06-06', 'morning');
  t.ctx.nudge = allowOnce();
  t.add('my goal', { main: true });
  events.length = 0;
  t.tick();
  assert.ok(!events.some(([e]) => e === 'nudge'));
});

test('serialize/hydrate round-trips including ids and streak', () => {
  const { t } = boot();
  const m = t.add('keep', { main: true });
  t.complete(m.id);
  t.add('pending');
  const slice = t.serialize();

  const t2 = new TasksSystem({ bus: new EventBus(), clock: fakeClock(), nudge: noNudge });
  t2.init();
  t2.hydrate(slice);
  assert.equal(t2.tasks.length, 2);
  assert.equal(t2.streakDays, 1);
  // new ids keep incrementing, no collision with restored ones
  const added = t2.add('after restore');
  assert.equal(t2.tasks.filter((x) => x.id === added.id).length, 1);
});
