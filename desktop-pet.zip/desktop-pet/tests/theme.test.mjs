import { test } from 'node:test';
import assert from 'node:assert/strict';
import { bucketForHour, themeForHour, themeFor, rgba } from '../src/ui/Theme.js';

test('bucketForHour classifies the day', () => {
  assert.equal(bucketForHour(6), 'morning');
  assert.equal(bucketForHour(11), 'morning');
  assert.equal(bucketForHour(12), 'day');
  assert.equal(bucketForHour(16), 'day');
  assert.equal(bucketForHour(17), 'evening');
  assert.equal(bucketForHour(21), 'evening');
  assert.equal(bucketForHour(22), 'night');
  assert.equal(bucketForHour(3), 'night');
});

test('themeForHour returns a complete theme', () => {
  const t = themeForHour(19); // evening
  assert.equal(t.name, 'evening');
  assert.equal(typeof t.glow, 'string');
  assert.ok(t.glowAlpha > 0 && t.glowAlpha < 1);
  assert.ok(t.shadowScale > 0);
  assert.ok(t.shadowAlpha >= 0);
});

test('evening has a longer shadow than midday', () => {
  assert.ok(themeForHour(19).shadowScale > themeForHour(13).shadowScale);
});

test('themeFor accepts a Date', () => {
  const t = themeFor(new Date(2026, 0, 1, 8, 0, 0));
  assert.equal(t.name, 'morning');
});

test('rgba converts hex + alpha correctly', () => {
  assert.equal(rgba('#ffe7a8', 0.18), 'rgba(255,231,168,0.18)');
  assert.equal(rgba('#9db4ff', 0), 'rgba(157,180,255,0)');
});
