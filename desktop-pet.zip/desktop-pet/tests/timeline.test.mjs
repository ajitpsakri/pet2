import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TimelineSystem, crossedThreshold } from '../src/systems/timeline/TimelineSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const bus = new EventBus();
  const clock = { dayKey: () => '2026-06-08' };
  const celebrations = [];
  bus.on('celebrate', (p) => celebrations.push(p));
  const tl = new TimelineSystem({ bus, clock });
  tl.init();
  return { bus, tl, celebrations };
}

test('crossedThreshold fires only on exact thresholds', () => {
  assert.equal(crossedThreshold(10, [10, 50]), true);
  assert.equal(crossedThreshold(11, [10, 50]), false);
});

test('the first day together is recorded on init', () => {
  const { tl } = boot();
  assert.ok(tl.entries.some((e) => e.kind === 'firstday'));
});

test('pets received accumulate and hit a milestone at 10', () => {
  const { bus, tl, celebrations } = boot();
  for (let i = 0; i < 10; i++) bus.emit('pet:petted', {});
  assert.equal(tl.counters.pets, 10);
  assert.ok(tl.entries.some((e) => e.kind === 'milestone' && /10 pets/.test(e.text)));
  assert.ok(celebrations.some((c) => c.kind === 'milestone'));
});

test('fetches accumulate toward their own milestones', () => {
  const { bus, tl } = boot();
  for (let i = 0; i < 10; i++) bus.emit('fetch:caught', {});
  assert.ok(tl.entries.some((e) => /10 games of fetch/.test(e.text)));
});

test('meals shared are tracked', () => {
  const { bus, tl } = boot();
  for (let i = 0; i < 10; i++) bus.emit('feeding:meal', { meal: 'lunch' });
  assert.equal(tl.counters.meals, 10);
  assert.ok(tl.entries.some((e) => /10 meals/.test(e.text)));
});

test('level-ups are recorded, with a milestone at level 10', () => {
  const { bus, tl } = boot();
  bus.emit('pet:levelup', { level: 4 });
  assert.ok(tl.entries.some((e) => e.kind === 'level' && /level 4/.test(e.text)));
  bus.emit('pet:levelup', { level: 10 });
  assert.ok(tl.entries.some((e) => e.kind === 'milestone' && /Level 10/.test(e.text)));
});

test('friendship growth is recorded only when it rises', () => {
  const { bus, tl } = boot();
  bus.emit('relationship:changed', { friendship: 2 });
  bus.emit('relationship:changed', { friendship: 2 });
  bus.emit('relationship:changed', { friendship: 3 });
  assert.equal(tl.entries.filter((e) => e.kind === 'friendship').length, 2);
});

test('anniversaries are noted', () => {
  const { tl } = boot();
  tl.noteDaysTogether(7);
  assert.ok(tl.entries.some((e) => /One week/.test(e.text)));
  tl.noteDaysTogether(365);
  assert.ok(tl.entries.some((e) => /One year/.test(e.text)));
});

test('list() is newest-first', () => {
  const { bus, tl } = boot();
  bus.emit('pet:levelup', { level: 2 });
  bus.emit('pet:levelup', { level: 3 });
  assert.match(tl.list()[0].text, /level 3/);
});

test('serialize/hydrate round-trips memories', () => {
  const { bus, tl } = boot();
  bus.emit('pet:petted', {});
  bus.emit('relationship:changed', { friendship: 5 });
  const slice = tl.serialize();
  const tl2 = new TimelineSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-08' } });
  tl2.hydrate(slice);
  tl2.init();
  assert.equal(tl2.counters.pets, 1);
  assert.equal(tl2._lastFriendship, 5);
});

test('dispose stops recording', () => {
  const { bus, tl } = boot();
  tl.dispose();
  bus.emit('pet:petted', {});
  assert.equal(tl.counters.pets, 0);
});
