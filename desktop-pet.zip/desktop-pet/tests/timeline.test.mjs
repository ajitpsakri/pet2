import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TimelineSystem, crossedThreshold } from '../src/systems/timeline/TimelineSystem.js';
import { EventBus } from '../src/core/EventBus.js';

function boot() {
  const bus = new EventBus();
  const clock = { dayKey: () => '2026-06-06' };
  const celebrations = [];
  bus.on('celebrate', (p) => celebrations.push(p));
  const tl = new TimelineSystem({ bus, clock });
  tl.init();
  return { bus, tl, celebrations };
}

test('crossedThreshold only fires on exact threshold values', () => {
  assert.equal(crossedThreshold(10, [1, 10, 25]), true);
  assert.equal(crossedThreshold(11, [1, 10, 25]), false);
});

test('focus sprints increment a counter and record a milestone at the 1st', () => {
  const { bus, tl, celebrations } = boot();
  bus.emit('coding:focus:done', {});
  assert.equal(tl.counters.focus, 1);
  // 1 is a threshold -> milestone entry + celebrate
  assert.ok(tl.entries.some((e) => e.kind === 'milestone'));
  assert.ok(celebrations.some((c) => c.kind === 'milestone'));
});

test('non-threshold counts do not create milestone entries', () => {
  const { bus, tl } = boot();
  for (let i = 0; i < 5; i++) bus.emit('task:done', {}); // 5 is not a task threshold
  assert.equal(tl.counters.tasks, 5);
  assert.equal(tl.entries.filter((e) => e.kind === 'milestone').length, 0);
});

test('hitting 10 tasks records a together-milestone', () => {
  const { bus, tl } = boot();
  for (let i = 0; i < 10; i++) bus.emit('task:done', {});
  assert.ok(tl.entries.some((e) => e.kind === 'milestone' && /10 tasks/.test(e.text)));
});

test('project completion always records a moment with its name', () => {
  const { bus, tl } = boot();
  bus.emit('project:done', { id: 'p1', name: 'Firmware v2' });
  assert.ok(tl.entries.some((e) => e.kind === 'project' && /Firmware v2/.test(e.text)));
  assert.equal(tl.counters.projects, 1); // also a 1-project milestone
  assert.ok(tl.entries.some((e) => e.kind === 'milestone'));
});

test('learning goal done records the goal text', () => {
  const { bus, tl } = boot();
  bus.emit('learning:goaldone', { id: 'g1', text: 'Finish DDIA' });
  assert.ok(tl.entries.some((e) => e.kind === 'learngoal' && /Finish DDIA/.test(e.text)));
});

test('study minutes accumulate and cross hour milestones once', () => {
  const { bus, tl } = boot();
  bus.emit('learning:study', { min: 60 * 9 });
  assert.equal(tl.entries.filter((e) => e.kind === 'milestone').length, 0); // under 10h
  bus.emit('learning:study', { min: 120 }); // now 11h -> crosses 10h
  assert.ok(tl.entries.some((e) => /10 hours of study/.test(e.text)));
});

test('friendship level-ups are recorded only when the level increases', () => {
  const { bus, tl } = boot();
  bus.emit('relationship:changed', { friendship: 2 });
  bus.emit('relationship:changed', { friendship: 2 }); // no change
  bus.emit('relationship:changed', { friendship: 3 });
  assert.equal(tl.entries.filter((e) => e.kind === 'friendship').length, 2);
});

test('pet level-ups are recorded', () => {
  const { bus, tl } = boot();
  bus.emit('pet:levelup', { level: 4 });
  assert.ok(tl.entries.some((e) => e.kind === 'level' && /level 4/.test(e.text)));
});

test('list() returns newest first', () => {
  const { bus, tl } = boot();
  bus.emit('pet:levelup', { level: 2 });
  bus.emit('pet:levelup', { level: 3 });
  const list = tl.list();
  assert.match(list[0].text, /level 3/);
});

test('serialize/hydrate round-trips entries and counters', () => {
  const { bus, tl } = boot();
  bus.emit('coding:focus:done', {});
  bus.emit('relationship:changed', { friendship: 5 });
  const slice = tl.serialize();
  const tl2 = new TimelineSystem({ bus: new EventBus(), clock: { dayKey: () => '2026-06-06' } });
  tl2.init();
  tl2.hydrate(slice);
  assert.equal(tl2.counters.focus, 1);
  assert.equal(tl2._lastFriendship, 5);
  assert.ok(tl2.entries.length >= 1);
});

test('dispose stops further recording', () => {
  const { bus, tl } = boot();
  tl.dispose();
  bus.emit('coding:focus:done', {});
  assert.equal(tl.counters.focus, 0);
});
