import { test } from 'node:test';
import assert from 'node:assert/strict';
import { chooseMove } from '../src/systems/uno/ai.js';
import { canPlay, makeRng } from '../src/systems/uno/engine.js';
import { UnoSystem, badgesFor } from '../src/systems/uno/UnoSystem.js';
import { EventBus } from '../src/core/EventBus.js';

// ---- AI -------------------------------------------------------------------

test('AI draws when it has no legal move', () => {
  const hand = [{ color: 'blue', value: '3' }, { color: 'green', value: '7' }];
  const mv = chooseMove(hand, 'red', '9', 7, 'medium');
  assert.equal(mv.type, 'draw');
});

test('every difficulty only ever returns a legal play', () => {
  const hand = [
    { color: 'red', value: '5' }, { color: 'blue', value: '2' },
    { color: 'wild', value: 'wild' }, { color: 'green', value: 'skip' },
  ];
  for (const diff of ['easy', 'medium', 'smart']) {
    const mv = chooseMove(hand, 'red', '9', 5, diff, makeRng(1));
    assert.equal(mv.type, 'play');
    assert.ok(canPlay(hand[mv.index], 'red', '9'));
  }
});

test('a wild play always comes with a chosen colour', () => {
  const hand = [{ color: 'wild', value: 'wild4' }]; // only a wild is legal
  const mv = chooseMove(hand, 'red', '9', 5, 'smart', makeRng(2));
  assert.equal(mv.type, 'play');
  assert.ok(['red', 'yellow', 'green', 'blue'].includes(mv.chosenColor));
});

test('medium/smart hoard wilds when a normal card is legal', () => {
  const hand = [{ color: 'red', value: '4' }, { color: 'wild', value: 'wild' }];
  const mv = chooseMove(hand, 'red', '9', 7, 'medium', makeRng(3));
  assert.notEqual(hand[mv.index].color, 'wild'); // plays the red, keeps the wild
});

test('smart dog picks the colour it holds most of for a wild', () => {
  const hand = [
    { color: 'wild', value: 'wild' },
    { color: 'blue', value: '1' }, { color: 'blue', value: '7' }, { color: 'blue', value: '9' },
    { color: 'red', value: '2' },
  ];
  const mv = chooseMove(hand, 'green', '5', 7, 'smart', makeRng(4)); // only wild is legal
  assert.equal(mv.chosenColor, 'blue');
});

test('when the opponent is low, the dog disrupts with an action card', () => {
  const hand = [{ color: 'red', value: '1' }, { color: 'red', value: 'draw2' }];
  const mv = chooseMove(hand, 'red', '9', 1, 'smart', makeRng(5));
  assert.equal(hand[mv.index].value, 'draw2');
});

test('otherwise the dog sheds its highest-value number card', () => {
  const hand = [{ color: 'red', value: '2' }, { color: 'red', value: '9' }];
  const mv = chooseMove(hand, 'red', '4', 7, 'medium', makeRng(6));
  assert.equal(hand[mv.index].value, '9');
});

// ---- System / progression -------------------------------------------------

function sys() {
  const bus = new EventBus();
  const events = [];
  bus.on('celebrate', (p) => events.push(['celebrate', p]));
  bus.on('uno:badge', (p) => events.push(['badge', p]));
  return { bus, events, uno: new UnoSystem({ bus }) };
}

test('a win bumps wins + streak and grants the first-win badge + XP', () => {
  const { uno, events } = sys();
  uno.recordGame(0, 'easy', { red: 3 });
  assert.equal(uno.wins, 1);
  assert.equal(uno.streak, 1);
  assert.ok(uno.badges.includes('first_win'));
  assert.ok(events.some(([t, p]) => t === 'celebrate' && p.kind === 'uno' && p.xp > 0));
  assert.ok(events.some(([t]) => t === 'badge'));
});

test('a loss resets the streak but still counts the game', () => {
  const { uno } = sys();
  uno.recordGame(0, 'easy', {});
  uno.recordGame(1, 'easy', {});
  assert.equal(uno.gamesPlayed, 2);
  assert.equal(uno.wins, 1);
  assert.equal(uno.streak, 0);
});

test('three wins in a row unlocks the hat-trick badge', () => {
  const { uno } = sys();
  uno.recordGame(0, 'easy', {});
  uno.recordGame(0, 'easy', {});
  uno.recordGame(0, 'easy', {});
  assert.equal(uno.longestStreak, 3);
  assert.ok(uno.badges.includes('streak_3'));
});

test('beating the Smart Dog is tracked and badged', () => {
  const { uno } = sys();
  uno.recordGame(0, 'smart', {});
  assert.equal(uno.beatSmart, true);
  assert.ok(badgesFor(uno).includes('beat_smart'));
});

test('favourite colour aggregates human colour usage across games', () => {
  const { uno } = sys();
  uno.recordGame(1, 'easy', { blue: 2 });
  uno.recordGame(1, 'easy', { blue: 3, red: 1 });
  assert.equal(uno.favoriteColor(), 'blue');
});

test('serialize/hydrate round-trips progression', () => {
  const { uno } = sys();
  uno.recordGame(0, 'smart', { green: 4 });
  const slice = uno.serialize();
  const u2 = new UnoSystem({ bus: new EventBus() });
  u2.hydrate(slice);
  assert.equal(u2.wins, 1);
  assert.equal(u2.beatSmart, true);
  assert.equal(u2.favoriteColor(), 'green');
  assert.deepEqual(u2.badges, uno.badges);
});
