import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createDeck, shuffle, makeRng, canPlay, legalMoves, newGame, top, other,
  draw, play, drawAndPass, favoriteColor, COLORS,
} from '../src/systems/uno/engine.js';

test('a standard deck has 108 cards with correct composition', () => {
  const d = createDeck();
  assert.equal(d.length, 108);
  assert.equal(d.filter((c) => c.value === 'wild').length, 4);
  assert.equal(d.filter((c) => c.value === 'wild4').length, 4);
  assert.equal(d.filter((c) => c.color === 'red' && c.value === '0').length, 1);
  assert.equal(d.filter((c) => c.color === 'red' && c.value === '5').length, 2);
  assert.equal(d.filter((c) => c.color === 'blue' && c.value === 'skip').length, 2);
});

test('shuffle is deterministic for a fixed seed and preserves cards', () => {
  const a = shuffle(createDeck(), makeRng(42));
  const b = shuffle(createDeck(), makeRng(42));
  assert.deepEqual(a.map((c) => `${c.color}-${c.value}`), b.map((c) => `${c.color}-${c.value}`));
  assert.equal(a.length, 108);
});

test('canPlay matches colour, value, or any wild', () => {
  assert.equal(canPlay({ color: 'red', value: '5' }, 'red', '9'), true); // colour
  assert.equal(canPlay({ color: 'blue', value: '9' }, 'red', '9'), true); // value
  assert.equal(canPlay({ color: 'wild', value: 'wild' }, 'red', '9'), true); // wild
  assert.equal(canPlay({ color: 'blue', value: '3' }, 'red', '9'), false);
});

test('newGame deals 7 each, a non-action starter, and it is human first', () => {
  const s = newGame(7);
  assert.equal(s.hands[0].length, 7);
  assert.equal(s.hands[1].length, 7);
  assert.equal(s.turn, 0);
  assert.equal(top(s).color !== 'wild', true);
  assert.ok(!['skip', 'reverse', 'draw2'].includes(top(s).value));
  assert.equal(s.currentColor, top(s).color);
});

test('playing a number card passes the turn to the opponent', () => {
  const s = newGame(3);
  // Force a known hand/top.
  s.hands[0] = [{ id: 1, color: s.currentColor, value: '7' }, { id: 2, color: 'blue', value: '1' }];
  const ev = play(s, 0, 0);
  assert.equal(ev.error, undefined);
  assert.equal(ev.skipped, false);
  assert.equal(s.turn, 1);
  assert.equal(top(s).value, '7');
});

test('draw2 makes the opponent draw two and skips them (player goes again)', () => {
  const s = newGame(5);
  s.hands[0] = [{ id: 1, color: s.currentColor, value: 'draw2' }, { id: 2, color: 'red', value: '4' }];
  const before = s.hands[1].length;
  const ev = play(s, 0, 0);
  assert.equal(ev.drew, 2);
  assert.equal(s.hands[1].length, before + 2);
  assert.equal(s.turn, 0); // opponent skipped
});

test('skip and reverse both make the player go again in two-player', () => {
  const s = newGame(9);
  s.hands[0] = [{ id: 1, color: s.currentColor, value: 'skip' }, { id: 2, color: 'red', value: '2' }];
  play(s, 0, 0);
  assert.equal(s.turn, 0);
});

test('wild sets the active colour; wild4 also draws four and skips', () => {
  const s = newGame(11);
  s.hands[0] = [{ id: 1, color: 'wild', value: 'wild' }, { id: 2, color: 'red', value: '2' }];
  const ev = play(s, 0, 0, 'green');
  assert.equal(s.currentColor, 'green');
  assert.equal(ev.color, 'green');
  assert.equal(s.turn, 1);

  const s2 = newGame(12);
  s2.hands[0] = [{ id: 1, color: 'wild', value: 'wild4' }, { id: 2, color: 'red', value: '2' }];
  const before = s2.hands[1].length;
  const ev2 = play(s2, 0, 0, 'blue');
  assert.equal(s2.currentColor, 'blue');
  assert.equal(ev2.drew, 4);
  assert.equal(s2.hands[1].length, before + 4);
  assert.equal(s2.turn, 0);
});

test('illegal plays and out-of-turn plays are rejected', () => {
  const s = newGame(13);
  s.currentColor = 'red';
  s.discard = [{ id: 9, color: 'red', value: '9' }];
  s.hands[0] = [{ id: 1, color: 'blue', value: '3' }];
  assert.equal(play(s, 0, 0).error, 'illegal');
  assert.equal(play(s, 1, 0).error, 'not-your-turn');
});

test('emptying your hand wins the game', () => {
  const s = newGame(15);
  s.hands[0] = [{ id: 1, color: s.currentColor, value: '6' }];
  const ev = play(s, 0, 0);
  assert.equal(ev.win, true);
  assert.equal(s.status, 'won');
  assert.equal(s.winner, 0);
});

test('drawAndPass draws one and passes the turn', () => {
  const s = newGame(17);
  const before = s.hands[0].length;
  const ev = drawAndPass(s, 0);
  assert.equal(s.hands[0].length, before + 1);
  assert.equal(s.turn, 1);
  assert.equal(ev.type, 'draw');
});

test('draw reshuffles the discard when the draw pile is exhausted', () => {
  const s = newGame(19);
  // Drain the draw pile into a big discard.
  s.discard = s.discard.concat(s.drawPile.splice(0));
  assert.equal(s.drawPile.length, 0);
  const got = draw(s, 0, 1);
  assert.equal(got.length, 1); // refilled from discard
});

test('favoriteColor reports the most-played colour for a player', () => {
  const s = newGame(21);
  s.colorPlays[0] = { red: 3, blue: 1 };
  assert.equal(favoriteColor(s, 0), 'red');
  assert.equal(other(0), 1);
  assert.ok(COLORS.includes('green'));
});
