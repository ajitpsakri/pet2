/**
 * tools/genicons.js
 * ----------------------------------------------------------------------------
 * Generates build/icon.png (256×256) — the friendly teal creature — using only
 * Node's built-in zlib. No image libraries, no binary assets checked in: the
 * icon is drawn procedurally and PNG-encoded by hand. This keeps the repo
 * text-only and the whole project provably offline.
 *
 * Run:  node tools/genicons.js
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const SIZE = 256;

// ---------------------------------------------------------------------------
// Tiny software rasterizer (straight-alpha, source-over compositing)
// ---------------------------------------------------------------------------

// RGBA float buffer.
const buf = new Float32Array(SIZE * SIZE * 4); // r,g,b,a in 0..255

function over(x, y, r, g, b, a) {
  if (x < 0 || y < 0 || x >= SIZE || y >= SIZE || a <= 0) return;
  const i = (y * SIZE + x) * 4;
  const sa = a / 255;
  const da = buf[i + 3] / 255;
  const outA = sa + da * (1 - sa);
  if (outA <= 0) return;
  buf[i] = (r * sa + buf[i] * da * (1 - sa)) / outA;
  buf[i + 1] = (g * sa + buf[i + 1] * da * (1 - sa)) / outA;
  buf[i + 2] = (b * sa + buf[i + 2] * da * (1 - sa)) / outA;
  buf[i + 3] = outA * 255;
}

const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

/** Filled circle with ~1px anti-aliased edge. */
function circle(cx, cy, rad, [r, g, b], alpha = 1) {
  const x0 = Math.max(0, Math.floor(cx - rad - 1));
  const x1 = Math.min(SIZE - 1, Math.ceil(cx + rad + 1));
  const y0 = Math.max(0, Math.floor(cy - rad - 1));
  const y1 = Math.min(SIZE - 1, Math.ceil(cy + rad + 1));
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const d = Math.hypot(x + 0.5 - cx, y + 0.5 - cy);
      const cov = clamp01(rad - d + 0.5) * alpha;
      if (cov > 0) over(x, y, r, g, b, cov * 255);
    }
  }
}

/** Filled ellipse with ~1px anti-aliased edge. */
function ellipse(cx, cy, rx, ry, [r, g, b], alpha = 1) {
  const x0 = Math.max(0, Math.floor(cx - rx - 1));
  const x1 = Math.min(SIZE - 1, Math.ceil(cx + rx + 1));
  const y0 = Math.max(0, Math.floor(cy - ry - 1));
  const y1 = Math.min(SIZE - 1, Math.ceil(cy + ry + 1));
  const k = Math.min(rx, ry);
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const dn = Math.hypot((x + 0.5 - cx) / rx, (y + 0.5 - cy) / ry);
      const cov = clamp01((1 - dn) * k + 0.5) * alpha;
      if (cov > 0) over(x, y, r, g, b, cov * 255);
    }
  }
}

// ---------------------------------------------------------------------------
// Draw the creature (mirrors the palette in src/animations/sprites.js)
// ---------------------------------------------------------------------------

const C = {
  body: [111, 211, 199],
  ear: [92, 196, 183],
  belly: [216, 245, 240],
  outline: [45, 107, 99],
  eye: [35, 66, 61],
  cheek: [255, 154, 162],
  white: [255, 255, 255],
};

const cx = 128;
const bodyCy = 150;
const bodyR = 86;
const earOff = 56;
const earY = 80;
const earR = 30;
const OUT = 5; // outline thickness

// 1) Union silhouette outline (ears + body), drawn first so the fills leave a rim.
circle(cx - earOff, earY, earR + OUT, C.outline);
circle(cx + earOff, earY, earR + OUT, C.outline);
circle(cx, bodyCy, bodyR + OUT, C.outline);

// 2) Fills on top.
circle(cx - earOff, earY, earR, C.ear);
circle(cx + earOff, earY, earR, C.ear);
circle(cx, bodyCy, bodyR, C.body);

// 3) Belly.
ellipse(cx, bodyCy + 26, bodyR * 0.6, bodyR * 0.52, C.belly);

// 4) Cheeks.
circle(cx - 46, bodyCy + 6, 15, C.cheek, 0.85);
circle(cx + 46, bodyCy + 6, 15, C.cheek, 0.85);

// 5) Eyes + catchlights.
circle(cx - 30, bodyCy - 18, 13, C.eye);
circle(cx + 30, bodyCy - 18, 13, C.eye);
circle(cx - 26, bodyCy - 23, 4.5, C.white);
circle(cx + 34, bodyCy - 23, 4.5, C.white);

// 6) Little smile (two small arcs approximated with overlapping circles minus body).
for (let a = 0.15; a <= Math.PI - 0.15; a += 0.02) {
  const sx = cx + Math.cos(a) * 16;
  const sy = bodyCy + 10 + Math.sin(a) * 9;
  circle(sx, sy, 2.2, C.outline);
}

// ---------------------------------------------------------------------------
// Encode the float buffer as a PNG (truecolour + alpha, 8-bit)
// ---------------------------------------------------------------------------

function makeCrcTable() {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
}
const CRC_TABLE = makeCrcTable();
function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const body = Buffer.concat([typeBuf, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function encodePng() {
  // Raw scanlines: each prefixed with a filter byte (0 = none).
  const raw = Buffer.alloc(SIZE * (SIZE * 4 + 1));
  let p = 0;
  for (let y = 0; y < SIZE; y++) {
    raw[p++] = 0;
    for (let x = 0; x < SIZE; x++) {
      const i = (y * SIZE + x) * 4;
      raw[p++] = Math.round(buf[i]) & 0xff;
      raw[p++] = Math.round(buf[i + 1]) & 0xff;
      raw[p++] = Math.round(buf[i + 2]) & 0xff;
      raw[p++] = Math.round(buf[i + 3]) & 0xff;
    }
  }

  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(SIZE, 0);
  ihdr.writeUInt32BE(SIZE, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type: truecolour + alpha
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter
  ihdr[12] = 0; // interlace

  const idat = zlib.deflateSync(raw, { level: 9 });

  return Buffer.concat([
    sig,
    chunk('IHDR', ihdr),
    chunk('IDAT', idat),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// ---------------------------------------------------------------------------
// Write it out
// ---------------------------------------------------------------------------

const outDir = path.join(__dirname, '..', 'build');
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, 'icon.png');
fs.writeFileSync(outPath, encodePng());
console.log(`Wrote ${outPath} (${SIZE}×${SIZE})`);
