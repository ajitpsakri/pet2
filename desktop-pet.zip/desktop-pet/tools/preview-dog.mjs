/**
 * tools/preview-dog.mjs  (dev-only, not shipped)
 * Renders the puppy across several emotions to a PNG using a tiny software
 * rasterizer, so the procedural face can be eyeballed without a browser. It
 * mirrors the exact GEOM/PALETTE from sprites.js (curved ears/tongue are
 * approximated with ellipses/triangles — enough to judge proportions & charm).
 */
import fs from 'node:fs';
import zlib from 'node:zlib';
import { GEOM, PALETTE } from '../src/animations/sprites.js';

const W = 360, H = 360;
const buf = new Float32Array(W * H * 4);

const hex = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

function over(x, y, r, g, b, a) {
  x = Math.round(x); y = Math.round(y);
  if (x < 0 || y < 0 || x >= W || y >= H || a <= 0) return;
  const i = (y * W + x) * 4, sa = a / 255, da = buf[i + 3] / 255, o = sa + da * (1 - sa);
  if (o <= 0) return;
  buf[i] = (r * sa + buf[i] * da * (1 - sa)) / o;
  buf[i + 1] = (g * sa + buf[i + 1] * da * (1 - sa)) / o;
  buf[i + 2] = (b * sa + buf[i + 2] * da * (1 - sa)) / o;
  buf[i + 3] = o * 255;
}

// drawing happens through a transform (translate + uniform scale + xflip)
let T = { ox: 0, oy: 0, s: 1, fx: 1 };
const tx = (x, y) => [T.ox + x * T.s * T.fx, T.oy + y * T.s];

function ellipse(cx, cy, rx, ry, col, alpha = 1) {
  const [r, g, b] = typeof col === 'string' ? hex(col) : col;
  const s = T.s;
  rx *= s; ry *= s;
  const [px, py] = tx(cx, cy);
  const x0 = Math.floor(px - rx - 1), x1 = Math.ceil(px + rx + 1);
  const y0 = Math.floor(py - ry - 1), y1 = Math.ceil(py + ry + 1);
  const k = Math.min(rx, ry);
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
    const dn = Math.hypot((x + 0.5 - px) / rx, (y + 0.5 - py) / ry);
    const cov = clamp01((1 - dn) * k + 0.5) * alpha;
    if (cov > 0) over(x, y, r, g, b, cov * 255);
  }
}
function circle(cx, cy, rad, col, alpha = 1) { ellipse(cx, cy, rad, rad, col, alpha); }

function triangle(p0, p1, p2, col, alpha = 1) {
  const [r, g, b] = typeof col === 'string' ? hex(col) : col;
  const A = tx(...p0), B = tx(...p1), C = tx(...p2);
  const minx = Math.floor(Math.min(A[0], B[0], C[0])), maxx = Math.ceil(Math.max(A[0], B[0], C[0]));
  const miny = Math.floor(Math.min(A[1], B[1], C[1])), maxy = Math.ceil(Math.max(A[1], B[1], C[1]));
  const area = (B[0] - A[0]) * (C[1] - A[1]) - (B[1] - A[1]) * (C[0] - A[0]);
  if (Math.abs(area) < 1e-6) return;
  for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
    const px = x + 0.5, py = y + 0.5;
    const w0 = ((B[0] - A[0]) * (py - A[1]) - (B[1] - A[1]) * (px - A[0])) / area;
    const w1 = ((C[0] - B[0]) * (py - B[1]) - (C[1] - B[1]) * (px - B[0])) / area;
    const w2 = ((A[0] - C[0]) * (py - C[1]) - (A[1] - C[1]) * (px - C[0])) / area;
    if (w0 >= 0 && w1 >= 0 && w2 >= 0) over(x, y, r, g, b, alpha * 255);
  }
}
function seg(p0, p1, width, col, alpha = 1) {
  const A = tx(...p0), B = tx(...p1);
  const n = Math.ceil(Math.hypot(B[0] - A[0], B[1] - A[1]));
  const [r, g, b] = typeof col === 'string' ? hex(col) : col;
  const rad = (width * T.s) / 2;
  for (let i = 0; i <= n; i++) {
    const t = i / n, x = A[0] + (B[0] - A[0]) * t, y = A[1] + (B[1] - A[1]) * t;
    for (let yy = Math.floor(y - rad); yy <= Math.ceil(y + rad); yy++)
      for (let xx = Math.floor(x - rad); xx <= Math.ceil(x + rad); xx++) {
        const cov = clamp01(rad - Math.hypot(xx + 0.5 - x, yy + 0.5 - y) + 0.5);
        if (cov > 0) over(xx, yy, r, g, b, cov * alpha * 255);
      }
  }
}

// One dog, approximating sprites.js with the shared GEOM. `pose` mirrors the
// Animator pose fields; `mood`/`name` drive expression like the real renderer.
function dog(cx, cy, scale, pose, name, mood) {
  T = { ox: cx, oy: cy, s: scale, fx: 1 };
  const G = GEOM, droop = pose.droop || 0, perk = pose.earPerk, eo = pose.eyeOpen, mo = pose.mouthOpen;
  const feisty = name === 'bark' || mood === 'excited';
  const worried = mood === 'sad' || mood === 'sick' || droop > 0.5;

  // shadow
  ellipse(0, G.shadowY, 23, 6, '#000', 0.18);
  // tail (approx triangle)
  triangle([-15, 4], [-26, -8], [-13, 10], PALETTE.body);
  // hind paws
  ellipse(-12, 27, 6.5, 5, PALETTE.body); ellipse(12, 27, 6.5, 5, PALETTE.body);
  // body + belly
  ellipse(G.body.cx, G.body.cy + droop * 3, G.body.rx, G.body.ry - droop * 2, PALETTE.body);
  ellipse(G.belly.cx, G.belly.cy + droop * 2, G.belly.rx, G.belly.ry, PALETTE.belly);
  // front paws
  ellipse(-7, 30, 6, 4.5, PALETTE.belly); ellipse(7, 30, 6, 4.5, PALETTE.belly);
  // ears (approx as vertical ellipses, lifted by perk)
  const earLift = perk * 6;
  ellipse(-G.earPivot.dx - 2, G.earPivot.y + 8 - earLift, 6, 11, PALETTE.ear);
  ellipse(G.earPivot.dx + 2, G.earPivot.y + 8 - earLift, 6, 11, PALETTE.ear);
  // head + snout
  ellipse(G.head.cx, G.head.cy, G.head.rx, G.head.ry, PALETTE.body);
  ellipse(G.snout.cx, G.snout.cy, G.snout.rx, G.snout.ry, PALETTE.belly);
  // eyes
  for (const sx of [-1, 1]) {
    const ex = sx * G.eye.dx;
    if (eo < 0.12) seg([ex - 3, G.eye.y], [ex + 3, G.eye.y], 1.6, PALETTE.eye);
    else { ellipse(ex, G.eye.y, G.eye.r, G.eye.r * 1.15 * eo, PALETTE.eye); circle(ex + sx, G.eye.y - 1.4 * eo, 1.1, PALETTE.white); }
  }
  // brows
  let brow = 0; if (feisty) brow = 0.5; else if (worried) brow = -0.45;
  if (Math.abs(brow) > 0.01 && eo >= 0.12) for (const sx of [-1, 1])
    seg([sx * G.brow.dx - sx * 2.4, G.brow.y + brow * 2], [sx * G.brow.dx + sx * 2.4, G.brow.y - brow * 2], 1.8, PALETTE.outline);
  // nose
  ellipse(G.nose.cx, G.nose.cy, G.nose.rx, G.nose.ry, PALETTE.nose);
  // blush
  if ((pose.blush || 0) > 0.02) for (const sx of [-1, 1]) ellipse(sx * G.cheek.dx, G.cheek.y, 3.6, 2.3, PALETTE.cheek, pose.blush * 0.8);
  // mouth + tongue + teeth
  const ny = G.nose.cy + G.nose.ry;
  if (mo > 0.18) {
    ellipse(0, ny + 3 + mo * 1.5, 3 + mo * 2.2, 2 + mo * 3, '#7a3b3b');
    if (mo > 0.3 || feisty) ellipse(0, ny + 5 + mo * 2, 2.2 + mo, 2.4 + mo * 2.2, PALETTE.tongue);
    if (name === 'bark') for (const txx of [-2.2, 2.2]) triangle([txx - 1.2, ny + 1.5], [txx + 1.2, ny + 1.5], [txx, ny + 4], PALETTE.white);
  } else {
    seg([-4.4, ny + 1.6], [-2.6, ny + 2.6], 1.4, PALETTE.outline); seg([-2.6, ny + 2.6], [-0.8, ny + 1.6], 1.4, PALETTE.outline);
    seg([0.8, ny + 1.6], [2.6, ny + 2.6], 1.4, PALETTE.outline); seg([2.6, ny + 2.6], [4.4, ny + 1.6], 1.4, PALETTE.outline);
  }
}

// background
for (let i = 0; i < W * H; i++) { buf[i * 4] = 253; buf[i * 4 + 1] = 251; buf[i * 4 + 2] = 242; buf[i * 4 + 3] = 255; }

const cells = [
  ['idle (relaxed)', { eyeOpen: 1, mouthOpen: 0, earPerk: 0.6, blush: 0, droop: 0 }, 'idle', 'relaxed'],
  ['happy', { eyeOpen: 0.85, mouthOpen: 0.45, earPerk: 1, blush: 0.5, droop: 0 }, 'happy', 'happy'],
  ['sad', { eyeOpen: 0.7, mouthOpen: 0, earPerk: 0.1, blush: 0, droop: 0.7 }, 'sad', 'sad'],
  ['bark (feisty)', { eyeOpen: 1, mouthOpen: 0.7, earPerk: 1, blush: 0.1, droop: 0 }, 'bark', 'excited'],
];
const cw = W / 2, ch = H / 2;
cells.forEach((c, i) => {
  const col = i % 2, row = (i / 2) | 0;
  dog(col * cw + cw / 2, row * ch + ch / 2 + 8, 2.1, c[1], c[2], c[3]);
});

// ---- encode PNG ----
function crcTable() { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; }
const CT = crcTable();
const crc = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CT[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const chunk = (type, data) => { const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0); const body = Buffer.concat([Buffer.from(type, 'ascii'), data]); const cc = Buffer.alloc(4); cc.writeUInt32BE(crc(body), 0); return Buffer.concat([len, body, cc]); };
const raw = Buffer.alloc(H * (W * 4 + 1)); let p = 0;
for (let y = 0; y < H; y++) { raw[p++] = 0; for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; raw[p++] = buf[i] & 255; raw[p++] = buf[i + 1] & 255; raw[p++] = buf[i + 2] & 255; raw[p++] = buf[i + 3] & 255; } }
const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 6;
const png = Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
fs.writeFileSync(new URL('../build/preview-dog.png', import.meta.url), png);
console.log('wrote build/preview-dog.png');
