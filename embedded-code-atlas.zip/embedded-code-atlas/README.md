# Embedded Code Atlas

A **local-first**, fully offline VS Code extension for visualizing and navigating
large embedded, automotive, AUTOSAR, ADAS, and C/C++ codebases. No cloud, no
API calls, no telemetry — source never leaves the machine.

> **Status: v1.1.1 — responsiveness release.** The VS Code progress bar now actually advances during parsing (absolute→delta fix) and names the current file; the Dashboard computes in yielded stages with a visible progress bar ("Analyzing call graph… 3/7") and reports failures with a Show Log / Retry option instead of spinning forever; the hot per-function queries (risk scoring, top-functions) were rewritten from per-row correlated subqueries to single aggregation passes — ~1.4 s instead of minutes at 100k functions; Last built renders as a local date; a Show Log button was added to the home view and nav rail.
> phases are done. The final addition is an AUTOSAR view that recognises standard
> BSW and MCAL module names by filename, places them in the canonical AUTOSAR
> layer stack (Application → RTE → Services → ECU Abstraction → Complex Drivers →
> MCAL → Microcontroller), and flags upward dependencies as conformance
> violations. The tool now offers ten views over a fully-offline index: file,
> function, module, data-flow, state-machine, scheduler, architecture,
> complexity, AUTOSAR, and an aggregate dashboard — plus local explanations.

## AUTOSAR layers (Phase 16)

The **AUTOSAR** view applies automotive domain knowledge on top of the layering
engine. It recognises standard AUTOSAR Basic Software and MCAL modules by their
filename prefix — `Can`, `CanIf`, `Com`, `PduR`, `Dcm`, `EcuM`, `Os`, `Rte`,
`Dio`, `Adc`, `Pwm`, `Spi`, `Port`, `Mcu`, `Wdg`, `Cdd*`, and many more — and
places each into the canonical AUTOSAR layer stack:

```
Application → RTE → Services → ECU Abstraction → Complex Drivers → MCAL → Microcontroller
```

Include dependencies are aggregated between layers, and any that point *upward*
(for example an MCAL driver depending on a Services-layer module, or anything
reaching into the RTE) are flagged red as conformance violations. Insights lists
the recognised modules grouped by layer and every offending file pair. Files
that don't match a standard module are treated as Application code, and the view
tells you up front if no AUTOSAR modules were found at all.

### Note on accuracy

Recognition is by filename convention, which is how AUTOSAR stacks are
conventionally organised, but a project that renames generated modules or buries
them in unusual paths may not be classified correctly. It checks the *static
include* relationship between layers, not runtime RTE port wiring.

## Performance (Phase 15)

Two fronts: package/startup cost and large-graph rendering.

- **Bundling.** `npm run bundle` runs esbuild to produce two self-contained
  CommonJS files — `out/extension.js` (host, with `vscode` external) and
  `out/parseWorker.js` (worker body). The worker is emitted beside the host
  bundle so the Indexer's `path.join(__dirname, 'parseWorker.js')` resolution
  stays correct. `vscode:prepublish` bundles, and `.vscodeignore` then drops
  `node_modules` and sources from the `.vsix`. `npm run compile` keeps the plain
  tsc build (with the `out/index/` layout) for day-to-day development and
  type-checking; both layouts work because the worker path tracks `__dirname`.
- **Large-graph rendering.** The webview enables `hideEdgesOnViewport` and
  `textureOnViewport` so panning a big neighbourhood stays smooth, and uses
  `min-zoomed-font-size` so labels stop rendering once they're too small to
  read. Above ~400 nodes the layout switches to a cheaper fixed-iteration pass
  and edges render as straight "haystack" lines instead of beziers — a level of
  detail that trades arrowheads for frame rate only when the graph is huge.

The worker bundle is validated end-to-end in CI-style by spawning it through
`worker_threads` and round-tripping a real parse request.

## Local explanations (Phase 14)

Select any function or file node and press **Explain** for a plain-English
description, generated locally with no model and no network call.

- **For a function:** where it's defined, its role (RTOS task entry, interrupt
  handler, recursive participant, or uncalled entry point), its cyclomatic
  complexity in words, what it calls (noting unresolved library/macro calls),
  who calls it, and which globals it reads and writes.
- **For a file:** how many files it includes and is included by, how many
  functions it defines and their combined complexity, whether it sits in an
  include cycle, and whether it's a widely-depended-on hotspot.

Every sentence is a template filled from facts the indexer already extracted, so
the explanations are deterministic and verifiable — there is no generated text
that isn't backed by the graph.

## Insights dashboard (Phase 13)

The **Dashboard** is the single screen to open first. It runs every analysis and
presents the results together:

- **Health cards** — one per analysis (files/cycles, functions/recursion,
  modules/circular, globals/multi-writer, state machines, tasks/ISRs,
  layers/violations, complexity), each colour-coded green / amber / red by
  severity and clickable straight into that view.
- **Key findings** — a single prioritised list pulling the actual issues out of
  every analyser (layering violations, include and module cycles, recursion,
  shared-state hazards, high-complexity functions), worst first. Each finding
  links to the view that explains it.

Everything is composed from the cached analyses, so opening the dashboard costs
nothing beyond what the individual views already compute.

## Complexity & risk (Phase 12)

The **Complexity** view turns "where is the scary code?" into a ranked,
heat-coloured picture.

- **Cyclomatic complexity.** Each function gets a heuristic McCabe score — `1`
  plus its decision points (`if` / `for` / `while` / `case` / `catch` and the
  `&&`, `||`, `?` operators). Computed in both engines.
- **Risk score.** Complexity is combined with call-graph coupling:
  `risk = complexity + fan-in + fan-out`. A complex function called from many
  places (high fan-in) is the hardest to change safely.
- **Heat graph.** The top functions by risk are drawn as a call subgraph,
  coloured green → red by complexity. Insights ranks the riskiest functions and
  the files with the most total complexity.

### Note on accuracy

Cyclomatic complexity is approximated lexically (it counts keywords/operators in
the blanked function body), so macros that hide control flow, or `case`
fall-through, can skew it slightly. It is a triage signal, not a certified
metric.

## Architecture & layering (Phase 11)

The **Architecture** view checks the codebase against a layered-architecture
rule: higher layers may depend on lower ones, but a lower layer must never
depend on a higher one.

- **Layer mapping.** Each file is assigned to a layer by matching its path
  against an ordered layer list. The built-in default (top → bottom) is
  `app → service → middleware → driver → bsp → hal → mcal`; override it with the
  `embeddedCodeAtlas.architecture.layers` setting to match your folder names.
- **Violations.** Include edges are aggregated between layers. Any edge that
  points *upward* (a lower layer depending on a higher one) is a violation,
  drawn in red and listed in Insights with the exact file pair responsible.
- **Unlayered code is ignored.** Files matching no layer (shared `common`,
  `util`, `lib`, …) are excluded, so cross-cutting utilities don't masquerade as
  violations.

### Note on accuracy

Layer assignment is purely path-based, and dependencies come from the resolved
include graph (not call edges). A file in a misnamed folder will be mapped
wrong; tune the layer list to fit the project. The check reuses the same include
edges as the dependency and module views.

## RTOS scheduler (Phase 10)

The **Scheduler** view turns the implicit task structure of an RTOS firmware
into an explicit picture.

- **Task detection.** Calls to `xTaskCreate` / `xTaskCreateStatic` /
  `osThreadNew` / `osThreadCreate` are parsed argument-by-argument to pull out
  the entry function, task name, stack size, and priority.
- **Period inference.** Periodic delays (`vTaskDelay`, `vTaskDelayUntil`,
  `osDelay`, …) are recorded per function; a task's period is the delay found in
  its entry function. `vTaskDelayUntil` uses its second argument.
- **ISR detection.** Functions named like `TIM2_IRQHandler`, `*_ISR`,
  `*_Handler` are surfaced as interrupt handlers.
- **Preemption ladder.** ISRs sit on the top row (they preempt everything);
  tasks are ranked below by priority. Insights lists tasks (priority + period)
  and ISRs.

### Note on accuracy

This is a *static* structural view, not a runtime schedule — it shows what the
task set and priorities are, not a real timeline of execution. Periods are read
literally from delay arguments (e.g. `pdMS_TO_TICKS(10)`); priorities expressed
as macros are ordered heuristically. Tasks spawned indirectly (through a wrapper
or a table) may be missed.

## State machines (Phase 9)

The **State Machine** view recognises the most common firmware FSM idiom: a
`switch` on a state variable whose `case` bodies assign new values back to that
same variable. Each `state = NEXT;` inside `case CURRENT:` becomes a
`CURRENT → NEXT` transition, and the machine is drawn as a state diagram.

- **Self-assignment is the signal.** A switch that never reassigns its own
  scrutinee (an ordinary command dispatch, say) is deliberately *not* reported,
  which keeps false positives down.
- **Insights lists every machine** with its state and transition counts; click
  one to draw its diagram. Self-transitions (stay-in-state) render as loops.

It's heuristic: machines built from function-pointer tables or if/else chains
aren't captured yet, and state names come from the `case`/assignment labels.

## Data flow (Phase 8)

The **Data Flow** view answers "what touches this shared variable?" — the
question behind most embedded concurrency and state bugs.

- **Variable model.** The parser extracts file-scope (global) and static
  variables — registers, flags, buffers, config — and records every read and
  write inside function bodies, classified by whether the symbol is the target
  of an assignment / increment (write) or not (read). This runs in both the
  heuristic and clang engines.
- **Read/write graph.** Search a variable to see every function that touches it:
  write edges point *into* the variable (warm, solid), read edges point *out*
  (cool, dashed). Search a function instead to see the variables it accesses.
- **Multi-writer detection.** Insights lists variables written from more than
  one function — shared mutable state that's a re-entrancy / race risk when one
  writer is an ISR and another is the main loop or a different task. It also
  ranks the most-referenced variables.

### Note on accuracy

This is heuristic data flow, not full pointer/alias analysis. It tracks named
global/static variables by lexical reference; it does not follow writes through
pointers, aliases, or struct member paths, and a local variable that shadows a
global can be misattributed. Treat the multi-writer list as a high-value review
prompt, not a proof of a data race.

## Module detection (Phase 7)

The **Module Graph** lifts the view from individual files to subsystems:

- **Folder-based modules.** Files are grouped by directory, at an adjustable
  number of levels below the common root (the *Modules by folder* control).
  Directory layout is treated as the architecture because that's how embedded
  and automotive codebases are actually organised — and it keeps every grouping
  explainable, unlike opaque graph-clustering.
- **Inter-module dependencies.** Every file-level `#include` that crosses a
  module boundary is aggregated into a weighted module→module edge, so thicker
  arrows mean tighter coupling between subsystems.
- **Circular module dependencies.** The same SCC algorithm flags modules that
  depend on each other in a loop — an architectural smell more serious than a
  single file cycle. Cyclic modules get the warning outline and are listed in
  Insights.
- **Drill-down.** Click a module (or use *Show files*) to jump into the File
  Graph showing just that module's files, with all the Phase 5 hotspot and cycle
  cues intact.

Modules are sized by file count, and the Insights tab lists every module with
its file count and how many modules it depends on / is depended on by.

## Call-graph analysis (Phase 6)

The **Function Graph** centres on whatever you search for, then lets you trace
the call structure deliberately:

- **Direction.** Choose *Callees ↓* to follow what a function calls (execution
  flow), *Callers ↑* to see what calls it (impact / blast radius before a
  change), or both. Single-direction views lay out as a top-down tree so depth
  reads naturally; the mixed view stays force-directed.
- **Recursion detection.** Direct and mutual recursion is found with the same
  SCC algorithm used for include cycles; recursive functions get the doubled
  cycle outline, and the Insights tab lists every recursive group.
- **Entry points & hotspots.** Insights lists functions nobody calls (natural
  roots — `main`, ISRs, task bodies) and the most-called functions.
- **Path tracing.** Focus a function, then type a target in *Trace call path*:
  the view draws the shortest call chain between them, or tells you none exists.
  This is the "can this ISR ever reach a blocking/allocating call?" question
  embedded teams actually need answered.

Like the file graph, all of this runs over the cached, resolved call edges and
recomputes only when the index changes.

## Dependency analysis (Phase 5)

In the **File Graph**, switch the side panel to **Insights** to analyse the whole
project's `#include` structure:

- **Circular dependencies.** Every cyclic include chain is detected via Tarjan's
  strongly-connected-components algorithm (O(V+E), computed once per build and
  cached). Click any cycle to draw just that loop in isolation — the fastest way
  to see exactly which headers form the knot.
- **Hotspots.** Files are ranked by *fan-in* (how many other files include them).
  A header with very high fan-in is a change-risk choke point: touching it forces
  a wide rebuild. Click a hotspot to focus the graph on it.
- **Folder clusters.** Files are grouped by the directory just below their common
  root, giving a quick subsystem-size breakdown.

These also drive the graph's appearance: file nodes are **heat-coloured** from
cool to hot by fan-in, and any node inside a cycle gets a doubled warning
outline, so problems are visible at a glance without opening the panel.

### Note on accuracy

Cycle and hotspot analysis is only as good as include resolution, which matches
`#include` targets to indexed files by path/suffix. A target whose basename
exists in several directories can resolve ambiguously, so treat a reported cycle
as a strong signal to verify rather than proof. The clang engine's exact,
compiler-resolved includes (a later phase) remove this ambiguity.

## Graph views (Phase 4)

Open **File Graph** or **Function Graph** and the view renders an interactive,
zoomable graph driven by the index:

- **Search to focus.** Type a file or function name and press Enter (or click
  *Focus*). The view centres on that node and draws its neighbourhood.
- **Expand on demand.** Double-click a node — or select it and click *Expand
  from here* — to grow the slice outward. A **depth** control (1–3 hops) sets how
  far each focus reaches.
- **Overview mode.** With no search term, the view shows the most-connected
  nodes and the edges among them, so you get a sense of shape immediately.
- **Jump to source.** Right-click (or long-press) a node, or use *Open source*
  in the details panel, to open the definition in the editor.
- **Layout controls.** *Fit* reframes the graph; *Re-layout* re-runs the
  force-directed layout.

### Why neighbourhood slices, not the whole graph

A real embedded codebase has tens of thousands of functions; no browser renderer
draws that many nodes interactively. So the host never ships the whole graph — it
expands outward from a focus node by querying the call/include tables and caps
the result at `graph.maxNodes` (default 1500), flagging the slice as *truncated*
when the cap is hit. This keeps rendering smooth regardless of codebase size.

### Why a vendored Cytoscape

The renderer is [Cytoscape.js](https://js.cytoscape.org/), vendored into
`media/vendor/` and loaded from the extension itself — no CDN, no network, no
native code — so it runs on a fully air-gapped machine. The force-directed
`cose` layout ships in the core, and the graph is styled entirely from VS Code
theme tokens so it matches light, dark, and high-contrast themes.

### Known limitations (honest)

- The file graph resolves `#include` targets to indexed files by path/suffix
  match, so an include that matches multiple files (same basename in different
  directories) can draw an approximate edge. The clang engine's accurate include
  resolution is consumed in a later phase.
- Unresolved call targets (e.g. into uninstrumented system headers) appear as
  dashed leaf nodes and cannot be expanded — there is nothing indexed behind
  them.

## Call graph & engines (Phase 3)

Each function definition's body is scanned for call sites, producing
caller→callee edges stored in a `calls` table. Callee names are linked to
concrete function rows by unique-name match (ambiguous/overloaded names are left
unresolved rather than guessed). The Home view shows a live **Call edges** count,
and the index exposes `outgoing(fn)` / `incoming(fn)` neighbourhood queries that
Phase 6 will drive.

Two engines produce the same result shape:

| Engine | Needs | Accuracy | When used |
| --- | --- | --- | --- |
| `heuristic` | nothing | approximate (no macro expansion, no overload resolution) | default; always available |
| `clang` (`clangd`/`libclang` setting) | `clang` on PATH + `compile_commands.json` | accurate — clang resolves calls, members, macros | only when both are present |

The engine is chosen per build: if the `engine` setting asks for accuracy but
there's no compilation database or no working `clang`, the indexer logs the
reason and falls back to the heuristic engine. Even in clang mode, files with no
compile-DB entry (typically headers) are parsed heuristically, so nothing is
skipped. Point the extension at your toolchain's clang with
`embeddedCodeAtlas.clangPath` if it isn't on `PATH`.

### Why a clang AST dump rather than clangd's call hierarchy

clangd's call hierarchy is on-demand per symbol — ideal for interactively
expanding one node (a later phase) but far too slow to bulk-extract a
100k-function graph. `clang -ast-dump=json` emits an entire translation unit's
definitions and calls in one parallelisable pass, which is the right tool for
building the index.

### Known limitations (honest)

- **Header-defined bodies.** The clang engine attributes symbols to the file
  they're located in, so an inline/template function *defined* in a header is
  captured when that header is indexed (heuristically, as it has no compile-DB
  entry), not under the `.cpp` that includes it. Calls *made from* a `.cpp` body
  are fully captured.
- **The `refs` table** (general symbol cross-references) is created in the
  schema but populated in Phase 8 (Variable Flow), where it's actually consumed.
  Phase 3 ships the call graph, which is its headline deliverable.

## Indexing (Phase 2)

Run **Embedded Atlas: Rebuild Index** (or the Build index button on Home). The
indexer:

1. **Discovers** source files via VS Code's file index (honouring excludes) and
   detects the build system (CMake / Make / `compile_commands.json` / generic).
2. **Diffs** against the existing index using a cheap mtime+size check, so only
   new or changed files are reparsed — rescans are fast.
3. **Parses** the changed set across a `worker_threads` pool (one file per
   worker at a time), keeping the UI responsive.
4. **Writes** results to SQLite in batched transactions and persists the DB to
   `.vscode/embedded-atlas/index.sqlite` (configurable).

File saves, creates, and deletes trigger debounced incremental updates
automatically through the workspace watcher.

### Why sql.js (WASM) and not a native module

A native module such as `better-sqlite3` must be recompiled against VS Code's
exact Electron ABI for every version and platform, which breaks routinely on
locked-down corporate machines where rebuilding isn't possible. `sql.js` is pure
WASM with zero native compilation, so it just runs anywhere offline. The
tradeoff is that it holds the database in memory; all access goes through the
`IndexDatabase` interface so a native or out-of-process engine can replace it
for very large workspaces without changing any callers.

### Parsing accuracy

The default `heuristic` engine parses C/C++ without needing the code to compile,
which makes it robust on partial or vendor-locked trees but approximate on
macro-heavy code. Accurate parsing requires correct compile flags — Phase 3 adds
the `clangd`/`libclang` engines that consume a `compile_commands.json`
compilation database.

## Build & run

Requires Node.js 18+ and VS Code 1.85+.

```bash
npm install      # install dev dependencies (typescript, esbuild, @types/vscode)
npm run compile  # type-check and emit to out/ (development build)
```

Then press **F5** in VS Code (or run the "Run Extension" launch config) to open
an Extension Development Host with the extension loaded. Use `npm run watch` for
incremental rebuilds while developing.

For a production build, `npm run bundle` produces the esbuild bundles. To package
a `.vsix`: `npx @vscode/vsce package` (this runs the bundle via `vscode:prepublish`).

## Commands

All are available from the Command Palette under the **Embedded Atlas** category:

| Command | What it does |
| --- | --- |
| Open Embedded Atlas | Opens (or reveals) the Atlas panel on the Home view |
| Rebuild Index | Runs the indexer (placeholder progress run in Phase 1) |
| Show File Graph | Opens the panel on the file-dependency view |
| Show Function Graph | Opens the panel on the call-graph view |
| Show Module Graph | Opens the panel on the subsystem view |
| Show Log | Reveals the output channel |

`Show File Graph` is also on the Explorer context menu for C/C++ files, and
`Show Function Graph` is on the editor context menu.

## Settings (`embeddedCodeAtlas.*`)

- `logLevel` — output channel verbosity (`trace`…`error`)
- `engine` — code model backend: `heuristic` (no build needed, approximate),
  `clangd`, or `libclang` (accurate, needs a `compile_commands.json`)
- `indexing.include` / `indexing.exclude` — file globs
- `indexing.maxFileSizeKb` — skip oversized files
- `database.path` — SQLite location (defaults to `.vscode/embedded-atlas/`)
- `graph.maxNodes` — cap rendered nodes; larger graphs render as neighborhood slices

## Architecture

```
src/
  extension.ts            activate/deactivate; wires everything together
  logger.ts               OutputChannel-backed logger with level gating
  config.ts               typed settings access + change notification
  commands.ts             command registration; Rebuild Index progress driver
  panel/
    protocol.ts           typed host <-> webview message contract
    AtlasPanel.ts         singleton webview panel (CSP, nonce, message routing)
  workspace/
    WorkspaceWatcher.ts   debounced file watcher -> incremental-index trigger
  index/
    types.ts              record types + language classification
    schema.ts             SQLite DDL + schema version
    IndexDatabase.ts      sql.js-backed store behind a swappable interface
    heuristicParser.ts    scope-aware C/C++ extractor (functions, calls, scopes)
    parseWorker.ts        worker-thread body: read + hash + heuristic-parse
    WorkerPool.ts         fixed-size parse-worker pool with progress
    clangAst.ts           walks clang -ast-dump=json into the same record shape
    compileDb.ts          loads compile_commands.json -> per-file clang flags
    clangRunner.ts        runs clang AST dumps with bounded concurrency
    discovery.ts          file discovery + build-system detection
    Indexer.ts            orchestrates engine selection, parsing, persistence
  graph/
    types.ts              graph node/edge/payload + report wire contracts
    GraphService.ts       builds bounded neighbourhood slices from the index
    scc.ts                shared Tarjan strongly-connected-components finder
    DependencyAnalyzer.ts file include cycles, hotspots, clusters
    CallAnalyzer.ts       call recursion, entry points, path tracing
    ModuleAnalyzer.ts     folder-based modules, inter-module deps + cycles
    DataFlowAnalyzer.ts   variable read/write aggregation, multi-writer detection
    (state machines)      detected in heuristicParser, stored as transitions
    (rtos scheduler)      tasks/delays/ISRs detected in heuristicParser
    ArchitectureAnalyzer.ts  file→layer mapping, upward-dependency violations
    RiskAnalyzer.ts          complexity + fan-in/out risk scoring
    Explainer.ts             template plain-English summaries from facts
    AutosarAnalyzer.ts       AUTOSAR BSW/MCAL module classification + conformance
media/
  main.css                webview styling via VS Code theme tokens
  main.js                 webview app (hub + interactive Cytoscape graphs)
  vendor/
    cytoscape.min.js      offline graph renderer (copied in at build time)
resources/
  sql-wasm.wasm           sql.js engine (copied in at build time)
```

Design notes that matter for the phases ahead:

- The webview is sandboxed under a strict Content-Security-Policy with a
  per-load nonce; the extension and webview communicate only through the typed
  message protocol in `panel/protocol.ts`.
- `WorkspaceWatcher` already emits debounced, batched change sets so the Phase 2
  indexer can do incremental updates rather than full rescans.
- `Rebuild Index` is wired through the same progress + status messaging the real
  indexer will use, so swapping in the worker-backed scan won't disturb the UI.
- The graph views are intentionally thin placeholders; Phase 4 drops a
  Cytoscape/D3 renderer into `media/` and feeds it neighborhood slices queried
  from SQLite.

## License

MIT
