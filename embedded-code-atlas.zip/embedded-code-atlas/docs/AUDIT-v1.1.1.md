# Embedded Code Atlas — Production-Readiness Audit (against v1.1.1)

Audited as a hostile reviewer, against the actual source. Every finding below is
evidence-based (file/line behavior verified) or explicitly marked as estimate.
Verified scale reference: 15,797 files / 97,215 functions / 246,889 call edges.

---

## A. CRITICAL BUGS — must fix before v1.2

**A1. Include-edge resolution is O(files × includes) AND inaccurate.**
`allIncludeEdges()` joins `files` to `includes` with `tf.path LIKE '%/' || i.target`.
(1) Non-indexable LIKE join → full cross product: ~15.8k files × ~50–100k include
rows ≈ **~10⁹ comparisons** in WASM SQLite. This is the real cost inside
"Analyzing include dependencies" on the dashboard and the File-graph overview.
(2) **False edges:** any file whose path merely *ends with* the include string
matches — with same-named headers across AUTOSAR variants/SDK copies this
fabricates cross-variant dependencies and **false include cycles**.
*Fix:* resolve in JS: load all file paths once, build a basename→candidates map,
match each include by longest path-suffix; ambiguous matches (multiple equal
suffix length) → drop or pick same-directory-subtree. O(F + I·k). Cache result
until index changes.

**A2. Incremental updates are silently dropped.**
`applyChange()` begins `if (!this.db || this.busy) return;` — any file saved
while a rebuild or a previous change is in flight is **lost**; the index goes
stale with no indication until a manual rebuild.
*Fix:* queue incoming `WorkspaceChange`s while busy and drain after.

**A3. Watchdog race leaks workers.**
If a timed-out worker's reply arrives after the timer fired (terminate is
async): the stale `message` handler runs → `done` double-counts the file → it
calls `dispatch()` on the **terminated** worker → `postMessage` throws →
the `error` handler spawns a replacement — but the timeout path already spawned
one. Repeated timeouts grow the pool unboundedly.
*Fix:* a `retired` flag per worker; all handlers no-op once set.

**A4. Change detection misses real edits and re-flags oversize files.**
Diff line: `changed = Math.round(st.mtimeMs) !== Math.round(prev.mtime) || st.size > maxBytes;`
(1) **Size is never compared to the previous size** — a content change that
preserves mtime (git checkout with mtime restoration, some build steps, copy
tools) is invisible. (2) `st.size > maxBytes` marks every oversize file
"changed" on every rebuild, churning the skip path. The stored `hash` column is
never used for diffing.
*Fix:* `changed = mtime差 || st.size !== prev.size`; optionally hash-verify when
mtime differs but size matches; drop the maxBytes clause from "changed".

**A5. Every file save triggers full resolve + full DB rewrite.**
`applyChange` → `resolveCalls()` (measured **4.7 s** at 250k call rows) +
`resolveRefs()` + `persist()` (serializes and writes the **entire** DB — ~23 MB
at 100k functions, growing linearly). At your scale a single save costs
~5–8 s CPU + a multi-MB disk write, on the extension host.
*Fix:* scope resolution to symbols touched by the changed files (names defined
in or called from them); debounce persist (e.g., 30 s idle or on deactivate);
long-term: incremental page-level persistence (native SQLite, see roadmap).

## B. STABILITY RISKS

- **B1. sql.js is in-memory + serialize copy.** Measured: 100k fns ≈ 23 MB DB /
  178 MB RSS. Estimates: 500k fns ≈ 110–150 MB DB, 600–800 MB RSS;
  **1M functions ≈ 250–300 MB DB, >1.2 GB RSS with transient serialize copies —
  at/over the practical WASM ceiling.** First breaking point: ~50k files /
  ~400–500k functions on a 16 GB Windows laptop.
- **B2. No corruption recovery:** if the saved `.sqlite` is truncated (kill
  during write), open likely throws on every activation. Persist should write
  `tmp` + atomic rename; open should fall back to "rebuild required" on parse
  failure.
- **B3. Workspace switching / multi-root:** indexer binds the first folder;
  second root silently unindexed; switching workspaces while busy can write the
  old DB path. Needs explicit per-root handling or a documented single-root
  limitation.
- **B4. Late watchdog double-result:** even after A3's leak fix, the file gets
  recorded both failed and succeeded; progress can exceed total (cosmetic) —
  guard with the same retired flag.

## C. PERFORMANCE RISKS (next blockers, in order)

1. A1 (include join) — minutes today; after fix: <1 s.
2. A5 (resolve+persist per save).
3. `lookupFunctions`/`searchFunctions` use leading-wildcard LIKE → full 97k-row
   scan per search; fine today (~100 ms), regression risk at 500k — add a
   lowercase name column + prefix index, fall back to scan only for substring.
4. Dashboard Tarjan + analyzers all run on the extension host (1.9 s measured
   for call SCC at your scale). Acceptable now; move analyzers to a worker at
   >300k functions.
5. Webview: full DOM re-render per unhandled message type is mostly avoided via
   `full=false`, but `indexStats` triggers a complete re-render including the
   nav — harmless now, batch later.

## D. PARSER ACCURACY (known limits, ranked by impact on embedded code)

Heuristic engine misses/false-positives, with severity for automotive code:
- **Function pointers / dispatch tables (HIGH):** indirect calls invisible →
  call graph under-connected; "dead" callbacks; FSMs in pointer tables missed.
- **Conditional compilation (HIGH):** all `#if` branches parsed as live →
  duplicate definitions across configs; ambiguous names then *unresolve* calls
  (safe but lossy).
- **Macros that generate functions/calls (MED-HIGH):** vendor HAL `#define`
  wrappers invisible or mis-attributed; complexity under-counted when control
  flow hides in macros.
- **Typedef'd function decls / K&R / attributes (MED):** some definitions
  missed; `extern "C"` blocks handled, anonymous structs ignored (OK).
- **`.inl/.inc/.ipp/.tcc` not classified (MED):** vendor HALs ship these;
  currently invisible. One-line fix in `classifyLanguage`.
- Clang engine: per-file fallback works, but a *partial* compile_commands.json
  silently yields a mixed-precision index with no per-file engine indicator in
  the UI — add an engine column/badge.

## E. SECURITY & EXTENSION LIFECYCLE

- Webview CSP + nonce: solid; no remote content; storage is workspace-local.
- **`openFile` accepts any absolute path from the webview** — our own code, but
  defense-in-depth says reject paths outside the workspace.
- Disposal: subscriptions pushed correctly; `deactivate` does not flush a
  pending debounced persist → last edits can be lost on window close (ties into
  A5 fix).
- No command/SQL injection found (parameterized statements throughout); one
  exception: `topFunctions` builds `IN (${ids})` from internally-generated
  numeric ids — safe, but switch to placeholders on principle.

## F. MISSING ENTERPRISE CAPABILITIES (vs Understand / Source Insight / SonarQube)

Critical: symbol cross-reference browser (all uses of X, grouped read/write/call);
impact analysis (transitive blast radius — data already present); export/reporting
(SVG/PNG/CSV/HTML report); per-file engine/precision indicator.
Important: function-pointer resolution; macro expansion explorer; type/struct
hierarchy; architecture snapshots + diff between builds; CI/CLI mode; MISRA-lite
structural rules surfaced as Problems diagnostics.
Nice-to-have: requirements/traceability linking (ASPICE), community detection on
graphs, dead-code view, stack-depth estimation.

## G. TEST GAPS

Tested today: parser features (per phase), DB roundtrip, analyzers, watchdog,
scale benchmarks, bundled worker. Missing: incremental-change integration test
(create/edit/delete cycle), corruption-recovery test, multi-root test,
duplicate-name-resolution test, include-ambiguity test (will codify A1),
long-run memory soak, webview message-protocol contract test, Windows-paths CI
(backslash handling is exercised only implicitly).

## RECOMMENDED RELEASES

- **v1.2.0 — Correctness (1–2 days):** A1 JS include resolution (+ambiguity
  rule), A2 change queue, A3/B4 retired-worker guard, A4 size+hash diff,
  `.inl/.inc/.ipp` classification, atomic persist (B2), openFile workspace
  check, tests for each.
- **v1.3.0 — Scale & UX:** A5 scoped resolve + debounced persist; engine badge
  per file; xref browser + impact analysis view; export SVG/CSV/HTML report;
  search index column.
- **v1.4.0 — Enterprise:** CLI/CI mode (`atlas check --fail-on …`); MISRA-lite
  diagnostics in Problems panel; architecture snapshots & diff; analyzer worker
  offload.
- **v2.0.0 — Scale ceiling removal:** engine extraction + native SQLite backend
  (better-sqlite3) behind the existing interface; function-pointer resolution;
  optional standalone (Tauri) viewer for >500k-function repos.

## FINAL VERDICT (brutally honest)

**Rating: a good internal tool, one focused release away from "production-grade
internal tool"; not yet enterprise-grade.**

Evidence for: real architecture (engine/UI separation, swappable DB, two parse
engines, worker pool with watchdog), proven on a real 15.8k-file repo, every
fix benchmark-verified, honest accuracy documentation, clean offline packaging.
Evidence against: A1–A5 are the kind of correctness/perf bugs daily users hit
weekly (stale index from A2/A4 would be the #1 complaint from 100 developers;
A1's false cycles would erode trust in the analysis itself); no xref browser or
export, which Understand/Source Insight users consider table stakes; the WASM
memory ceiling caps it below the largest automotive monorepos. None of these are
architectural dead ends — the v1.2 list is mechanical, and the v2.0 backend swap
was designed for from day one.

**What breaks first with 100 daily developers:** stale indexes (A2+A4) within
the first week, include-cycle false positives (A1) undermining credibility, and
multi-second save hitches (A5) generating "the plugin makes VS Code slow"
tickets. Fix those four and the honest rating moves to production-grade.
