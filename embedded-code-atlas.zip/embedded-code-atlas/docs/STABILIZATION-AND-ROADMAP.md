# Embedded Code Atlas — Stabilization Report & Product Roadmap (v1.1.0)

## 1. Root cause analysis of the overnight hang

Observed: build stuck at "Parsing (heuristic) 16693/16706" overnight.

| # | Root cause | Mechanism | Severity |
|---|-----------|-----------|----------|
| 1 | **Quadratic line lookup** | `lineAt()` rescanned the file from offset 0 on *every* symbol hit. A symbol-dense generated file (the kind that lands last in a big scan) costs O(size × hits) ≈ 10¹¹+ ops → hours per file. | **Primary** |
| 2 | **No per-file watchdog** | One stuck worker blocked pool completion forever; remaining 13 files were queued behind/inside stuck workers. | **Primary** |
| 3 | **Per-row correlated subqueries in resolve** | `UPDATE … WHERE (SELECT COUNT(*) …)=1` evaluated per row over potentially millions of `refs`/`calls` rows in single-threaded WASM SQLite. | High |
| 4 | **Silent resolve/persist phase** | No progress message after parsing → even a *working* resolve looked frozen. | Medium |
| 5 | **Empty default excludes** | `build/`, `.git/`, `CMakeFiles/`, vendor and generated trees were indexed; 16.7k files likely included thousands of unneeded ones. | Medium |
| 6 | **Unbounded refs per file** | Generated config files emit tens of thousands of reference rows each → memory pressure in the in-memory WASM DB. | Medium |

Not found: symlink loops (discovery uses `vscode.workspace.findFiles`, which doesn't follow them), duplicate indexing (path-keyed upsert), or graph-side O(N²) (graphs are BFS neighborhood slices; analyzers are linear/Tarjan).

## 2. Fixes shipped in v1.1.0 (all verified by test)

1. `lineAt` → cached line-start index + binary search. **Measured: 1.43 MB symbol-dense file parses in 352 ms** (previously effectively unbounded).
2. WorkerPool watchdog (`indexing.parseTimeoutSec`, default 30 s): a stuck file is skipped, logged, and its worker terminated and respawned; worker *crashes* also fail one file instead of the whole build. **Measured: poison file skipped at the timeout, pool completes.**
3. `resolveCalls`/`resolveRefs` rewritten as one GROUP-BY pass + one indexed UPDATE per unique unresolved name. **Measured: 4 800 rows resolve in ~270 ms / ~70 ms.**
4. Progress now shows the current filename during parsing and distinct stages: *Resolving symbols (calls) → Resolving symbols (globals) → Saving index to disk*.
5. Real default excludes (`build/`, `out/`, `dist/`, `.git/`, `node_modules/`, `.cache/`, `CMakeFiles/`); `maxFileSizeKb` default lowered 4096→2048.
6. Refs capped at 4 000 per file (graphs aggregate counts anyway; rows past that add weight, not insight).

## 3. Performance & memory plan (current architecture)

Stage timings now visible in the progress UI; the log records per-stage durations and skipped files. Remaining known costs and the plan:

- **In-memory WASM SQLite** holds the whole index plus serialization buffer. Fine to roughly ~1–2 M rows; beyond that the right fix is a native backend (see §5) — `better-sqlite3` in a standalone process, or splitting the DB per top-level folder. Not patched in-extension because native modules complicate corporate-laptop installs.
- **Incremental builds** already diff by mtime/size; resolve is now cheap enough to run per change.
- Graphs already do lazy neighborhood loading + node caps + LOD rendering (Phase 15); no whole-graph rendering exists.

## 4. VS Code extension vs standalone desktop app

| Criterion | VS Code extension | Standalone (Tauri/Electron) |
|---|---|---|
| Editor integration (jump to source, diagnostics, CodeLens) | **Native** | Requires bridging back to an editor |
| Install on locked-down laptops | VSIX side-load, no admin | MSI/EXE often needs IT approval |
| Memory ceiling | Extension host + WASM heap (~2 GB practical) | Own process; native SQLite; effectively unlimited |
| UI freedom | Webview (already fully used) | Full window, multi-pane, dockable |
| Headless/CI use | No | Yes (shared engine → CLI) |
| Maintenance | One codebase | Two front ends unless engine is extracted |

## 5. Recommendation: **hybrid, engine-first** — not a rewrite

The analyzers and database layer are already pure Node modules with no `vscode` imports (this was deliberate). Extract them into `@atlas/engine`, then:

- **Phase 1 (done — this release):** stabilize the extension; watchdog, linear hot paths, batched resolve, honest progress.
- **Phase 2:** extract `src/index` + `src/graph` into an engine package; the extension becomes a thin host. Add `atlas` **CLI** (`atlas index`, `atlas check --fail-on layering,cycles`) for CI gates — highest organizational value per effort.
- **Phase 3:** optional native backend in the CLI/engine (`better-sqlite3`) for multi-million-LOC repos; the extension keeps sql.js for zero-native installs and can *read* an engine-produced index.
- **Phase 4:** standalone viewer (**Tauri** preferred: ~10 MB, lower RAM; Electron acceptable if corporate policy favors it) reusing the existing webview JS (it's plain JS + Cytoscape — ports nearly as-is). React+Sigma.js only if graphs must exceed ~20 k visible nodes.
- **Phase 5:** advanced intelligence on the shared engine: impact analysis, architecture diff between commits, function-pointer resolution, stack-depth estimation.
- **Phase 6:** enterprise scale: per-module sharded indexes, background daemon, multi-repo federation.

Verdict: keep VS Code as the primary UI (its editor integration is the product's daily value), ship the CLI for CI, and build the standalone viewer only when a real >2 GB-index user appears. A full rewrite now would discard a working, tested system to chase a constraint not yet hit.
