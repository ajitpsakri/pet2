'use strict';
/*
 * Production bundler. Produces two self-contained CommonJS bundles:
 *   out/extension.js   — the extension host entry (vscode kept external)
 *   out/parseWorker.js — the worker-thread body (sql.js is not pulled in here)
 *
 * The worker is emitted at out/parseWorker.js on purpose: the Indexer resolves
 * it via path.join(__dirname, 'parseWorker.js'), and when the host is bundled
 * to out/extension.js, __dirname is out/ — so the worker must sit beside it.
 * (Under the plain tsc build, Indexer.js lives in out/index/ and the worker is
 * emitted there instead; both layouts stay internally consistent.)
 */
const esbuild = require('esbuild');

const production = process.argv.includes('--production');

const common = {
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node18',
  external: ['vscode'],
  minify: production,
  sourcemap: !production,
  logLevel: 'info',
};

async function main() {
  await Promise.all([
    esbuild.build({ ...common, entryPoints: ['src/extension.ts'], outfile: 'out/extension.js' }),
    esbuild.build({ ...common, entryPoints: ['src/index/parseWorker.ts'], outfile: 'out/parseWorker.js' }),
  ]);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
