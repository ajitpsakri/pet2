// @ts-check
(function () {
  'use strict';

  const vscode = acquireVsCodeApi();
  /* global cytoscape */

  /** @typedef {'home'|'file-graph'|'function-graph'|'module-graph'} AtlasView */

  const VIEWS = {
    home: {
      label: 'Home', icon: '⌂', title: 'Embedded Code Atlas',
      desc: 'A local-first map of your embedded / C / C++ codebase. Everything runs offline — no source ever leaves this machine. Build the index to populate the graphs below.',
    },
    dashboard: {
      label: 'Dashboard', icon: '▤', title: 'Insights Dashboard',
      desc: 'A single overview of the whole codebase — index totals, per-analysis health, and the most important findings across cycles, recursion, shared state, layering, and complexity. Click any card or finding to jump straight to it.',
    },
    'file-graph': {
      label: 'File Graph', icon: '◫', title: 'File Dependency Graph',
      desc: 'How translation units and headers depend on one another. Search for a file or click a node to expand its neighbourhood.',
    },
    'function-graph': {
      label: 'Function Graph', icon: 'ƒ', title: 'Function Call Graph',
      desc: 'Caller/callee relationships. Search for a function or click a node to trace execution flow outward.',
    },
    'module-graph': {
      label: 'Module Graph', icon: '▦', title: 'Module Graph',
      desc: 'Auto-detected subsystems grouped from folder structure, with inter-module dependencies and circular-dependency detection. Click a module to inspect its files.',
    },
    'data-flow-graph': {
      label: 'Data Flow', icon: '⇄', title: 'Data Flow Graph',
      desc: 'Which functions read and write each global / shared variable. Search a variable or function; writes point into a variable, reads point out. Use Insights to find multi-writer shared state.',
    },
    'state-machine-graph': {
      label: 'State Machines', icon: '◉', title: 'State Machine Graph',
      desc: 'State machines detected from switch-on-state-variable patterns, drawn as state-transition diagrams. Use Insights to pick a machine; search by state variable or function name.',
    },
    'scheduler-graph': {
      label: 'Scheduler', icon: '⚡', title: 'Scheduler (RTOS)',
      desc: 'RTOS tasks and interrupt handlers arranged as a preemption ladder: ISRs on top, then tasks by priority. Detected from xTaskCreate / osThreadNew and handler naming; periods come from vTaskDelay / osDelay. A static view of the schedule, not a runtime trace.',
    },
    'architecture-graph': {
      label: 'Architecture', icon: '⌂', title: 'Architecture (Layering)',
      desc: 'Files mapped to architectural layers (top to bottom), with include dependencies aggregated between layers. Upward dependencies — a lower layer depending on a higher one — are flagged red as layering violations. Configure layer names in settings.',
    },
    'complexity-graph': {
      label: 'Complexity', icon: '🔥', title: 'Complexity / Risk',
      desc: 'The riskiest functions, heat-coloured by cyclomatic complexity (green → red) and linked by their calls. Risk combines complexity with call fan-in and fan-out. Use Insights for the ranked function and per-file complexity lists.',
    },
    'autosar-graph': {
      label: 'AUTOSAR', icon: '⚙', title: 'AUTOSAR Layers',
      desc: 'Standard AUTOSAR BSW and MCAL modules (Can, CanIf, Com, Rte, Dio, …) recognised by filename and placed in the canonical layer stack. Upward dependencies — a lower layer depending on a higher one — are flagged red as conformance violations. Use Insights for the module list per layer.',
    },
  };

  let state = Object.assign(
    {
      view: 'home',
      workspaceName: null,
      engine: 'heuristic',
      stats: { files: 0, functions: 0, calls: 0, variables: 0, lastBuilt: null },
      status: { text: 'Ready', busy: false },
      graphControls: { query: '', depth: 1, direction: 'both' },
    },
    vscode.getState() || {},
  );

  const root = /** @type {HTMLElement} */ (document.getElementById('app'));

  // Graph runtime (kept outside `state` because they are live objects / DOM).
  /** @type {any} */ let cy = null;
  /** @type {HTMLElement|null} */ let cyHost = null;
  /** @type {HTMLElement|null} */ let detailsRef = null;
  /** @type {Record<string, any>} */ let lastPayload = { 'file-graph': null, 'function-graph': null, 'module-graph': null };
  /** @type {any} */ let selected = null;
  let pendingApply = false;
  let lastTap = { id: '', t: 0 };
  /** @type {'selection'|'insights'} */ let detailsMode = 'selection';
  /** @type {any} */ let depReport = null;
  /** @type {any} */ let callReport = null;
  /** @type {any} */ let moduleReport = null;
  /** @type {any} */ let dataFlowReport = null;
  /** @type {any} */ let smReport = null;
  /** @type {any} */ let schedReport = null;
  /** @type {any} */ let archReport = null;
  /** @type {any} */ let cxReport = null;
  /** @type {any} */ let autosarReport = null;
  /** @type {any} */ let dashReport = null;
  let dashRequested = false;
  /** @type {string|null} */ let explainTarget = null;
  /** @type {any} */ let explanation = null;
  let pendingDrill = false;
  let traceQuery = '';

  function persist() { vscode.setState(state); }
  function post(message) { vscode.postMessage(message); }

  function el(tag, props, children) {
    const node = document.createElement(tag);
    if (props) {
      for (const [k, v] of Object.entries(props)) {
        if (k === 'class') node.className = v;
        else if (k === 'text') node.textContent = v;
        else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
        else if (v !== null && v !== undefined) node.setAttribute(k, String(v));
      }
    }
    for (const c of children || []) {
      if (c) node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return node;
  }

  function navigate(view, suppressAuto) {
    if (!VIEWS[view]) view = 'home';
    state.view = view;
    persist();
    post({ type: 'navigate', view });
    render();
    if (isGraphView(view) && !lastPayload[view] && !suppressAuto) requestGraph('');
  }

  function isGraphView(v) { return v === 'file-graph' || v === 'function-graph' || v === 'module-graph' || v === 'data-flow-graph' || v === 'state-machine-graph' || v === 'scheduler-graph' || v === 'architecture-graph' || v === 'complexity-graph' || v === 'autosar-graph'; }

  function render() {
    root.setAttribute('aria-busy', state.status.busy ? 'true' : 'false');
    root.replaceChildren(renderTopbar(), renderRail(), renderMain(), renderStatus());
    if (isGraphView(state.view)) syncGraph();
  }

  function renderTopbar() {
    return el('header', { class: 'topbar' }, [
      el('h1', { text: 'Embedded Atlas' }),
      el('span', { class: 'workspace', text: state.workspaceName ? state.workspaceName : 'No workspace open' }),
      el('span', { class: 'badge', text: 'engine: ' + state.engine }),
    ]);
  }

  function renderRail() {
    const rail = el('nav', { class: 'rail', 'aria-label': 'Atlas views' }, []);
    rail.appendChild(el('div', { class: 'group-label', text: 'Views' }));
    for (const key of Object.keys(VIEWS)) {
      rail.appendChild(
        el('button', {
          class: 'nav-item', type: 'button',
          'aria-current': state.view === key ? 'true' : 'false',
          onclick: () => navigate(key),
        }, [el('span', { 'aria-hidden': 'true', text: VIEWS[key].icon }), VIEWS[key].label]),
      );
    }
    rail.appendChild(el('div', { class: 'group-label', text: 'Index' }));
    rail.appendChild(el('button', {
      class: 'nav-item', type: 'button',
      onclick: () => post({ type: 'command', command: 'embeddedCodeAtlas.rebuildIndex' }),
    }, [el('span', { 'aria-hidden': 'true', text: '↻' }), 'Rebuild Index']));
    rail.appendChild(el('button', {
      class: 'nav-item', type: 'button',
      onclick: () => post({ type: 'command', command: 'embeddedCodeAtlas.showLog' }),
    }, [el('span', { 'aria-hidden': 'true', text: '☰' }), 'Show Log']));
    return rail;
  }

  function renderMain() {
    const view = VIEWS[state.view];
    const graphy = isGraphView(state.view);
    const main = el('main', { class: 'main' + (graphy ? ' main-graph' : '') }, [
      el('div', { class: 'view-header' }, [el('h2', { text: view.title }), el('p', { text: view.desc })]),
    ]);

    if (state.view === 'home') {
      main.appendChild(renderStats());
      main.appendChild(el('div', { class: 'actions' }, [
        el('button', { class: 'btn', type: 'button', onclick: () => post({ type: 'command', command: 'embeddedCodeAtlas.rebuildIndex' }) }, ['Build index']),
        el('button', { class: 'btn', type: 'button', onclick: () => navigate('dashboard') }, ['Open Dashboard']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('file-graph') }, ['Open File Graph']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('function-graph') }, ['Open Function Graph']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('module-graph') }, ['Open Module Graph']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('data-flow-graph') }, ['Open Data Flow']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('state-machine-graph') }, ['Open State Machines']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('scheduler-graph') }, ['Open Scheduler']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('architecture-graph') }, ['Open Architecture']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('complexity-graph') }, ['Open Complexity']),
        el('button', { class: 'btn secondary', type: 'button', onclick: () => navigate('autosar-graph') }, ['Open AUTOSAR']),
      ]));
    } else if (state.view === 'dashboard') {
      main.appendChild(renderDashboard());
    } else if (isGraphView(state.view)) {
      main.appendChild(renderGraphView());
    }
    return main;
  }

  function renderDashboard() {
    const wrap = el('div', { class: 'dashboard' }, []);
    if (!dashReport) {
      if (!dashRequested) { dashRequested = true; post({ type: 'requestDashboardReport' }); }
      wrap.appendChild(el('div', { class: 'details-empty', text: 'Aggregating analyses…' }));
      return wrap;
    }
    const r = dashReport;
    const sev = { ok: cssVar('--vscode-charts-green', '#3fb950'), warn: cssVar('--vscode-charts-yellow', '#d6b34a'), bad: cssVar('--vscode-errorForeground', '#f14c4c') };

    const grid = el('div', { class: 'stat-grid' }, []);
    r.cards.forEach((c) => {
      const card = el('button', {
        class: 'stat dash-card', type: 'button', title: c.label,
        onclick: () => navigate(c.view),
      }, [
        el('div', { class: 'value', text: c.value }),
        el('div', { class: 'label', text: c.label }),
        el('div', { class: 'dash-sub', text: c.sub }),
      ]);
      card.style.borderLeft = '3px solid ' + sev[c.severity];
      grid.appendChild(card);
    });
    wrap.appendChild(grid);

    wrap.appendChild(el('h3', { class: 'dash-head', text: 'Key findings' }));
    if (r.findings.length === 0) {
      wrap.appendChild(el('div', { class: 'details-empty', text: 'No structural issues found — no cycles, layering violations, or shared-state hazards. 🎉' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.findings.forEach((f) => {
        const item = el('button', {
          class: 'insight-item' + (f.severity === 'bad' ? ' bad' : ''), type: 'button',
          onclick: () => navigate(f.view),
        }, [
          el('span', { class: 'badge-num', text: f.severity === 'bad' ? '!' : '•' }),
          el('span', { class: 'mod-name', text: f.text }),
        ]);
        if (f.severity === 'warn') item.style.borderColor = sev.warn;
        list.appendChild(item);
      });
      wrap.appendChild(list);
    }
    return wrap;
  }

  function renderGraphView() {
    const ctl = state.graphControls;
    const noun = state.view === 'file-graph' ? 'file' : state.view === 'data-flow-graph' ? 'variable or function' : state.view === 'state-machine-graph' ? 'state variable or function' : 'function';

    const searchInput = el('input', {
      class: 'graph-search', type: 'text', placeholder: 'Search ' + noun + '… (Enter to focus)',
      value: ctl.query,
    });
    searchInput.addEventListener('input', (e) => { ctl.query = e.target.value; persist(); });
    searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') requestGraph(ctl.query.trim()); });

    const isModule = state.view === 'module-graph';
    const isSched = state.view === 'scheduler-graph';
    const isArch = state.view === 'architecture-graph';
    const isCx = state.view === 'complexity-graph';
    const isAutosar = state.view === 'autosar-graph';
    const depthSel = el('select', { class: 'graph-depth', title: isModule ? 'Folder levels per module' : 'Expansion depth' },
      ['1', '2', '3'].map((d) => {
        const unit = isModule ? ' level' : ' hop';
        const o = el('option', { value: d, text: d + unit + (d === '1' ? '' : 's') });
        if (Number(d) === ctl.depth) o.setAttribute('selected', 'true');
        return o;
      }));
    depthSel.addEventListener('change', (e) => {
      ctl.depth = Number(e.target.value); persist();
      if (isModule) { moduleReport = null; requestGraph(''); if (detailsMode === 'insights') post({ type: 'requestModuleReport', depth: ctl.depth }); }
      else { const focus = lastPayload[state.view] && lastPayload[state.view].focus; requestGraph(focus || ctl.query.trim()); }
    });

    const toolbarChildren = isModule
      ? [el('span', { class: 'toolbar-label', text: 'Modules by folder' }), depthSel]
      : isSched
      ? [el('span', { class: 'toolbar-label', text: 'Tasks by priority · ISRs on top' })]
      : isArch
      ? [el('span', { class: 'toolbar-label', text: 'Layers top → bottom · upward = violation' })]
      : isCx
      ? [el('span', { class: 'toolbar-label', text: 'Riskiest functions · heat = complexity' })]
      : isAutosar
      ? [el('span', { class: 'toolbar-label', text: 'AUTOSAR layers · upward = non-conformant' })]
      : [
          searchInput,
          el('button', { class: 'btn small', type: 'button', onclick: () => requestGraph(ctl.query.trim()) }, ['Focus']),
          el('button', { class: 'btn small secondary', type: 'button', onclick: () => { ctl.query = ''; persist(); requestGraph(''); } }, ['Overview']),
        ];
    if (!isModule && !isSched && !isArch && !isCx && !isAutosar && state.view !== 'data-flow-graph' && state.view !== 'state-machine-graph') toolbarChildren.push(depthSel);

    if (state.view === 'function-graph') {
      const dirSel = el('select', { class: 'graph-depth', title: 'Call direction' },
        [['both', 'Callers + callees'], ['callees', 'Callees ↓'], ['callers', 'Callers ↑']].map(([v, label]) => {
          const o = el('option', { value: v, text: label });
          if ((ctl.direction || 'both') === v) o.setAttribute('selected', 'true');
          return o;
        }));
      dirSel.addEventListener('change', (e) => {
        ctl.direction = e.target.value; persist();
        const focus = lastPayload[state.view] && lastPayload[state.view].focus;
        requestGraph(focus || ctl.query.trim());
      });
      toolbarChildren.push(dirSel);
    }

    toolbarChildren.push(
      el('button', { class: 'btn small secondary', type: 'button', onclick: () => { if (cy) cy.fit(undefined, 30); } }, ['Fit']),
      el('button', { class: 'btn small secondary', type: 'button', onclick: relayout }, ['Re-layout']),
    );
    const toolbar = el('div', { class: 'graph-toolbar' }, toolbarChildren);

    if (!cyHost) cyHost = el('div', { class: 'cy-host', id: 'cy' }, []);

    const sidebar = el('aside', { class: 'graph-details' }, []);
    sidebar.appendChild(renderDetailTabs());
    detailsRef = el('div', { class: 'details-body' }, []);
    sidebar.appendChild(detailsRef);

    const stage = el('div', { class: 'graph-stage' }, [cyHost, sidebar]);
    const wrap = el('div', { class: 'graph-wrap' }, [toolbar, renderGraphMeta(), stage]);
    return wrap;
  }

  function renderDetailTabs() {
    const tab = (mode, label) => el('button', {
      class: 'tab' + (detailsMode === mode ? ' active' : ''), type: 'button',
      onclick: () => setDetailsMode(mode),
    }, [label]);
    return el('div', { class: 'details-tabs' }, [tab('selection', 'Selection'), tab('insights', 'Insights')]);
  }

  function setDetailsMode(mode) {
    detailsMode = mode;
    if (mode === 'insights') {
      if (state.view === 'file-graph' && !depReport) post({ type: 'requestDependencyReport' });
      if (state.view === 'function-graph' && !callReport) post({ type: 'requestCallReport' });
      if (state.view === 'module-graph' && !moduleReport) post({ type: 'requestModuleReport', depth: state.graphControls.depth });
      if (state.view === 'data-flow-graph' && !dataFlowReport) post({ type: 'requestDataFlowReport' });
      if (state.view === 'state-machine-graph' && !smReport) post({ type: 'requestStateMachineReport' });
      if (state.view === 'scheduler-graph' && !schedReport) post({ type: 'requestSchedulerReport' });
      if (state.view === 'architecture-graph' && !archReport) post({ type: 'requestArchitectureReport' });
      if (state.view === 'complexity-graph' && !cxReport) post({ type: 'requestComplexityReport' });
      if (state.view === 'autosar-graph' && !autosarReport) post({ type: 'requestAutosarReport' });
    }
    updateDetails();
  }

  function renderGraphMeta() {
    const p = lastPayload[state.view];
    const meta = el('div', { class: 'graph-meta' }, []);
    if (p) {
      meta.appendChild(el('span', { class: 'meta-chip', text: p.nodes.length + ' nodes · ' + p.edges.length + ' edges' }));
      if (p.truncated) meta.appendChild(el('span', { class: 'meta-chip warn', text: 'truncated at node cap' }));
      if (p.note) meta.appendChild(el('span', { class: 'meta-note', text: p.note }));
    } else {
      meta.appendChild(el('span', { class: 'meta-note', text: 'Loading…' }));
    }
    return meta;
  }

  function updateDetails() {
    if (!detailsRef) return;
    detailsRef.replaceChildren();
    if (detailsMode === 'insights' && state.view === 'file-graph') { renderInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'function-graph') { renderCallInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'module-graph') { renderModuleInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'data-flow-graph') { renderDataFlowInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'state-machine-graph') { renderStateMachineInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'scheduler-graph') { renderSchedulerInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'architecture-graph') { renderArchitectureInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'complexity-graph') { renderComplexityInsights(detailsRef); return; }
    if (detailsMode === 'insights' && state.view === 'autosar-graph') { renderAutosarInsights(detailsRef); return; }
    if (!selected) {
      detailsRef.appendChild(el('div', { class: 'details-empty', text: 'Click a node to inspect it. Double-click to expand its neighbourhood.' }));
      return;
    }
    const d = selected;
    detailsRef.appendChild(el('div', { class: 'details-title', text: d.label }));
    const kindText = d.kind + (d.resolved === false ? ' (unresolved)' : '') + (d.inCycle ? ' · in cycle' : '');
    detailsRef.appendChild(el('div', { class: 'details-kind', text: kindText }));
    if (d.kind === 'file' && (d.fanIn !== undefined)) {
      detailsRef.appendChild(el('div', { class: 'details-kind', text: 'included by ' + (d.fanIn || 0) + ' · includes ' + (d.fanOut || 0) }));
    }
    if (d.detail) detailsRef.appendChild(el('div', { class: 'details-detail', text: d.detail }));
    const actions = el('div', { class: 'details-actions' }, []);
    if (d.kind === 'module') {
      actions.appendChild(el('button', { class: 'btn small', type: 'button', onclick: () => drillModule(d.id) }, ['Show files']));
    }
    if (d.file) actions.appendChild(el('button', { class: 'btn small', type: 'button', onclick: () => post({ type: 'openFile', path: d.file, line: d.line }) }, ['Open source']));
    if (d.kind === 'function' || d.kind === 'file' || d.kind === 'variable') actions.appendChild(el('button', { class: 'btn small secondary', type: 'button', onclick: () => requestGraph(d.id) }, ['Expand from here']));
    if (d.kind === 'function' || d.kind === 'file') {
      actions.appendChild(el('button', { class: 'btn small secondary', type: 'button', onclick: () => { explainTarget = d.id; explanation = null; post({ type: 'requestExplanation', target: d.id }); updateDetails(); } }, ['Explain']));
    }
    detailsRef.appendChild(actions);
    if (explainTarget === d.id) {
      const box = el('div', { class: 'explain-box' }, []);
      box.appendChild(el('div', { class: 'explain-head', text: 'Explanation' }));
      if (!explanation) box.appendChild(el('div', { class: 'details-empty', text: 'Generating…' }));
      else explanation.lines.forEach((ln) => box.appendChild(el('p', { class: 'explain-line', text: ln })));
      detailsRef.appendChild(box);
    }
  }

  function drillModule(moduleNodeId) {
    pendingDrill = true;
    post({ type: 'requestModuleFiles', moduleNodeId, depth: state.graphControls.depth });
  }

  function renderInsights(container) {
    if (!depReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Analysing dependencies…' }));
      return;
    }
    const r = depReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.totalFiles + ' files · ' + r.totalEdges + ' include edges' }));

    // Circular dependencies.
    container.appendChild(el('div', { class: 'insight-head', text: 'Circular dependencies (' + r.cycles.length + ')' }));
    if (r.cycles.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None found — no circular #include chains.' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.cycles.slice(0, 30).forEach((c, i) => {
        list.appendChild(el('button', {
          class: 'insight-item cycle', type: 'button', title: c.labels.join(' → '),
          onclick: () => post({ type: 'requestSubgraph', nodeIds: c.nodeIds }),
        }, [el('span', { class: 'badge-num', text: String(c.nodeIds.length) }), c.labels.slice(0, 3).join(' → ') + (c.labels.length > 3 ? ' → …' : '')]));
      });
      container.appendChild(list);
    }

    // Hotspots.
    container.appendChild(el('div', { class: 'insight-head', text: 'Hotspots (most included)' }));
    if (r.hotspots.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No include relationships indexed yet.' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.hotspots.slice(0, 12).forEach((h) => {
        list.appendChild(el('button', {
          class: 'insight-item', type: 'button', title: h.path,
          onclick: () => requestGraph(h.nodeId),
        }, [el('span', { class: 'badge-num', text: String(h.fanIn) }), h.label]));
      });
      container.appendChild(list);
    }

    // Clusters.
    if (r.clusters.length) {
      container.appendChild(el('div', { class: 'insight-head', text: 'Folders' }));
      const chips = el('div', { class: 'cluster-chips' }, []);
      r.clusters.slice(0, 8).forEach((c) => chips.appendChild(el('span', { class: 'meta-chip', text: c.name + ' · ' + c.fileCount })));
      container.appendChild(chips);
    }
  }

  function renderStats() {
    const { files, functions, calls, variables, lastBuilt } = state.stats;
    const stat = (value, label) => el('div', { class: 'stat' }, [el('div', { class: 'value', text: value }), el('div', { class: 'label', text: label })]);
    return el('div', { class: 'stat-grid' }, [
      stat(files.toLocaleString(), 'Files indexed'),
      stat(functions.toLocaleString(), 'Functions'),
      stat((calls || 0).toLocaleString(), 'Call edges'),
      stat((variables || 0).toLocaleString(), 'Variables'),
      stat(lastBuilt || '—', 'Last built'),
    ]);
  }

  function renderStatus() {
    return el('footer', { class: 'status' + (state.status.busy ? ' busy' : '') }, [
      el('span', { class: 'dot', 'aria-hidden': 'true' }),
      el('span', { text: state.status.text }),
    ]);
  }

  // ---- Graph requests + Cytoscape ----------------------------------------

  function requestGraph(seed) {
    if (!isGraphView(state.view)) return;
    const msg = { type: 'requestGraph', kind: state.view, seed: seed || undefined, depth: state.graphControls.depth };
    if (state.view === 'function-graph') msg.direction = state.graphControls.direction || 'both';
    post(msg);
  }

  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name);
    return (v && v.trim()) || fallback;
  }

  function graphStyle() {
    const fg = cssVar('--vscode-editor-foreground', '#ccc');
    const fn = cssVar('--vscode-charts-blue', '#4a9eff');
    const file = cssVar('--vscode-charts-green', '#3fb950');
    const muted = cssVar('--vscode-descriptionForeground', '#888');
    const seed = cssVar('--vscode-charts-orange', '#e09b3a');
    const hot = cssVar('--vscode-charts-red', '#e05561');
    const cycle = cssVar('--vscode-errorForeground', '#f14c4c');
    const edge = cssVar('--vscode-editorIndentGuide-background', '#555');
    return [
      { selector: 'node', style: {
        'background-color': fn, 'label': 'data(label)', 'color': fg, 'font-size': 9,
        'text-valign': 'bottom', 'text-margin-y': 3, 'width': 'mapData(deg, 0, 12, 14, 40)',
        'height': 'mapData(deg, 0, 12, 14, 40)', 'text-max-width': 120, 'min-zoomed-font-size': 6,
      } },
      // File nodes: green -> red heat by fan-in (how many files include them).
      { selector: 'node[kind = "file"]', style: { 'background-color': 'mapData(fanIn, 0, 10, ' + file + ', ' + hot + ')', 'shape': 'round-rectangle' } },
      // Module nodes: larger rounded boxes sized by file count, label inside.
      { selector: 'node[kind = "module"]', style: {
        'background-color': cssVar('--vscode-charts-purple', '#b180d7'), 'shape': 'round-rectangle',
        'width': 'mapData(fileCount, 1, 60, 26, 90)', 'height': 'mapData(fileCount, 1, 60, 20, 60)',
        'text-valign': 'center', 'text-margin-y': 0, 'font-size': 11, 'color': cssVar('--vscode-editor-background', '#fff'),
        'text-outline-width': 2, 'text-outline-color': cssVar('--vscode-charts-purple', '#b180d7'),
      } },
      { selector: 'node[kind = "unresolved"]', style: { 'background-color': muted, 'border-width': 1, 'border-style': 'dashed', 'border-color': muted, 'opacity': 0.7 } },
      // Variable nodes: diamond, distinct accent colour.
      { selector: 'node[kind = "variable"]', style: {
        'background-color': cssVar('--vscode-charts-yellow', '#d6b34a'), 'shape': 'diamond',
        'width': 22, 'height': 22, 'color': fg,
      } },
      // State nodes: rounded "pill" with the state label inside.
      { selector: 'node[kind = "state"]', style: {
        'background-color': cssVar('--vscode-charts-purple', '#b180d7'), 'shape': 'round-rectangle',
        'width': 'label', 'height': 22, 'padding': 6, 'text-valign': 'center', 'font-size': 10,
        'color': cssVar('--vscode-editor-background', '#fff'),
        'text-outline-width': 2, 'text-outline-color': cssVar('--vscode-charts-purple', '#b180d7'),
      } },
      // Task nodes: wide pill labelled with the task name.
      { selector: 'node[kind = "task"]', style: {
        'background-color': cssVar('--vscode-charts-green', '#3fb950'), 'shape': 'round-rectangle',
        'width': 'label', 'height': 24, 'padding': 8, 'text-valign': 'center', 'font-size': 10,
        'color': cssVar('--vscode-editor-background', '#fff'),
        'text-outline-width': 2, 'text-outline-color': cssVar('--vscode-charts-green', '#3fb950'),
      } },
      // ISR nodes: red hexagon — highest preemption.
      { selector: 'node[kind = "isr"]', style: {
        'background-color': cssVar('--vscode-charts-red', '#e05561'), 'shape': 'hexagon',
        'width': 'label', 'height': 26, 'padding': 8, 'text-valign': 'center', 'font-size': 10,
        'color': cssVar('--vscode-editor-background', '#fff'),
        'text-outline-width': 2, 'text-outline-color': cssVar('--vscode-charts-red', '#e05561'),
      } },
      // Layer nodes: wide blue band spanning the architecture stack.
      { selector: 'node[kind = "layer"]', style: {
        'background-color': cssVar('--vscode-charts-blue', '#4a9eff'), 'shape': 'round-rectangle',
        'width': 'label', 'height': 30, 'padding': 14, 'text-valign': 'center', 'font-size': 11,
        'color': cssVar('--vscode-editor-background', '#fff'),
        'text-outline-width': 2, 'text-outline-color': cssVar('--vscode-charts-blue', '#4a9eff'),
      } },
      // Complexity view: function nodes heat-coloured green -> red by complexity.
      { selector: 'node[kind = "function"][complexity]', style: {
        'background-color': 'mapData(complexity, 1, 15, ' + cssVar('--vscode-charts-green', '#3fb950') + ', ' + hot + ')',
      } },
      { selector: 'node[?seed]', style: { 'border-width': 3, 'border-color': seed } },
      { selector: 'node[?inCycle]', style: { 'border-width': 3, 'border-color': cycle, 'border-style': 'double' } },
      { selector: 'node:selected', style: { 'border-width': 4, 'border-color': fg, 'border-style': 'solid' } },
      { selector: 'edge', style: {
        'width': 'mapData(count, 1, 8, 1, 4)', 'line-color': edge, 'target-arrow-color': edge,
        'target-arrow-shape': 'triangle', 'curve-style': 'bezier', 'arrow-scale': 0.8, 'opacity': 0.8,
      } },
      // Data-flow edges: writes are warm (data in), reads are cool (data out).
      { selector: 'edge[kind = "write"]', style: { 'line-color': hot, 'target-arrow-color': hot, 'line-style': 'solid' } },
      { selector: 'edge[kind = "read"]', style: { 'line-color': cssVar('--vscode-charts-blue', '#4a9eff'), 'target-arrow-color': cssVar('--vscode-charts-blue', '#4a9eff'), 'line-style': 'dashed' } },
      // Transition edges: state machine arrows, with self-loops curved.
      { selector: 'edge[kind = "transition"]', style: { 'line-color': cssVar('--vscode-charts-purple', '#b180d7'), 'target-arrow-color': cssVar('--vscode-charts-purple', '#b180d7'), 'width': 2 } },
      { selector: 'edge[kind = "transition"][source = "target"]', style: { 'loop-direction': '0deg', 'loop-sweep': '-40deg' } },
      // Architecture edges: normal downward deps muted; upward violations red + bold.
      { selector: 'edge[kind = "layerdep"]', style: { 'line-color': muted, 'target-arrow-color': muted, 'opacity': 0.6 } },
      { selector: 'edge[kind = "violation"]', style: {
        'line-color': cssVar('--vscode-charts-red', '#e05561'), 'target-arrow-color': cssVar('--vscode-charts-red', '#e05561'),
        'width': 3, 'line-style': 'solid', 'opacity': 1,
      } },
    ];
  }

  function ensureCy() {
    if (cy || !cyHost || typeof cytoscape === 'undefined') return;
    cy = cytoscape({ container: cyHost, elements: [], style: graphStyle(), wheelSensitivity: 0.2, minZoom: 0.1, maxZoom: 4,
      hideEdgesOnViewport: true, textureOnViewport: true, motionBlur: false });
    cy.on('tap', 'node', (evt) => {
      const node = evt.target;
      selected = node.data();
      if (explainTarget !== selected.id) { explainTarget = null; explanation = null; }
      updateDetails();
      const now = Date.now();
      if (lastTap.id === selected.id && now - lastTap.t < 300) {
        if (selected.kind === 'module') drillModule(selected.id);
        else if (selected.kind !== 'unresolved') requestGraph(selected.id);
      }
      lastTap = { id: selected.id, t: now };
    });
    cy.on('cxttap', 'node', (evt) => {
      const d = evt.target.data();
      if (d.file) post({ type: 'openFile', path: d.file, line: d.line });
    });
    cy.on('tap', (evt) => { if (evt.target === cy) { selected = null; updateDetails(); } });
  }

  function applyGraph(payload) {
    ensureCy();
    if (!cy) return;
    const deg = {};
    for (const e of payload.edges) { deg[e.source] = (deg[e.source] || 0) + 1; deg[e.target] = (deg[e.target] || 0) + 1; }
    const elements = [];
    for (const n of payload.nodes) elements.push({ data: Object.assign({}, n, { deg: deg[n.id] || 0 }) });
    for (const e of payload.edges) elements.push({ data: { id: e.id, source: e.source, target: e.target, kind: e.kind, count: e.count || 1 } });

    cy.elements().remove();
    cy.add(elements);
    cy.style(graphStyle());
    runLayout(payload.nodes.length);

    selected = null;
    updateDetails();
    if (payload.focus) {
      const f = cy.getElementById(payload.focus);
      if (f && f.length) { selected = f.data(); updateDetails(); }
    }
  }

  function renderCallInsights(container) {
    if (!callReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Analysing call graph…' }));
      return;
    }
    const r = callReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.totalFunctions + ' functions · ' + r.totalCalls + ' resolved calls' }));

    // Path tracer: "can the focused function reach X?"
    const focus = lastPayload['function-graph'] && lastPayload['function-graph'].focus;
    container.appendChild(el('div', { class: 'insight-head', text: 'Trace call path' }));
    if (!focus) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Focus a function first, then trace whether it can reach another.' }));
    } else {
      const traceInput = el('input', { class: 'graph-search', type: 'text', placeholder: 'Target function…', value: traceQuery });
      traceInput.addEventListener('input', (e) => { traceQuery = e.target.value; });
      const go = () => { if (traceQuery.trim()) post({ type: 'requestCallPath', fromNodeId: focus, query: traceQuery.trim() }); };
      traceInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
      container.appendChild(el('div', { class: 'trace-row' }, [traceInput, el('button', { class: 'btn small', type: 'button', onclick: go }, ['Trace'])]));
    }

    appendInsightList(container, 'Entry points (no callers)', r.entryPoints.slice(0, 12),
      (e) => [el('span', { class: 'badge-num', text: '→' }), e.label], (e) => requestGraph(e.nodeId));

    container.appendChild(el('div', { class: 'insight-head', text: 'Recursion (' + r.recursion.length + ')' }));
    if (r.recursion.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No recursive cycles found.' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.recursion.slice(0, 20).forEach((c) => list.appendChild(el('button', {
        class: 'insight-item cycle', type: 'button', title: c.labels.join(' → '),
        onclick: () => requestGraph(c.nodeIds[0]),
      }, [el('span', { class: 'badge-num', text: String(c.nodeIds.length) }), c.labels.slice(0, 3).join(' → ') + (c.labels.length > 3 ? ' → …' : '')])));
      container.appendChild(list);
    }

    appendInsightList(container, 'Most called', r.mostCalled.slice(0, 12),
      (m) => [el('span', { class: 'badge-num', text: String(m.callers) }), m.label], (m) => requestGraph(m.nodeId));
  }

  function appendInsightList(container, title, items, contentFn, onClick) {
    container.appendChild(el('div', { class: 'insight-head', text: title }));
    if (!items.length) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None.' }));
      return;
    }
    const list = el('div', { class: 'insight-list' }, []);
    items.forEach((it) => list.appendChild(el('button', { class: 'insight-item', type: 'button', onclick: () => onClick(it) }, contentFn(it))));
    container.appendChild(list);
  }

  function renderModuleInsights(container) {
    if (!moduleReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Analysing modules…' }));
      return;
    }
    const r = moduleReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.moduleCount + ' modules · ' + r.crossEdges + ' cross-module deps' }));

    container.appendChild(el('div', { class: 'insight-head', text: 'Circular module deps (' + r.cycles.length + ')' }));
    if (r.cycles.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None — module dependencies are acyclic.' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.cycles.slice(0, 20).forEach((c) => list.appendChild(el('div', {
        class: 'insight-item cycle', title: c.labels.join(' → '),
      }, [el('span', { class: 'badge-num', text: String(c.nodeIds.length) }), c.labels.slice(0, 3).join(' → ') + (c.labels.length > 3 ? ' → …' : '')])));
      container.appendChild(list);
    }

    container.appendChild(el('div', { class: 'insight-head', text: 'Modules' }));
    const list = el('div', { class: 'insight-list' }, []);
    r.modules.slice(0, 30).forEach((m) => list.appendChild(el('button', {
      class: 'insight-item' + (m.inCycle ? ' cycle' : ''), type: 'button', title: m.name + ' — show files',
      onclick: () => drillModule(m.nodeId),
    }, [
      el('span', { class: 'badge-num', text: String(m.fileCount) }),
      el('span', { class: 'mod-name', text: m.name }),
      el('span', { class: 'mod-deps', text: '↓' + m.dependsOn + ' ↑' + m.dependedOnBy }),
    ])));
    container.appendChild(list);
  }

  function renderDataFlowInsights(container) {
    if (!dataFlowReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Analysing data flow…' }));
      return;
    }
    const r = dataFlowReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.totalVariables + ' variables · ' + r.totalRefs + ' references' }));

    container.appendChild(el('div', { class: 'insight-head', text: 'Multi-writer (shared state)' }));
    if (r.multiWriter.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No variable is written by more than one function.' }));
    } else {
      const list = el('div', { class: 'insight-list' }, []);
      r.multiWriter.slice(0, 15).forEach((v) => list.appendChild(el('button', {
        class: 'insight-item cycle', type: 'button', title: v.label + ' written by ' + v.writers + ' functions',
        onclick: () => requestGraph(v.nodeId),
      }, [el('span', { class: 'badge-num', text: String(v.writers) + 'w' }), el('span', { class: 'mod-name', text: v.label })])));
      container.appendChild(list);
    }

    appendInsightList(container, 'Most referenced', r.hotspots.slice(0, 12),
      (v) => [el('span', { class: 'badge-num', text: 'r' + v.reads + '/w' + v.writes }), el('span', { class: 'mod-name', text: v.label })],
      (v) => requestGraph(v.nodeId));
  }

  function renderStateMachineInsights(container) {
    if (!smReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Scanning for state machines…' }));
      return;
    }
    const r = smReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.machines.length + ' state machine' + (r.machines.length === 1 ? '' : 's') + ' detected' }));
    if (r.machines.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None found. State machines are recognised from a switch on a state variable whose cases assign new states.' }));
      return;
    }
    const list = el('div', { class: 'insight-list' }, []);
    r.machines.slice(0, 30).forEach((mc) => list.appendChild(el('button', {
      class: 'insight-item', type: 'button', title: mc.varName + (mc.fnName ? ' in ' + mc.fnName + '()' : ''),
      onclick: () => requestGraph(mc.nodeId),
    }, [
      el('span', { class: 'badge-num', text: String(mc.states) }),
      el('span', { class: 'mod-name', text: mc.varName + (mc.fnName ? ' · ' + mc.fnName : '') }),
      el('span', { class: 'mod-deps', text: mc.transitions + '→' }),
    ])));
    container.appendChild(list);
  }

  function renderSchedulerInsights(container) {
    if (!schedReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Scanning for RTOS tasks…' }));
      return;
    }
    const r = schedReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.tasks.length + ' task' + (r.tasks.length === 1 ? '' : 's') + ' · ' + r.isrs.length + ' ISR' + (r.isrs.length === 1 ? '' : 's') }));
    if (r.tasks.length === 0 && r.isrs.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No tasks or ISRs found. Tasks are recognised from xTaskCreate / osThreadNew; ISRs from handler naming conventions.' }));
      return;
    }
    if (r.tasks.length) {
      container.appendChild(el('div', { class: 'insight-head', text: 'Tasks (by priority)' }));
      const list = el('div', { class: 'insight-list' }, []);
      r.tasks.forEach((t) => list.appendChild(el('button', {
        class: 'insight-item', type: 'button', title: t.entry + '()' + (t.period ? ' · every ' + t.period : ''),
        onclick: () => requestGraph(t.nodeId),
      }, [
        el('span', { class: 'badge-num', text: t.priority != null ? 'P' + t.priority : '–' }),
        el('span', { class: 'mod-name', text: (t.name || t.entry) }),
        el('span', { class: 'mod-deps', text: t.period ? '⏱ ' + t.period : '' }),
      ])));
      container.appendChild(list);
    }
    if (r.isrs.length) {
      container.appendChild(el('div', { class: 'insight-head', text: 'Interrupt handlers' }));
      const list = el('div', { class: 'insight-list' }, []);
      r.isrs.forEach((i) => list.appendChild(el('button', {
        class: 'insight-item', type: 'button', title: i.file,
        onclick: () => requestGraph(i.nodeId),
      }, [el('span', { class: 'badge-num', text: 'IRQ' }), el('span', { class: 'mod-name', text: i.name })])));
      container.appendChild(list);
    }
  }

  function renderArchitectureInsights(container) {
    if (!archReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Analysing layering…' }));
      return;
    }
    const r = archReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.layerCount + ' layers · ' + r.violationCount + ' violation' + (r.violationCount === 1 ? '' : 's') + (r.configured ? '' : ' · default layers') }));
    if (r.layerCount === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No recognised layers. Set embeddedCodeAtlas.architecture.layers to map your folders (top to bottom).' }));
      return;
    }
    container.appendChild(el('div', { class: 'insight-head', text: 'Layers (top → bottom)' }));
    const ll = el('div', { class: 'insight-list' }, []);
    r.layers.forEach((l) => ll.appendChild(el('div', { class: 'insight-item' }, [
      el('span', { class: 'badge-num', text: String(l.fileCount) }),
      el('span', { class: 'mod-name', text: l.label }),
    ])));
    container.appendChild(ll);

    container.appendChild(el('div', { class: 'insight-head', text: 'Violations (upward deps)' }));
    if (r.violations.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None — no lower layer depends on a higher one. 🎉' }));
    } else {
      const vl = el('div', { class: 'insight-list' }, []);
      r.violations.slice(0, 40).forEach((v) => vl.appendChild(el('div', {
        class: 'insight-item bad', title: v.fromPath + ' → ' + v.toPath,
      }, [
        el('span', { class: 'mod-name', text: base(v.fromPath) + ' → ' + base(v.toPath) }),
        el('span', { class: 'mod-deps', text: v.fromLayer + '→' + v.toLayer }),
      ])));
      container.appendChild(vl);
    }
  }

  function base(p) { const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')); return i >= 0 ? p.slice(i + 1) : p; }

  function renderComplexityInsights(container) {
    if (!cxReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Scoring complexity…' }));
      return;
    }
    const r = cxReport;
    container.appendChild(el('div', { class: 'details-kind', text: 'avg complexity ' + (r.avgComplexity || 0).toFixed(1) + ' · max ' + r.maxComplexity }));
    if (r.functions.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No functions indexed yet.' }));
      return;
    }
    container.appendChild(el('div', { class: 'insight-head', text: 'Riskiest functions' }));
    const fl = el('div', { class: 'insight-list' }, []);
    r.functions.slice(0, 15).forEach((f) => fl.appendChild(el('button', {
      class: 'insight-item' + (f.complexity >= 10 ? ' bad' : ''), type: 'button',
      title: f.name + ' — complexity ' + f.complexity + ', fan-in ' + f.fanIn + ', fan-out ' + f.fanOut,
      onclick: () => requestGraph(f.nodeId),
    }, [
      el('span', { class: 'badge-num', text: 'cc' + f.complexity }),
      el('span', { class: 'mod-name', text: f.name }),
      el('span', { class: 'mod-deps', text: 'risk ' + f.risk }),
    ])));
    container.appendChild(fl);

    container.appendChild(el('div', { class: 'insight-head', text: 'Files by total complexity' }));
    const ffl = el('div', { class: 'insight-list' }, []);
    r.files.slice(0, 12).forEach((f) => ffl.appendChild(el('div', { class: 'insight-item' }, [
      el('span', { class: 'badge-num', text: String(f.totalComplexity) }),
      el('span', { class: 'mod-name', text: f.path }),
      el('span', { class: 'mod-deps', text: f.functionCount + ' fn · max ' + f.maxComplexity }),
    ])));
    container.appendChild(ffl);
  }

  function renderAutosarInsights(container) {
    if (!autosarReport) {
      container.appendChild(el('div', { class: 'details-empty', text: 'Classifying AUTOSAR modules…' }));
      return;
    }
    const r = autosarReport;
    container.appendChild(el('div', { class: 'details-kind', text: r.recognized + ' module file' + (r.recognized === 1 ? '' : 's') + ' · ' + r.violationCount + ' violation' + (r.violationCount === 1 ? '' : 's') }));
    if (r.recognized === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'No standard AUTOSAR BSW/MCAL modules detected (Can, CanIf, Com, Dio, Rte, …).' }));
      return;
    }
    container.appendChild(el('div', { class: 'insight-head', text: 'Layers (top → bottom)' }));
    const ll = el('div', { class: 'insight-list' }, []);
    r.layers.forEach((l) => ll.appendChild(el('div', { class: 'insight-item', title: l.modules.join(', ') }, [
      el('span', { class: 'badge-num', text: String(l.moduleCount) }),
      el('span', { class: 'mod-name', text: l.label }),
      el('span', { class: 'mod-deps', text: l.modules.slice(0, 4).join(' ') + (l.modules.length > 4 ? ' …' : '') }),
    ])));
    container.appendChild(ll);

    container.appendChild(el('div', { class: 'insight-head', text: 'Non-conformant dependencies' }));
    if (r.violations.length === 0) {
      container.appendChild(el('div', { class: 'details-empty', text: 'None — all dependencies respect the AUTOSAR layer order. 🎉' }));
    } else {
      const vl = el('div', { class: 'insight-list' }, []);
      r.violations.slice(0, 40).forEach((v) => vl.appendChild(el('div', { class: 'insight-item bad', title: v.fromPath + ' → ' + v.toPath }, [
        el('span', { class: 'mod-name', text: v.fromPath + ' → ' + v.toPath }),
        el('span', { class: 'mod-deps', text: v.fromLayer + '→' + v.toLayer }),
      ])));
      container.appendChild(vl);
    }
  }

  function runLayout(count) {
    if (!cy) return;
    cy.resize();
    // Scheduler & Architecture views: a fixed ladder. Rank gives the row
    // (scheduler: 0 = ISRs on top; architecture: 0 = top layer); nodes spread
    // evenly across each row.
    if (state.view === 'scheduler-graph' || state.view === 'architecture-graph' || state.view === 'autosar-graph') {
      const byRank = {};
      cy.nodes().forEach((n) => { const r = n.data('rank') || 0; (byRank[r] = byRank[r] || []).push(n.id()); });
      const ranks = Object.keys(byRank).map(Number).sort((a, b) => a - b);
      const w = Math.max(cy.width(), 420);
      const pos = {};
      ranks.forEach((r, ri) => {
        const ids = byRank[r];
        const gap = w / (ids.length + 1);
        ids.forEach((id, i) => { pos[id] = { x: gap * (i + 1), y: 60 + ri * 90 }; });
      });
      cy.layout({ name: 'preset', positions: (n) => pos[n.id()], fit: true, padding: 36, animate: count <= 120, animationDuration: 350 }).run();
      return;
    }
    const p = lastPayload[state.view];
    const dir = state.graphControls.direction || 'both';
    // A single-direction call graph reads best as a top-down hierarchy rooted
    // at the focus; everything else uses force-directed layout.
    const big = count > 400;
    const useTree = state.view === 'function-graph' && dir !== 'both' && p && p.focus;
    const opts = useTree
      ? {
          name: 'breadthfirst', directed: true, roots: [p.focus],
          // Callers flow upward into the focus; invert so the focus sits on top.
          ...(dir === 'callers' ? { roots: undefined } : {}),
          spacingFactor: 1.1, fit: true, padding: 30, animate: count <= 120, animationDuration: 350,
        }
      : {
          name: 'cose', animate: count <= 120, animationDuration: 350,
          nodeRepulsion: 6000, idealEdgeLength: 70,
          // Label-aware sizing and randomisation get expensive at scale; below
          // a cheaper fixed pass keeps very large neighbourhoods responsive.
          nodeDimensionsIncludeLabels: count <= 300, fit: true, padding: 30,
          numIter: big ? 250 : 1000, randomize: !big,
        };
    cy.layout(opts).run();
    // Level-of-detail: above a threshold, draw edges as cheap straight haystacks
    // (no bezier maths, no arrowheads) — a large rendering win when zoomed out.
    cy.batch(() => cy.edges().style('curve-style', big ? 'haystack' : 'bezier'));
  }

  function relayout() { const p = lastPayload[state.view]; if (p) runLayout(p.nodes.length); }

  // Mounts/refreshes the graph for the current view after a render() pass.
  function syncGraph() {
    ensureCy();
    updateDetails();
    if (pendingApply) {
      const p = lastPayload[state.view];
      if (p) applyGraph(p);
      pendingApply = false;
    } else if (cy) {
      // DOM was rebuilt around the persistent host; make sure sizing is correct.
      requestAnimationFrame(() => { try { cy.resize(); } catch (_) { /* noop */ } });
    }
  }

  window.addEventListener('message', (event) => {
    const msg = event.data;
    if (!msg || typeof msg.type !== 'string') return;
    let full = true;
    switch (msg.type) {
      case 'init':
        state.view = msg.view || 'home';
        state.workspaceName = msg.workspaceName;
        state.engine = msg.engine;
        break;
      case 'navigate':
        state.view = VIEWS[msg.view] ? msg.view : 'home';
        break;
      case 'status':
        state.status = { text: msg.text, busy: !!msg.busy };
        break;
      case 'indexStats':
        state.stats = { files: msg.files, functions: msg.functions, calls: msg.calls || 0, variables: msg.variables || 0, lastBuilt: msg.lastBuilt };
        // A fresh build invalidates cached graphs and analysis.
        lastPayload = { 'file-graph': null, 'function-graph': null, 'module-graph': null };
        depReport = null;
        callReport = null;
        moduleReport = null;
        dataFlowReport = null;
        smReport = null;
        schedReport = null;
        archReport = null;
        cxReport = null;
        autosarReport = null;
        dashReport = null;
        dashRequested = false;
        explainTarget = null;
        explanation = null;
        break;
      case 'config':
        state.engine = msg.engine;
        break;
      case 'graph':
        lastPayload[msg.payload.kind] = msg.payload;
        if (pendingDrill && msg.payload.kind === 'file-graph') {
          pendingDrill = false;
          pendingApply = true;
          persist();
          navigate('file-graph', true);
          full = false;
          break;
        }
        if (msg.payload.kind === state.view) pendingApply = true;
        break;
      case 'dependencyReport':
        depReport = msg.report;
        if (state.view === 'file-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'callReport':
        callReport = msg.report;
        if (state.view === 'function-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'moduleReport':
        moduleReport = msg.report;
        if (state.view === 'module-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'dataFlowReport':
        dataFlowReport = msg.report;
        if (state.view === 'data-flow-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'stateMachineReport':
        smReport = msg.report;
        if (state.view === 'state-machine-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'schedulerReport':
        schedReport = msg.report;
        if (state.view === 'scheduler-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'architectureReport':
        archReport = msg.report;
        if (state.view === 'architecture-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'complexityReport':
        cxReport = msg.report;
        if (state.view === 'complexity-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'autosarReport':
        autosarReport = msg.report;
        if (state.view === 'autosar-graph' && detailsMode === 'insights') { updateDetails(); full = false; }
        else full = false;
        break;
      case 'dashboardReport':
        dashReport = msg.report;
        dashRequested = false;
        if (state.view === 'dashboard') render();
        full = false;
        break;
      case 'explanation':
        if (explainTarget === msg.explanation.target) { explanation = msg.explanation; updateDetails(); }
        full = false;
        break;
      case 'graphError':
        state.status = { text: 'Graph error: ' + msg.message, busy: false };
        break;
      default:
        return;
    }
    persist();
    if (full) render();
    if (isGraphView(state.view) && !lastPayload[state.view] && !pendingDrill) requestGraph('');
  });

  render();
  post({ type: 'ready' });
  if (isGraphView(state.view)) requestGraph('');
})();
