const fs = require('fs');
const path = require('path');

function copy(srcRel, destRel) {
  const src = path.join(__dirname, '..', srcRel);
  const dest = path.join(__dirname, '..', destRel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
  console.log(`Copied ${srcRel} -> ${destRel}`);
}

// sql.js WASM engine, loaded via the extension URI (bundler-safe).
copy('node_modules/sql.js/dist/sql-wasm.wasm', 'resources/sql-wasm.wasm');
// Cytoscape UMD bundle for the webview graph renderer (offline, no CDN).
copy('node_modules/cytoscape/dist/cytoscape.min.js', 'media/vendor/cytoscape.min.js');
