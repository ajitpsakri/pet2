import * as vscode from 'vscode';
import { Logger } from './logger';
import { Config } from './config';
import { AtlasPanel } from './panel/AtlasPanel';
import { AtlasView } from './panel/protocol';
import { Indexer } from './index/Indexer';

/**
 * Registers every command contributed in package.json. View commands open (or
 * reveal) the panel and navigate it; Rebuild Index drives the real indexer
 * through VS Code's progress + cancellation UI.
 */
export function registerCommands(
  context: vscode.ExtensionContext,
  logger: Logger,
  config: Config,
  indexer: Indexer,
): vscode.Disposable[] {
  const openView = (view: AtlasView) => () => {
    logger.info(`Command: open view "${view}".`);
    AtlasPanel.createOrShow(context, logger, config, indexer, view);
  };

  const commands: Array<[string, (...args: unknown[]) => unknown]> = [
    ['embeddedCodeAtlas.open', openView('home')],
    ['embeddedCodeAtlas.showFileGraph', openView('file-graph')],
    ['embeddedCodeAtlas.showFunctionGraph', openView('function-graph')],
    ['embeddedCodeAtlas.showModuleGraph', openView('module-graph')],
    ['embeddedCodeAtlas.showDataFlowGraph', openView('data-flow-graph')],
    ['embeddedCodeAtlas.showStateMachineGraph', openView('state-machine-graph')],
    ['embeddedCodeAtlas.showSchedulerGraph', openView('scheduler-graph')],
    ['embeddedCodeAtlas.showArchitectureGraph', openView('architecture-graph')],
    ['embeddedCodeAtlas.showComplexityGraph', openView('complexity-graph')],
    ['embeddedCodeAtlas.showDashboard', openView('dashboard')],
    ['embeddedCodeAtlas.showAutosarGraph', openView('autosar-graph')],
    ['embeddedCodeAtlas.showLog', () => logger.show()],
    ['embeddedCodeAtlas.rebuildIndex', () => rebuildIndex(logger, indexer)],
  ];

  return commands.map(([id, handler]) => vscode.commands.registerCommand(id, handler));
}

async function rebuildIndex(logger: Logger, indexer: Indexer): Promise<void> {
  logger.info('Command: rebuild index.');
  const panel = AtlasPanel.current();
  panel?.post({ type: 'status', text: 'Indexing…', busy: true });

  try {
    await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: 'Embedded Atlas: building index',
        cancellable: true,
      },
      async (progress, token) => {
        const stats = await indexer.rebuild(
          { report: (message, increment) => progress.report({ message, increment }) },
          token,
        );
        logger.info(`Index built: ${stats.files} files, ${stats.functions} functions, ${stats.classes} classes.`);
      },
    );
    panel?.post({ type: 'status', text: 'Index up to date', busy: false });
  } catch (err) {
    logger.error('Index build failed.', err);
    panel?.post({ type: 'status', text: 'Index build failed — see log', busy: false });
    void vscode.window.showErrorMessage('Embedded Atlas: index build failed. See the Embedded Code Atlas output channel.');
  }
}
