import * as vscode from 'vscode';
import { LogLevel } from './logger';

export const CONFIG_SECTION = 'embeddedCodeAtlas';

export type EngineKind = 'heuristic' | 'clangd' | 'libclang';

export interface AtlasConfig {
  logLevel: LogLevel;
  engine: EngineKind;
  clangPath: string;
  include: string[];
  exclude: string[];
  maxFileSizeKb: number;
  databasePath: string;
  graphMaxNodes: number;
  architectureLayers: string[];
}

/**
 * Reads strongly-typed settings out of the `embeddedCodeAtlas.*` namespace and
 * notifies listeners when any of them change. Centralising config access keeps
 * the rest of the codebase free of magic strings.
 */
export class Config implements vscode.Disposable {
  private readonly emitter = new vscode.EventEmitter<AtlasConfig>();
  readonly onDidChange = this.emitter.event;
  private readonly subscription: vscode.Disposable;

  constructor() {
    this.subscription = vscode.workspace.onDidChangeConfiguration((e) => {
      if (e.affectsConfiguration(CONFIG_SECTION)) {
        this.emitter.fire(this.current());
      }
    });
  }

  current(): AtlasConfig {
    const c = vscode.workspace.getConfiguration(CONFIG_SECTION);
    return {
      logLevel: c.get<LogLevel>('logLevel', 'info'),
      engine: c.get<EngineKind>('engine', 'heuristic'),
      clangPath: c.get<string>('clangPath', 'clang'),
      include: c.get<string[]>('indexing.include', ['**/*.{c,cc,cpp,cxx,h,hh,hpp,hxx}']),
      exclude: c.get<string[]>('indexing.exclude', []),
      maxFileSizeKb: c.get<number>('indexing.maxFileSizeKb', 4096),
      databasePath: c.get<string>('database.path', ''),
      graphMaxNodes: c.get<number>('graph.maxNodes', 1500),
      architectureLayers: c.get<string[]>('architecture.layers', []),
    };
  }

  dispose(): void {
    this.subscription.dispose();
    this.emitter.dispose();
  }
}
