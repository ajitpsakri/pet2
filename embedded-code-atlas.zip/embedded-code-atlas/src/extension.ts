import * as vscode from 'vscode';
import { Logger } from './logger';
import { Config } from './config';
import { registerCommands } from './commands';
import { AtlasPanel } from './panel/AtlasPanel';
import { WorkspaceWatcher } from './workspace/WorkspaceWatcher';
import { Indexer } from './index/Indexer';

let logger: Logger | undefined;

export function activate(context: vscode.ExtensionContext): void {
  const config = new Config();
  const initial = config.current();

  logger = new Logger('Embedded Code Atlas', initial.logLevel);
  logger.info(`Embedded Code Atlas v${context.extension.packageJSON.version} activating…`);
  logger.info(`Engine: ${initial.engine}. Workspace: ${vscode.workspace.name ?? '(none)'}.`);

  context.subscriptions.push(
    config.onDidChange((c) => logger?.setLevel(c.logLevel)),
    config,
    logger,
  );

  // Index lifecycle. Load the persisted DB lazily so activation stays fast;
  // stats flow to the panel via the indexer's update event.
  const indexer = new Indexer(context, logger, config);
  context.subscriptions.push(indexer);
  indexer.load().then(
    (s) => logger?.info(`Index ready: ${s.files} files, ${s.functions} functions.`),
    (err) => logger?.error('Failed to load index.', err),
  );

  // Commands.
  context.subscriptions.push(...registerCommands(context, logger, config, indexer));

  // Workspace watcher -> incremental index updates.
  const watcher = new WorkspaceWatcher(logger, config);
  context.subscriptions.push(
    watcher,
    watcher.onDidChange((change) => {
      void indexer.applyChange(change).catch((err) => logger?.error('Incremental index update failed.', err));
    }),
  );

  // Restore the panel after a window reload.
  context.subscriptions.push(
    vscode.window.registerWebviewPanelSerializer('embeddedCodeAtlas.panel', {
      async deserializeWebviewPanel(panel: vscode.WebviewPanel) {
        if (logger) {
          AtlasPanel.revive(panel, context, logger, config, indexer);
        }
      },
    }),
  );

  logger.info('Embedded Code Atlas activated.');
}

export function deactivate(): void {
  logger?.info('Embedded Code Atlas deactivated.');
  logger = undefined;
}
