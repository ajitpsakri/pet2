import { FileRow } from '../index/IndexDatabase';

/**
 * Built-in layer order, top (most abstract) to bottom (closest to hardware).
 * Each layer has aliases matched against path segments. Files that match no
 * layer are treated as unlayered and excluded from the analysis, so shared
 * utility/common code doesn't generate spurious violations.
 */
const DEFAULT_LAYERS: Array<{ label: string; aliases: string[] }> = [
  { label: 'app', aliases: ['app', 'application', 'apps', 'main'] },
  { label: 'service', aliases: ['service', 'services', 'feature', 'features'] },
  { label: 'middleware', aliases: ['middleware', 'mw', 'rtos', 'os', 'kernel'] },
  { label: 'driver', aliases: ['driver', 'drivers', 'dev', 'device'] },
  { label: 'bsp', aliases: ['bsp', 'board'] },
  { label: 'hal', aliases: ['hal'] },
  { label: 'mcal', aliases: ['mcal', 'periph', 'peripheral', 'register', 'regs'] },
];

export interface LayerInfo {
  label: string;
  rank: number;
  fileCount: number;
}

export interface LayerEdge {
  from: string;
  to: string;
  count: number;
  violation: boolean;
}

export interface Violation {
  fromPath: string;
  toPath: string;
  fromLayer: string;
  toLayer: string;
}

export interface ArchitectureAnalysis {
  layers: LayerInfo[];
  edges: LayerEdge[];
  violations: Violation[];
  totalViolations: number;
  configured: boolean;
}

interface Layering {
  resolve(path: string): { label: string; rank: number } | null;
}

/** Build a layer resolver from configured labels, or fall back to the defaults. */
function makeLayering(configured: string[]): { layering: Layering; configured: boolean } {
  const layers = configured.length
    ? configured.map((label, i) => ({ label: label.toLowerCase(), aliases: [label.toLowerCase()], rank: i }))
    : DEFAULT_LAYERS.map((l, i) => ({ ...l, rank: i }));
  const resolve = (p: string) => {
    const segs = p.toLowerCase().split(/[/\\]/).filter(Boolean);
    for (const layer of layers) {
      for (const seg of segs) {
        if (layer.aliases.some((a) => seg === a || seg.startsWith(a))) {
          return { label: layer.label, rank: layer.rank };
        }
      }
    }
    return null;
  };
  return { layering: { resolve }, configured: configured.length > 0 };
}

/**
 * Map files to architectural layers, aggregate include dependencies between
 * layers, and flag every *upward* dependency (a lower layer depending on a
 * higher one) as a violation of layered architecture.
 */
export function analyzeArchitecture(
  files: FileRow[],
  edges: Array<{ src: number; dst: number }>,
  configuredLayers: string[],
): ArchitectureAnalysis {
  const { layering, configured } = makeLayering(configuredLayers);

  const fileLayer = new Map<number, { label: string; rank: number }>();
  const pathById = new Map<number, string>();
  const counts = new Map<string, { rank: number; n: number }>();
  for (const f of files) {
    pathById.set(f.id, f.path);
    const l = layering.resolve(f.path);
    if (!l) continue;
    fileLayer.set(f.id, l);
    const c = counts.get(l.label) ?? { rank: l.rank, n: 0 };
    c.n++;
    counts.set(l.label, c);
  }

  const layers: LayerInfo[] = [...counts.entries()]
    .map(([label, { rank, n }]) => ({ label, rank, fileCount: n }))
    .sort((a, b) => a.rank - b.rank);

  const edgeAgg = new Map<string, LayerEdge>();
  const violations: Violation[] = [];
  for (const e of edges) {
    const a = fileLayer.get(e.src);
    const b = fileLayer.get(e.dst);
    if (!a || !b || a.label === b.label) continue;
    const violation = a.rank > b.rank; // a (the includer) is below b → upward dep
    const key = `${a.label}->${b.label}`;
    const agg = edgeAgg.get(key);
    if (agg) agg.count++;
    else edgeAgg.set(key, { from: a.label, to: b.label, count: 1, violation });
    if (violation && violations.length < 200) {
      violations.push({ fromPath: pathById.get(e.src) ?? '?', toPath: pathById.get(e.dst) ?? '?', fromLayer: a.label, toLayer: b.label });
    }
  }

  const totalViolations = [...edgeAgg.values()].filter((x) => x.violation).reduce((s, x) => s + x.count, 0);
  return { layers, edges: [...edgeAgg.values()], violations, totalViolations, configured };
}
