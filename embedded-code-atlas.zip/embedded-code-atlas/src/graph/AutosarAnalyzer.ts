import * as path from 'path';
import { FileRow } from '../index/IndexDatabase';

/**
 * Canonical AUTOSAR layered architecture, top (application) to bottom
 * (hardware). Ranks are used the same way as the generic architecture view: an
 * include from a lower layer up into a higher one violates the layering.
 */
const LAYERS = [
  'Application',
  'RTE',
  'Services',
  'ECU Abstraction',
  'Complex Drivers',
  'MCAL',
  'Microcontroller',
] as const;
const RANK: Record<string, number> = Object.fromEntries(LAYERS.map((l, i) => [l, i]));

/** AUTOSAR BSW / MCAL module short-names mapped to their standard layer. */
const MODULE_LAYER: Record<string, string> = {};
const add = (layer: string, mods: string[]) => mods.forEach((m) => { MODULE_LAYER[m] = layer; });
add('RTE', ['Rte', 'Os']); // Os is sometimes drawn beside RTE; keep with RTE band
add('Services', [
  'Com', 'PduR', 'IpduM', 'LdCom', 'NvM', 'MemIf', 'Ea', 'Fee', 'Dcm', 'Dem', 'Det', 'FiM',
  'EcuM', 'BswM', 'ComM', 'EcuC', 'Nm', 'CanNm', 'FrNm', 'UdpNm', 'CanTp', 'FrTp', 'DoIP',
  'CanSM', 'LinSM', 'FrSM', 'EthSM', 'Xcp', 'E2E', 'Crypto', 'CryIf', 'Csm', 'KeyM', 'SecOC',
  'WdgM', 'Tm', 'StbM', 'Sd', 'SoAd', 'TcpIp', 'Dlt',
]);
add('ECU Abstraction', [
  'CanIf', 'LinIf', 'FrIf', 'EthIf', 'CanTrcv', 'LinTrcv', 'FrTrcv', 'EthTrcv', 'WdgIf', 'CanXcp',
]);
add('MCAL', [
  'Can', 'Lin', 'Fr', 'Eth', 'Spi', 'Adc', 'Pwm', 'Icu', 'Gpt', 'Port', 'Dio', 'Mcu', 'Wdg',
  'Fls', 'Eep', 'Ocu', 'CorTst', 'RamTst', 'Sent', 'Ocotp',
]);

export interface AutosarLayer {
  label: string;
  rank: number;
  moduleCount: number;
  modules: string[];
}

export interface AutosarViolation {
  fromPath: string;
  toPath: string;
  fromLayer: string;
  toLayer: string;
}

export interface AutosarAnalysis {
  recognized: number;
  layers: AutosarLayer[];
  violations: AutosarViolation[];
  totalViolations: number;
}

/** Extract the AUTOSAR module short-name from a filename (token before _ or .). */
function moduleOf(p: string): string | null {
  const base = path.basename(p);
  const token = base.split(/[._]/)[0];
  if (!token) return null;
  if (MODULE_LAYER[token]) return token;
  if (/^Cdd/.test(token)) return token; // complex driver
  return null;
}

function layerOf(token: string | null): string | null {
  if (token === null) return null;
  if (MODULE_LAYER[token]) return MODULE_LAYER[token];
  if (/^Cdd/.test(token)) return 'Complex Drivers';
  return null;
}

/**
 * Classify files into AUTOSAR layers by their recognised module name. Files
 * that match no BSW/MCAL module are treated as Application code (the top
 * layer). The view is only meaningful when at least one standard module is
 * present, so callers should check `recognized`.
 */
export function analyzeAutosar(
  files: FileRow[],
  edges: Array<{ src: number; dst: number }>,
): AutosarAnalysis {
  const fileLayer = new Map<number, string>();
  const pathById = new Map<number, string>();
  const layerModules = new Map<string, Set<string>>();
  const layerFiles = new Map<string, number>();
  let recognized = 0;

  for (const f of files) {
    pathById.set(f.id, f.path);
    const token = moduleOf(f.path);
    const layer = layerOf(token) ?? 'Application';
    if (token) recognized++;
    fileLayer.set(f.id, layer);
    layerFiles.set(layer, (layerFiles.get(layer) ?? 0) + 1);
    if (token) {
      if (!layerModules.has(layer)) layerModules.set(layer, new Set());
      layerModules.get(layer)!.add(token);
    }
  }

  const layers: AutosarLayer[] = [...layerFiles.keys()]
    .map((label) => ({ label, rank: RANK[label], moduleCount: layerFiles.get(label) ?? 0, modules: [...(layerModules.get(label) ?? [])].sort() }))
    .sort((a, b) => a.rank - b.rank);

  const violations: AutosarViolation[] = [];
  const seen = new Set<string>();
  for (const e of edges) {
    const a = fileLayer.get(e.src);
    const b = fileLayer.get(e.dst);
    if (!a || !b || a === b) continue;
    if (RANK[a] > RANK[b]) {
      const key = `${a}->${b}`;
      if (!seen.has(key) || violations.length < 200) seen.add(key);
      violations.push({ fromPath: pathById.get(e.src) ?? '?', toPath: pathById.get(e.dst) ?? '?', fromLayer: a, toLayer: b });
    }
  }

  return { recognized, layers, violations: violations.slice(0, 200), totalViolations: violations.length };
}
