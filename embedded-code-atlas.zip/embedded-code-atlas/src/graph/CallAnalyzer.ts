import { FnRow } from '../index/IndexDatabase';
import { tarjanCycles } from './scc';

export interface CallCycle {
  ids: number[];
  labels: string[];
}

export interface CallEntry {
  id: number;
  name: string;
  file: string;
  line: number;
}

export interface MostCalled {
  id: number;
  name: string;
  callers: number;
}

export interface CallAnalysis {
  totalFunctions: number;
  totalCalls: number;
  /** Recursive cliques (direct or mutual recursion) found via SCC. */
  recursion: CallCycle[];
  inCycle: Set<number>;
  /** Functions nobody calls but that call others — natural roots / entry points. */
  entryPoints: CallEntry[];
  mostCalled: MostCalled[];
  /** caller -> callees adjacency, for path tracing. */
  adjacency: Map<number, number[]>;
}

export function analyzeCalls(
  functions: FnRow[],
  edges: Array<{ src: number; dst: number }>,
): CallAnalysis {
  const byId = new Map<number, FnRow>();
  for (const f of functions) byId.set(f.id, f);

  const adjacency = new Map<number, number[]>();
  const incoming = new Map<number, number>();
  const outgoing = new Map<number, number>();
  for (const f of functions) { adjacency.set(f.id, []); incoming.set(f.id, 0); outgoing.set(f.id, 0); }
  for (const e of edges) {
    if (!adjacency.has(e.src) || !byId.has(e.dst)) continue;
    adjacency.get(e.src)!.push(e.dst);
    outgoing.set(e.src, (outgoing.get(e.src) ?? 0) + 1);
    incoming.set(e.dst, (incoming.get(e.dst) ?? 0) + 1);
  }

  const cycles = tarjanCycles(functions.map((f) => f.id), adjacency);
  const inCycle = new Set<number>();
  for (const c of cycles) for (const id of c) inCycle.add(id);
  const recursion: CallCycle[] = cycles
    .map((ids) => ({ ids, labels: ids.map((id) => byId.get(id)?.name ?? String(id)) }))
    .sort((a, b) => b.ids.length - a.ids.length);

  const entryPoints: CallEntry[] = functions
    .filter((f) => (incoming.get(f.id) ?? 0) === 0 && (outgoing.get(f.id) ?? 0) > 0)
    .map((f) => ({ id: f.id, name: f.name, file: f.file, line: f.line }))
    .sort((a, b) => (outgoing.get(b.id) ?? 0) - (outgoing.get(a.id) ?? 0))
    .slice(0, 25);

  const mostCalled: MostCalled[] = functions
    .map((f) => ({ id: f.id, name: f.name, callers: incoming.get(f.id) ?? 0 }))
    .filter((m) => m.callers > 0)
    .sort((a, b) => b.callers - a.callers)
    .slice(0, 25);

  return {
    totalFunctions: functions.length,
    totalCalls: edges.length,
    recursion,
    inCycle,
    entryPoints,
    mostCalled,
    adjacency,
  };
}

/**
 * Shortest call path from `from` to `to` over the callee adjacency (BFS).
 * Returns the ordered list of function ids, or null if `to` is unreachable.
 * This answers "can A ever call B?" — e.g. can an ISR reach a blocking call.
 */
export function callPath(adjacency: Map<number, number[]>, from: number, to: number): number[] | null {
  if (from === to) return [from];
  const prev = new Map<number, number>();
  const seen = new Set<number>([from]);
  const queue: number[] = [from];
  while (queue.length) {
    const v = queue.shift()!;
    for (const w of adjacency.get(v) ?? []) {
      if (seen.has(w)) continue;
      seen.add(w);
      prev.set(w, v);
      if (w === to) {
        const path = [to];
        let cur = to;
        while (cur !== from) { cur = prev.get(cur)!; path.push(cur); }
        return path.reverse();
      }
      queue.push(w);
    }
  }
  return null;
}
