import { VarRow } from '../index/IndexDatabase';

export interface VarStat {
  id: number;
  name: string;
  scope: string;
  reads: number;
  writes: number;
  writers: number;
}

export interface DataFlowAnalysis {
  totalVariables: number;
  totalRefs: number;
  hotspots: VarStat[];
  multiWriter: VarStat[];
}

/**
 * Aggregates variable references project-wide. The headline embedded concern is
 * *shared mutable state*: a global written from more than one function is a
 * concurrency / re-entrancy risk (ISR vs main loop, multiple tasks), so those
 * are surfaced separately from raw reference counts.
 */
export function analyzeDataFlow(
  variables: VarRow[],
  refEdges: Array<{ fn: number; var: number; kind: string }>,
): DataFlowAnalysis {
  const byId = new Map<number, VarRow>();
  for (const v of variables) byId.set(v.id, v);

  const reads = new Map<number, number>();
  const writes = new Map<number, number>();
  const writers = new Map<number, Set<number>>();
  let totalRefs = 0;
  for (const e of refEdges) {
    if (!byId.has(e.var)) continue;
    totalRefs++;
    if (e.kind === 'write') {
      writes.set(e.var, (writes.get(e.var) ?? 0) + 1);
      if (!writers.has(e.var)) writers.set(e.var, new Set());
      writers.get(e.var)!.add(e.fn);
    } else {
      reads.set(e.var, (reads.get(e.var) ?? 0) + 1);
    }
  }

  const stats: VarStat[] = variables.map((v) => ({
    id: v.id,
    name: v.name,
    scope: v.scope,
    reads: reads.get(v.id) ?? 0,
    writes: writes.get(v.id) ?? 0,
    writers: writers.get(v.id)?.size ?? 0,
  }));

  const hotspots = stats
    .filter((s) => s.reads + s.writes > 0)
    .sort((a, b) => (b.reads + b.writes) - (a.reads + a.writes))
    .slice(0, 25);

  const multiWriter = stats
    .filter((s) => s.writers > 1)
    .sort((a, b) => b.writers - a.writers || b.writes - a.writes)
    .slice(0, 25);

  return { totalVariables: variables.length, totalRefs, hotspots, multiWriter };
}
