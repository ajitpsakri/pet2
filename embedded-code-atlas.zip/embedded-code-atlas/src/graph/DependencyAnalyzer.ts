import * as path from 'path';
import { FileRow } from '../index/IndexDatabase';
import { tarjanCycles } from './scc';

/** A circular include dependency: an ordered ring of file ids. */
export interface FileCycle {
  ids: number[];
  paths: string[];
}

export interface Hotspot {
  id: number;
  path: string;
  fanIn: number;
  fanOut: number;
}

export interface Cluster {
  name: string;
  fileCount: number;
}

export interface DependencyAnalysis {
  totalFiles: number;
  totalEdges: number;
  cycles: FileCycle[];
  hotspots: Hotspot[];
  clusters: Cluster[];
  /** File ids that participate in at least one cycle. */
  inCycle: Set<number>;
  fanIn: Map<number, number>;
  fanOut: Map<number, number>;
}

/**
 * Analyses the whole resolved include graph in one pass:
 *   - circular dependencies via Tarjan's strongly-connected-components (any SCC
 *     larger than one node, or a self-loop, is a dependency cycle);
 *   - hotspots ranked by fan-in (a header pulled in by many files);
 *   - folder clusters relative to the common path root.
 *
 * Runs in O(V + E) and is computed once per index build, then cached.
 */
export function analyzeDependencies(
  files: FileRow[],
  edges: Array<{ src: number; dst: number }>,
): DependencyAnalysis {
  const pathById = new Map<number, string>();
  for (const f of files) pathById.set(f.id, f.path);

  const adj = new Map<number, number[]>();
  const fanIn = new Map<number, number>();
  const fanOut = new Map<number, number>();
  for (const f of files) { adj.set(f.id, []); fanIn.set(f.id, 0); fanOut.set(f.id, 0); }
  for (const e of edges) {
    if (!adj.has(e.src) || !pathById.has(e.dst)) continue;
    adj.get(e.src)!.push(e.dst);
    fanOut.set(e.src, (fanOut.get(e.src) ?? 0) + 1);
    fanIn.set(e.dst, (fanIn.get(e.dst) ?? 0) + 1);
  }

  const cycles = tarjanCycles(files.map((f) => f.id), adj);
  const inCycle = new Set<number>();
  for (const c of cycles) for (const id of c) inCycle.add(id);

  const cycleRecords: FileCycle[] = cycles
    .map((ids) => ({ ids, paths: ids.map((id) => pathById.get(id) ?? String(id)) }))
    .sort((a, b) => b.ids.length - a.ids.length);

  const hotspots: Hotspot[] = files
    .map((f) => ({ id: f.id, path: f.path, fanIn: fanIn.get(f.id) ?? 0, fanOut: fanOut.get(f.id) ?? 0 }))
    .filter((h) => h.fanIn > 0 || h.fanOut > 0)
    .sort((a, b) => b.fanIn - a.fanIn || b.fanOut - a.fanOut)
    .slice(0, 25);

  return {
    totalFiles: files.length,
    totalEdges: edges.length,
    cycles: cycleRecords,
    hotspots,
    clusters: clusterByFolder(files),
    inCycle,
    fanIn,
    fanOut,
  };
}


/** Group files by the path segment just below their common root directory. */
function clusterByFolder(files: FileRow[]): Cluster[] {
  if (files.length === 0) return [];
  const dirs = files.map((f) => path.dirname(f.path).split(/[\\/]/).filter(Boolean));
  const root = commonPrefix(dirs);
  const counts = new Map<string, number>();
  for (const segs of dirs) {
    const name = segs.length > root.length ? segs[root.length] : '(root)';
    counts.set(name, (counts.get(name) ?? 0) + 1);
  }
  return [...counts.entries()]
    .map(([name, fileCount]) => ({ name, fileCount }))
    .sort((a, b) => b.fileCount - a.fileCount);
}

function commonPrefix(seqs: string[][]): string[] {
  if (seqs.length === 0) return [];
  let prefix = seqs[0];
  for (const s of seqs.slice(1)) {
    let i = 0;
    while (i < prefix.length && i < s.length && prefix[i] === s[i]) i++;
    prefix = prefix.slice(0, i);
    if (prefix.length === 0) break;
  }
  return prefix;
}
