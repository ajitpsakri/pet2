import * as path from 'path';
import { IndexDatabase } from '../index/IndexDatabase';
import { Explanation } from './types';

const ISR_RE = /(_IRQHandler|_Handler|Handler|_ISR|^ISR_)/;

function complexityWord(cc: number): string {
  if (cc <= 3) return 'low';
  if (cc <= 7) return 'moderate';
  if (cc <= 14) return 'high';
  return 'very high';
}

/** Join a list of names into readable prose, truncating long lists. */
function nameList(names: string[], max = 6): string {
  const uniq = [...new Set(names)];
  if (uniq.length <= max) return uniq.join(', ');
  return `${uniq.slice(0, max).join(', ')} (and ${uniq.length - max} more)`;
}

/**
 * Build a plain-English explanation of a function purely from indexed facts —
 * no model, no network. Every sentence is grounded in something the indexer
 * actually recorded (calls, references, complexity, task/ISR conventions).
 */
export function explainFunction(db: IndexDatabase, id: number, recursive: boolean): Explanation {
  const fn = db.functionById(id);
  if (!fn) return { target: `fn:${id}`, title: 'Unknown function', lines: ['This function is no longer in the index.'] };

  const cc = db.functionComplexity(id);
  const outs = db.outgoing(id);
  const ins = db.incoming(id);
  const vars = db.functionVarRefs(id);
  const isTask = db.listTasks().find((t) => t.entry === fn.name);
  const lines: string[] = [];

  // Opening: what and where.
  lines.push(`${fn.signature} is defined in ${path.basename(fn.file)} at line ${fn.line}.`);

  // Role.
  const roles: string[] = [];
  if (isTask) roles.push(`the entry point of RTOS task ${isTask.name ? `"${isTask.name}"` : `(${isTask.api})`}${isTask.period ? `, running every ${isTask.period}` : ''}`);
  if (ISR_RE.test(fn.name)) roles.push('an interrupt handler (by naming convention)');
  if (recursive) roles.push('part of a recursive cycle');
  if (ins.length === 0 && outs.length > 0 && !isTask) roles.push('uncalled within the codebase — likely an entry point or invoked externally');
  if (ins.length === 0 && outs.length === 0) roles.push('isolated — it neither calls nor is called by indexed code');
  if (roles.length) lines.push(`It appears to be ${roles.join('; ')}.`);

  // Complexity.
  lines.push(`Its cyclomatic complexity is ${cc} (${complexityWord(cc)})${cc >= 15 ? ' — a strong candidate for refactoring or extra test coverage' : ''}.`);

  // Calls out.
  if (outs.length) {
    const resolved = outs.filter((o) => o.resolved).map((o) => o.name);
    const unresolved = outs.filter((o) => !o.resolved).map((o) => o.name);
    let s = `It calls ${nameList(outs.map((o) => o.name))}`;
    if (unresolved.length && resolved.length) s += ` (${unresolved.length} unresolved — likely library or macro calls)`;
    else if (unresolved.length && !resolved.length) s += ' (none resolved to indexed definitions — likely library or macro calls)';
    lines.push(s + '.');
  } else {
    lines.push('It makes no calls to other functions.');
  }

  // Called by.
  if (ins.length) lines.push(`It is called by ${nameList(ins.map((i) => i.name))} (${ins.length} caller${ins.length === 1 ? '' : 's'}).`);

  // Data touched.
  const reads = vars.filter((v) => v.reads > 0).map((v) => v.name);
  const writes = vars.filter((v) => v.writes > 0).map((v) => v.name);
  if (reads.length || writes.length) {
    const parts: string[] = [];
    if (reads.length) parts.push(`reads ${nameList(reads)}`);
    if (writes.length) parts.push(`writes ${nameList(writes)}`);
    lines.push(`On global state, it ${parts.join(' and ')}.`);
  }

  return { target: `fn:${id}`, title: fn.signature, lines };
}

/** Build a plain-English explanation of a file from its include relationships. */
export function explainFile(db: IndexDatabase, id: number, includedBy: number, inCycle: boolean): Explanation {
  const files = db.allFiles();
  const f = files.find((x) => x.id === id);
  if (!f) return { target: `file:${id}`, title: 'Unknown file', lines: ['This file is no longer in the index.'] };

  const includes = db.allIncludeEdges().filter((e) => e.src === id).length;
  const fnCount = db.functionRiskRows().filter((r) => r.file === f.path);
  const totalCx = fnCount.reduce((s, r) => s + r.complexity, 0);
  const lines: string[] = [];
  lines.push(`${path.basename(f.path)} includes ${includes} other indexed file${includes === 1 ? '' : 's'} and is included by ${includedBy}.`);
  lines.push(`It defines ${fnCount.length} function${fnCount.length === 1 ? '' : 's'} with a combined cyclomatic complexity of ${totalCx}.`);
  if (inCycle) lines.push('It participates in a circular include dependency, which can slow incremental builds and tangle ownership.');
  if (includedBy >= 8) lines.push(`With ${includedBy} dependents it is a hotspot — changes here ripple widely, so its interface should stay stable.`);
  return { target: `file:${id}`, title: path.basename(f.path), lines };
}
