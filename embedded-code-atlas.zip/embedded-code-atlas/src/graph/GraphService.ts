import * as path from 'path';
import { IndexDatabase, CallNeighbor, FnRow, FileRow, VarRow, SmRow } from '../index/IndexDatabase';
import { GraphPayload, GraphNode, GraphEdge, GraphRequest } from './types';
import { ModuleAnalysis } from './ModuleAnalyzer';
import { ArchitectureAnalysis } from './ArchitectureAnalyzer';
import { RiskAnalysis } from './RiskAnalyzer';
import { AutosarAnalysis } from './AutosarAnalyzer';

/**
 * Turns the indexed relational data into a renderable neighbourhood slice.
 *
 * Two strategies:
 *  - *Overview* (no seed): the most-connected nodes plus the edges among them,
 *    so opening a graph cold still shows the shape of the codebase.
 *  - *Focused*: breadth-first expansion outward from a seed node up to `depth`
 *    hops, stopping at `maxNodes` so the renderer never chokes.
 */
export class GraphService {
  constructor(private readonly db: IndexDatabase) {}

  build(req: GraphRequest): GraphPayload {
    switch (req.kind) {
      case 'function-graph':
        return this.functionGraph(req);
      case 'file-graph':
        return this.fileGraph(req);
      case 'data-flow-graph':
        return this.dataFlowGraph(req);
      case 'state-machine-graph':
        return this.stateMachineGraph(req);
      case 'scheduler-graph':
        return this.schedulerGraph();
      case 'architecture-graph':
        // Built by the Indexer via buildArchitecture(); never routed here.
        return { kind: 'architecture-graph', focus: null, nodes: [], edges: [], truncated: false };
      case 'complexity-graph':
        // Built by the Indexer via buildComplexity(); never routed here.
        return { kind: 'complexity-graph', focus: null, nodes: [], edges: [], truncated: false };
      case 'autosar-graph':
        // Built by the Indexer via buildAutosar(); never routed here.
        return { kind: 'autosar-graph', focus: null, nodes: [], edges: [], truncated: false };
      case 'module-graph':
        return {
          kind: 'module-graph',
          focus: null,
          nodes: [],
          edges: [],
          truncated: false,
          note: 'Module detection arrives in Phase 7. Use the file or function graph for now.',
        };
    }
  }

  // ---- Function call graph ------------------------------------------------

  private functionGraph(req: GraphRequest): GraphPayload {
    const seedRow = this.resolveFunctionSeed(req.seed);
    if (!seedRow) {
      return this.functionOverview(req.maxNodes);
    }

    const nodes = new Map<string, GraphNode>();
    const edges = new Map<string, GraphEdge>();
    const fnNodeId = (id: number) => `fn:${id}`;

    nodes.set(fnNodeId(seedRow.id), this.fnNode(seedRow, true));

    let frontier = [seedRow.id];
    const visited = new Set<number>([seedRow.id]);
    let truncated = false;
    const dir = req.direction ?? 'both';

    for (let hop = 0; hop < req.depth && frontier.length; hop++) {
      const next: number[] = [];
      for (const id of frontier) {
        const callerKey = fnNodeId(id);
        if (dir === 'both' || dir === 'callees') {
          for (const nb of this.db.outgoing(id)) {
            if (this.addCallEdge(nodes, edges, callerKey, nb, 'out', req.maxNodes, visited, next)) continue;
            truncated = true;
          }
        }
        if (dir === 'both' || dir === 'callers') {
          for (const nb of this.db.incoming(id)) {
            if (this.addCallEdge(nodes, edges, callerKey, nb, 'in', req.maxNodes, visited, next)) continue;
            truncated = true;
          }
        }
        if (nodes.size >= req.maxNodes) { truncated = true; break; }
      }
      frontier = next;
    }

    return {
      kind: 'function-graph',
      focus: fnNodeId(seedRow.id),
      nodes: [...nodes.values()],
      edges: [...edges.values()],
      truncated,
    };
  }

  /**
   * Adds one call neighbour and its edge. Returns false only when the node cap
   * blocked adding a brand-new node (so the caller can flag truncation).
   */
  private addCallEdge(
    nodes: Map<string, GraphNode>,
    edges: Map<string, GraphEdge>,
    currentKey: string,
    nb: CallNeighbor,
    dir: 'out' | 'in',
    maxNodes: number,
    visited: Set<number>,
    next: number[],
  ): boolean {
    const nbKey = nb.id !== null ? `fn:${nb.id}` : `u:${nb.name}`;
    if (!nodes.has(nbKey)) {
      if (nodes.size >= maxNodes) return false;
      nodes.set(nbKey, this.callNode(nb));
      if (nb.id !== null && !visited.has(nb.id)) {
        visited.add(nb.id);
        next.push(nb.id);
      }
    }
    const source = dir === 'out' ? currentKey : nbKey;
    const target = dir === 'out' ? nbKey : currentKey;
    const edgeId = `${source}->${target}`;
    if (!edges.has(edgeId)) {
      edges.set(edgeId, { id: edgeId, source, target, kind: 'call', count: nb.count });
    }
    return true;
  }

  private functionOverview(maxNodes: number): GraphPayload {
    const top = this.db.topFunctions(Math.min(maxNodes, 60));
    const idset = new Set(top.map((f) => f.id));
    const nodes = top.map((f) => this.fnNode(f, false));
    const edges = new Map<string, GraphEdge>();
    for (const f of top) {
      for (const nb of this.db.outgoing(f.id)) {
        if (nb.id !== null && idset.has(nb.id)) {
          const id = `fn:${f.id}->fn:${nb.id}`;
          edges.set(id, { id, source: `fn:${f.id}`, target: `fn:${nb.id}`, kind: 'call', count: nb.count });
        }
      }
    }
    return {
      kind: 'function-graph',
      focus: null,
      nodes,
      edges: [...edges.values()],
      truncated: false,
      note: nodes.length ? 'Overview: most-connected functions. Search or click a node to explore.' : 'No functions indexed yet — build the index first.',
    };
  }

  private fnNode(f: FnRow, seed: boolean): GraphNode {
    return { id: `fn:${f.id}`, label: f.name, kind: 'function', detail: f.signature, file: f.file, line: f.line, seed, resolved: true };
  }

  private callNode(nb: CallNeighbor): GraphNode {
    if (nb.id !== null) {
      return { id: `fn:${nb.id}`, label: nb.name, kind: 'function', detail: nb.signature ?? undefined, file: nb.file ?? undefined, line: nb.line ?? undefined, resolved: true };
    }
    return { id: `u:${nb.name}`, label: nb.name, kind: 'unresolved', detail: 'unresolved call target', resolved: false };
  }

  private resolveFunctionSeed(seed?: string): FnRow | null {
    if (!seed) return null;
    if (seed.startsWith('fn:')) {
      const id = Number(seed.slice(3));
      return Number.isFinite(id) ? this.db.functionById(id) : null;
    }
    return this.db.lookupFunctions(seed, 1)[0] ?? null;
  }

  /** Build a graph of an ordered call path: nodes for each id, edges between
   *  consecutive hops. Endpoints are marked as seeds. */
  buildCallPath(ids: number[], note: string): GraphPayload {
    const nodes = new Map<string, GraphNode>();
    const edges = new Map<string, GraphEdge>();
    ids.forEach((id, i) => {
      const row = this.db.functionById(id);
      if (row) {
        const n = this.fnNode(row, i === 0 || i === ids.length - 1);
        nodes.set(n.id, n);
      }
      if (i > 0) {
        const eid = `fn:${ids[i - 1]}->fn:${id}`;
        edges.set(eid, { id: eid, source: `fn:${ids[i - 1]}`, target: `fn:${id}`, kind: 'call' });
      }
    });
    return { kind: 'function-graph', focus: `fn:${ids[0]}`, nodes: [...nodes.values()], edges: [...edges.values()], truncated: false, note };
  }

  // ---- File dependency graph ---------------------------------------------

  private fileGraph(req: GraphRequest): GraphPayload {
    const seedRow = this.resolveFileSeed(req.seed);
    if (!seedRow) {
      return this.fileOverview(req.maxNodes);
    }

    const nodes = new Map<string, GraphNode>();
    const edges = new Map<string, GraphEdge>();
    const key = (id: number) => `file:${id}`;
    nodes.set(key(seedRow.id), this.fileNode(seedRow, true));

    let frontier: FileRow[] = [seedRow];
    const visited = new Set<number>([seedRow.id]);
    let truncated = false;

    for (let hop = 0; hop < req.depth && frontier.length; hop++) {
      const next: FileRow[] = [];
      for (const f of frontier) {
        const { out, in: inc } = this.db.fileNeighbors(f.id, f.path);
        for (const nb of out) {
          if (!this.addFileEdge(nodes, edges, key(f.id), nb, 'out', req.maxNodes, visited, next)) truncated = true;
        }
        for (const nb of inc) {
          if (!this.addFileEdge(nodes, edges, key(f.id), nb, 'in', req.maxNodes, visited, next)) truncated = true;
        }
        if (nodes.size >= req.maxNodes) { truncated = true; break; }
      }
      frontier = next;
    }

    return { kind: 'file-graph', focus: key(seedRow.id), nodes: [...nodes.values()], edges: [...edges.values()], truncated };
  }

  private addFileEdge(
    nodes: Map<string, GraphNode>,
    edges: Map<string, GraphEdge>,
    currentKey: string,
    nb: FileRow,
    dir: 'out' | 'in',
    maxNodes: number,
    visited: Set<number>,
    next: FileRow[],
  ): boolean {
    const nbKey = `file:${nb.id}`;
    if (nbKey === currentKey) return true;
    if (!nodes.has(nbKey)) {
      if (nodes.size >= maxNodes) return false;
      nodes.set(nbKey, this.fileNode(nb, false));
      if (!visited.has(nb.id)) { visited.add(nb.id); next.push(nb); }
    }
    const source = dir === 'out' ? currentKey : nbKey;
    const target = dir === 'out' ? nbKey : currentKey;
    const edgeId = `${source}=>${target}`;
    if (!edges.has(edgeId)) edges.set(edgeId, { id: edgeId, source, target, kind: 'include' });
    return true;
  }

  private fileOverview(maxNodes: number): GraphPayload {
    const top = this.db.topFiles(Math.min(maxNodes, 60));
    const idset = new Set(top.map((f) => f.id));
    const nodes = top.map((f) => this.fileNode(f, false));
    const edges = new Map<string, GraphEdge>();
    for (const f of top) {
      for (const nb of this.db.fileNeighbors(f.id, f.path).out) {
        if (idset.has(nb.id)) {
          const id = `file:${f.id}=>file:${nb.id}`;
          edges.set(id, { id, source: `file:${f.id}`, target: `file:${nb.id}`, kind: 'include' });
        }
      }
    }
    return {
      kind: 'file-graph',
      focus: null,
      nodes,
      edges: [...edges.values()],
      truncated: false,
      note: nodes.length ? 'Overview: files with the most includes. Search or click a node to explore.' : 'No files indexed yet — build the index first.',
    };
  }

  private fileNode(f: FileRow, seed: boolean): GraphNode {
    return { id: `file:${f.id}`, label: path.basename(f.path), kind: 'file', detail: f.path, file: f.path, seed };
  }

  private resolveFileSeed(seed?: string): FileRow | null {
    if (!seed) return null;
    if (seed.startsWith('file:')) {
      const id = Number(seed.slice(5));
      return Number.isFinite(id) ? this.db.fileById(id) : null;
    }
    return this.db.lookupFiles(seed, 1)[0] ?? null;
  }

  /** Build a graph of exactly the given files and the include edges among them. */
  buildFileSubgraph(ids: number[]): GraphPayload {
    const idset = new Set(ids);
    const nodes = new Map<string, GraphNode>();
    const edges = new Map<string, GraphEdge>();
    for (const id of ids) {
      const row = this.db.fileById(id);
      if (row) nodes.set(`file:${id}`, this.fileNode(row, false));
    }
    for (const id of ids) {
      const row = this.db.fileById(id);
      if (!row) continue;
      for (const nb of this.db.fileNeighbors(id, row.path).out) {
        if (idset.has(nb.id)) {
          const edgeId = `file:${id}=>file:${nb.id}`;
          edges.set(edgeId, { id: edgeId, source: `file:${id}`, target: `file:${nb.id}`, kind: 'include' });
        }
      }
    }
    return {
      kind: 'file-graph',
      focus: null,
      nodes: [...nodes.values()],
      edges: [...edges.values()],
      truncated: false,
      note: `Cycle: ${ids.length} files in a circular include dependency.`,
    };
  }

  /** Build the module-level architecture graph from a module analysis. */
  /** Render AUTOSAR module classification as a canonical layer stack. */
  buildAutosar(a: AutosarAnalysis): GraphPayload {
    if (a.recognized === 0) {
      return { kind: 'autosar-graph', focus: null, nodes: [], edges: [], truncated: false,
        note: 'No standard AUTOSAR BSW/MCAL modules detected (Can, CanIf, Com, Dio, Rte, …). This view is meant for AUTOSAR-style codebases.' };
    }
    const nodes: GraphNode[] = a.layers.map((l) => ({
      id: `layer:${l.label}`, label: `${l.label} (${l.moduleCount})`, kind: 'layer', rank: l.rank,
      detail: l.modules.length ? `modules: ${l.modules.join(', ')}` : `${l.moduleCount} file${l.moduleCount === 1 ? '' : 's'}`,
    }));
    const seen = new Set<string>();
    const edges: GraphEdge[] = [];
    for (const v of a.violations) {
      const key = `${v.fromLayer}=>${v.toLayer}`;
      if (seen.has(key)) continue;
      seen.add(key);
      edges.push({ id: key, source: `layer:${v.fromLayer}`, target: `layer:${v.toLayer}`, kind: 'violation', count: 1 });
    }
    return {
      kind: 'autosar-graph', focus: null, nodes, edges, truncated: false,
      note: a.totalViolations === 0
        ? `${a.recognized} AUTOSAR module files across ${a.layers.length} layers — no upward dependencies. Conformant.`
        : `${a.recognized} module files · ${a.totalViolations} non-conformant upward dependenc${a.totalViolations === 1 ? 'y' : 'ies'} (red).`,
    };
  }

  /** Render the top-risk functions as a heat-coloured call subgraph. */
  buildComplexity(a: RiskAnalysis, maxNodes: number): GraphPayload {
    if (a.functions.length === 0) {
      return { kind: 'complexity-graph', focus: null, nodes: [], edges: [], truncated: false, note: 'No functions indexed yet — build the index first.' };
    }
    const cap = Math.min(maxNodes, 40);
    const top = a.functions.slice(0, cap);
    const ids = new Set(top.map((f) => f.id));
    const nodes: GraphNode[] = top.map((f, i) => ({
      id: `fn:${f.id}`, label: f.name, kind: 'function', complexity: f.complexity,
      detail: `${f.name} — complexity ${f.complexity}, fan-in ${f.fanIn}, fan-out ${f.fanOut}, risk ${f.risk}`,
      file: f.file, line: f.line, seed: i === 0,
    }));
    const edges: GraphEdge[] = [];
    for (const e of this.db.allCallEdges()) {
      if (ids.has(e.src) && ids.has(e.dst) && e.src !== e.dst) {
        edges.push({ id: `c:${e.src}->${e.dst}`, source: `fn:${e.src}`, target: `fn:${e.dst}`, kind: 'call', count: 1 });
      }
    }
    return {
      kind: 'complexity-graph', focus: `fn:${top[0].id}`, nodes, edges,
      truncated: a.functions.length > cap,
      note: `Top ${top.length} functions by risk (of ${a.functions.length}). Colour = cyclomatic complexity (green → red); avg ${a.avgComplexity.toFixed(1)}, max ${a.maxComplexity}.`,
    };
  }

  /** Render the layering analysis as a vertical layer stack; upward deps are violations. */
  buildArchitecture(a: ArchitectureAnalysis): GraphPayload {
    if (a.layers.length === 0) {
      return { kind: 'architecture-graph', focus: null, nodes: [], edges: [], truncated: false,
        note: a.configured ? 'No files matched the configured architecture layers.' : 'No recognised layers (app / middleware / driver / hal / …). Configure embeddedCodeAtlas.architecture.layers to map your folders.' };
    }
    const nodes: GraphNode[] = a.layers.map((l) => ({
      id: `layer:${l.label}`, label: `${l.label} (${l.fileCount})`, kind: 'layer', rank: l.rank,
      detail: `layer ${l.rank} · ${l.fileCount} file${l.fileCount === 1 ? '' : 's'}`,
    }));
    const edges: GraphEdge[] = a.edges.map((e) => ({
      id: `${e.from}=>${e.to}`, source: `layer:${e.from}`, target: `layer:${e.to}`,
      kind: e.violation ? 'violation' : 'layerdep', count: e.count,
    }));
    const v = a.totalViolations;
    return { kind: 'architecture-graph', focus: null, nodes, edges, truncated: false,
      note: v === 0
        ? `${a.layers.length} layers, no upward dependencies — layering is clean.`
        : `${a.layers.length} layers · ${v} upward dependency violation${v === 1 ? '' : 's'} (red). Lower layers should not depend on higher ones.` };
  }

  buildModuleGraph(analysis: ModuleAnalysis): GraphPayload {
    const nodes: GraphNode[] = analysis.modules.map((m) => ({
      id: `mod:${m.index}`,
      label: m.name,
      kind: 'module',
      detail: `${m.fileIds.length} file${m.fileIds.length === 1 ? '' : 's'}`,
      fileCount: m.fileIds.length,
      inCycle: analysis.inCycle.has(m.index),
    }));
    const edges: GraphEdge[] = analysis.edges.map((e) => ({
      id: `mod:${e.src}=>mod:${e.dst}`,
      source: `mod:${e.src}`,
      target: `mod:${e.dst}`,
      kind: 'include',
      count: e.weight,
    }));
    const note = nodes.length
      ? `${nodes.length} modules · ${edges.length} cross-module dependencies. Click a module to inspect its files.`
      : 'No files indexed yet — build the index first.';
    return { kind: 'module-graph', focus: null, nodes, edges, truncated: false, note };
  }

  /** Build a file graph of the files inside one module (drill-down). */
  buildModuleFiles(name: string, fileIds: number[], maxNodes: number): GraphPayload {
    const capped = fileIds.slice(0, maxNodes);
    const payload = this.buildFileSubgraph(capped);
    payload.note = `Files in module "${name}" (${capped.length}${fileIds.length > capped.length ? ' of ' + fileIds.length : ''}).`;
    payload.truncated = fileIds.length > capped.length;
    return payload;
  }

  // ---- Data flow ----------------------------------------------------------

  private dataFlowGraph(req: GraphRequest): GraphPayload {
    const seed = req.seed;
    if (seed && seed.startsWith('var:')) {
      const v = this.db.variableById(Number(seed.slice(4)));
      if (v) return this.variableFlow(v, req.maxNodes);
    }
    if (seed && seed.startsWith('fn:')) {
      const f = this.db.functionById(Number(seed.slice(3)));
      if (f) return this.functionFlow(f, req.maxNodes);
    }
    if (seed) {
      const v = this.db.lookupVariables(seed, 1)[0];
      if (v) return this.variableFlow(v, req.maxNodes);
      const f = this.db.lookupFunctions(seed, 1)[0];
      if (f) return this.functionFlow(f, req.maxNodes);
    }
    return this.dataFlowOverview(req.maxNodes);
  }

  private variableFlow(v: VarRow, maxNodes: number): GraphPayload {
    const nodes: GraphNode[] = [this.varNode(v, true)];
    const edges: GraphEdge[] = [];
    let truncated = false;
    for (const n of this.db.variableRefs(v.id)) {
      if (nodes.length >= maxNodes) { truncated = true; break; }
      nodes.push(this.fnNode({ id: n.id, name: n.name, signature: n.signature, file: n.file, line: n.line }, false));
      this.pushRefEdges(edges, `fn:${n.id}`, `var:${v.id}`, n.reads, n.writes);
    }
    return { kind: 'data-flow-graph', focus: `var:${v.id}`, nodes, edges, truncated };
  }

  private functionFlow(f: FnRow, maxNodes: number): GraphPayload {
    const nodes: GraphNode[] = [this.fnNode(f, true)];
    const edges: GraphEdge[] = [];
    let truncated = false;
    for (const n of this.db.functionVarRefs(f.id)) {
      if (nodes.length >= maxNodes) { truncated = true; break; }
      nodes.push(this.varNode({ id: n.id, name: n.name, type: null, scope: n.scope, file: '', line: 0 }, false));
      this.pushRefEdges(edges, `fn:${f.id}`, `var:${n.id}`, n.reads, n.writes);
    }
    return { kind: 'data-flow-graph', focus: `fn:${f.id}`, nodes, edges, truncated };
  }

  private dataFlowOverview(maxNodes: number): GraphPayload {
    const vars = this.db.topVariables(Math.min(maxNodes, 25));
    const nodes = new Map<string, GraphNode>();
    const edges: GraphEdge[] = [];
    for (const v of vars) {
      nodes.set(`var:${v.id}`, this.varNode(v, false));
      for (const n of this.db.variableRefs(v.id)) {
        if (nodes.size >= maxNodes) break;
        if (!nodes.has(`fn:${n.id}`)) {
          nodes.set(`fn:${n.id}`, this.fnNode({ id: n.id, name: n.name, signature: n.signature, file: n.file, line: n.line }, false));
        }
        this.pushRefEdges(edges, `fn:${n.id}`, `var:${v.id}`, n.reads, n.writes);
      }
    }
    return {
      kind: 'data-flow-graph',
      focus: null,
      nodes: [...nodes.values()],
      edges,
      truncated: false,
      note: nodes.size ? 'Overview: most-referenced shared variables. Search a variable or function to focus.' : 'No global/static variables indexed yet — build the index first.',
    };
  }

  /** A write is function -> variable (data flows in); a read is variable -> function. */
  private pushRefEdges(edges: GraphEdge[], fnId: string, varId: string, reads: number, writes: number): void {
    if (writes > 0) edges.push({ id: `${fnId}=w=>${varId}`, source: fnId, target: varId, kind: 'write', count: writes });
    if (reads > 0) edges.push({ id: `${varId}=r=>${fnId}`, source: varId, target: fnId, kind: 'read', count: reads });
  }

  private varNode(v: VarRow, seed: boolean): GraphNode {
    const detail = v.file ? `${v.scope}${v.type ? ': ' + v.type : ''} — ${path.basename(v.file)}:${v.line}` : v.scope;
    return { id: `var:${v.id}`, label: v.name, kind: 'variable', detail, file: v.file || undefined, line: v.line || undefined, seed };
  }

  // ---- State machines -----------------------------------------------------

  private stateMachineGraph(req: GraphRequest): GraphPayload {
    let machine: SmRow | null = null;
    if (req.seed && req.seed.startsWith('sm:')) machine = this.db.stateMachineById(Number(req.seed.slice(3)));
    else if (req.seed) machine = this.db.lookupStateMachines(req.seed, 1)[0] ?? null;
    else machine = this.db.listStateMachines()[0] ?? null;

    if (!machine) {
      return { kind: 'state-machine-graph', focus: null, nodes: [], edges: [], truncated: false, note: 'No state machines detected. They are recognised from a switch on a state variable whose cases assign new states.' };
    }

    const transitions = this.db.stateTransitions(machine.id);
    const nodes = new Map<string, GraphNode>();
    const edges = new Map<string, GraphEdge>();
    const nodeId = (label: string) => `state:${machine!.id}:${label}`;
    const ensure = (label: string) => {
      const id = nodeId(label);
      if (!nodes.has(id)) nodes.set(id, { id, label, kind: 'state', seed: label === '(entry)' });
    };
    for (const t of transitions) {
      ensure(t.from);
      ensure(t.to);
      const eid = `${nodeId(t.from)}->${nodeId(t.to)}`;
      const existing = edges.get(eid);
      if (existing) existing.count = (existing.count ?? 1) + 1;
      else edges.set(eid, { id: eid, source: nodeId(t.from), target: nodeId(t.to), kind: 'transition', count: 1 });
    }
    const where = machine.fnName ? ` in ${machine.fnName}()` : '';
    return {
      kind: 'state-machine-graph',
      focus: null,
      nodes: [...nodes.values()],
      edges: [...edges.values()],
      truncated: false,
      note: `State machine on "${machine.varName}"${where}: ${nodes.size} states, ${transitions.length} transitions.`,
    };
  }

  // ---- Scheduler ----------------------------------------------------------

  private schedulerGraph(): GraphPayload {
    const tasks = this.db.listTasks().slice();
    const isrs = this.db.listIsrs();
    if (tasks.length === 0 && isrs.length === 0) {
      return { kind: 'scheduler-graph', focus: null, nodes: [], edges: [], truncated: false, note: 'No RTOS tasks or ISRs detected. Tasks are recognised from xTaskCreate / osThreadNew; ISRs from handler naming conventions.' };
    }
    tasks.sort((a, b) => priorityScore(b.priority) - priorityScore(a.priority));
    const nodes: GraphNode[] = [];
    isrs.forEach((i) => nodes.push({
      id: `isr:${i.id}`, label: i.name, kind: 'isr', rank: 0,
      detail: 'interrupt handler', file: i.file, line: i.line,
    }));
    tasks.forEach((t, idx) => nodes.push({
      id: `task:${t.id}`, label: t.name || t.entry, kind: 'task', rank: idx + 1,
      detail: `${t.entry}()${t.priority ? ' · prio ' + t.priority : ''}${t.period ? ' · every ' + t.period : ''}${t.stack ? ' · stack ' + t.stack : ''}`,
      file: t.file, line: t.line,
    }));
    return {
      kind: 'scheduler-graph', focus: null, nodes, edges: [], truncated: false,
      note: `${tasks.length} task${tasks.length === 1 ? '' : 's'}, ${isrs.length} ISR${isrs.length === 1 ? '' : 's'}. Higher = higher preemption priority; ISRs preempt all tasks.`,
    };
  }
}

/** Heuristic numeric priority for ordering tasks; higher = more urgent. */
function priorityScore(p: string | null): number {
  if (!p) return -1;
  const s = p.trim();
  const num = s.match(/^\d+/);
  if (num) return parseInt(num[0], 10);
  if (/max/i.test(s)) return 90;
  if (/abovenormal/i.test(s)) return 25;
  if (/belownormal/i.test(s)) return 15;
  if (/realtime|isr|highest/i.test(s)) return 40;
  if (/high/i.test(s)) return 30;
  if (/normal/i.test(s)) return 20;
  if (/low/i.test(s)) return 10;
  if (/idle/i.test(s)) return 0;
  return 5;
}
