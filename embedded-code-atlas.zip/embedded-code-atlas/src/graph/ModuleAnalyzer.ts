import { FileRow } from '../index/IndexDatabase';
import { tarjanCycles } from './scc';

export interface ModuleRecord {
  /** Index into the modules array; used as the node id "mod:<index>". */
  index: number;
  name: string;
  fileIds: number[];
}

export interface ModuleEdge {
  src: number;
  dst: number;
  /** Number of file-level include edges crossing this module boundary. */
  weight: number;
}

export interface ModuleCycle {
  indices: number[];
  names: string[];
}

export interface ModuleAnalysis {
  modules: ModuleRecord[];
  edges: ModuleEdge[];
  cycles: ModuleCycle[];
  inCycle: Set<number>;
  /** fileId -> module index. */
  moduleOfFile: Map<number, number>;
  dependsOn: Map<number, number>;
  dependedOnBy: Map<number, number>;
}

/**
 * Groups files into modules by directory, at `depth` levels below the common
 * root, then aggregates file include edges into inter-module dependencies.
 *
 * Directory layout is treated as the source of truth for module boundaries —
 * it matches how embedded/automotive codebases are actually organised and keeps
 * every grouping explainable ("this module is this folder"), unlike opaque
 * graph-clustering. Module-level cycles are found with the shared SCC finder.
 */
export function analyzeModules(
  files: FileRow[],
  fileEdges: Array<{ src: number; dst: number }>,
  depth: number,
): ModuleAnalysis {
  const dirsById = new Map<number, string[]>();
  for (const f of files) dirsById.set(f.id, dirOf(f.path));
  const root = commonPrefix([...dirsById.values()]);
  const d = Math.max(1, depth);

  const nameToIndex = new Map<string, number>();
  const modules: ModuleRecord[] = [];
  const moduleOfFile = new Map<number, number>();

  for (const f of files) {
    const segs = dirsById.get(f.id)!;
    const rel = segs.slice(root.length);
    const name = rel.length === 0 ? '(root)' : rel.slice(0, d).join('/');
    let idx = nameToIndex.get(name);
    if (idx === undefined) {
      idx = modules.length;
      nameToIndex.set(name, idx);
      modules.push({ index: idx, name, fileIds: [] });
    }
    modules[idx].fileIds.push(f.id);
    moduleOfFile.set(f.id, idx);
  }

  // Aggregate cross-module include edges.
  const edgeWeights = new Map<string, number>();
  for (const e of fileEdges) {
    const a = moduleOfFile.get(e.src);
    const b = moduleOfFile.get(e.dst);
    if (a === undefined || b === undefined || a === b) continue;
    const key = `${a}>${b}`;
    edgeWeights.set(key, (edgeWeights.get(key) ?? 0) + 1);
  }
  const edges: ModuleEdge[] = [];
  const adj = new Map<number, number[]>();
  const dependsOn = new Map<number, number>();
  const dependedOnBy = new Map<number, number>();
  for (const m of modules) adj.set(m.index, []);
  for (const [key, weight] of edgeWeights) {
    const [src, dst] = key.split('>').map(Number);
    edges.push({ src, dst, weight });
    adj.get(src)!.push(dst);
    dependsOn.set(src, (dependsOn.get(src) ?? 0) + 1);
    dependedOnBy.set(dst, (dependedOnBy.get(dst) ?? 0) + 1);
  }

  const sccs = tarjanCycles(modules.map((m) => m.index), adj);
  const inCycle = new Set<number>();
  for (const c of sccs) for (const i of c) inCycle.add(i);
  const cycles: ModuleCycle[] = sccs
    .map((indices) => ({ indices, names: indices.map((i) => modules[i].name) }))
    .sort((a, b) => b.indices.length - a.indices.length);

  return { modules, edges, cycles, inCycle, moduleOfFile, dependsOn, dependedOnBy };
}

function dirOf(p: string): string[] {
  const segs = p.split(/[\\/]/).filter(Boolean);
  return segs.slice(0, -1); // drop the filename
}

function commonPrefix(seqs: string[][]): string[] {
  if (seqs.length === 0) return [];
  let prefix = seqs[0];
  for (const s of seqs.slice(1)) {
    let i = 0;
    while (i < prefix.length && i < s.length && prefix[i] === s[i]) i++;
    prefix = prefix.slice(0, i);
    if (prefix.length === 0) break;
  }
  return prefix;
}
