import * as path from 'path';
import { RiskRow } from '../index/IndexDatabase';

export interface RankedFunction {
  id: number;
  name: string;
  file: string;
  line: number;
  complexity: number;
  fanIn: number;
  fanOut: number;
  risk: number;
}

export interface FileRisk {
  path: string;
  totalComplexity: number;
  functionCount: number;
  maxComplexity: number;
}

export interface RiskAnalysis {
  maxComplexity: number;
  avgComplexity: number;
  functions: RankedFunction[];
  files: FileRisk[];
}

/**
 * Combine cyclomatic complexity with call-graph coupling into a single risk
 * score. The intuition: a complex function is harder to get right, and one with
 * high fan-in is harder to change safely (many callers depend on it), while high
 * fan-out means it depends on a lot. Risk = complexity + fanIn + fanOut — simple
 * and interpretable rather than a black-box weighting.
 */
export function analyzeRisk(rows: RiskRow[]): RiskAnalysis {
  const functions: RankedFunction[] = rows.map((r) => ({
    id: r.id,
    name: r.name,
    file: r.file,
    line: r.line,
    complexity: r.complexity,
    fanIn: r.fanIn,
    fanOut: r.fanOut,
    risk: r.complexity + r.fanIn + r.fanOut,
  }));
  functions.sort((a, b) => b.risk - a.risk || b.complexity - a.complexity);

  const fileMap = new Map<string, FileRisk>();
  for (const r of rows) {
    const f = fileMap.get(r.file) ?? { path: r.file, totalComplexity: 0, functionCount: 0, maxComplexity: 0 };
    f.totalComplexity += r.complexity;
    f.functionCount++;
    f.maxComplexity = Math.max(f.maxComplexity, r.complexity);
    fileMap.set(r.file, f);
  }
  const files = [...fileMap.values()].sort((a, b) => b.totalComplexity - a.totalComplexity);

  const maxComplexity = rows.reduce((m, r) => Math.max(m, r.complexity), 1);
  const avgComplexity = rows.length ? rows.reduce((s, r) => s + r.complexity, 0) / rows.length : 0;
  return { maxComplexity, avgComplexity, functions, files };
}

/** Shorten a path to its basename for compact display. */
export function baseName(p: string): string {
  return path.basename(p);
}
