/**
 * Tarjan's strongly-connected-components algorithm, returning only the
 * components that represent a cycle: any SCC with more than one node, plus any
 * single node with a self-loop. Implemented iteratively so deep graphs (long
 * include or call chains) cannot overflow the call stack.
 *
 * Shared by the file-dependency and call-graph analyzers — one tested
 * implementation, two callers.
 */
export function tarjanCycles(ids: number[], adj: Map<number, number[]>): number[][] {
  let index = 0;
  const idx = new Map<number, number>();
  const low = new Map<number, number>();
  const onStack = new Set<number>();
  const stack: number[] = [];
  const result: number[][] = [];

  for (const start of ids) {
    if (idx.has(start)) continue;
    // Iterative DFS with an explicit work stack of (node, childPointer).
    const work: Array<{ v: number; i: number }> = [{ v: start, i: 0 }];
    idx.set(start, index); low.set(start, index); index++; stack.push(start); onStack.add(start);

    while (work.length) {
      const frame = work[work.length - 1];
      const v = frame.v;
      const neighbors = adj.get(v) ?? [];
      if (frame.i < neighbors.length) {
        const w = neighbors[frame.i++];
        if (!idx.has(w)) {
          idx.set(w, index); low.set(w, index); index++; stack.push(w); onStack.add(w);
          work.push({ v: w, i: 0 });
        } else if (onStack.has(w)) {
          low.set(v, Math.min(low.get(v)!, idx.get(w)!));
        }
      } else {
        if (low.get(v) === idx.get(v)) {
          const comp: number[] = [];
          let w: number;
          do { w = stack.pop()!; onStack.delete(w); comp.push(w); } while (w !== v);
          const selfLoop = (adj.get(v) ?? []).includes(v);
          if (comp.length > 1 || selfLoop) result.push(comp);
        }
        work.pop();
        if (work.length) {
          const parent = work[work.length - 1].v;
          low.set(parent, Math.min(low.get(parent)!, low.get(v)!));
        }
      }
    }
  }
  return result;
}
