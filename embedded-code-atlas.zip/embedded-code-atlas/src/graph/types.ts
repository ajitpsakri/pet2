/**
 * Wire types for graph data sent to the webview. These describe a *neighbourhood
 * slice* — never the whole graph — because rendering an entire 100k-node call
 * graph would overwhelm any browser renderer. The host expands outward from a
 * focus node on demand and caps the node count.
 */

export type GraphKind = 'file-graph' | 'function-graph' | 'module-graph' | 'data-flow-graph' | 'state-machine-graph' | 'scheduler-graph' | 'architecture-graph' | 'complexity-graph' | 'autosar-graph';

export interface GraphNode {
  /** Stable id, namespaced by kind: "fn:123", "file:45", or "u:name". */
  id: string;
  label: string;
  kind: 'function' | 'file' | 'unresolved' | 'module' | 'variable' | 'state' | 'task' | 'isr' | 'layer';
  /** Signature (functions) or full path (files); shown in the details panel. */
  detail?: string;
  /** Source location for "open in editor". */
  file?: string;
  line?: number;
  /** True for the focus node the neighbourhood was built around. */
  seed?: boolean;
  /** Whether a call target resolved to a concrete definition. */
  resolved?: boolean;
  /** File-graph only: this file participates in an include cycle. */
  inCycle?: boolean;
  /** File-graph only: how many files include this one (hotspot heat). */
  fanIn?: number;
  /** File-graph only: how many files this one includes. */
  fanOut?: number;
  /** Module-graph only: number of files in the module. */
  fileCount?: number;
  /** Scheduler view only: vertical band (0 = ISR/highest preemption). */
  rank?: number;
  /** Complexity view only: cyclomatic complexity (drives heat colour). */
  complexity?: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  kind: 'call' | 'include' | 'read' | 'write' | 'transition' | 'runs' | 'layerdep' | 'violation';
  /** Aggregated multiplicity (e.g. number of call sites). */
  count?: number;
}

export interface GraphPayload {
  kind: GraphKind;
  /** Node id the slice is centred on, or null for an overview. */
  focus: string | null;
  nodes: GraphNode[];
  edges: GraphEdge[];
  /** True if the node cap was hit and the slice is incomplete. */
  truncated: boolean;
  /** Human-readable context (empty index, overview mode, deferred feature). */
  note?: string;
}

export interface GraphRequest {
  kind: GraphKind;
  /** Search text or an existing node id to centre on; empty = overview. */
  seed?: string;
  /** Hops to expand from the focus (1–3). */
  depth: number;
  maxNodes: number;
  /** Function graph only: which call directions to expand. */
  direction?: 'both' | 'callees' | 'callers';
}

/** A circular include dependency, expressed in webview node ids + labels. */
export interface CycleReport {
  nodeIds: string[];
  labels: string[];
}

export interface HotspotReport {
  nodeId: string;
  label: string;
  path: string;
  fanIn: number;
  fanOut: number;
}

export interface ClusterReport {
  name: string;
  fileCount: number;
}

/** Whole-project dependency findings surfaced in the File Graph view. */
export interface DependencyReport {
  totalFiles: number;
  totalEdges: number;
  cycles: CycleReport[];
  hotspots: HotspotReport[];
  clusters: ClusterReport[];
}

export interface CallEntryReport {
  nodeId: string;
  label: string;
  file: string;
  line: number;
}

export interface MostCalledReport {
  nodeId: string;
  label: string;
  callers: number;
}

/** Whole-project call-graph findings surfaced in the Function Graph view. */
export interface CallReport {
  totalFunctions: number;
  totalCalls: number;
  recursion: CycleReport[];
  entryPoints: CallEntryReport[];
  mostCalled: MostCalledReport[];
}

export interface ModuleEntry {
  nodeId: string;
  name: string;
  fileCount: number;
  dependsOn: number;
  dependedOnBy: number;
  inCycle: boolean;
}

/** Module-detection findings surfaced in the Module Graph view. */
export interface ModuleReport {
  moduleCount: number;
  crossEdges: number;
  modules: ModuleEntry[];
  cycles: CycleReport[];
}

export interface VarHotspot {
  nodeId: string;
  label: string;
  scope: string;
  reads: number;
  writes: number;
  writers: number;
}

/** Data-flow findings surfaced in the Data Flow view. */
export interface DataFlowReport {
  totalVariables: number;
  totalRefs: number;
  /** Most-referenced shared variables. */
  hotspots: VarHotspot[];
  /** Variables written by more than one function (shared mutable state). */
  multiWriter: VarHotspot[];
}

export interface StateMachineEntry {
  nodeId: string;
  varName: string;
  fnName: string | null;
  file: string;
  line: number;
  states: number;
  transitions: number;
}

/** Detected state machines surfaced in the State Machine view. */
export interface StateMachineReport {
  machines: StateMachineEntry[];
}

export interface TaskEntry {
  nodeId: string;
  name: string | null;
  entry: string;
  priority: string | null;
  period: string | null;
  stack: string | null;
  api: string;
  file: string;
  line: number;
}

export interface IsrEntry {
  nodeId: string;
  name: string;
  file: string;
  line: number;
}

/** RTOS scheduler findings surfaced in the Scheduler view. */
export interface SchedulerReport {
  tasks: TaskEntry[];
  isrs: IsrEntry[];
}

export interface LayerSummary {
  label: string;
  rank: number;
  fileCount: number;
}

export interface ViolationEntry {
  fromPath: string;
  toPath: string;
  fromLayer: string;
  toLayer: string;
}

/** Architecture/layering findings surfaced in the Architecture view. */
export interface ArchitectureReport {
  configured: boolean;
  layerCount: number;
  violationCount: number;
  layers: LayerSummary[];
  violations: ViolationEntry[];
}

export interface RiskEntry {
  nodeId: string;
  name: string;
  file: string;
  line: number;
  complexity: number;
  fanIn: number;
  fanOut: number;
  risk: number;
}

export interface FileRiskEntry {
  path: string;
  totalComplexity: number;
  functionCount: number;
  maxComplexity: number;
}

/** Complexity/risk findings surfaced in the Complexity view. */
export interface ComplexityReport {
  maxComplexity: number;
  avgComplexity: number;
  functions: RiskEntry[];
  files: FileRiskEntry[];
}

export interface DashboardCard {
  /** Target view this card links to. */
  view: string;
  label: string;
  value: string;
  sub: string;
  severity: 'ok' | 'warn' | 'bad';
}

export interface DashboardFinding {
  severity: 'warn' | 'bad';
  text: string;
  view: string;
}

/** Aggregated cross-analysis overview surfaced in the Dashboard view. */
export interface DashboardReport {
  stats: { files: number; functions: number; calls: number; variables: number };
  cards: DashboardCard[];
  findings: DashboardFinding[];
}

/** A plain-English, template-generated explanation of a node (no LLM). */
export interface Explanation {
  target: string;
  title: string;
  lines: string[];
}

export interface AutosarLayerEntry {
  label: string;
  rank: number;
  moduleCount: number;
  modules: string[];
}

export interface AutosarViolationEntry {
  fromPath: string;
  toPath: string;
  fromLayer: string;
  toLayer: string;
}

/** AUTOSAR conformance findings surfaced in the AUTOSAR view. */
export interface AutosarReport {
  recognized: number;
  violationCount: number;
  layers: AutosarLayerEntry[];
  violations: AutosarViolationEntry[];
}
