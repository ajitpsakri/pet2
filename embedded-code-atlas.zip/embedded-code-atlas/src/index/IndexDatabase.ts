import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import {
  ParsedFile,
  IndexStats,
  FileRecord,
  FunctionRecord,
} from './types';
import { SCHEMA_SQL, SCHEMA_VERSION } from './schema';

/** A neighbour in the call graph (a resolved function or an unresolved name). */
export interface CallNeighbor {
  id: number | null;
  name: string;
  signature: string | null;
  file: string | null;
  line: number | null;
  resolved: boolean;
  count: number;
}

/** A function row used to seed and label call-graph nodes. */
export interface FnRow {
  id: number;
  name: string;
  signature: string;
  file: string;
  line: number;
}

/** A file row used to seed and label dependency-graph nodes. */
export interface FileRow {
  id: number;
  path: string;
}

/** A variable row used to seed and label data-flow nodes. */
export interface VarRow {
  id: number;
  name: string;
  type: string | null;
  scope: string;
  file: string;
  line: number;
}

/** A function that references a variable, with aggregated read/write counts. */
export interface VarRefNeighbor {
  id: number;
  name: string;
  signature: string;
  file: string;
  line: number;
  reads: number;
  writes: number;
}

/** A variable referenced by a function, with aggregated read/write counts. */
export interface FnVarNeighbor {
  id: number;
  name: string;
  scope: string;
  reads: number;
  writes: number;
}

/** A detected state machine with its size, for listing and seeding. */
export interface SmRow {
  id: number;
  varName: string;
  fnName: string | null;
  file: string;
  line: number;
  stateCount: number;
  transitionCount: number;
}

export interface TransitionRow {
  from: string;
  to: string;
  line: number;
}

/** A detected RTOS task, with period joined from a delay in its entry function. */
export interface TaskRow {
  id: number;
  name: string | null;
  entry: string;
  priority: string | null;
  stack: string | null;
  api: string;
  file: string;
  line: number;
  period: string | null;
}

/** An interrupt handler, recognised by naming convention. */
export interface IsrRow {
  id: number;
  name: string;
  file: string;
  line: number;
}

/** A function with its complexity and call fan-in/out, for risk scoring. */
export interface RiskRow {
  id: number;
  name: string;
  signature: string;
  file: string;
  line: number;
  complexity: number;
  fanIn: number;
  fanOut: number;
}

/**
 * Persistence contract for the index. The rest of the extension depends only
 * on this interface, so a future native-SQLite or out-of-process engine can be
 * dropped in for very large workspaces without touching callers.
 */
export interface IndexDatabase {
  /** path -> {hash, mtime} for every indexed file, for incremental diffing. */
  knownFiles(): Map<string, { hash: string; mtime: number }>;
  /** Insert or replace one file and all of its extracted symbols atomically. */
  upsertFile(parsed: ParsedFile): void;
  /** Remove a file and (via cascade) its symbols. */
  removeFile(path: string): void;
  /** Wrap a batch of mutations in a single transaction. */
  transaction(work: () => void): void;
  /** Link call edges to concrete callee rows by unique-name match. */
  resolveCalls(): void;
  /** Link variable references to concrete variable rows by unique-name match. */
  resolveRefs(): void;
  stats(): IndexStats;
  setLastBuilt(iso: string): void;
  searchFunctions(query: string, limit: number): FunctionRecord[];
  /** Outgoing calls (callees) from a function, aggregated by target. */
  outgoing(functionId: number): CallNeighbor[];
  /** Incoming calls (callers) to a function, aggregated by source. */
  incoming(functionId: number): CallNeighbor[];
  /** Functions whose name matches a LIKE query, for graph seeding. */
  lookupFunctions(query: string, limit: number): FnRow[];
  functionById(id: number): FnRow | null;
  /** Cyclomatic complexity of one function (1 if unknown). */
  functionComplexity(id: number): number;
  /** Most call-connected functions, for the overview graph. */
  topFunctions(limit: number): FnRow[];
  lookupFiles(query: string, limit: number): FileRow[];
  fileById(id: number): FileRow | null;
  /** Files with the most includes, for the overview graph. */
  topFiles(limit: number): FileRow[];
  /** Resolved include neighbours of a file, both directions. */
  fileNeighbors(fileId: number, path: string): { out: FileRow[]; in: FileRow[] };
  /** Every indexed file (for whole-project dependency analysis). */
  allFiles(): FileRow[];
  /** Every resolved include edge as src->dst file id pairs (deduplicated). */
  allIncludeEdges(): Array<{ src: number; dst: number }>;
  /** Every indexed function (for whole-project call analysis). */
  allFunctions(): FnRow[];
  /** Every resolved call edge as caller->callee function id pairs. */
  allCallEdges(): Array<{ src: number; dst: number }>;
  /** Variables whose name matches a LIKE query, for data-flow seeding. */
  lookupVariables(query: string, limit: number): VarRow[];
  variableById(id: number): VarRow | null;
  /** Most-referenced variables, for the data-flow overview. */
  topVariables(limit: number): VarRow[];
  /** Functions that read/write a variable, aggregated. */
  variableRefs(varId: number): VarRefNeighbor[];
  /** Variables a function reads/writes, aggregated. */
  functionVarRefs(functionId: number): FnVarNeighbor[];
  /** Every variable (for whole-project data-flow analysis). */
  allVariables(): VarRow[];
  /** Every resolved ref edge: function id, variable id, kind. */
  allRefEdges(): Array<{ fn: number; var: number; kind: string }>;
  /** All detected state machines, with state/transition counts. */
  listStateMachines(): SmRow[];
  stateMachineById(id: number): SmRow | null;
  lookupStateMachines(query: string, limit: number): SmRow[];
  stateTransitions(machineId: number): TransitionRow[];
  /** All detected RTOS tasks, with period inferred from their entry function. */
  listTasks(): TaskRow[];
  /** Functions that look like interrupt handlers (by naming convention). */
  listIsrs(): IsrRow[];
  /** Every function with complexity + call fan-in/out, for risk scoring. */
  functionRiskRows(): RiskRow[];
  /** Serialize the whole DB to bytes for writing to disk. */
  serialize(): Uint8Array;
  close(): void;
}

let SQL: SqlJsStatic | undefined;

/** Initialise the sql.js runtime once, using pre-loaded wasm bytes. */
export async function initSqlEngine(wasmBytes: Uint8Array): Promise<void> {
  if (!SQL) {
    const wasmBinary = wasmBytes.buffer.slice(
      wasmBytes.byteOffset,
      wasmBytes.byteOffset + wasmBytes.byteLength,
    ) as ArrayBuffer;
    SQL = await initSqlJs({ wasmBinary });
  }
}

export class SqlJsIndexDatabase implements IndexDatabase {
  private constructor(private readonly db: Database) {
    // Per-connection setting; must be (re)enabled every open, including when
    // reopening from serialized bytes.
    this.db.run('PRAGMA foreign_keys = ON');
  }

  /** Open from existing bytes (or create fresh) and ensure the schema matches. */
  static open(existing?: Uint8Array): SqlJsIndexDatabase {
    if (!SQL) {
      throw new Error('sql.js engine not initialised; call initSqlEngine() first.');
    }
    const db = existing && existing.length ? new SQL.Database(existing) : new SQL.Database();
    let instance = new SqlJsIndexDatabase(db);
    if (!instance.schemaMatches()) {
      // Fresh DB or an incompatible schema version: (re)create from scratch.
      instance.close();
      instance = new SqlJsIndexDatabase(new SQL.Database());
      instance.initSchema();
    }
    return instance;
  }

  private schemaMatches(): boolean {
    try {
      const v = this.getMeta('schemaVersion');
      return v === String(SCHEMA_VERSION);
    } catch {
      return false;
    }
  }

  private initSchema(): void {
    this.db.run(SCHEMA_SQL);
    this.setMeta('schemaVersion', String(SCHEMA_VERSION));
  }

  private getMeta(key: string): string | null {
    const stmt = this.db.prepare('SELECT value FROM meta WHERE key = ?');
    try {
      stmt.bind([key]);
      return stmt.step() ? (stmt.getAsObject().value as string) : null;
    } finally {
      stmt.free();
    }
  }

  private setMeta(key: string, value: string): void {
    this.db.run('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', [key, value]);
  }

  knownFiles(): Map<string, { hash: string; mtime: number }> {
    const map = new Map<string, { hash: string; mtime: number }>();
    const stmt = this.db.prepare('SELECT path, hash, mtime FROM files');
    try {
      while (stmt.step()) {
        const row = stmt.getAsObject() as { path: string; hash: string; mtime: number };
        map.set(row.path, { hash: row.hash, mtime: row.mtime });
      }
    } finally {
      stmt.free();
    }
    return map;
  }

  transaction(work: () => void): void {
    this.db.run('BEGIN');
    try {
      work();
      this.db.run('COMMIT');
    } catch (err) {
      this.db.run('ROLLBACK');
      throw err;
    }
  }

  upsertFile(parsed: ParsedFile): void {
    const f: FileRecord = parsed.file;
    this.deleteFileRows(f.path);
    this.db.run('INSERT INTO files(path,size,language,hash,mtime) VALUES(?,?,?,?,?)', [
      f.path, f.size, f.language, f.hash, f.mtime,
    ]);
    const fileId = this.db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0] as number;

    for (const inc of f.includes) {
      this.db.run('INSERT INTO includes(file_id,target) VALUES(?,?)', [fileId, inc]);
    }
    const functionIds: number[] = [];
    for (const fn of parsed.functions) {
      this.db.run('INSERT INTO functions(file_id,name,line,signature,namespace,class,complexity) VALUES(?,?,?,?,?,?,?)', [
        fileId, fn.name, fn.line, fn.signature, fn.namespace, fn.className, fn.complexity,
      ]);
      functionIds.push(this.db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0] as number);
    }
    for (const cl of parsed.classes) {
      this.db.run('INSERT INTO classes(file_id,name,line,kind) VALUES(?,?,?,?)', [fileId, cl.name, cl.line, cl.kind]);
    }
    for (const ns of parsed.namespaces) {
      this.db.run('INSERT OR IGNORE INTO namespaces(name) VALUES(?)', [ns.name]);
    }
    for (const call of parsed.calls) {
      const callerId = functionIds[call.fnIndex];
      if (callerId === undefined) continue;
      this.db.run('INSERT INTO calls(file_id,caller_id,callee_name,callee_id,line) VALUES(?,?,?,NULL,?)', [
        fileId, callerId, call.callee, call.line,
      ]);
    }

    const varIdByName = new Map<string, number>();
    for (const v of parsed.variables) {
      this.db.run('INSERT INTO variables(file_id,name,type,scope,class,line) VALUES(?,?,?,?,?,?)', [
        fileId, v.name, v.type, v.scope, v.className, v.line,
      ]);
      varIdByName.set(v.name, this.db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0] as number);
    }
    const fnIdByName = new Map<string, number>();
    parsed.functions.forEach((fn, i) => { if (!fnIdByName.has(fn.name)) fnIdByName.set(fn.name, functionIds[i]); });
    for (const r of parsed.refs) {
      const fnId = r.fnName ? fnIdByName.get(r.fnName) ?? null : null;
      const varId = varIdByName.get(r.symbol) ?? null;
      this.db.run('INSERT INTO refs(file_id,function_id,var_id,symbol,kind,line) VALUES(?,?,?,?,?,?)', [
        fileId, fnId, varId, r.symbol, r.kind, r.line,
      ]);
    }
    for (const sm of parsed.stateMachines) {
      const fnId = sm.fnName ? fnIdByName.get(sm.fnName) ?? null : null;
      this.db.run('INSERT INTO state_machines(file_id,function_id,var_name,fn_name,line) VALUES(?,?,?,?,?)', [
        fileId, fnId, sm.varName, sm.fnName, sm.line,
      ]);
      const machineId = this.db.exec('SELECT last_insert_rowid() AS id')[0].values[0][0] as number;
      for (const t of sm.transitions) {
        this.db.run('INSERT INTO state_transitions(machine_id,file_id,from_state,to_state,line) VALUES(?,?,?,?,?)', [
          machineId, fileId, t.from, t.to, t.line,
        ]);
      }
    }
    for (const t of parsed.tasks) {
      this.db.run('INSERT INTO rtos_tasks(file_id,name,entry,priority,stack,api,line) VALUES(?,?,?,?,?,?,?)', [
        fileId, t.name, t.entry, t.priority, t.stack, t.api, t.line,
      ]);
    }
    for (const d of parsed.delays) {
      this.db.run('INSERT INTO rtos_delays(file_id,fn_name,period,line) VALUES(?,?,?,?)', [fileId, d.fnName, d.period, d.line]);
    }
  }

  removeFile(path: string): void {
    this.deleteFileRows(path);
  }

  private deleteFileRows(path: string): void {
    // Delete children explicitly so correctness does not depend on the
    // per-connection foreign_keys pragma being active (it is not preserved
    // when a DB is reopened from serialized bytes).
    const stmt = this.db.prepare('SELECT id FROM files WHERE path = ?');
    let fileId: number | null = null;
    try {
      stmt.bind([path]);
      if (stmt.step()) fileId = (stmt.getAsObject().id as number);
    } finally {
      stmt.free();
    }
    if (fileId === null) return;
    // Calls in *other* files may point at functions defined here; unlink them
    // so they get re-resolved on the next build instead of dangling.
    this.db.run('UPDATE calls SET callee_id = NULL WHERE callee_id IN (SELECT id FROM functions WHERE file_id = ?)', [fileId]);
    this.db.run('UPDATE refs SET var_id = NULL WHERE var_id IN (SELECT id FROM variables WHERE file_id = ?)', [fileId]);
    this.db.run('DELETE FROM state_transitions WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM state_machines WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM rtos_tasks WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM rtos_delays WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM calls WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM refs WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM variables WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM includes WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM functions WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM classes WHERE file_id = ?', [fileId]);
    this.db.run('DELETE FROM files WHERE id = ?', [fileId]);
  }

  resolveCalls(): void {
    // Link only unambiguous (unique-name) callees. Overloaded or duplicated
    // names are left unresolved rather than guessed.
    this.db.run(
      `UPDATE calls SET callee_id = (
         SELECT f.id FROM functions f WHERE f.name = calls.callee_name
       )
       WHERE callee_id IS NULL
         AND (SELECT COUNT(*) FROM functions f2 WHERE f2.name = calls.callee_name) = 1`,
    );
  }

  resolveRefs(): void {
    // Link references to a global only when its name is unambiguous project-wide.
    this.db.run(
      `UPDATE refs SET var_id = (
         SELECT v.id FROM variables v WHERE v.name = refs.symbol
       )
       WHERE var_id IS NULL
         AND (SELECT COUNT(*) FROM variables v2 WHERE v2.name = refs.symbol) = 1`,
    );
  }

  stats(): IndexStats {
    const count = (table: string): number => {
      const r = this.db.exec(`SELECT COUNT(*) FROM ${table}`);
      return r.length ? (r[0].values[0][0] as number) : 0;
    };
    return {
      files: count('files'),
      functions: count('functions'),
      classes: count('classes'),
      calls: count('calls'),
      variables: count('variables'),
      lastBuilt: this.getMeta('lastBuilt'),
    };
  }

  setLastBuilt(iso: string): void {
    this.setMeta('lastBuilt', iso);
  }

  searchFunctions(query: string, limit: number): FunctionRecord[] {
    const stmt = this.db.prepare(
      `SELECT fn.name, f.path AS file, fn.line, fn.signature, fn.namespace, fn.class AS className
       FROM functions fn JOIN files f ON f.id = fn.file_id
       WHERE fn.name LIKE ? ORDER BY fn.name LIMIT ?`,
    );
    const out: FunctionRecord[] = [];
    try {
      stmt.bind([`%${query}%`, limit]);
      while (stmt.step()) {
        out.push(stmt.getAsObject() as unknown as FunctionRecord);
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  outgoing(functionId: number): CallNeighbor[] {
    // Resolved callees aggregated by target; plus unresolved names by name.
    const resolved = this.queryNeighbors(
      `SELECT f.id AS id, f.name AS name, f.signature AS signature, src.path AS file, f.line AS line, COUNT(*) AS count
       FROM calls c JOIN functions f ON f.id = c.callee_id JOIN files src ON src.id = f.file_id
       WHERE c.caller_id = ? AND c.callee_id IS NOT NULL
       GROUP BY f.id ORDER BY count DESC`,
      functionId,
      true,
    );
    const unresolved = this.queryNeighbors(
      `SELECT NULL AS id, c.callee_name AS name, NULL AS signature, NULL AS file, NULL AS line, COUNT(*) AS count
       FROM calls c WHERE c.caller_id = ? AND c.callee_id IS NULL
       GROUP BY c.callee_name ORDER BY count DESC`,
      functionId,
      false,
    );
    return [...resolved, ...unresolved];
  }

  incoming(functionId: number): CallNeighbor[] {
    return this.queryNeighbors(
      `SELECT f.id AS id, f.name AS name, f.signature AS signature, src.path AS file, f.line AS line, COUNT(*) AS count
       FROM calls c JOIN functions f ON f.id = c.caller_id JOIN files src ON src.id = f.file_id
       WHERE c.callee_id = ?
       GROUP BY f.id ORDER BY count DESC`,
      functionId,
      true,
    );
  }

  private queryNeighbors(sql: string, id: number, resolved: boolean): CallNeighbor[] {
    const stmt = this.db.prepare(sql);
    const out: CallNeighbor[] = [];
    try {
      stmt.bind([id]);
      while (stmt.step()) {
        const r = stmt.getAsObject() as { id: number | null; name: string; signature: string | null; file: string | null; line: number | null; count: number };
        out.push({ ...r, resolved });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  lookupFunctions(query: string, limit: number): FnRow[] {
    return this.fnRows(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line
       FROM functions fn JOIN files f ON f.id = fn.file_id
       WHERE fn.name LIKE ? ORDER BY length(fn.name), fn.name LIMIT ?`,
      [`%${query}%`, limit],
    );
  }

  functionById(id: number): FnRow | null {
    const rows = this.fnRows(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line
       FROM functions fn JOIN files f ON f.id = fn.file_id WHERE fn.id = ?`,
      [id],
    );
    return rows[0] ?? null;
  }

  functionComplexity(id: number): number {
    const r = this.db.exec('SELECT complexity FROM functions WHERE id = ?', [id]);
    return r.length && r[0].values.length ? (r[0].values[0][0] as number) : 1;
  }

  topFunctions(limit: number): FnRow[] {
    return this.fnRows(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line,
        ((SELECT COUNT(*) FROM calls c WHERE c.caller_id = fn.id)
         + (SELECT COUNT(*) FROM calls c WHERE c.callee_id = fn.id)) AS deg
       FROM functions fn JOIN files f ON f.id = fn.file_id
       ORDER BY deg DESC, fn.name LIMIT ?`,
      [limit],
    );
  }

  private fnRows(sql: string, params: (string | number)[]): FnRow[] {
    const stmt = this.db.prepare(sql);
    const out: FnRow[] = [];
    try {
      stmt.bind(params);
      while (stmt.step()) {
        const r = stmt.getAsObject() as { id: number; name: string; signature: string; file: string; line: number };
        out.push({ id: r.id, name: r.name, signature: r.signature, file: r.file, line: r.line });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  lookupFiles(query: string, limit: number): FileRow[] {
    return this.fileRows('SELECT id, path FROM files WHERE path LIKE ? ORDER BY length(path), path LIMIT ?', [`%${query}%`, limit]);
  }

  fileById(id: number): FileRow | null {
    return this.fileRows('SELECT id, path FROM files WHERE id = ?', [id])[0] ?? null;
  }

  topFiles(limit: number): FileRow[] {
    return this.fileRows(
      `SELECT f.id AS id, f.path AS path, (SELECT COUNT(*) FROM includes i WHERE i.file_id = f.id) AS deg
       FROM files f ORDER BY deg DESC, f.path LIMIT ?`,
      [limit],
    );
  }

  fileNeighbors(fileId: number, path: string): { out: FileRow[]; in: FileRow[] } {
    // Include targets are matched to indexed files by exact path or path
    // suffix (e.g. "fusion/Kalman.hpp" -> ".../src/fusion/Kalman.hpp").
    const outRows = this.fileRows(
      `SELECT DISTINCT tf.id AS id, tf.path AS path
       FROM includes i JOIN files tf ON (tf.path = i.target OR tf.path LIKE '%/' || i.target)
       WHERE i.file_id = ?`,
      [fileId],
    );
    const inRows = this.fileRows(
      `SELECT DISTINCT sf.id AS id, sf.path AS path
       FROM includes i JOIN files sf ON sf.id = i.file_id
       WHERE i.target = ? OR ? LIKE '%/' || i.target`,
      [path, path],
    );
    return { out: outRows, in: inRows };
  }

  private fileRows(sql: string, params: (string | number)[]): FileRow[] {
    const stmt = this.db.prepare(sql);
    const out: FileRow[] = [];
    try {
      stmt.bind(params);
      while (stmt.step()) {
        const r = stmt.getAsObject() as { id: number; path: string };
        out.push({ id: r.id, path: r.path });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  allFiles(): FileRow[] {
    return this.fileRows('SELECT id, path FROM files ORDER BY id', []);
  }

  allIncludeEdges(): Array<{ src: number; dst: number }> {
    // Resolve every include target to an indexed file by exact or suffix match;
    // de-duplicate (src,dst) pairs and drop self-edges.
    const stmt = this.db.prepare(
      `SELECT DISTINCT i.file_id AS src, tf.id AS dst
       FROM includes i JOIN files tf ON (tf.path = i.target OR tf.path LIKE '%/' || i.target)
       WHERE i.file_id <> tf.id`,
    );
    const out: Array<{ src: number; dst: number }> = [];
    try {
      while (stmt.step()) {
        const r = stmt.getAsObject() as { src: number; dst: number };
        out.push({ src: r.src, dst: r.dst });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  allFunctions(): FnRow[] {
    return this.fnRows(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line
       FROM functions fn JOIN files f ON f.id = fn.file_id ORDER BY fn.id`,
      [],
    );
  }

  allCallEdges(): Array<{ src: number; dst: number }> {
    const stmt = this.db.prepare(
      'SELECT DISTINCT caller_id AS src, callee_id AS dst FROM calls WHERE callee_id IS NOT NULL',
    );
    const out: Array<{ src: number; dst: number }> = [];
    try {
      while (stmt.step()) {
        const r = stmt.getAsObject() as { src: number; dst: number };
        out.push({ src: r.src, dst: r.dst });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  private varRows(sql: string, params: (string | number)[]): VarRow[] {
    const stmt = this.db.prepare(sql);
    const out: VarRow[] = [];
    try {
      stmt.bind(params);
      while (stmt.step()) {
        const r = stmt.getAsObject() as { id: number; name: string; type: string | null; scope: string; file: string; line: number };
        out.push({ id: r.id, name: r.name, type: r.type, scope: r.scope, file: r.file, line: r.line });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  lookupVariables(query: string, limit: number): VarRow[] {
    return this.varRows(
      `SELECT v.id AS id, v.name AS name, v.type AS type, v.scope AS scope, f.path AS file, v.line AS line
       FROM variables v JOIN files f ON f.id = v.file_id
       WHERE v.name LIKE ? ORDER BY length(v.name), v.name LIMIT ?`,
      [`%${query}%`, limit],
    );
  }

  variableById(id: number): VarRow | null {
    return this.varRows(
      `SELECT v.id AS id, v.name AS name, v.type AS type, v.scope AS scope, f.path AS file, v.line AS line
       FROM variables v JOIN files f ON f.id = v.file_id WHERE v.id = ?`,
      [id],
    )[0] ?? null;
  }

  topVariables(limit: number): VarRow[] {
    return this.varRows(
      `SELECT v.id AS id, v.name AS name, v.type AS type, v.scope AS scope, f.path AS file, v.line AS line,
        (SELECT COUNT(*) FROM refs r WHERE r.var_id = v.id) AS refcount
       FROM variables v JOIN files f ON f.id = v.file_id
       ORDER BY refcount DESC, v.name LIMIT ?`,
      [limit],
    );
  }

  variableRefs(varId: number): VarRefNeighbor[] {
    const stmt = this.db.prepare(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line,
        SUM(CASE WHEN r.kind='read' THEN 1 ELSE 0 END) AS reads,
        SUM(CASE WHEN r.kind='write' THEN 1 ELSE 0 END) AS writes
       FROM refs r JOIN functions fn ON fn.id = r.function_id JOIN files f ON f.id = fn.file_id
       WHERE r.var_id = ? AND r.function_id IS NOT NULL
       GROUP BY fn.id ORDER BY (reads+writes) DESC`,
    );
    const out: VarRefNeighbor[] = [];
    try {
      stmt.bind([varId]);
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as VarRefNeighbor);
    } finally {
      stmt.free();
    }
    return out;
  }

  functionVarRefs(functionId: number): FnVarNeighbor[] {
    const stmt = this.db.prepare(
      `SELECT v.id AS id, v.name AS name, v.scope AS scope,
        SUM(CASE WHEN r.kind='read' THEN 1 ELSE 0 END) AS reads,
        SUM(CASE WHEN r.kind='write' THEN 1 ELSE 0 END) AS writes
       FROM refs r JOIN variables v ON v.id = r.var_id
       WHERE r.function_id = ? AND r.var_id IS NOT NULL
       GROUP BY v.id ORDER BY (reads+writes) DESC`,
    );
    const out: FnVarNeighbor[] = [];
    try {
      stmt.bind([functionId]);
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as FnVarNeighbor);
    } finally {
      stmt.free();
    }
    return out;
  }

  allVariables(): VarRow[] {
    return this.varRows(
      `SELECT v.id AS id, v.name AS name, v.type AS type, v.scope AS scope, f.path AS file, v.line AS line
       FROM variables v JOIN files f ON f.id = v.file_id ORDER BY v.id`,
      [],
    );
  }

  allRefEdges(): Array<{ fn: number; var: number; kind: string }> {
    const stmt = this.db.prepare(
      'SELECT DISTINCT function_id AS fn, var_id AS var, kind FROM refs WHERE function_id IS NOT NULL AND var_id IS NOT NULL',
    );
    const out: Array<{ fn: number; var: number; kind: string }> = [];
    try {
      while (stmt.step()) {
        const r = stmt.getAsObject() as { fn: number; var: number; kind: string };
        out.push({ fn: r.fn, var: r.var, kind: r.kind });
      }
    } finally {
      stmt.free();
    }
    return out;
  }

  private smRows(where: string, params: (string | number)[]): SmRow[] {
    const stmt = this.db.prepare(
      `SELECT sm.id AS id, sm.var_name AS varName, sm.fn_name AS fnName, f.path AS file, sm.line AS line,
        (SELECT COUNT(*) FROM state_transitions t WHERE t.machine_id = sm.id) AS transitionCount,
        (SELECT COUNT(DISTINCT s) FROM (
            SELECT from_state AS s FROM state_transitions WHERE machine_id = sm.id
            UNION SELECT to_state AS s FROM state_transitions WHERE machine_id = sm.id
        )) AS stateCount
       FROM state_machines sm JOIN files f ON f.id = sm.file_id
       ${where} ORDER BY transitionCount DESC, sm.var_name`,
    );
    const out: SmRow[] = [];
    try {
      stmt.bind(params);
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as SmRow);
    } finally {
      stmt.free();
    }
    return out;
  }

  listStateMachines(): SmRow[] {
    return this.smRows('', []);
  }

  stateMachineById(id: number): SmRow | null {
    return this.smRows('WHERE sm.id = ?', [id])[0] ?? null;
  }

  lookupStateMachines(query: string, limit: number): SmRow[] {
    return this.smRows('WHERE sm.var_name LIKE ? OR sm.fn_name LIKE ?', [`%${query}%`, `%${query}%`]).slice(0, limit);
  }

  stateTransitions(machineId: number): TransitionRow[] {
    const stmt = this.db.prepare('SELECT from_state AS "from", to_state AS "to", line FROM state_transitions WHERE machine_id = ?');
    const out: TransitionRow[] = [];
    try {
      stmt.bind([machineId]);
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as TransitionRow);
    } finally {
      stmt.free();
    }
    return out;
  }

  listTasks(): TaskRow[] {
    const stmt = this.db.prepare(
      `SELECT t.id AS id, t.name AS name, t.entry AS entry, t.priority AS priority, t.stack AS stack,
        t.api AS api, f.path AS file, t.line AS line,
        (SELECT d.period FROM rtos_delays d WHERE d.fn_name = t.entry ORDER BY d.line LIMIT 1) AS period
       FROM rtos_tasks t JOIN files f ON f.id = t.file_id
       ORDER BY t.name`,
    );
    const out: TaskRow[] = [];
    try {
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as TaskRow);
    } finally {
      stmt.free();
    }
    return out;
  }

  listIsrs(): IsrRow[] {
    // Recognise interrupt handlers by common naming conventions.
    const stmt = this.db.prepare(
      `SELECT fn.id AS id, fn.name AS name, f.path AS file, fn.line AS line
       FROM functions fn JOIN files f ON f.id = fn.file_id
       WHERE fn.name LIKE '%IRQHandler' OR fn.name LIKE '%\\_IRQHandler' ESCAPE '\\'
          OR fn.name LIKE '%\\_ISR' ESCAPE '\\' OR fn.name LIKE 'ISR\\_%' ESCAPE '\\'
          OR fn.name LIKE '%\\_Handler' ESCAPE '\\' OR fn.name LIKE '%Handler'
       GROUP BY fn.name ORDER BY fn.name`,
    );
    const out: IsrRow[] = [];
    try {
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as IsrRow);
    } finally {
      stmt.free();
    }
    return out;
  }

  functionRiskRows(): RiskRow[] {
    const stmt = this.db.prepare(
      `SELECT fn.id AS id, fn.name AS name, fn.signature AS signature, f.path AS file, fn.line AS line,
        fn.complexity AS complexity,
        (SELECT COUNT(*) FROM calls c WHERE c.callee_id = fn.id) AS fanIn,
        (SELECT COUNT(DISTINCT c2.callee_id) FROM calls c2 WHERE c2.caller_id = fn.id AND c2.callee_id IS NOT NULL) AS fanOut
       FROM functions fn JOIN files f ON f.id = fn.file_id`,
    );
    const out: RiskRow[] = [];
    try {
      while (stmt.step()) out.push(stmt.getAsObject() as unknown as RiskRow);
    } finally {
      stmt.free();
    }
    return out;
  }

  serialize(): Uint8Array {
    return this.db.export();
  }

  close(): void {
    this.db.close();
  }
}
