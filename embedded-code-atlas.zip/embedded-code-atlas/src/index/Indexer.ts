import * as vscode from 'vscode';
import * as path from 'path';
import * as os from 'os';
import * as fsp from 'fs/promises';
import { spawn } from 'child_process';
import { Logger } from '../logger';
import { Config } from '../config';
import { initSqlEngine, SqlJsIndexDatabase, IndexDatabase, CallNeighbor } from './IndexDatabase';
import { WorkerPool, PoolCallbacks } from './WorkerPool';
import { ClangRunner } from './clangRunner';
import { GraphService } from '../graph/GraphService';
import { GraphPayload, GraphRequest, GraphNode, DependencyReport, CallReport, ModuleReport, DataFlowReport, StateMachineReport, SchedulerReport, ArchitectureReport, ComplexityReport, DashboardReport, DashboardCard, DashboardFinding, AutosarReport } from '../graph/types';
import { analyzeDependencies, DependencyAnalysis } from '../graph/DependencyAnalyzer';
import { analyzeCalls, callPath, CallAnalysis } from '../graph/CallAnalyzer';
import { analyzeModules, ModuleAnalysis } from '../graph/ModuleAnalyzer';
import { analyzeArchitecture, ArchitectureAnalysis } from '../graph/ArchitectureAnalyzer';
import { analyzeRisk, RiskAnalysis, baseName } from '../graph/RiskAnalyzer';
import { analyzeAutosar, AutosarAnalysis } from '../graph/AutosarAnalyzer';
import { explainFunction, explainFile } from '../graph/Explainer';
import { Explanation } from '../graph/types';
import { analyzeDataFlow, DataFlowAnalysis } from '../graph/DataFlowAnalyzer';
import { CompilationDatabase } from './compileDb';
import { discover } from './discovery';
import { ParseRequest, ParseResponse, IndexStats, classifyLanguage } from './types';
import { WorkspaceChange } from '../workspace/WorkspaceWatcher';

export interface ProgressSink {
  report(message: string, increment?: number): void;
}

type EngineKind = 'heuristic' | 'clang';

/**
 * Owns the index lifecycle: load the DB, discover files, decide what changed
 * (cheap mtime+size pre-filter for fast rescans), parse the changed set with
 * the selected engine, resolve call edges, and persist. The accurate (clang)
 * engine is used only when requested AND a compilation database and clang are
 * both available; otherwise it transparently falls back to the heuristic
 * engine, including per-file (e.g. headers with no compile-DB entry).
 */
export class Indexer implements vscode.Disposable {
  private readonly statsEmitter = new vscode.EventEmitter<IndexStats>();
  readonly onDidUpdateStats = this.statsEmitter.event;

  private db: IndexDatabase | undefined;
  private engineReady = false;
  private busy = false;
  /** Cached whole-project dependency analysis; invalidated on any index change. */
  private depCache: DependencyAnalysis | null = null;
  /** Cached whole-project call analysis; invalidated on any index change. */
  private callCache: CallAnalysis | null = null;
  /** Cached module analysis + the depth it was computed at. */
  private moduleCache: ModuleAnalysis | null = null;
  private moduleCacheDepth = -1;
  /** Cached data-flow analysis; invalidated on any index change. */
  private dataFlowCache: DataFlowAnalysis | null = null;
  /** Cached architecture/layering analysis; invalidated on any index change. */
  private archCache: ArchitectureAnalysis | null = null;
  /** Cached complexity/risk analysis; invalidated on any index change. */
  private riskCache: RiskAnalysis | null = null;
  /** Cached AUTOSAR classification; invalidated on any index change. */
  private autosarCache: AutosarAnalysis | null = null;

  private engineKind: EngineKind = 'heuristic';
  private clangDb: CompilationDatabase | undefined;
  private clangPath = 'clang';

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly logger: Logger,
    private readonly config: Config,
  ) {}

  isBusy(): boolean {
    return this.busy;
  }

  async load(): Promise<IndexStats> {
    await this.ensureEngine();
    const dbPath = this.dbPath();
    let bytes: Uint8Array | undefined;
    try {
      bytes = await vscode.workspace.fs.readFile(vscode.Uri.file(dbPath));
      this.logger.info(`Loaded index from ${dbPath} (${bytes.length} bytes).`);
    } catch {
      this.logger.info('No existing index found; starting empty.');
    }
    this.db = SqlJsIndexDatabase.open(bytes);
    return this.emitStats();
  }

  private async ensureEngine(): Promise<void> {
    if (this.engineReady) return;
    const wasmUri = vscode.Uri.joinPath(this.context.extensionUri, 'resources', 'sql-wasm.wasm');
    const wasm = await vscode.workspace.fs.readFile(wasmUri);
    await initSqlEngine(wasm);
    this.engineReady = true;
  }

  async rebuild(progress: ProgressSink, token: vscode.CancellationToken, force = false): Promise<IndexStats> {
    if (this.busy) {
      this.logger.warn('Index build already in progress; ignoring.');
      return this.emitStats();
    }
    this.busy = true;
    try {
      if (!this.db) await this.load();
      const cfg = this.config.current();

      progress.report('Discovering files', 5);
      const found = await discover(cfg.include, cfg.exclude, this.logger);
      this.context.workspaceState.update('atlas.projectKind', found.projectKind);

      await this.selectEngine(found.compileCommands);

      const known = this.db!.knownFiles();
      const discoveredPaths = new Set(found.files.map((f) => f.path));

      progress.report('Checking for changes', 10);
      const toParse: ParseRequest[] = [];
      const maxBytes = cfg.maxFileSizeKb * 1024;
      for (const f of found.files) {
        if (token.isCancellationRequested) break;
        const prev = known.get(f.path);
        let changed = force || !prev;
        if (!changed && prev) {
          try {
            const st = await fsp.stat(f.path);
            changed = Math.round(st.mtimeMs) !== Math.round(prev.mtime) || st.size > maxBytes;
          } catch {
            changed = true;
          }
        }
        if (changed) toParse.push({ path: f.path, language: f.language, maxBytes });
      }

      const removed = [...known.keys()].filter((p) => !discoveredPaths.has(p));
      this.logger.info(`To parse: ${toParse.length}; unchanged: ${found.files.length - toParse.length}; removed: ${removed.length}; engine: ${this.engineKind}.`);

      await this.runParse(toParse, removed, progress, token);

      progress.report('Resolving call edges', 95);
      this.db!.resolveCalls();
      this.db!.resolveRefs();
      const iso = new Date().toISOString();
      this.db!.setLastBuilt(iso);
      await this.persist();
      progress.report('Done', 100);
      return this.emitStats();
    } finally {
      this.busy = false;
    }
  }

  async applyChange(change: WorkspaceChange): Promise<void> {
    if (!this.db || this.busy) return;
    this.busy = true;
    try {
      const cfg = this.config.current();
      const maxBytes = cfg.maxFileSizeKb * 1024;
      const reqs: ParseRequest[] = [...change.created, ...change.changed]
        .map((u) => ({ path: u.fsPath, language: classifyLanguage(u.fsPath), maxBytes }))
        .filter((r) => r.language !== 'unknown');
      const removed = change.deleted.map((u) => u.fsPath);
      if (!reqs.length && !removed.length) return;

      const noop: ProgressSink = { report: () => undefined };
      const token = new vscode.CancellationTokenSource().token;
      await this.runParse(reqs, removed, noop, token);
      this.db.resolveCalls();
      this.db.resolveRefs();
      await this.persist();
      this.emitStats();
    } finally {
      this.busy = false;
    }
  }

  /** Decide which engine to use for this build, with graceful fallback. */
  private async selectEngine(compileCommands: string | null): Promise<void> {
    const cfg = this.config.current();
    this.clangDb = undefined;
    this.engineKind = 'heuristic';
    if (cfg.engine === 'heuristic') return;

    if (!compileCommands) {
      this.logger.warn(`Engine "${cfg.engine}" requested but no compile_commands.json found; using heuristic engine.`);
      return;
    }
    if (!(await this.clangAvailable(cfg.clangPath))) {
      this.logger.warn(`clang not found at "${cfg.clangPath}"; using heuristic engine. Set embeddedCodeAtlas.clangPath to enable the accurate engine.`);
      return;
    }
    try {
      this.clangDb = await CompilationDatabase.load(compileCommands);
      this.clangPath = cfg.clangPath;
      this.engineKind = 'clang';
      this.logger.info(`Accurate engine enabled: clang + ${this.clangDb.files().length} compile-DB entries.`);
    } catch (err) {
      this.logger.warn(`Failed to load ${compileCommands}; using heuristic engine.`);
      this.logger.debug(String(err));
    }
  }

  private clangAvailable(clangPath: string): Promise<boolean> {
    return new Promise((resolve) => {
      const child = spawn(clangPath, ['--version']);
      child.on('error', () => resolve(false));
      child.on('close', (code) => resolve(code === 0));
    });
  }

  private concurrency(): number {
    return Math.max(1, os.cpus().length - 1);
  }

  /** Parse a set of files with the selected engine(s) and write to the DB. */
  private async runParse(toParse: ParseRequest[], removed: string[], progress: ProgressSink, token: vscode.CancellationToken): Promise<void> {
    const db = this.db!;
    this.depCache = null; // any parse/removal invalidates dependency analysis
    this.callCache = null;
    this.moduleCache = null;
    this.moduleCacheDepth = -1;
    this.dataFlowCache = null;
    this.archCache = null;
    this.riskCache = null;
    this.autosarCache = null;
    if (removed.length) {
      db.transaction(() => removed.forEach((p) => db.removeFile(p)));
    }
    if (!toParse.length) return;

    let buffer: ParseResponse[] = [];
    const flush = () => {
      if (!buffer.length) return;
      const batch = buffer;
      buffer = [];
      db.transaction(() => {
        for (const res of batch) {
          if (res.ok) db.upsertFile(res.parsed);
          else this.logger.debug(`Parse skipped/failed: ${res.path} — ${res.error}`);
        }
      });
    };
    const sink = (label: string): PoolCallbacks => ({
      onResult: (res) => { buffer.push(res); if (buffer.length >= 500) flush(); },
      onProgress: (done, total) => progress.report(`Parsing (${label}) ${done}/${total}`, 0),
      isCancelled: () => token.isCancellationRequested,
    });

    // Split: clang handles files with a compile-DB entry; everything else
    // (headers, files outside the build) goes to the heuristic engine.
    let clangReqs: ParseRequest[] = [];
    let heuristicReqs = toParse;
    if (this.engineKind === 'clang' && this.clangDb) {
      clangReqs = toParse.filter((r) => this.clangDb!.has(r.path));
      heuristicReqs = toParse.filter((r) => !this.clangDb!.has(r.path));
    }

    if (clangReqs.length && this.clangDb) {
      const runner = new ClangRunner(this.clangPath, this.clangDb, this.logger, this.concurrency());
      await runner.run(clangReqs, sink('clang'));
    }
    if (heuristicReqs.length) {
      const workerPath = path.join(__dirname, 'parseWorker.js');
      const pool = new WorkerPool(workerPath, this.logger);
      await pool.run(heuristicReqs, sink('heuristic'));
    }
    flush();
  }

  private async persist(): Promise<void> {
    if (!this.db) return;
    const dbPath = this.dbPath();
    const dir = path.dirname(dbPath);
    await vscode.workspace.fs.createDirectory(vscode.Uri.file(dir));
    await vscode.workspace.fs.writeFile(vscode.Uri.file(dbPath), this.db.serialize());
    this.logger.debug(`Index persisted to ${dbPath}.`);
  }

  private dbPath(): string {
    const configured = this.config.current().databasePath;
    if (configured) return configured;
    const folder = vscode.workspace.workspaceFolders?.[0];
    const base = folder ? folder.uri.fsPath : this.context.globalStorageUri.fsPath;
    return path.join(base, '.vscode', 'embedded-atlas', 'index.sqlite');
  }

  getStats(): IndexStats {
    return this.db ? this.db.stats() : { files: 0, functions: 0, classes: 0, calls: 0, variables: 0, lastBuilt: null };
  }

  search(query: string, limit = 50) {
    return this.db ? this.db.searchFunctions(query, limit) : [];
  }

  outgoing(functionId: number): CallNeighbor[] {
    return this.db ? this.db.outgoing(functionId) : [];
  }

  incoming(functionId: number): CallNeighbor[] {
    return this.db ? this.db.incoming(functionId) : [];
  }

  /** Build a renderable neighbourhood slice for the requested graph view. */
  buildGraph(req: GraphRequest): GraphPayload {
    if (!this.db) {
      return { kind: req.kind, focus: null, nodes: [], edges: [], truncated: false, note: 'Index not loaded yet.' };
    }
    const gs = new GraphService(this.db);
    if (req.kind === 'module-graph') {
      return gs.buildModuleGraph(this.getModuleAnalysis(req.depth));
    }
    if (req.kind === 'architecture-graph') {
      return gs.buildArchitecture(this.getArchitectureAnalysis());
    }
    if (req.kind === 'complexity-graph') {
      return gs.buildComplexity(this.getRiskAnalysis(), req.maxNodes);
    }
    if (req.kind === 'autosar-graph') {
      return gs.buildAutosar(this.getAutosarAnalysis());
    }
    const payload = gs.build(req);
    if (req.kind === 'file-graph') this.annotateFiles(payload.nodes);
    if (req.kind === 'function-graph') this.annotateFunctions(payload.nodes);
    return payload;
  }

  /** Data-flow findings: most-referenced and multi-writer variables. */
  dataFlowReport(): DataFlowReport {
    const a = this.getDataFlowAnalysis();
    const map = (s: { id: number; name: string; scope: string; reads: number; writes: number; writers: number }) =>
      ({ nodeId: `var:${s.id}`, label: s.name, scope: s.scope, reads: s.reads, writes: s.writes, writers: s.writers });
    return { totalVariables: a.totalVariables, totalRefs: a.totalRefs, hotspots: a.hotspots.map(map), multiWriter: a.multiWriter.map(map) };
  }

  private getDataFlowAnalysis(): DataFlowAnalysis {
    if (this.dataFlowCache) return this.dataFlowCache;
    if (!this.db) return { totalVariables: 0, totalRefs: 0, hotspots: [], multiWriter: [] };
    this.dataFlowCache = analyzeDataFlow(this.db.allVariables(), this.db.allRefEdges());
    return this.dataFlowCache;
  }

  /** All detected state machines, for the State Machine view list. */
  stateMachineReport(): StateMachineReport {
    if (!this.db) return { machines: [] };
    return {
      machines: this.db.listStateMachines().map((m) => ({
        nodeId: `sm:${m.id}`,
        varName: m.varName,
        fnName: m.fnName,
        file: m.file,
        line: m.line,
        states: m.stateCount,
        transitions: m.transitionCount,
      })),
    };
  }

  /** RTOS scheduler findings: tasks (with priority/period) and ISRs. */
  schedulerReport(): SchedulerReport {
    if (!this.db) return { tasks: [], isrs: [] };
    return {
      tasks: this.db.listTasks().map((t) => ({
        nodeId: `task:${t.id}`, name: t.name, entry: t.entry, priority: t.priority,
        period: t.period, stack: t.stack, api: t.api, file: t.file, line: t.line,
      })),
      isrs: this.db.listIsrs().map((i) => ({ nodeId: `isr:${i.id}`, name: i.name, file: i.file, line: i.line })),
    };
  }

  /** Architecture/layering findings: layer summary and upward-dependency violations. */
  architectureReport(): ArchitectureReport {
    const a = this.getArchitectureAnalysis();
    return {
      configured: a.configured,
      layerCount: a.layers.length,
      violationCount: a.totalViolations,
      layers: a.layers.map((l) => ({ label: l.label, rank: l.rank, fileCount: l.fileCount })),
      violations: a.violations.map((v) => ({ fromPath: v.fromPath, toPath: v.toPath, fromLayer: v.fromLayer, toLayer: v.toLayer })),
    };
  }

  private getArchitectureAnalysis(): ArchitectureAnalysis {
    if (this.archCache) return this.archCache;
    if (!this.db) return { layers: [], edges: [], violations: [], totalViolations: 0, configured: false };
    this.archCache = analyzeArchitecture(this.db.allFiles(), this.db.allIncludeEdges(), this.config.current().architectureLayers);
    return this.archCache;
  }

  /** Complexity/risk findings: riskiest functions and per-file complexity totals. */
  complexityReport(): ComplexityReport {
    const a = this.getRiskAnalysis();
    return {
      maxComplexity: a.maxComplexity,
      avgComplexity: a.avgComplexity,
      functions: a.functions.slice(0, 40).map((f) => ({
        nodeId: `fn:${f.id}`, name: f.name, file: f.file, line: f.line,
        complexity: f.complexity, fanIn: f.fanIn, fanOut: f.fanOut, risk: f.risk,
      })),
      files: a.files.slice(0, 25).map((f) => ({
        path: baseName(f.path), totalComplexity: f.totalComplexity, functionCount: f.functionCount, maxComplexity: f.maxComplexity,
      })),
    };
  }

  private getRiskAnalysis(): RiskAnalysis {
    if (this.riskCache) return this.riskCache;
    if (!this.db) return { maxComplexity: 1, avgComplexity: 0, functions: [], files: [] };
    this.riskCache = analyzeRisk(this.db.functionRiskRows());
    return this.riskCache;
  }

  /** AUTOSAR classification: modules per layer and non-conformant dependencies. */
  autosarReport(): AutosarReport {
    const a = this.getAutosarAnalysis();
    return {
      recognized: a.recognized,
      violationCount: a.totalViolations,
      layers: a.layers.map((l) => ({ label: l.label, rank: l.rank, moduleCount: l.moduleCount, modules: l.modules })),
      violations: a.violations.map((v) => ({ fromPath: baseName(v.fromPath), toPath: baseName(v.toPath), fromLayer: v.fromLayer, toLayer: v.toLayer })),
    };
  }

  private getAutosarAnalysis(): AutosarAnalysis {
    if (this.autosarCache) return this.autosarCache;
    if (!this.db) return { recognized: 0, layers: [], violations: [], totalViolations: 0 };
    this.autosarCache = analyzeAutosar(this.db.allFiles(), this.db.allIncludeEdges());
    return this.autosarCache;
  }

  /** A single cross-analysis overview: headline counts plus prioritised findings. */
  /** A plain-English, locally generated explanation of a function or file node. */
  explain(target: string): Explanation {
    if (!this.db) return { target, title: 'Not ready', lines: ['The index is not loaded yet.'] };
    if (target.startsWith('fn:')) {
      const id = Number(target.slice(3));
      const recursive = this.getCallAnalysis().inCycle.has(id);
      return explainFunction(this.db, id, recursive);
    }
    if (target.startsWith('file:')) {
      const id = Number(target.slice(5));
      const dep = this.getDependencyAnalysis();
      return explainFile(this.db, id, dep.fanIn.get(id) ?? 0, dep.inCycle.has(id));
    }
    return { target, title: 'Not explainable', lines: ['Explanations are available for functions and files.'] };
  }

  /** A single cross-analysis overview: headline counts plus prioritised findings. */
  dashboardReport(): DashboardReport {
    if (!this.db) return { stats: { files: 0, functions: 0, calls: 0, variables: 0 }, cards: [], findings: [] };
    const s = this.db.stats();
    const dep = this.getDependencyAnalysis();
    const call = this.getCallAnalysis();
    const mod = this.getModuleAnalysis(1);
    const df = this.getDataFlowAnalysis();
    const arch = this.getArchitectureAnalysis();
    const risk = this.getRiskAnalysis();
    const machines = this.db.listStateMachines();
    const tasks = this.db.listTasks();
    const isrs = this.db.listIsrs();
    const highCx = risk.functions.filter((f) => f.complexity >= 10).length;

    const sev = (bad: boolean, warn = false): 'ok' | 'warn' | 'bad' => (bad ? 'bad' : warn ? 'warn' : 'ok');
    const cards: DashboardCard[] = [
      { view: 'file-graph', label: 'Files', value: String(s.files), sub: `${dep.cycles.length} include cycle${dep.cycles.length === 1 ? '' : 's'}`, severity: sev(dep.cycles.length > 0) },
      { view: 'function-graph', label: 'Functions', value: String(s.functions), sub: `${call.recursion.length} recursive`, severity: sev(false, call.recursion.length > 0) },
      { view: 'module-graph', label: 'Modules', value: String(mod.modules.length), sub: `${mod.cycles.length} circular`, severity: sev(mod.cycles.length > 0) },
      { view: 'data-flow-graph', label: 'Globals', value: String(s.variables), sub: `${df.multiWriter.length} multi-writer`, severity: sev(false, df.multiWriter.length > 0) },
      { view: 'state-machine-graph', label: 'State machines', value: String(machines.length), sub: 'detected', severity: 'ok' },
      { view: 'scheduler-graph', label: 'RTOS tasks', value: String(tasks.length), sub: `${isrs.length} ISR${isrs.length === 1 ? '' : 's'}`, severity: 'ok' },
      { view: 'architecture-graph', label: 'Layers', value: String(arch.layers.length), sub: `${arch.totalViolations} violation${arch.totalViolations === 1 ? '' : 's'}`, severity: sev(arch.totalViolations > 0) },
      { view: 'complexity-graph', label: 'Max complexity', value: String(risk.maxComplexity), sub: `${highCx} function${highCx === 1 ? '' : 's'} ≥10`, severity: sev(risk.maxComplexity >= 15, risk.maxComplexity >= 10) },
    ];

    const findings: DashboardFinding[] = [];
    for (const v of arch.violations.slice(0, 4)) findings.push({ severity: 'bad', text: `Layering: ${v.fromLayer} depends on ${v.toLayer} (${baseName(v.fromPath)} → ${baseName(v.toPath)})`, view: 'architecture-graph' });
    for (const c of dep.cycles.slice(0, 3)) findings.push({ severity: 'bad', text: `Include cycle: ${c.paths.map(baseName).join(' → ')}`, view: 'file-graph' });
    for (const c of mod.cycles.slice(0, 2)) findings.push({ severity: 'bad', text: `Module cycle: ${c.names.join(' → ')}`, view: 'module-graph' });
    for (const r of call.recursion.slice(0, 3)) findings.push({ severity: 'warn', text: `Recursion: ${r.labels.join(' → ')}`, view: 'function-graph' });
    for (const w of df.multiWriter.slice(0, 3)) findings.push({ severity: 'warn', text: `Shared state: ${w.name} written by ${w.writers} functions`, view: 'data-flow-graph' });
    for (const f of risk.functions.filter((x) => x.complexity >= 15).slice(0, 3)) findings.push({ severity: 'warn', text: `High complexity: ${f.name} (cc ${f.complexity})`, view: 'complexity-graph' });
    findings.sort((a, b) => (a.severity === b.severity ? 0 : a.severity === 'bad' ? -1 : 1));

    return { stats: { files: s.files, functions: s.functions, calls: s.calls, variables: s.variables }, cards, findings: findings.slice(0, 14) };
  }

  /** Module-detection findings: sizes, cross-module deps, module cycles. */
  moduleReport(depth: number): ModuleReport {
    const a = this.getModuleAnalysis(depth);
    const modules = a.modules
      .map((m) => ({
        nodeId: `mod:${m.index}`,
        name: m.name,
        fileCount: m.fileIds.length,
        dependsOn: a.dependsOn.get(m.index) ?? 0,
        dependedOnBy: a.dependedOnBy.get(m.index) ?? 0,
        inCycle: a.inCycle.has(m.index),
      }))
      .sort((x, y) => y.fileCount - x.fileCount);
    return {
      moduleCount: a.modules.length,
      crossEdges: a.edges.length,
      modules,
      cycles: a.cycles.map((c) => ({ nodeIds: c.indices.map((i) => `mod:${i}`), labels: c.names })),
    };
  }

  /** Drill into a module: the file graph of the files it contains. */
  buildModuleFiles(moduleNodeId: string, depth: number): GraphPayload {
    if (!this.db) return { kind: 'file-graph', focus: null, nodes: [], edges: [], truncated: false };
    const idx = Number(moduleNodeId.replace('mod:', ''));
    const a = this.getModuleAnalysis(depth);
    const mod = a.modules[idx];
    if (!mod) return { kind: 'file-graph', focus: null, nodes: [], edges: [], truncated: false, note: 'Module not found.' };
    const cfg = this.config.current();
    const payload = new GraphService(this.db).buildModuleFiles(mod.name, mod.fileIds, cfg.graphMaxNodes);
    this.annotateFiles(payload.nodes);
    return payload;
  }

  private getModuleAnalysis(depth: number): ModuleAnalysis {
    const d = Math.max(1, depth || 1);
    if (this.moduleCache && this.moduleCacheDepth === d) return this.moduleCache;
    if (!this.db) {
      return { modules: [], edges: [], cycles: [], inCycle: new Set(), moduleOfFile: new Map(), dependsOn: new Map(), dependedOnBy: new Map() };
    }
    this.moduleCache = analyzeModules(this.db.allFiles(), this.db.allIncludeEdges(), d);
    this.moduleCacheDepth = d;
    return this.moduleCache;
  }

  /** Whole-project recursion, entry points, and most-called functions. */
  callReport(): CallReport {
    const a = this.getCallAnalysis();
    return {
      totalFunctions: a.totalFunctions,
      totalCalls: a.totalCalls,
      recursion: a.recursion.map((c) => ({ nodeIds: c.ids.map((id) => `fn:${id}`), labels: c.labels })),
      entryPoints: a.entryPoints.map((e) => ({ nodeId: `fn:${e.id}`, label: e.name, file: e.file, line: e.line })),
      mostCalled: a.mostCalled.map((m) => ({ nodeId: `fn:${m.id}`, label: m.name, callers: m.callers })),
    };
  }

  /** Trace a call path from a function to a target named by `query`. */
  traceCallPath(fromNodeId: string, query: string): GraphPayload {
    const empty: GraphPayload = { kind: 'function-graph', focus: null, nodes: [], edges: [], truncated: false };
    if (!this.db) return { ...empty, note: 'Index not loaded yet.' };
    const fromId = Number(fromNodeId.replace('fn:', ''));
    const fromRow = this.db.functionById(fromId);
    const target = this.db.lookupFunctions(query, 1)[0];
    if (!fromRow || !target) {
      return { ...empty, note: `Could not resolve ${!fromRow ? 'source' : 'target'} function.` };
    }
    const a = this.getCallAnalysis();
    const path = callPath(a.adjacency, fromId, target.id);
    const gs = new GraphService(this.db);
    if (!path) {
      const payload = gs.buildCallPath([fromId, target.id], `No call path found from ${fromRow.name} to ${target.name} (within indexed, resolved calls).`);
      // Drop the synthetic edge for the no-path case.
      payload.edges = [];
      this.annotateFunctions(payload.nodes);
      return payload;
    }
    const payload = gs.buildCallPath(path, `Call path: ${fromRow.name} → ${target.name} (${path.length - 1} hop${path.length - 1 === 1 ? '' : 's'}).`);
    this.annotateFunctions(payload.nodes);
    return payload;
  }

  private getCallAnalysis(): CallAnalysis {
    if (this.callCache) return this.callCache;
    if (!this.db) {
      return { totalFunctions: 0, totalCalls: 0, recursion: [], inCycle: new Set(), entryPoints: [], mostCalled: [], adjacency: new Map() };
    }
    this.callCache = analyzeCalls(this.db.allFunctions(), this.db.allCallEdges());
    return this.callCache;
  }

  private annotateFunctions(nodes: GraphNode[]): void {
    const a = this.getCallAnalysis();
    for (const n of nodes) {
      if (n.kind !== 'function') continue;
      const id = Number(n.id.replace('fn:', ''));
      n.inCycle = a.inCycle.has(id);
    }
  }

  /** Build a graph of an explicit file set (e.g. a detected cycle). */
  buildSubgraph(nodeIds: string[]): GraphPayload {
    if (!this.db) {
      return { kind: 'file-graph', focus: null, nodes: [], edges: [], truncated: false };
    }
    const ids = nodeIds.map((n) => Number(n.replace('file:', ''))).filter((n) => Number.isFinite(n));
    const payload = new GraphService(this.db).buildFileSubgraph(ids);
    this.annotateFiles(payload.nodes);
    return payload;
  }

  /** Whole-project circular dependencies, hotspots, and folder clusters. */
  dependencyReport(): DependencyReport {
    const a = this.getDependencyAnalysis();
    return {
      totalFiles: a.totalFiles,
      totalEdges: a.totalEdges,
      cycles: a.cycles.map((c) => ({
        nodeIds: c.ids.map((id) => `file:${id}`),
        labels: c.paths.map((p) => path.basename(p)),
      })),
      hotspots: a.hotspots.map((h) => ({ nodeId: `file:${h.id}`, label: path.basename(h.path), path: h.path, fanIn: h.fanIn, fanOut: h.fanOut })),
      clusters: a.clusters,
    };
  }

  private getDependencyAnalysis(): DependencyAnalysis {
    if (this.depCache) return this.depCache;
    if (!this.db) {
      return { totalFiles: 0, totalEdges: 0, cycles: [], hotspots: [], clusters: [], inCycle: new Set(), fanIn: new Map(), fanOut: new Map() };
    }
    this.depCache = analyzeDependencies(this.db.allFiles(), this.db.allIncludeEdges());
    return this.depCache;
  }

  private annotateFiles(nodes: GraphNode[]): void {
    const a = this.getDependencyAnalysis();
    for (const n of nodes) {
      if (n.kind !== 'file') continue;
      const id = Number(n.id.replace('file:', ''));
      n.inCycle = a.inCycle.has(id);
      n.fanIn = a.fanIn.get(id) ?? 0;
      n.fanOut = a.fanOut.get(id) ?? 0;
    }
  }

  private emitStats(): IndexStats {
    const s = this.getStats();
    this.statsEmitter.fire(s);
    return s;
  }

  dispose(): void {
    this.db?.close();
    this.statsEmitter.dispose();
  }
}
