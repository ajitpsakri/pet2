import { Worker } from 'worker_threads';
import * as os from 'os';
import { ParseRequest, ParseResponse } from './types';
import { Logger } from '../logger';

export interface PoolCallbacks {
  onResult: (res: ParseResponse) => void;
  /** `current` is the path most recently dispatched, for progress display. */
  onProgress: (done: number, total: number, current?: string) => void;
  isCancelled?: () => boolean;
}

/**
 * Fixed-size pool of parse workers. Each worker processes one request at a
 * time; as soon as it returns, the next queued request is dispatched to it.
 *
 * Every request runs under a watchdog: if a worker fails to answer within the
 * timeout, it is terminated and replaced, and the file is recorded as a parse
 * failure instead of stalling the whole build. One pathological file (huge
 * generated source, regex worst case) must never hang an overnight index.
 */
export class WorkerPool {
  private readonly size: number;

  constructor(
    private readonly workerPath: string,
    private readonly logger: Logger,
    requestedSize?: number,
    private readonly taskTimeoutMs = 30_000,
  ) {
    const cpus = Math.max(1, os.cpus().length - 1);
    this.size = Math.max(1, Math.min(requestedSize ?? cpus, cpus));
  }

  run(requests: ParseRequest[], cb: PoolCallbacks): Promise<void> {
    const total = requests.length;
    if (total === 0) {
      cb.onProgress(0, 0);
      return Promise.resolve();
    }

    const workerCount = Math.min(this.size, total);
    this.logger.info(`Parsing ${total} file(s) across ${workerCount} worker(s), ${this.taskTimeoutMs}ms/file watchdog.`);

    return new Promise<void>((resolve, reject) => {
      const queue = requests.slice();
      let done = 0;
      let active = workerCount;
      let settled = false;
      const live = new Set<Worker>();

      const finish = (err?: Error) => {
        if (settled) return;
        settled = true;
        for (const w of live) void w.terminate();
        if (err) reject(err);
        else resolve();
      };

      const startWorker = () => {
        const worker = new Worker(this.workerPath);
        live.add(worker);
        let timer: ReturnType<typeof setTimeout> | null = null;
        let current: ParseRequest | null = null;

        const clear = () => { if (timer) { clearTimeout(timer); timer = null; } };

        const dispatch = () => {
          if (settled) return;
          if (cb.isCancelled?.()) {
            active--;
            if (active === 0) finish();
            return;
          }
          const next = queue.shift();
          if (!next) {
            active--;
            if (active === 0) finish();
            return;
          }
          current = next;
          cb.onProgress(done, total, next.path);
          timer = setTimeout(() => {
            // Watchdog fired: give up on this file, replace the worker.
            const stuck = current;
            current = null;
            live.delete(worker);
            void worker.terminate();
            this.logger.warn(`Parse timeout (${this.taskTimeoutMs}ms): ${stuck?.path ?? '?'} — skipped, worker restarted.`);
            done++;
            if (stuck) cb.onResult({ ok: false, path: stuck.path, error: `parse timeout after ${this.taskTimeoutMs}ms (skipped)` });
            cb.onProgress(done, total);
            startWorker();
          }, this.taskTimeoutMs);
          worker.postMessage(next);
        };

        worker.on('message', (res: ParseResponse) => {
          clear();
          current = null;
          done++;
          cb.onResult(res);
          cb.onProgress(done, total);
          dispatch();
        });
        worker.on('error', (err) => {
          // A crash in one worker fails its current file, not the whole build.
          clear();
          live.delete(worker);
          this.logger.error('Parse worker error; restarting worker.', err);
          if (current) {
            done++;
            cb.onResult({ ok: false, path: current.path, error: String(err) });
            cb.onProgress(done, total);
            current = null;
          }
          if (!settled) startWorker();
        });
        worker.on('exit', (code) => {
          if (code !== 0 && !settled && live.has(worker)) {
            this.logger.warn(`Parse worker exited with code ${code}.`);
          }
        });
        dispatch();
      };

      for (let i = 0; i < workerCount; i++) startWorker();
    });
  }
}
