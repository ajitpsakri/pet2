import { Worker } from 'worker_threads';
import * as os from 'os';
import { ParseRequest, ParseResponse } from './types';
import { Logger } from '../logger';

export interface PoolCallbacks {
  onResult: (res: ParseResponse) => void;
  onProgress: (done: number, total: number) => void;
  isCancelled?: () => boolean;
}

/**
 * Fixed-size pool of parse workers. Each worker processes one request at a
 * time; as soon as it returns, the next queued request is dispatched to it.
 * This keeps all cores busy without unbounded memory, and the host thread
 * stays free to update the UI and write the database.
 */
export class WorkerPool {
  private readonly size: number;

  constructor(
    private readonly workerPath: string,
    private readonly logger: Logger,
    requestedSize?: number,
  ) {
    const cpus = Math.max(1, os.cpus().length - 1);
    this.size = Math.max(1, Math.min(requestedSize ?? cpus, cpus));
  }

  run(requests: ParseRequest[], cb: PoolCallbacks): Promise<void> {
    const total = requests.length;
    if (total === 0) {
      cb.onProgress(0, 0);
      return Promise.resolve();
    }

    const workerCount = Math.min(this.size, total);
    this.logger.info(`Parsing ${total} file(s) across ${workerCount} worker(s).`);

    return new Promise<void>((resolve, reject) => {
      const queue = requests.slice();
      const workers: Worker[] = [];
      let done = 0;
      let active = workerCount;
      let settled = false;

      const finish = (err?: Error) => {
        if (settled) return;
        settled = true;
        for (const w of workers) void w.terminate();
        if (err) reject(err);
        else resolve();
      };

      const dispatch = (worker: Worker) => {
        if (cb.isCancelled?.()) {
          active--;
          if (active === 0) finish();
          return;
        }
        const next = queue.shift();
        if (!next) {
          active--;
          if (active === 0) finish();
          return;
        }
        worker.postMessage(next);
      };

      for (let i = 0; i < workerCount; i++) {
        const worker = new Worker(this.workerPath);
        workers.push(worker);
        worker.on('message', (res: ParseResponse) => {
          done++;
          cb.onResult(res);
          cb.onProgress(done, total);
          dispatch(worker);
        });
        worker.on('error', (err) => {
          this.logger.error('Parse worker error.', err);
          finish(err);
        });
        worker.on('exit', (code) => {
          if (code !== 0 && !settled) {
            this.logger.warn(`Parse worker exited with code ${code}.`);
          }
        });
        dispatch(worker);
      }
    });
  }
}
