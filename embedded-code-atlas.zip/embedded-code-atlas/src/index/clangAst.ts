import * as path from 'path';
import {
  ParsedFile,
  FileRecord,
  FunctionRecord,
  ClassRecord,
  NamespaceRecord,
  RawCall,
  Language,
} from './types';

/**
 * Converts a clang `-ast-dump=json` translation unit into a ParsedFile.
 *
 * This is the accurate engine: clang has already resolved overloads, member
 * accesses, and macros, so call detection has no false positives and callee
 * names are real. Two clang-isms must be handled while walking:
 *   - `loc.file` is only emitted when it changes, so the current file is
 *     tracked down the DFS; we record only nodes located in the target file
 *     (everything else is from system/3rd-party headers in the same TU).
 *   - `loc.line` is likewise omitted when unchanged, so the line is inherited.
 *
 * Limitation: symbols *defined* in headers (inline/template bodies) are
 * attributed to their header, not the .cpp, and so are captured when that
 * header is itself indexed (or by the heuristic engine). Calls made from the
 * .cpp body are fully captured here.
 */

interface AstNode {
  kind?: string;
  name?: string;
  tagUsed?: string;
  loc?: { file?: string; line?: number };
  range?: { begin?: { line?: number; file?: string } };
  type?: { qualType?: string };
  referencedDecl?: { kind?: string; name?: string };
  inner?: AstNode[];
}

export function astToParsedFile(
  root: unknown,
  targetPath: string,
  language: Language,
  hash: string,
  size: number,
  mtime: number,
): ParsedFile {
  const target = path.resolve(targetPath);
  const functions: FunctionRecord[] = [];
  const classes: ClassRecord[] = [];
  const calls: RawCall[] = [];
  const namespaceSet = new Set<string>();
  const classSeen = new Set<string>();

  const nsStack: string[] = [];
  const classStack: string[] = [];
  const fnStack: number[] = [];

  const visit = (node: AstNode, curFile: string, curLine: number): void => {
    if (!node || typeof node !== 'object') return;
    const file = node.loc?.file ?? node.range?.begin?.file ?? curFile;
    const line = node.loc?.line ?? node.range?.begin?.line ?? curLine;
    const inTarget = path.resolve(file || '') === target;

    switch (node.kind) {
      case 'NamespaceDecl': {
        const name = node.name ?? '(anonymous)';
        nsStack.push(name);
        if (inTarget && node.name) namespaceSet.add(nsStack.join('::'));
        node.inner?.forEach((c) => visit(c, file, line));
        nsStack.pop();
        return;
      }
      case 'CXXRecordDecl': {
        const isDef = !!node.inner && (node.tagUsed === 'class' || node.tagUsed === 'struct');
        if (isDef && node.name) {
          if (inTarget) {
            const key = `${node.name}@${line}`;
            if (!classSeen.has(key)) {
              classSeen.add(key);
              classes.push({ name: node.name, file: target, line, kind: node.tagUsed === 'struct' ? 'struct' : 'class' });
            }
          }
          classStack.push(node.name);
          node.inner?.forEach((c) => visit(c, file, line));
          classStack.pop();
          return;
        }
        break;
      }
      case 'FunctionDecl':
      case 'CXXMethodDecl':
      case 'CXXConstructorDecl':
      case 'CXXDestructorDecl': {
        const hasBody = (node.inner ?? []).some((c) => c.kind === 'CompoundStmt' || c.kind === 'CXXTryStmt');
        if (hasBody && node.name && inTarget) {
          const idx = functions.length;
          functions.push({
            name: node.name,
            file: target,
            line,
            signature: buildSignature(node.name, node.type?.qualType),
            namespace: nsStack.length ? nsStack.join('::') : null,
            className: classStack.length ? classStack[classStack.length - 1] : null,
            complexity: 1,
          });
          fnStack.push(idx);
          node.inner?.forEach((c) => visit(c, file, line));
          fnStack.pop();
          return;
        }
        break;
      }
      case 'CallExpr':
      case 'CXXMemberCallExpr':
      case 'CXXOperatorCallExpr': {
        if (inTarget && fnStack.length) {
          const callee = calleeName((node.inner ?? [])[0]);
          if (callee && !callee.startsWith('operator')) {
            calls.push({ fnIndex: fnStack[fnStack.length - 1], callee, line });
          }
        }
        break; // fall through to recurse into arguments for nested calls
      }
      default:
        break;
    }
    node.inner?.forEach((c) => visit(c, file, line));
  };

  visit(root as AstNode, '', 0);

  // clang's AST has no preprocessor directives, so include edges are filled in
  // by the runner from a raw include scan of the source text.
  const namespaces: NamespaceRecord[] = [...namespaceSet].map((name) => ({ name }));
  const file: FileRecord = { path: targetPath, size, language, hash, mtime, includes: [] };
  return { file, functions, classes, namespaces, calls, variables: [], refs: [], stateMachines: [], tasks: [], delays: [] };
}

/** Find the called function's name from the callee subtree (inner[0]). */
function calleeName(node: AstNode | undefined): string | null {
  if (!node) return null;
  if (node.kind === 'DeclRefExpr' && node.referencedDecl?.name) return node.referencedDecl.name;
  if (node.kind === 'MemberExpr') return node.name ?? node.referencedDecl?.name ?? null;
  for (const c of node.inner ?? []) {
    const n = calleeName(c);
    if (n) return n;
  }
  return null;
}

function buildSignature(name: string, qualType?: string): string {
  if (!qualType) return `${name}()`;
  const open = qualType.indexOf('(');
  const close = qualType.lastIndexOf(')');
  const params = open >= 0 && close > open ? qualType.slice(open, close + 1) : '()';
  return `${name}${params.replace(/\s+/g, ' ')}`;
}
