import { spawn } from 'child_process';
import * as fsp from 'fs/promises';
import * as crypto from 'crypto';
import { Logger } from '../logger';
import { CompilationDatabase } from './compileDb';
import { astToParsedFile } from './clangAst';
import { scanIncludes, extractDataFlow, complexityByName } from './heuristicParser';
import { ParseRequest, ParseResponse } from './types';
import { PoolCallbacks } from './WorkerPool';

/**
 * Drives the accurate engine. Each compilable file is parsed with
 * `clang -ast-dump=json` using the flags reconstructed from the compilation
 * database. clang runs as a subprocess, so the heavy work is off the JS thread;
 * we just bound how many run at once. Files with no compile-DB entry (typically
 * headers) are reported as skipped so the caller can fall back to the heuristic
 * engine for them.
 */
export class ClangRunner {
  constructor(
    private readonly clangPath: string,
    private readonly compileDb: CompilationDatabase,
    private readonly logger: Logger,
    private readonly concurrency: number,
  ) {}

  async run(requests: ParseRequest[], cb: PoolCallbacks): Promise<void> {
    const total = requests.length;
    if (!total) { cb.onProgress(0, 0); return; }
    this.logger.info(`Clang AST: ${total} file(s), concurrency ${this.concurrency}.`);

    const queue = requests.slice();
    let done = 0;
    const worker = async (): Promise<void> => {
      for (;;) {
        if (cb.isCancelled?.()) return;
        const req = queue.shift();
        if (!req) return;
        const res = await this.parseOne(req);
        done++;
        cb.onResult(res);
        cb.onProgress(done, total);
      }
    };

    const lanes = Array.from({ length: Math.min(this.concurrency, total) }, () => worker());
    await Promise.all(lanes);
  }

  private async parseOne(req: ParseRequest): Promise<ParseResponse> {
    const built = this.compileDb.astArgs(req.path);
    if (!built) {
      return { ok: false, path: req.path, error: 'no compile_commands entry (fall back to heuristic)' };
    }
    try {
      const stat = await fsp.stat(req.path);
      if (stat.size > req.maxBytes) {
        return { ok: false, path: req.path, error: `skipped: ${stat.size} bytes exceeds limit` };
      }
      const json = await this.dumpAst(built.args, built.cwd);
      const ast = JSON.parse(json);
      const buf = await fsp.readFile(req.path);
      const hash = crypto.createHash('sha1').update(buf).digest('hex');
      const parsed = astToParsedFile(ast, req.path, req.language, hash, stat.size, stat.mtimeMs);
      const source = buf.toString('utf8');
      parsed.file.includes = scanIncludes(source);
      const df = extractDataFlow(source);
      parsed.variables = df.variables;
      parsed.refs = df.refs;
      parsed.stateMachines = df.stateMachines;
      parsed.tasks = df.tasks;
      parsed.delays = df.delays;
      const cx = complexityByName(source);
      for (const fn of parsed.functions) { const c = cx.get(fn.name); if (c) fn.complexity = c; }
      return { ok: true, parsed };
    } catch (err) {
      return { ok: false, path: req.path, error: err instanceof Error ? err.message : String(err) };
    }
  }

  private dumpAst(args: string[], cwd: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const child = spawn(this.clangPath, args, { cwd });
      const out: Buffer[] = [];
      let errLen = 0;
      const errBits: Buffer[] = [];
      child.stdout.on('data', (d: Buffer) => out.push(d));
      child.stderr.on('data', (d: Buffer) => { if (errLen < 4096) { errBits.push(d); errLen += d.length; } });
      child.on('error', reject);
      child.on('close', (code) => {
        const stdout = Buffer.concat(out).toString('utf8');
        // clang emits diagnostics on stderr but still produces a usable AST on
        // non-zero exit for code that does not fully compile; accept any JSON.
        if (stdout.trimStart().startsWith('{')) {
          resolve(stdout);
        } else {
          reject(new Error(`clang produced no AST (exit ${code}): ${Buffer.concat(errBits).toString('utf8').slice(0, 300)}`));
        }
      });
    });
  }
}
