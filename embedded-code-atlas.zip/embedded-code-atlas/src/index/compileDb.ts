import * as fsp from 'fs/promises';
import * as path from 'path';

interface CompileEntry {
  directory: string;
  file: string;
  command?: string;
  arguments?: string[];
}

/**
 * Loads a `compile_commands.json` compilation database and, for any source
 * file, reconstructs the clang flags needed to parse it the way the build
 * does. Getting these flags right (include paths, defines, std, sysroot) is the
 * single thing that determines whether the accurate engine produces a real
 * call graph or garbage on embedded code.
 */
export class CompilationDatabase {
  private readonly byFile = new Map<string, CompileEntry>();

  private constructor(entries: CompileEntry[]) {
    for (const e of entries) {
      this.byFile.set(path.resolve(e.directory, e.file), e);
    }
  }

  static async load(jsonPath: string): Promise<CompilationDatabase> {
    const raw = await fsp.readFile(jsonPath, 'utf8');
    const entries = JSON.parse(raw) as CompileEntry[];
    return new CompilationDatabase(entries);
  }

  has(filePath: string): boolean {
    return this.byFile.has(path.resolve(filePath));
  }

  files(): string[] {
    return [...this.byFile.keys()];
  }

  /**
   * Build the argument list for an AST dump of `filePath`: keep the flags that
   * affect parsing (-I, -D, -std, -isystem, -include, target/sysroot) and drop
   * output/compile-action flags that an AST dump must not carry.
   */
  astArgs(filePath: string): { args: string[]; cwd: string } | null {
    const entry = this.byFile.get(path.resolve(filePath));
    if (!entry) return null;

    const tokens = entry.arguments ? entry.arguments.slice() : tokenize(entry.command ?? '');
    const args: string[] = [];
    for (let i = 1; i < tokens.length; i++) {
      // skip the compiler (index 0)
      const t = tokens[i];
      if (t === '-o' || t === '-c' || t === '-MD' || t === '-MMD' || t === '-MF' || t === '-MT' || t === '-MQ') {
        if (t === '-o' || t === '-MF' || t === '-MT' || t === '-MQ') i++; // skip its argument
        continue;
      }
      if (t === entry.file || path.resolve(entry.directory, t) === path.resolve(entry.directory, entry.file)) {
        continue; // the source file itself; we append it explicitly
      }
      if (/^-(o|c)$/.test(t)) continue;
      args.push(t);
    }
    args.push('-Xclang', '-ast-dump=json', '-fsyntax-only');
    args.push(filePath);
    return { args, cwd: entry.directory };
  }
}

/** Minimal shell-style tokenizer for the legacy `command` string form. */
function tokenize(command: string): string[] {
  const out: string[] = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(command))) {
    out.push(m[1] ?? m[2] ?? m[3]);
  }
  return out;
}
