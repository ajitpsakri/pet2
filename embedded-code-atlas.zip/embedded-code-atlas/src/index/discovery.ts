import * as vscode from 'vscode';
import { ProjectKind, Language, classifyLanguage } from './types';

export interface DiscoveredFile {
  path: string;
  language: Language;
}

export interface Discovery {
  files: DiscoveredFile[];
  projectKind: ProjectKind;
  /** Path to compile_commands.json if one was found (key for Phase 3). */
  compileCommands: string | null;
}

/**
 * Enumerates indexable source files using VS Code's own file index (which
 * honours .gitignore and search excludes) and classifies the build system.
 * The project kind and compile_commands location are recorded now because
 * Phase 3's accurate parser depends entirely on having correct compile flags.
 */
export async function discover(include: string[], exclude: string[], logger?: { info: (m: string) => void }): Promise<Discovery> {
  const includeGlob = include.length === 1 ? include[0] : `{${include.join(',')}}`;
  const excludeGlob = exclude.length ? `{${exclude.join(',')}}` : null;

  const uris = await vscode.workspace.findFiles(includeGlob, excludeGlob);
  const files: DiscoveredFile[] = uris
    .map((u) => ({ path: u.fsPath, language: classifyLanguage(u.fsPath) }))
    .filter((f) => f.language !== 'unknown');

  const compileCommandsUris = await vscode.workspace.findFiles('**/compile_commands.json', excludeGlob, 1);
  const compileCommands = compileCommandsUris[0]?.fsPath ?? null;

  let projectKind: ProjectKind = 'generic';
  if (compileCommands) {
    projectKind = 'compile-commands';
  } else if ((await vscode.workspace.findFiles('**/CMakeLists.txt', excludeGlob, 1)).length) {
    projectKind = 'cmake';
  } else if ((await vscode.workspace.findFiles('**/{Makefile,makefile,GNUmakefile}', excludeGlob, 1)).length) {
    projectKind = 'make';
  }

  logger?.info(`Discovered ${files.length} source file(s); project kind: ${projectKind}${compileCommands ? ' (compile_commands.json found)' : ''}.`);
  return { files, projectKind, compileCommands };
}
