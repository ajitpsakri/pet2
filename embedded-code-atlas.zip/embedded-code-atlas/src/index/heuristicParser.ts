import {
  ParsedFile,
  FileRecord,
  FunctionRecord,
  ClassRecord,
  NamespaceRecord,
  RawCall,
  RawVariable,
  RawRef,
  RawStateMachine,
  RawTransition,
  RawTask,
  RawDelay,
  Language,
} from './types';

/**
 * A scope-aware *heuristic* extractor for C/C++.
 *
 * This is the Phase 2 "heuristic" engine: it works without a compilation
 * database and never needs the code to compile, which makes it robust on
 * partial or vendor-locked trees — at the cost of accuracy on macro-heavy or
 * unusual code. Phase 3 swaps in a libclang/clangd-backed parser behind the
 * same ParsedFile contract; nothing downstream changes.
 *
 * Strategy:
 *   1. Blank out comments and string/char literals while preserving length and
 *      newlines, so byte offsets still map to correct line numbers and stray
 *      braces inside literals can't corrupt scope tracking.
 *   2. Find namespace and class/struct scopes by brace matching.
 *   3. Find function definitions and attribute each to its enclosing scope by
 *      offset containment.
 */

const CONTROL_KEYWORDS = new Set([
  'if', 'for', 'while', 'switch', 'catch', 'return', 'sizeof', 'decltype',
  'static_assert', 'else', 'do', 'case', 'and', 'or', 'not', 'alignof',
  'noexcept', 'constexpr', 'typedef', 'using', 'template',
]);

export function parseSource(path: string, source: string, language: Language, hash: string, size: number, mtime: number): ParsedFile {
  const noComments = blankComments(source);
  const clean = blankLiterals(noComments);

  const includes = findIncludes(noComments);
  const scopes = findScopes(clean);
  const namespaces = dedupeNamespaces(scopes);
  const classes = scopesToClasses(scopes, path);
  const defs = findFunctions(clean, path, scopes);
  const functions = defs.map((d) => d.record);
  const calls = findCalls(clean, defs);
  const variables = findVariables(clean, defs);
  const refs = findRefs(clean, defs, new Set(variables.map((v) => v.name)));
  const stateMachines = findStateMachines(clean, defs);
  const tasks = findRtosTasks(noComments);
  const delays = findDelays(clean, defs);

  const file: FileRecord = { path, size, language, hash, mtime, includes };
  return { file, functions, classes, namespaces, calls, variables, refs, stateMachines, tasks, delays };
}

/**
 * Engine-independent data-flow extraction over raw source. The clang engine
 * reuses this so its files also get variable/ref data — the heuristic function
 * ranges are only used to attribute each reference to an enclosing function by
 * name, which lines up with whatever engine recorded the functions.
 */
export function extractDataFlow(source: string): { variables: RawVariable[]; refs: RawRef[]; stateMachines: RawStateMachine[]; tasks: RawTask[]; delays: RawDelay[] } {
  const noComments = blankComments(source);
  const clean = blankLiterals(noComments);
  const scopes = findScopes(clean);
  const defs = findFunctions(clean, '', scopes);
  const variables = findVariables(clean, defs);
  const refs = findRefs(clean, defs, new Set(variables.map((v) => v.name)));
  const stateMachines = findStateMachines(clean, defs);
  const tasks = findRtosTasks(noComments);
  const delays = findDelays(clean, defs);
  return { variables, refs, stateMachines, tasks, delays };
}

// ---------------------------------------------------------------------------
// Lexical cleanup
// ---------------------------------------------------------------------------

/** Replace comment bodies with spaces, keeping newlines and total length. */
function blankComments(src: string): string {
  const out = src.split('');
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    const d = src[i + 1];
    if (c === '/' && d === '/') {
      while (i < n && src[i] !== '\n') { out[i] = ' '; i++; }
    } else if (c === '/' && d === '*') {
      out[i] = ' '; out[i + 1] = ' '; i += 2;
      while (i < n && !(src[i] === '*' && src[i + 1] === '/')) {
        if (src[i] !== '\n') out[i] = ' ';
        i++;
      }
      if (i < n) { out[i] = ' '; out[i + 1] = ' '; i += 2; }
    } else if (c === '"' || c === '\'') {
      i = skipString(src, out, i, c, false);
    } else {
      i++;
    }
  }
  return out.join('');
}

/** Replace string/char literal contents with spaces (comments already gone). */
function blankLiterals(src: string): string {
  const out = src.split('');
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '"' || c === '\'') {
      i = skipString(src, out, i, c, true);
    } else {
      i++;
    }
  }
  return out.join('');
}

/** Advance past a string/char literal; optionally blank its interior. */
function skipString(src: string, out: string[], start: number, quote: string, blank: boolean): number {
  let i = start + 1;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '\\') { if (blank) { out[i] = ' '; out[i + 1] = ' '; } i += 2; continue; }
    if (c === quote) { i++; break; }
    if (blank && c !== '\n') out[i] = ' ';
    i++;
  }
  return i;
}

// ---------------------------------------------------------------------------
// Includes
// ---------------------------------------------------------------------------

function findIncludes(noComments: string): string[] {
  const re = /^[ \t]*#[ \t]*include[ \t]*([<"])([^>"]+)[>"]/gm;
  const found = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = re.exec(noComments))) {
    found.add(m[2].trim());
  }
  return [...found];
}

// ---------------------------------------------------------------------------
// Scopes (namespaces + classes/structs)
// ---------------------------------------------------------------------------

interface Scope {
  kind: 'namespace' | 'class' | 'struct';
  name: string;
  /** Fully-qualified namespace path at the point of declaration. */
  qualified: string;
  open: number; // index just after '{'
  close: number; // index of matching '}'
  line: number;
}

function findScopes(clean: string): Scope[] {
  const scopes: Scope[] = [];
  const re = /\b(namespace|class|struct)\b([^;{}]*?)\{/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const kind = m[1] as 'namespace' | 'class' | 'struct';
    const head = m[2];
    const name = extractScopeName(head);
    const openBrace = re.lastIndex - 1;
    const close = matchBrace(clean, openBrace);
    if (close < 0) continue;
    if (!name && kind !== 'namespace') continue; // anonymous class in a typedef etc.
    scopes.push({
      kind,
      name: name || '(anonymous)',
      qualified: '',
      open: openBrace + 1,
      close,
      line: lineAt(clean, m.index),
    });
  }
  // Assign qualified namespace paths based on containment.
  for (const s of scopes) {
    const enclosingNs = scopes
      .filter((p) => p.kind === 'namespace' && p !== s && p.open <= s.open && s.close <= p.close)
      .sort((a, b) => b.open - a.open);
    const prefix = enclosingNs.map((p) => p.name).reverse().join('::');
    s.qualified = s.kind === 'namespace'
      ? (prefix ? `${prefix}::${s.name}` : s.name)
      : prefix;
  }
  return scopes;
}

function extractScopeName(head: string): string {
  // Strip inheritance lists and attributes; take the last identifier before ':' or end.
  const beforeColon = head.split(':')[0];
  const ids = beforeColon.match(/[A-Za-z_]\w*/g);
  if (!ids || ids.length === 0) return '';
  // Skip leading specifiers like 'final', 'alignas', export macros.
  const skip = new Set(['final', 'alignas', 'export']);
  for (let i = ids.length - 1; i >= 0; i--) {
    if (!skip.has(ids[i])) return ids[i];
  }
  return '';
}

function matchBrace(src: string, openIndex: number): number {
  let depth = 0;
  for (let i = openIndex; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return i; }
  }
  return -1;
}

function dedupeNamespaces(scopes: Scope[]): NamespaceRecord[] {
  const seen = new Set<string>();
  const out: NamespaceRecord[] = [];
  for (const s of scopes) {
    if (s.kind === 'namespace' && s.qualified && !seen.has(s.qualified)) {
      seen.add(s.qualified);
      out.push({ name: s.qualified });
    }
  }
  return out;
}

function scopesToClasses(scopes: Scope[], path: string): ClassRecord[] {
  return scopes
    .filter((s) => (s.kind === 'class' || s.kind === 'struct') && s.name !== '(anonymous)')
    .map((s) => ({ name: s.name, file: path, line: s.line, kind: s.kind as 'class' | 'struct' }));
}

// ---------------------------------------------------------------------------
// Functions
// ---------------------------------------------------------------------------

interface FunctionDef {
  record: FunctionRecord;
  open: number; // index of body '{'
  close: number; // index of matching '}'
}

function findFunctions(clean: string, path: string, scopes: Scope[]): FunctionDef[] {
  const out: FunctionDef[] = [];
  const knownNamespaces = new Set(
    scopes.filter((s) => s.kind === 'namespace' && s.qualified).map((s) => s.qualified),
  );
  // Match a name immediately followed by a parenthesised parameter list, then
  // (after optional trailing specifiers) an opening brace — i.e. a definition.
  const re = /([A-Za-z_]\w*(?:\s*::\s*[A-Za-z_]\w*)*)\s*\(([^;{}()]*(?:\([^()]*\)[^;{}()]*)*)\)\s*(?:const\b|noexcept\b|override\b|final\b|->\s*[^;{]+|:\s*[^;{]+)*\s*\{/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const rawName = m[1].replace(/\s+/g, '');
    const simpleName = rawName.split('::').pop() as string;
    if (CONTROL_KEYWORDS.has(simpleName)) continue;
    const before = clean.slice(Math.max(0, m.index - 1), m.index);
    if (before === '.') continue;

    const nameOffset = m.index;
    const enclosing = innermostScope(scopes, nameOffset);

    let namespace: string | null;
    let className: string | null;
    if (rawName.includes('::')) {
      const qual = rawName.split('::').slice(0, -1);
      const full = qual.join('::');
      if (knownNamespaces.has(full)) {
        namespace = full;
        className = null;
      } else {
        className = qual[qual.length - 1] ?? null;
        const ns = qual.slice(0, -1).join('::');
        namespace = ns || null;
      }
    } else if (enclosing) {
      className = enclosing.kind === 'class' || enclosing.kind === 'struct' ? enclosing.name : null;
      namespace = enclosing.qualified || null;
    } else {
      namespace = null;
      className = null;
    }

    const open = re.lastIndex - 1;
    const close = matchBrace(clean, open);
    if (close < 0) continue;

    const params = m[2].replace(/\s+/g, ' ').trim();
    out.push({
      record: {
        name: simpleName,
        file: path,
        line: lineAt(clean, nameOffset),
        signature: `${simpleName}(${params})`,
        namespace: namespace || null,
        className: className || null,
        complexity: cyclomaticComplexity(clean.slice(open + 1, close)),
      },
      open,
      close,
    });
  }
  return out;
}

function innermostScope(scopes: Scope[], offset: number): Scope | null {
  let best: Scope | null = null;
  for (const s of scopes) {
    if (s.open <= offset && offset <= s.close) {
      if (!best || s.open > best.open) best = s;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// Calls
// ---------------------------------------------------------------------------

const CALL_EXCLUDE = new Set([
  ...CONTROL_KEYWORDS,
  'sizeof', 'alignof', 'static_cast', 'dynamic_cast', 'reinterpret_cast',
  'const_cast', 'typeid', 'new', 'delete', 'throw', 'operator',
]);

/**
 * Find call expressions and attribute each to the innermost function body that
 * contains it. Definitions' own signatures sit outside any body range, so they
 * are naturally excluded. Names are resolved to concrete callees later, so this
 * only needs to identify *which* names are being called.
 */
function findCalls(clean: string, defs: FunctionDef[]): RawCall[] {
  if (defs.length === 0) return [];
  const calls: RawCall[] = [];
  // identifier path (a::b, obj.m, ptr->m) directly followed by '('. A lookbehind
  // (rather than a consumed boundary char) avoids skipping calls that sit
  // immediately after another call's '(' — e.g. the inner call in `if (x())`.
  const re = /(?<![\w.>:])((?:[A-Za-z_]\w*\s*(?:::|\.|->)\s*)*[A-Za-z_]\w*)\s*\(/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const path = m[1];
    const callee = path.split(/::|\.|->/).map((s) => s.trim()).filter(Boolean).pop();
    if (!callee || CALL_EXCLUDE.has(callee)) continue;
    const offset = m.index;
    const owner = innermostFunction(defs, offset);
    if (owner < 0) continue; // call at file scope (e.g. static initialiser)
    calls.push({ fnIndex: owner, callee, line: lineAt(clean, offset) });
  }
  return calls;
}

function innermostFunction(defs: FunctionDef[], offset: number): number {
  let best = -1;
  let bestOpen = -1;
  for (let i = 0; i < defs.length; i++) {
    const d = defs[i];
    if (d.open < offset && offset < d.close && d.open > bestOpen) {
      best = i;
      bestOpen = d.open;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// Variables & references (data flow)
// ---------------------------------------------------------------------------

const VAR_TYPE_KEYWORDS = /^(static|const|volatile|extern|register|_Atomic|struct|union|enum|signed|unsigned|inline|constexpr|thread_local)$/;
const NOT_A_DECL = /^(return|else|do|case|default|goto|break|continue|using|typedef|namespace|class|struct|union|enum|template|public|private|protected|friend|operator)\b/;

/**
 * Extract file-scope (global) and static variable declarations — the shared
 * state that matters for embedded data-flow: registers, config, buffers, flags.
 * Local variables are intentionally skipped; cross-function flow is about
 * globals. Heuristic and conservative: ambiguous statements are dropped rather
 * than guessed, and this can miss or over-match on macro-heavy declarations.
 */
function findVariables(clean: string, defs: FunctionDef[]): RawVariable[] {
  const out: RawVariable[] = [];
  const seen = new Set<string>();
  // Walk top-level (brace depth 0) statements only, so we never pick up locals.
  let depth = 0;
  let stmtStart = 0;
  for (let i = 0; i < clean.length; i++) {
    const c = clean[i];
    if (c === '{') { if (depth === 0) { /* skip block body */ } depth++; }
    else if (c === '}') { depth = Math.max(0, depth - 1); stmtStart = i + 1; }
    else if (c === ';' && depth === 0) {
      const stmt = clean.slice(stmtStart, i);
      stmtStart = i + 1;
      const offset = stmtStart;
      if (innermostFunction(defs, stmtStart - 1) >= 0) continue; // inside a body
      const v = parseDeclaration(stmt);
      if (v && !seen.has(v.name)) {
        seen.add(v.name);
        out.push({ name: v.name, type: v.type, scope: v.isStatic ? 'static' : 'global', className: null, line: lineAt(clean, offset) });
      }
    } else if (c === '#' && (i === 0 || clean[i - 1] === '\n')) {
      // Skip preprocessor line.
      while (i < clean.length && clean[i] !== '\n') i++;
      stmtStart = i + 1;
    }
  }
  return out;
}

function parseDeclaration(stmt: string): { name: string; type: string; isStatic: boolean } | null {
  const s = stmt.trim();
  if (!s || NOT_A_DECL.test(s)) return null;
  if (s.includes('(') || s.includes(')')) return null; // function decl / call / init with ctor
  if (s.includes('=') === false && !/[A-Za-z_]\w*\s*\[?/.test(s)) return null;
  // Take the part before '=' (initialiser) and the first declared name.
  const head = s.split('=')[0].trim();
  const tokens = head.split(/\s+/).filter(Boolean);
  if (tokens.length < 2) return null; // need at least a type and a name
  const isStatic = tokens.includes('static') || tokens.includes('extern');
  // The declared name is the last identifier, stripped of pointer/array bits.
  let last = tokens[tokens.length - 1].replace(/[*&]/g, '');
  const arr = last.indexOf('[');
  if (arr >= 0) last = last.slice(0, arr);
  if (!/^[A-Za-z_]\w*$/.test(last)) return null;
  if (VAR_TYPE_KEYWORDS.test(last)) return null; // looks like a bare type, no name
  const typeTokens = tokens.slice(0, -1).filter((t) => !VAR_TYPE_KEYWORDS.test(t) || t === 'struct');
  const type = (typeTokens.join(' ') || tokens.slice(0, -1).join(' ')).replace(/[*&]/g, '').trim();
  if (!type) return null;
  return { name: last, type, isStatic };
}

const REF_EXCLUDE = new Set([...CONTROL_KEYWORDS, 'sizeof', 'true', 'false', 'nullptr', 'this']);

/**
 * Find reads and writes of the given variable names inside function bodies.
 * A reference is classified as a *write* if it is the target of an assignment
 * (`x =`, `x +=`, …) or a `++`/`--`; otherwise a *read*. Address-of and
 * compound cases default to read (conservative).
 */
function findRefs(clean: string, defs: FunctionDef[], varNames: Set<string>): RawRef[] {
  if (defs.length === 0 || varNames.size === 0) return [];
  const refs: RawRef[] = [];
  const re = /(?<![\w.>:])([A-Za-z_]\w*)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const name = m[1];
    if (!varNames.has(name) || REF_EXCLUDE.has(name)) continue;
    const offset = m.index;
    const owner = innermostFunction(defs, offset);
    if (owner < 0) continue;
    const after = clean.slice(re.lastIndex, re.lastIndex + 3);
    const before = clean.slice(Math.max(0, offset - 2), offset);
    const kind = isWriteContext(after, before) ? 'write' : 'read';
    refs.push({ symbol: name, kind, line: lineAt(clean, offset), fnName: defs[owner].record.name });
  }
  return refs;
}

function isWriteContext(after: string, before: string): boolean {
  const a = after.replace(/^\s+/, '');
  // Assignment (but not ==, <=, >=, !=) or compound assignment.
  if (/^=[^=]/.test(a) || /^[-+*/%&|^]=/.test(a) || /^(<<=|>>=)/.test(a)) return true;
  // Post-increment/decrement.
  if (/^(\+\+|--)/.test(a)) return true;
  // Pre-increment/decrement.
  if (/(\+\+|--)\s*$/.test(before)) return true;
  return false;
}

// ---------------------------------------------------------------------------
// State machines (switch-on-state-variable)
// ---------------------------------------------------------------------------

/**
 * Detect state machines expressed as a `switch` on a state variable whose case
 * bodies assign new values back to that same variable. The self-assignment is
 * what separates a real FSM from an ordinary switch (e.g. a command dispatch).
 * Each `state = NEXT;` inside a `case CURRENT:` becomes a CURRENT -> NEXT edge.
 */
function findStateMachines(clean: string, defs: FunctionDef[]): RawStateMachine[] {
  const machines: RawStateMachine[] = [];
  const re = /\bswitch\s*\(([^)]*)\)\s*\{/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const scrutinee = lastIdentifier(m[1]);
    if (!scrutinee) continue;
    const open = re.lastIndex - 1;
    const close = matchBrace(clean, open);
    if (close < 0) continue;
    const body = clean.slice(open + 1, close);

    // Collect case/default label positions within the body.
    const labels: Array<{ pos: number; label: string }> = [];
    const labelRe = /\bcase\s+([A-Za-z_]\w*(?:::[A-Za-z_]\w*)?)\s*:|\bdefault\s*:/g;
    let lm: RegExpExecArray | null;
    while ((lm = labelRe.exec(body))) {
      labels.push({ pos: lm.index, label: lm[1] ? lm[1] : 'default' });
    }

    // Find assignments to the scrutinee variable inside the body.
    const assignRe = new RegExp(`(?<![\\w.])${escapeRegExp(scrutinee)}\\s*=\\s*([A-Za-z_]\\w*(?:::[A-Za-z_]\\w*)?)\\s*;`, 'g');
    const transitions: RawTransition[] = [];
    let am: RegExpExecArray | null;
    while ((am = assignRe.exec(body))) {
      // Reject == and >=/<=/!= (the char before '=' was the var, so this is '='
      // only when not followed by '='; the regex already required a single '=').
      const to = am[1];
      const from = enclosingLabel(labels, am.index);
      transitions.push({ from, to, line: lineAt(clean, open + 1 + am.index) });
    }

    if (transitions.length === 0) continue; // ordinary switch, not an FSM
    machines.push({
      varName: scrutinee,
      fnName: enclosingFnName(defs, m.index),
      line: lineAt(clean, m.index),
      transitions,
    });
  }
  return machines;
}

function lastIdentifier(expr: string): string | null {
  const ids = expr.match(/[A-Za-z_]\w*/g);
  if (!ids || ids.length === 0) return null;
  // Skip a trailing call like foo() — but expr rarely ends in a call; take last id.
  return ids[ids.length - 1];
}

function enclosingLabel(labels: Array<{ pos: number; label: string }>, pos: number): string {
  let best = '(entry)';
  for (const l of labels) {
    if (l.pos < pos) best = l.label;
    else break;
  }
  return best;
}

function enclosingFnName(defs: FunctionDef[], offset: number): string | null {
  const idx = innermostFunction(defs, offset);
  return idx >= 0 ? defs[idx].record.name : null;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ---------------------------------------------------------------------------
// Cyclomatic complexity
// ---------------------------------------------------------------------------

/**
 * Heuristic McCabe cyclomatic complexity over a (literal/comment-blanked)
 * function body: 1 + the number of decision points. Counts if / for / while /
 * case / catch and the short-circuit and ternary operators &&, ||, ?. `else`
 * and `default` are not counted (they add no independent path).
 */
function cyclomaticComplexity(body: string): number {
  let count = 1;
  const kw = body.match(/\b(if|for|while|case|catch)\b/g);
  if (kw) count += kw.length;
  const ops = body.match(/&&|\|\||\?/g);
  if (ops) count += ops.length;
  return count;
}

/**
 * Engine-independent complexity per function name, for the clang engine to
 * overlay onto its own function records (clang's AST has no easy complexity).
 * On overloads, the maximum complexity for a name wins.
 */
export function complexityByName(source: string): Map<string, number> {
  const clean = blankLiterals(blankComments(source));
  const scopes = findScopes(clean);
  const defs = findFunctions(clean, '', scopes);
  const map = new Map<string, number>();
  for (const d of defs) {
    const prev = map.get(d.record.name) ?? 0;
    if (d.record.complexity > prev) map.set(d.record.name, d.record.complexity);
  }
  return map;
}

// ---------------------------------------------------------------------------
// RTOS tasks & periodic delays
// ---------------------------------------------------------------------------

/**
 * Detect RTOS task creation. Parses the argument list of common task-spawn
 * APIs so the entry function, name, and priority can be pulled out. Operates on
 * comment-stripped-but-string-intact source so task name literals survive.
 */
function findRtosTasks(noComments: string): RawTask[] {
  const out: RawTask[] = [];
  const re = /\b(xTaskCreate|xTaskCreateStatic|osThreadNew|osThreadCreate|task_create|thread_create)\s*\(/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(noComments))) {
    const api = m[1];
    const openParen = re.lastIndex - 1;
    const args = splitArgs(readParen(noComments, openParen));
    if (args.length === 0) continue;
    let name: string | null = null;
    let entry = identArg(args[0]);
    let priority: string | null = null;
    let stack: string | null = null;
    if (api === 'xTaskCreate' || api === 'xTaskCreateStatic') {
      entry = identArg(args[0]);
      name = stringArg(args[1]);
      stack = args[2] ? args[2].trim() : null;
      priority = args[4] ? args[4].trim() : null;
    } else if (api === 'osThreadNew') {
      entry = identArg(args[0]);
    } else if (api === 'osThreadCreate') {
      entry = identArg(args[0]);
    } else {
      entry = identArg(args[0]);
      name = args[1] ? stringArg(args[1]) : null;
    }
    if (!entry) continue;
    out.push({ name, entry, priority, stack, api, line: lineAt(noComments, m.index) });
  }
  return out;
}

/** Detect periodic delays and attribute each to its enclosing function. */
function findDelays(clean: string, defs: FunctionDef[]): RawDelay[] {
  const out: RawDelay[] = [];
  const re = /\b(vTaskDelayUntil|vTaskDelay|osDelayUntil|osDelay|HAL_Delay|delay_ms|sleep_ms)\s*\(/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const owner = innermostFunction(defs, m.index);
    if (owner < 0) continue;
    const args = splitArgs(readParen(clean, re.lastIndex - 1));
    // For *DelayUntil the period is the 2nd arg; otherwise the 1st.
    const periodArg = /Until$/.test(m[1]) ? (args[1] ?? args[0]) : args[0];
    const period = (periodArg ?? '').trim();
    if (!period) continue;
    out.push({ fnName: defs[owner].record.name, period, line: lineAt(clean, m.index) });
  }
  return out;
}

/** Read the contents between '(' at openParen and its matching ')'. */
function readParen(src: string, openParen: number): string {
  let depth = 0;
  for (let i = openParen; i < src.length; i++) {
    if (src[i] === '(') depth++;
    else if (src[i] === ')') { depth--; if (depth === 0) return src.slice(openParen + 1, i); }
  }
  return '';
}

/** Split an argument list on top-level commas (ignoring nested parens/brackets). */
function splitArgs(s: string): string[] {
  const args: string[] = [];
  let depth = 0; let start = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '(' || c === '[' || c === '{') depth++;
    else if (c === ')' || c === ']' || c === '}') depth--;
    else if (c === ',' && depth === 0) { args.push(s.slice(start, i)); start = i + 1; }
  }
  if (s.trim()) args.push(s.slice(start));
  return args;
}

function identArg(a: string | undefined): string {
  if (!a) return '';
  const ids = a.replace(/[&*()]/g, ' ').match(/[A-Za-z_]\w*/g);
  return ids ? ids[ids.length - 1] : '';
}

function stringArg(a: string | undefined): string | null {
  if (!a) return null;
  const m = a.match(/"([^"]*)"/);
  return m ? m[1] : null;
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

function lineAt(src: string, offset: number): number {
  let line = 1;
  for (let i = 0; i < offset && i < src.length; i++) {
    if (src[i] === '\n') line++;
  }
  return line;
}

/** Public helper: extract #include targets from raw source (used by the clang
 *  engine, whose AST does not carry preprocessor directives). */
export function scanIncludes(source: string): string[] {
  return findIncludes(blankComments(source));
}
