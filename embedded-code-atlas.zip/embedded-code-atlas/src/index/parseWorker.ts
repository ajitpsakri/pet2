import { parentPort } from 'worker_threads';
import * as fs from 'fs';
import * as crypto from 'crypto';
import { parseSource } from './heuristicParser';
import { ParseRequest, ParseResponse } from './types';

/**
 * Worker-thread body. Each message is a single ParseRequest; the worker reads
 * the file, hashes its contents, runs the heuristic parser, and posts back a
 * ParseResponse. Keeping workers stateless and one-request-at-a-time makes the
 * pool's scheduling trivial and failures isolated to a single file.
 */

if (!parentPort) {
  throw new Error('parseWorker must be run as a worker thread.');
}

parentPort.on('message', (req: ParseRequest) => {
  const res = handle(req);
  parentPort!.postMessage(res);
});

function handle(req: ParseRequest): ParseResponse {
  try {
    const stat = fs.statSync(req.path);
    if (stat.size > req.maxBytes) {
      return { ok: false, path: req.path, error: `skipped: ${stat.size} bytes exceeds limit` };
    }
    const buf = fs.readFileSync(req.path);
    const hash = crypto.createHash('sha1').update(buf).digest('hex');
    const text = buf.toString('utf8');
    const parsed = parseSource(req.path, text, req.language, hash, stat.size, stat.mtimeMs);
    return { ok: true, parsed };
  } catch (err) {
    return { ok: false, path: req.path, error: err instanceof Error ? err.message : String(err) };
  }
}
