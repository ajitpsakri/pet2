/** Bump when the schema changes incompatibly; triggers a full rebuild. */
export const SCHEMA_VERSION = 6;

/**
 * Schema for the workspace index. Phase 3 adds `calls` and `refs` tables; the
 * file/function/class/namespace tables defined here are stable. Foreign keys
 * cascade on file delete so incremental updates only touch one file's rows.
 */
export const SCHEMA_SQL = `
PRAGMA journal_mode = MEMORY;
PRAGMA synchronous = OFF;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS files (
  id       INTEGER PRIMARY KEY,
  path     TEXT UNIQUE NOT NULL,
  size     INTEGER NOT NULL,
  language TEXT NOT NULL,
  hash     TEXT NOT NULL,
  mtime    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS includes (
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  target  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_includes_file ON includes(file_id);
CREATE INDEX IF NOT EXISTS idx_includes_target ON includes(target);

CREATE TABLE IF NOT EXISTS functions (
  id        INTEGER PRIMARY KEY,
  file_id   INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name      TEXT NOT NULL,
  line      INTEGER NOT NULL,
  signature TEXT NOT NULL,
  namespace TEXT,
  class     TEXT,
  complexity INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_functions_name ON functions(name);
CREATE INDEX IF NOT EXISTS idx_functions_file ON functions(file_id);

CREATE TABLE IF NOT EXISTS classes (
  id      INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name    TEXT NOT NULL,
  line    INTEGER NOT NULL,
  kind    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_classes_name ON classes(name);

CREATE TABLE IF NOT EXISTS namespaces (
  name TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS state_machines (
  id          INTEGER PRIMARY KEY,
  file_id     INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  function_id INTEGER,
  var_name    TEXT NOT NULL,
  fn_name     TEXT,
  line        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sm_file ON state_machines(file_id);

CREATE TABLE IF NOT EXISTS state_transitions (
  id         INTEGER PRIMARY KEY,
  machine_id INTEGER NOT NULL REFERENCES state_machines(id) ON DELETE CASCADE,
  file_id    INTEGER NOT NULL,
  from_state TEXT NOT NULL,
  to_state   TEXT NOT NULL,
  line       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_st_machine ON state_transitions(machine_id);
CREATE INDEX IF NOT EXISTS idx_st_file ON state_transitions(file_id);

CREATE TABLE IF NOT EXISTS rtos_tasks (
  id         INTEGER PRIMARY KEY,
  file_id    INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name       TEXT,
  entry      TEXT NOT NULL,
  priority   TEXT,
  stack      TEXT,
  api        TEXT NOT NULL,
  line       INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_file ON rtos_tasks(file_id);

CREATE TABLE IF NOT EXISTS rtos_delays (
  id      INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  fn_name TEXT NOT NULL,
  period  TEXT NOT NULL,
  line    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_delays_fn ON rtos_delays(fn_name);

CREATE TABLE IF NOT EXISTS calls (
  id          INTEGER PRIMARY KEY,
  file_id     INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  caller_id   INTEGER NOT NULL REFERENCES functions(id) ON DELETE CASCADE,
  callee_name TEXT NOT NULL,
  callee_id   INTEGER,
  line        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_calls_caller ON calls(caller_id);
CREATE INDEX IF NOT EXISTS idx_calls_callee ON calls(callee_id);
CREATE INDEX IF NOT EXISTS idx_calls_callee_name ON calls(callee_name);

-- Scaffolded for Phase 8 (variable flow). Populated there, not in Phase 3.
CREATE TABLE IF NOT EXISTS variables (
  id      INTEGER PRIMARY KEY,
  file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name    TEXT NOT NULL,
  type    TEXT,
  scope   TEXT NOT NULL,
  class   TEXT,
  line    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_variables_name ON variables(name);
CREATE INDEX IF NOT EXISTS idx_variables_file ON variables(file_id);

CREATE TABLE IF NOT EXISTS refs (
  id          INTEGER PRIMARY KEY,
  file_id     INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  function_id INTEGER,
  var_id      INTEGER,
  symbol      TEXT NOT NULL,
  kind        TEXT NOT NULL,
  line        INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_refs_var ON refs(var_id);
CREATE INDEX IF NOT EXISTS idx_refs_function ON refs(function_id);
CREATE INDEX IF NOT EXISTS idx_refs_symbol ON refs(symbol);
CREATE INDEX IF NOT EXISTS idx_refs_symbol ON refs(symbol);
`;
