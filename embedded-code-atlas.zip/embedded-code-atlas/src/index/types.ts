/** Source language classification for an indexed file. */
export type Language = 'c' | 'cpp' | 'c-header' | 'cpp-header' | 'unknown';

/** How the workspace appears to be built — informs Phase 3 flag discovery. */
export type ProjectKind = 'cmake' | 'make' | 'compile-commands' | 'generic';

export interface FileRecord {
  path: string;
  size: number;
  language: Language;
  /** Content hash; used to skip unchanged files on rescan. */
  hash: string;
  /** Last-modified time in ms; cheap pre-filter before hashing. */
  mtime: number;
  /** Resolved-or-raw include targets discovered in the file. */
  includes: string[];
}

export interface FunctionRecord {
  name: string;
  file: string;
  line: number;
  signature: string;
  /** Enclosing namespace path, e.g. "ns::inner", or null at global scope. */
  namespace: string | null;
  /** Enclosing class/struct name, or null for free functions. */
  className: string | null;
  /** McCabe cyclomatic complexity (heuristic: 1 + decision points). */
  complexity: number;
}

export interface ClassRecord {
  name: string;
  file: string;
  line: number;
  kind: 'class' | 'struct';
}

export interface NamespaceRecord {
  name: string;
}

/**
 * A call site found inside a function body. `fnIndex` points into the owning
 * ParsedFile.functions array so the database can attach the edge to the correct
 * caller row after insertion. `callee` is a name; resolution to a concrete
 * callee row happens later (unique-name match), identically for both engines.
 */
export interface RawCall {
  fnIndex: number;
  callee: string;
  line: number;
}

/** A file-scope or static variable declaration (the "shared state" we track). */
export interface RawVariable {
  name: string;
  type: string;
  scope: 'global' | 'static';
  className: string | null;
  line: number;
}

/** A read or write of a tracked variable, attributed to its enclosing function. */
export interface RawRef {
  symbol: string;
  kind: 'read' | 'write';
  line: number;
  /** Enclosing function name, resolved to an id at insert time. */
  fnName: string | null;
}

export interface RawTransition {
  from: string;
  to: string;
  line: number;
}

/** A detected switch-on-state-variable state machine. */
export interface RawStateMachine {
  varName: string;
  fnName: string | null;
  line: number;
  transitions: RawTransition[];
}

/** A detected RTOS task creation (xTaskCreate / osThreadNew / …). */
export interface RawTask {
  name: string | null;
  entry: string;
  priority: string | null;
  stack: string | null;
  api: string;
  line: number;
}

/** A periodic delay call, attributed to its enclosing function by name. */
export interface RawDelay {
  fnName: string;
  period: string;
  line: number;
}

/** Everything the parser extracts from one translation unit / header. */
export interface ParsedFile {
  file: FileRecord;
  functions: FunctionRecord[];
  classes: ClassRecord[];
  namespaces: NamespaceRecord[];
  calls: RawCall[];
  variables: RawVariable[];
  refs: RawRef[];
  stateMachines: RawStateMachine[];
  tasks: RawTask[];
  delays: RawDelay[];
}

export interface IndexStats {
  files: number;
  functions: number;
  classes: number;
  calls: number;
  variables: number;
  lastBuilt: string | null;
}

/** Work item sent to a parse worker. */
export interface ParseRequest {
  path: string;
  language: Language;
  maxBytes: number;
}

/** Result returned from a parse worker (or an error for that file). */
export type ParseResponse =
  | { ok: true; parsed: ParsedFile }
  | { ok: false; path: string; error: string };

export function classifyLanguage(path: string): Language {
  const lower = path.toLowerCase();
  if (/\.(cpp|cc|cxx|c\+\+)$/.test(lower)) return 'cpp';
  if (/\.(hpp|hh|hxx|h\+\+)$/.test(lower)) return 'cpp-header';
  if (/\.c$/.test(lower)) return 'c';
  if (/\.h$/.test(lower)) return 'c-header';
  return 'unknown';
}
