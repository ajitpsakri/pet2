import * as vscode from 'vscode';

export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error';

const LEVEL_ORDER: Record<LogLevel, number> = {
  trace: 10,
  debug: 20,
  info: 30,
  warn: 40,
  error: 50,
};

/**
 * Thin wrapper around a VS Code OutputChannel that gates messages by a
 * configurable level. A single instance is created on activation and passed
 * to every subsystem (commands, panel, workspace watcher, and — later — the
 * indexer and analysis passes).
 */
export class Logger implements vscode.Disposable {
  private readonly channel: vscode.OutputChannel;
  private threshold: number;

  constructor(name = 'Embedded Code Atlas', level: LogLevel = 'info') {
    this.channel = vscode.window.createOutputChannel(name);
    this.threshold = LEVEL_ORDER[level];
  }

  setLevel(level: LogLevel): void {
    this.threshold = LEVEL_ORDER[level];
    this.info(`Log level set to "${level}".`);
  }

  trace(message: string, ...args: unknown[]): void {
    this.write('trace', message, args);
  }

  debug(message: string, ...args: unknown[]): void {
    this.write('debug', message, args);
  }

  info(message: string, ...args: unknown[]): void {
    this.write('info', message, args);
  }

  warn(message: string, ...args: unknown[]): void {
    this.write('warn', message, args);
  }

  error(message: string, error?: unknown, ...args: unknown[]): void {
    const extra = error instanceof Error ? `\n${error.stack ?? error.message}` : error ? ` ${this.stringify(error)}` : '';
    this.write('error', message + extra, args);
  }

  /** Reveal the output channel in the panel. */
  show(): void {
    this.channel.show(true);
  }

  private write(level: LogLevel, message: string, args: unknown[]): void {
    if (LEVEL_ORDER[level] < this.threshold) {
      return;
    }
    const ts = new Date().toISOString().substring(11, 23);
    const tail = args.length ? ' ' + args.map((a) => this.stringify(a)).join(' ') : '';
    this.channel.appendLine(`[${ts}] [${level.toUpperCase()}] ${message}${tail}`);
  }

  private stringify(value: unknown): string {
    if (typeof value === 'string') {
      return value;
    }
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }

  dispose(): void {
    this.channel.dispose();
  }
}
