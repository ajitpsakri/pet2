import * as vscode from 'vscode';
import { Logger } from '../logger';
import { Config } from '../config';
import { Indexer } from '../index/Indexer';
import { IndexStats } from '../index/types';
import { AtlasView, HostToWebview, WebviewToHost, isWebviewMessage } from './protocol';

const VIEW_TYPE = 'embeddedCodeAtlas.panel';

/**
 * Owns the single Atlas webview panel. Responsibilities:
 *  - create / reveal / revive the panel (only one exists at a time)
 *  - build hardened HTML (strict CSP, per-load nonce, no inline script)
 *  - route messages between the host and the webview in a typed way
 *
 * Graph rendering itself lives in the webview (media/main.js); this class is
 * the host-side broker that later phases feed real index data through.
 */
export class AtlasPanel {
  private static instance: AtlasPanel | undefined;

  static createOrShow(context: vscode.ExtensionContext, logger: Logger, config: Config, indexer: Indexer, view: AtlasView = 'home'): AtlasPanel {
    const column = vscode.window.activeTextEditor?.viewColumn ?? vscode.ViewColumn.One;

    if (AtlasPanel.instance) {
      AtlasPanel.instance.panel.reveal(column);
      AtlasPanel.instance.navigate(view);
      return AtlasPanel.instance;
    }

    const panel = vscode.window.createWebviewPanel(VIEW_TYPE, 'Embedded Atlas', column, {
      enableScripts: true,
      retainContextWhenHidden: true,
      localResourceRoots: [vscode.Uri.joinPath(context.extensionUri, 'media')],
    });

    AtlasPanel.instance = new AtlasPanel(panel, context, logger, config, indexer, view);
    return AtlasPanel.instance;
  }

  /** Restore the panel after a window reload (registered as a serializer). */
  static revive(panel: vscode.WebviewPanel, context: vscode.ExtensionContext, logger: Logger, config: Config, indexer: Indexer): void {
    AtlasPanel.instance = new AtlasPanel(panel, context, logger, config, indexer, 'home');
  }

  static current(): AtlasPanel | undefined {
    return AtlasPanel.instance;
  }

  private readonly disposables: vscode.Disposable[] = [];
  private pendingView: AtlasView;

  private constructor(
    private readonly panel: vscode.WebviewPanel,
    private readonly context: vscode.ExtensionContext,
    private readonly logger: Logger,
    private readonly config: Config,
    private readonly indexer: Indexer,
    initialView: AtlasView,
  ) {
    this.pendingView = initialView;
    this.panel.webview.html = this.buildHtml(this.panel.webview);

    this.panel.onDidDispose(() => this.dispose(), null, this.disposables);

    this.panel.webview.onDidReceiveMessage(
      (raw: unknown) => this.handleMessage(raw),
      null,
      this.disposables,
    );

    // Push live index stats to the webview while the panel is open.
    this.disposables.push(this.indexer.onDidUpdateStats((s) => this.postStats(s)));

    logger.debug(`Atlas panel created (initial view: ${initialView}).`);
  }

  private postStats(s: IndexStats): void {
    this.post({ type: 'indexStats', files: s.files, functions: s.functions, calls: s.calls, variables: s.variables, lastBuilt: s.lastBuilt });
  }

  /** Switch the webview to a given view, queuing if it has not signalled ready. */
  navigate(view: AtlasView): void {
    this.pendingView = view;
    this.post({ type: 'navigate', view });
  }

  post(message: HostToWebview): void {
    void this.panel.webview.postMessage(message);
  }

  private handleMessage(raw: unknown): void {
    if (!isWebviewMessage(raw)) {
      this.logger.warn('Discarded malformed webview message.');
      return;
    }
    const msg = raw as WebviewToHost;
    switch (msg.type) {
      case 'ready': {
        const cfg = this.config.current();
        this.post({
          type: 'init',
          view: this.pendingView,
          workspaceName: vscode.workspace.name ?? null,
          engine: cfg.engine,
        });
        this.postStats(this.indexer.getStats());
        break;
      }
      case 'navigate':
        this.pendingView = msg.view;
        break;
      case 'command':
        void vscode.commands.executeCommand(msg.command);
        break;
      case 'openFile':
        this.openFile(msg.path, msg.line);
        break;
      case 'requestGraph': {
        const cfg = this.config.current();
        const depth = Math.max(1, Math.min(3, msg.depth ?? 1));
        try {
          const payload = this.indexer.buildGraph({ kind: msg.kind, seed: msg.seed, depth, maxNodes: cfg.graphMaxNodes, direction: msg.direction });
          this.post({ type: 'graph', payload });
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          this.logger.error('Graph build failed.', err);
          this.post({ type: 'graphError', kind: msg.kind, message });
        }
        break;
      }
      case 'requestDependencyReport': {
        try {
          this.post({ type: 'dependencyReport', report: this.indexer.dependencyReport() });
        } catch (err) {
          this.logger.error('Dependency analysis failed.', err);
          this.post({ type: 'graphError', kind: 'file-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestCallReport': {
        try {
          this.post({ type: 'callReport', report: this.indexer.callReport() });
        } catch (err) {
          this.logger.error('Call analysis failed.', err);
          this.post({ type: 'graphError', kind: 'function-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestCallPath': {
        try {
          this.post({ type: 'graph', payload: this.indexer.traceCallPath(msg.fromNodeId, msg.query) });
        } catch (err) {
          this.logger.error('Call path trace failed.', err);
          this.post({ type: 'graphError', kind: 'function-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestModuleReport': {
        try {
          this.post({ type: 'moduleReport', report: this.indexer.moduleReport(msg.depth ?? 1) });
        } catch (err) {
          this.logger.error('Module analysis failed.', err);
          this.post({ type: 'graphError', kind: 'module-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestDataFlowReport': {
        try {
          this.post({ type: 'dataFlowReport', report: this.indexer.dataFlowReport() });
        } catch (err) {
          this.logger.error('Data-flow analysis failed.', err);
          this.post({ type: 'graphError', kind: 'data-flow-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestStateMachineReport': {
        try {
          this.post({ type: 'stateMachineReport', report: this.indexer.stateMachineReport() });
        } catch (err) {
          this.logger.error('State machine analysis failed.', err);
          this.post({ type: 'graphError', kind: 'state-machine-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestSchedulerReport': {
        try {
          this.post({ type: 'schedulerReport', report: this.indexer.schedulerReport() });
        } catch (err) {
          this.logger.error('Scheduler analysis failed.', err);
          this.post({ type: 'graphError', kind: 'scheduler-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestArchitectureReport': {
        try {
          this.post({ type: 'architectureReport', report: this.indexer.architectureReport() });
        } catch (err) {
          this.logger.error('Architecture analysis failed.', err);
          this.post({ type: 'graphError', kind: 'architecture-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestComplexityReport': {
        try {
          this.post({ type: 'complexityReport', report: this.indexer.complexityReport() });
        } catch (err) {
          this.logger.error('Complexity analysis failed.', err);
          this.post({ type: 'graphError', kind: 'complexity-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestDashboardReport': {
        // Run staged with an event-loop yield between stages so progress
        // messages actually reach the webview while the analyses compute, and
        // report failure instead of leaving the spinner up forever.
        void (async () => {
          try {
            const report = await this.indexer.dashboardReportAsync((label, done, total) =>
              this.post({ type: 'analysisProgress', label, done, total }));
            this.post({ type: 'dashboardReport', report });
          } catch (err) {
            this.logger.error('Dashboard analysis failed.', err);
            this.post({ type: 'dashboardError', message: err instanceof Error ? err.message : String(err) });
          }
        })();
        break;
      }
      case 'requestExplanation': {
        try {
          this.post({ type: 'explanation', explanation: this.indexer.explain(msg.target) });
        } catch (err) {
          this.logger.error('Explanation failed.', err);
        }
        break;
      }
      case 'requestAutosarReport': {
        try {
          this.post({ type: 'autosarReport', report: this.indexer.autosarReport() });
        } catch (err) {
          this.logger.error('AUTOSAR analysis failed.', err);
          this.post({ type: 'graphError', kind: 'autosar-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestModuleFiles': {
        try {
          this.post({ type: 'graph', payload: this.indexer.buildModuleFiles(msg.moduleNodeId, msg.depth ?? 1) });
        } catch (err) {
          this.logger.error('Module drill-down failed.', err);
          this.post({ type: 'graphError', kind: 'file-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'requestSubgraph': {
        try {
          this.post({ type: 'graph', payload: this.indexer.buildSubgraph(msg.nodeIds) });
        } catch (err) {
          this.logger.error('Subgraph build failed.', err);
          this.post({ type: 'graphError', kind: 'file-graph', message: err instanceof Error ? err.message : String(err) });
        }
        break;
      }
      case 'log':
        this.logger[msg.level](`[webview] ${msg.message}`);
        break;
      default:
        this.logger.warn(`Unhandled webview message type: ${(msg as { type: string }).type}`);
    }
  }

  private async openFile(path: string, line?: number): Promise<void> {
    try {
      const doc = await vscode.workspace.openTextDocument(vscode.Uri.file(path));
      const editor = await vscode.window.showTextDocument(doc);
      if (typeof line === 'number') {
        const pos = new vscode.Position(Math.max(0, line - 1), 0);
        editor.selection = new vscode.Selection(pos, pos);
        editor.revealRange(new vscode.Range(pos, pos), vscode.TextEditorRevealType.InCenter);
      }
    } catch (err) {
      this.logger.error(`Failed to open file: ${path}`, err);
      void vscode.window.showErrorMessage(`Embedded Atlas could not open ${path}.`);
    }
  }

  private buildHtml(webview: vscode.Webview): string {
    const nonce = makeNonce();
    const mediaUri = (file: string) =>
      webview.asWebviewUri(vscode.Uri.joinPath(this.context.extensionUri, 'media', file));

    const csp = [
      `default-src 'none'`,
      `img-src ${webview.cspSource} data:`,
      `style-src ${webview.cspSource}`,
      `script-src 'nonce-${nonce}'`,
      `font-src ${webview.cspSource}`,
    ].join('; ');

    return /* html */ `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="${csp}" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="${mediaUri('main.css')}" rel="stylesheet" />
  <title>Embedded Atlas</title>
</head>
<body>
  <div id="app" aria-busy="false"></div>
  <script nonce="${nonce}" src="${mediaUri('vendor/cytoscape.min.js')}"></script>
  <script nonce="${nonce}" src="${mediaUri('main.js')}"></script>
</body>
</html>`;
  }

  dispose(): void {
    AtlasPanel.instance = undefined;
    this.panel.dispose();
    while (this.disposables.length) {
      this.disposables.pop()?.dispose();
    }
    this.logger.debug('Atlas panel disposed.');
  }
}

function makeNonce(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let text = '';
  for (let i = 0; i < 32; i++) {
    text += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return text;
}
