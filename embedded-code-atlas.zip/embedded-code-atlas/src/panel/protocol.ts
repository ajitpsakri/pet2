/**
 * Message protocol between the extension host and the Atlas webview.
 *
 * The webview is untrusted and sandboxed, so every message crossing the
 * boundary is explicitly typed and validated. Keeping the contract in one
 * place lets both sides evolve in lockstep as later phases add real graph
 * payloads.
 */

import type { GraphPayload, GraphKind, DependencyReport, CallReport, ModuleReport, DataFlowReport, StateMachineReport, SchedulerReport, ArchitectureReport, ComplexityReport, DashboardReport, Explanation, AutosarReport } from '../graph/types';

export type AtlasView = 'home' | 'dashboard' | 'file-graph' | 'function-graph' | 'module-graph' | 'data-flow-graph' | 'state-machine-graph' | 'scheduler-graph' | 'architecture-graph' | 'complexity-graph' | 'autosar-graph';

/** Messages sent FROM the extension host TO the webview. */
export type HostToWebview =
  | { type: 'init'; view: AtlasView; workspaceName: string | null; engine: string }
  | { type: 'navigate'; view: AtlasView }
  | { type: 'status'; text: string; busy: boolean }
  | { type: 'indexStats'; files: number; functions: number; calls: number; variables: number; lastBuilt: string | null }
  | { type: 'config'; engine: string; graphMaxNodes: number }
  | { type: 'graph'; payload: GraphPayload }
  | { type: 'graphError'; kind: GraphKind; message: string }
  | { type: 'dependencyReport'; report: DependencyReport }
  | { type: 'callReport'; report: CallReport }
  | { type: 'moduleReport'; report: ModuleReport }
  | { type: 'dataFlowReport'; report: DataFlowReport }
  | { type: 'stateMachineReport'; report: StateMachineReport }
  | { type: 'schedulerReport'; report: SchedulerReport }
  | { type: 'architectureReport'; report: ArchitectureReport }
  | { type: 'complexityReport'; report: ComplexityReport }
  | { type: 'dashboardReport'; report: DashboardReport }
  | { type: 'explanation'; explanation: Explanation }
  | { type: 'autosarReport'; report: AutosarReport };

/** Messages sent FROM the webview TO the extension host. */
export type WebviewToHost =
  | { type: 'ready' }
  | { type: 'navigate'; view: AtlasView }
  | { type: 'command'; command: string }
  | { type: 'openFile'; path: string; line?: number }
  | { type: 'requestGraph'; kind: GraphKind; seed?: string; depth?: number; direction?: 'both' | 'callees' | 'callers' }
  | { type: 'requestDependencyReport' }
  | { type: 'requestCallReport' }
  | { type: 'requestCallPath'; fromNodeId: string; query: string }
  | { type: 'requestModuleReport'; depth?: number }
  | { type: 'requestDataFlowReport' }
  | { type: 'requestStateMachineReport' }
  | { type: 'requestSchedulerReport' }
  | { type: 'requestArchitectureReport' }
  | { type: 'requestComplexityReport' }
  | { type: 'requestDashboardReport' }
  | { type: 'requestExplanation'; target: string }
  | { type: 'requestAutosarReport' }
  | { type: 'requestModuleFiles'; moduleNodeId: string; depth?: number }
  | { type: 'requestSubgraph'; nodeIds: string[] }
  | { type: 'log'; level: 'debug' | 'info' | 'warn' | 'error'; message: string };

export function isWebviewMessage(value: unknown): value is WebviewToHost {
  return typeof value === 'object' && value !== null && typeof (value as { type?: unknown }).type === 'string';
}
