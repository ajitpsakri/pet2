import * as vscode from 'vscode';
import { Logger } from '../logger';
import { Config } from '../config';

export interface WorkspaceChange {
  created: vscode.Uri[];
  changed: vscode.Uri[];
  deleted: vscode.Uri[];
}

/**
 * Watches the workspace for changes to indexable source files and emits a
 * debounced, batched change set. Phase 2's indexer subscribes to this to do
 * incremental updates instead of full rescans; for now we batch, log, and
 * track a dirty set so the wiring is exercised end to end.
 */
export class WorkspaceWatcher implements vscode.Disposable {
  private readonly emitter = new vscode.EventEmitter<WorkspaceChange>();
  readonly onDidChange = this.emitter.event;

  private watchers: vscode.FileSystemWatcher[] = [];
  private readonly created = new Set<string>();
  private readonly changed = new Set<string>();
  private readonly deleted = new Set<string>();
  private flushTimer: NodeJS.Timeout | undefined;
  private configSub: vscode.Disposable;

  constructor(
    private readonly logger: Logger,
    private readonly config: Config,
    private readonly debounceMs = 400,
  ) {
    this.rebuildWatchers();
    this.configSub = config.onDidChange(() => this.rebuildWatchers());
  }

  private rebuildWatchers(): void {
    this.disposeWatchers();
    const patterns = this.config.current().include;
    for (const pattern of patterns) {
      const watcher = vscode.workspace.createFileSystemWatcher(pattern);
      watcher.onDidCreate((uri) => this.record('create', uri));
      watcher.onDidChange((uri) => this.record('change', uri));
      watcher.onDidDelete((uri) => this.record('delete', uri));
      this.watchers.push(watcher);
    }
    this.logger.debug(`Watching ${patterns.length} include pattern(s).`);
  }

  private record(kind: 'create' | 'change' | 'delete', uri: vscode.Uri): void {
    const key = uri.fsPath;
    // Latest event for a path wins.
    this.created.delete(key);
    this.changed.delete(key);
    this.deleted.delete(key);
    if (kind === 'create') {
      this.created.add(key);
    } else if (kind === 'change') {
      this.changed.add(key);
    } else {
      this.deleted.add(key);
    }
    this.scheduleFlush();
  }

  private scheduleFlush(): void {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
    }
    this.flushTimer = setTimeout(() => this.flush(), this.debounceMs);
  }

  private flush(): void {
    this.flushTimer = undefined;
    if (!this.created.size && !this.changed.size && !this.deleted.size) {
      return;
    }
    const change: WorkspaceChange = {
      created: [...this.created].map((p) => vscode.Uri.file(p)),
      changed: [...this.changed].map((p) => vscode.Uri.file(p)),
      deleted: [...this.deleted].map((p) => vscode.Uri.file(p)),
    };
    this.created.clear();
    this.changed.clear();
    this.deleted.clear();
    this.logger.info(
      `Workspace change: +${change.created.length} ~${change.changed.length} -${change.deleted.length}. Index marked dirty.`,
    );
    this.emitter.fire(change);
  }

  private disposeWatchers(): void {
    for (const w of this.watchers) {
      w.dispose();
    }
    this.watchers = [];
  }

  dispose(): void {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
    }
    this.disposeWatchers();
    this.configSub.dispose();
    this.emitter.dispose();
  }
}
